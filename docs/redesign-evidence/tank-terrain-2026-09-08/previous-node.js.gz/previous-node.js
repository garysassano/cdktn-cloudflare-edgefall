// src/game/core/canonical.ts
function canonical(value) {
  const ancestors = /* @__PURE__ */ new Set();
  let nodes = 0;
  function encode(item, depth) {
    if (++nodes > 1e5 || depth > 64) throw new RangeError("Canonical state exceeds bounds");
    if (item === null || typeof item === "boolean" || typeof item === "string")
      return JSON.stringify(item);
    if (typeof item === "number" && Number.isSafeInteger(item))
      return String(item === 0 ? 0 : item);
    if (typeof item !== "object" || item === null)
      throw new TypeError("Noncanonical authoritative value");
    if (ancestors.has(item)) throw new TypeError("Cyclic authoritative state");
    ancestors.add(item);
    let result;
    if (Array.isArray(item)) {
      const parts = [];
      for (let index = 0; index < item.length; index++) {
        if (!Object.hasOwn(item, index)) throw new TypeError("Sparse authoritative array");
        parts.push(encode(item[index], depth + 1));
      }
      result = `[${parts.join(",")}]`;
    } else {
      if (Object.getPrototypeOf(item) !== Object.prototype && Object.getPrototypeOf(item) !== null) {
        throw new TypeError("Authoritative records must be plain objects");
      }
      if (Object.getOwnPropertySymbols(item).length)
        throw new TypeError("Symbol state keys are unsupported");
      const record = item;
      result = `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${encode(record[key], depth + 1)}`).join(",")}}`;
    }
    ancestors.delete(item);
    return result;
  }
  return encode(value, 0);
}
function stateHash(value) {
  const text = canonical(value);
  let hash = 2166136261;
  for (let index = 0; index < text.length; index++)
    hash = Math.imul(hash ^ text.charCodeAt(index), 16777619);
  return (hash >>> 0).toString(16).padStart(8, "0");
}

// src/game/core/numeric.ts
var SUBPIXELS = 256;
var MAX_POSITION = 2 ** 24;
var MAX_SHAPE = 2 ** 16;
var MAX_MOTION = 2 ** 16;
var COUNTER_LIMIT = 4294963200;
function integer(value, minimum, maximum, label) {
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
    throw new RangeError(`${label} must be an integer in [${minimum}, ${maximum}]`);
  }
  return value;
}
function position(value) {
  return integer(value, -MAX_POSITION, MAX_POSITION, "position");
}
function motion(value) {
  return integer(value, -MAX_MOTION, MAX_MOTION, "motion");
}
function pixels(value) {
  return position(
    integer(value, -MAX_POSITION / SUBPIXELS, MAX_POSITION / SUBPIXELS, "pixels") * SUBPIXELS
  );
}
function divide(numerator, denominator) {
  integer(numerator, -Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER, "numerator");
  integer(denominator, 1, Number.MAX_SAFE_INTEGER, "denominator");
  const quotient = Math.trunc(numerator / denominator) || 0;
  return { quotient, remainder: numerator - quotient * denominator };
}
function compareContactTime(an, ad, bn, bd) {
  for (const n of [an, bn]) integer(n, -(2 ** 26), 2 ** 26, "contact numerator");
  for (const d of [ad, bd]) integer(d, 1, 2 ** 17, "contact denominator");
  const left = an * bd;
  const right = bn * ad;
  return left < right ? -1 : left > right ? 1 : 0;
}
function nextCounter(current) {
  integer(current, 0, COUNTER_LIMIT - 2, "counter requiring session rotation");
  return current + 1;
}

// src/game/input/types.ts
var Held = {
  Left: 1 << 0,
  Right: 1 << 1,
  Up: 1 << 2,
  Down: 1 << 3,
  Fire: 1 << 4,
  VehicleSpecial: 1 << 5
};
var HELD_MASK = 63;
function directionalIntent(held, facing2, grounded) {
  const horizontal = Number(Boolean(held & Held.Right)) - Number(Boolean(held & Held.Left));
  const vertical = Number(Boolean(held & Held.Down)) - Number(Boolean(held & Held.Up));
  const nextFacing = horizontal === 0 ? facing2 : horizontal < 0 ? -1 : 1;
  return {
    horizontal,
    vertical,
    facing: nextFacing,
    crouch: grounded && vertical > 0,
    aim: vertical < 0 ? 1 : vertical > 0 && !grounded ? 2 : 0
  };
}

// src/game/physics/sweep.ts
var ZERO = { x: 0, y: 0 };
var START = { numerator: 0, denominator: 1 };
var END = { numerator: 1, denominator: 1 };
function compare(a, b) {
  return compareContactTime(a.numerator, a.denominator, b.numerator, b.denominator);
}
function validate(rect, delta, segment) {
  position(rect.x);
  position(rect.y);
  integer(rect.w, segment ? 0 : 1, MAX_POSITION, "sweep width");
  integer(rect.h, segment ? 0 : 1, MAX_POSITION, "sweep height");
  position(rect.x + rect.w);
  position(rect.y + rect.h);
  motion(delta.x);
  motion(delta.y);
  position(rect.x + delta.x);
  position(rect.y + delta.y);
  position(rect.x + rect.w + delta.x);
  position(rect.y + rect.h + delta.y);
}
function validateSweepTarget(target) {
  integer(target.id, 1, COUNTER_LIMIT - 1, "collision entity ID");
  if (target.kind !== "solid" && target.kind !== "one-way")
    throw new Error("Unsupported collision terrain");
  validate(target.rect, target.delta, false);
}
function sweepBounds(rect, delta = ZERO) {
  validate(rect, delta, true);
  return {
    minX: rect.x + Math.min(0, delta.x),
    minY: rect.y + Math.min(0, delta.y),
    maxX: rect.x + rect.w + Math.max(0, delta.x),
    maxY: rect.y + rect.h + Math.max(0, delta.y)
  };
}
function slab(min, max, targetMin, targetMax, delta) {
  if (delta === 0) return min < targetMax && max > targetMin ? "inside" : null;
  const denominator = Math.abs(delta);
  return delta > 0 ? {
    enter: { numerator: targetMin - max, denominator },
    exit: { numerator: targetMax - min, denominator },
    normal: -1
  } : {
    enter: { numerator: min - targetMax, denominator },
    exit: { numerator: max - targetMin, denominator },
    normal: 1
  };
}
function sweepAabb(body, delta, target, targetDelta = ZERO) {
  validate(body, delta, true);
  validate(target, targetDelta, false);
  if (body.x < target.x + target.w && body.x + body.w > target.x && body.y < target.y + target.h && body.y + body.h > target.y)
    return { kind: "overlap" };
  const axes = [
    slab(body.x, body.x + body.w, target.x, target.x + target.w, delta.x - targetDelta.x),
    slab(body.y, body.y + body.h, target.y, target.y + target.h, delta.y - targetDelta.y)
  ];
  let enter;
  let exit;
  const normals = [];
  for (const [index, axis] of axes.entries()) {
    if (axis === null) return null;
    if (axis === "inside") continue;
    if (!enter || compare(axis.enter, enter) > 0) enter = axis.enter;
    if (!exit || compare(axis.exit, exit) < 0) exit = axis.exit;
    normals.push({
      time: axis.enter,
      normal: index === 0 ? { x: axis.normal, y: 0 } : { x: 0, y: axis.normal }
    });
  }
  if (!enter || !exit || compare(enter, START) < 0 || compare(enter, END) > 0 || compare(enter, exit) >= 0)
    return null;
  return {
    kind: "hit",
    time: enter,
    normals: normals.filter((item) => compare(item.time, enter) === 0).map((item) => item.normal)
  };
}
function sweepOneWay(body, delta, target, targetDelta = ZERO) {
  validate(body, delta, true);
  validate(target, targetDelta, false);
  const distance = target.y - (body.y + body.h);
  const relativeY = delta.y - targetDelta.y;
  if (distance < 0 || relativeY <= 0 || distance > relativeY) return null;
  const time = { numerator: distance, denominator: relativeY };
  const relativeX = delta.x - targetDelta.x;
  if ((body.x - target.x - target.w) * relativeY + relativeX * distance >= 0 || (body.x + body.w - target.x) * relativeY + relativeX * distance <= 0)
    return null;
  return { kind: "hit", time, normals: [{ x: 0, y: -1 }] };
}
function earliestSweep(body, delta, targets2, ignoredOneWayId) {
  validate(body, delta, true);
  integer(targets2.length, 0, 4096, "sweep candidate count");
  const ids = /* @__PURE__ */ new Set();
  const overlaps2 = [];
  let contacts = [];
  let earliest;
  for (const target of [...targets2].sort((a, b) => a.id - b.id)) {
    validateSweepTarget(target);
    if (ids.has(target.id)) throw new Error("Duplicate collision entity ID");
    ids.add(target.id);
    if (target.kind === "one-way" && target.id === ignoredOneWayId) continue;
    const result = target.kind === "solid" ? sweepAabb(body, delta, target.rect, target.delta) : sweepOneWay(body, delta, target.rect, target.delta);
    if (result?.kind === "overlap") {
      overlaps2.push(target.id);
      continue;
    }
    if (!result || earliest && compare(result.time, earliest) > 0) continue;
    if (!earliest || compare(result.time, earliest) < 0) contacts = [];
    earliest = result.time;
    for (const normal of result.normals)
      contacts.push({ otherId: target.id, kind: target.kind, time: result.time, normal });
  }
  return { overlaps: overlaps2, contacts };
}
function displacementAtContact(delta, time) {
  motion(delta.x);
  motion(delta.y);
  integer(time.denominator, 1, MAX_MOTION * 2, "contact denominator");
  integer(time.numerator, 0, time.denominator, "contact numerator");
  return {
    x: Math.trunc(delta.x * time.numerator / time.denominator) || 0,
    y: Math.trunc(delta.y * time.numerator / time.denominator) || 0
  };
}

// src/game/physics/grid.ts
var MAX_TARGETS = 4096;
var MAX_ENTRY_CELLS = 256;
var MAX_GRID_REFERENCES = 65536;
var MAX_QUERY_CELLS = 4096;
function validateBounds(bounds) {
  for (const value of [bounds.minX, bounds.minY, bounds.maxX, bounds.maxY]) position(value);
  if (bounds.minX > bounds.maxX || bounds.minY > bounds.maxY)
    throw new Error("Inverted spatial bounds");
}
function intersects(a, b) {
  return a.minX <= b.maxX && a.maxX >= b.minX && a.minY <= b.maxY && a.maxY >= b.minY;
}
function sorted(values) {
  return Object.freeze([...values].sort((a, b) => a.id - b.id));
}
var CollisionGrid = class {
  constructor(targets2, cellPixels = 64) {
    this.cellPixels = cellPixels;
    if (cellPixels !== 32 && cellPixels !== 64)
      throw new Error("Spatial cell size must be 32 or 64 pixels");
    integer(targets2.length, 0, MAX_TARGETS, "spatial target count");
    let references = 0;
    for (const value of [...targets2].sort((a, b) => a.id - b.id)) {
      validateSweepTarget(value);
      if (this.#entries.has(value.id)) throw new Error("Duplicate collision entity ID");
      const target = Object.freeze({
        ...value,
        rect: Object.freeze({ ...value.rect }),
        delta: Object.freeze({ ...value.delta })
      });
      const bounds = sweepBounds(target.rect, target.delta);
      this.#entries.set(target.id, { target, bounds });
      const range = this.#range(bounds);
      if (range.count > MAX_ENTRY_CELLS || references + range.count > MAX_GRID_REFERENCES) {
        this.#overflow.push(target.id);
        continue;
      }
      references += range.count;
      for (let x = range.minX; x <= range.maxX; x++) {
        for (let y = range.minY; y <= range.maxY; y++) {
          const key = `${x},${y}`;
          const bucket = this.#buckets.get(key) ?? [];
          bucket.push(target.id);
          this.#buckets.set(key, bucket);
        }
      }
    }
    this.targets = sorted([...this.#entries.values()].map((entry) => entry.target));
    this.hasMotion = this.targets.some((target) => target.delta.x !== 0 || target.delta.y !== 0);
    this.statistics = Object.freeze({
      targets: targets2.length,
      cells: this.#buckets.size,
      references,
      overflow: this.#overflow.length
    });
    Object.freeze(this);
  }
  cellPixels;
  targets;
  hasMotion;
  statistics;
  #buckets = /* @__PURE__ */ new Map();
  #entries = /* @__PURE__ */ new Map();
  #overflow = [];
  #range(bounds) {
    const size = this.cellPixels * SUBPIXELS;
    const minX = Math.floor(bounds.minX / size);
    const minY = Math.floor(bounds.minY / size);
    const maxX = Math.floor(bounds.maxX / size);
    const maxY = Math.floor(bounds.maxY / size);
    return { minX, minY, maxX, maxY, count: (maxX - minX + 1) * (maxY - minY + 1) };
  }
  query(bounds) {
    return this.inspectQuery(bounds).targets;
  }
  get(id2) {
    return this.#entries.get(id2)?.target;
  }
  inspectQuery(bounds) {
    validateBounds(bounds);
    const range = this.#range(bounds);
    const ids = /* @__PURE__ */ new Set();
    const scan = range.count > MAX_QUERY_CELLS;
    if (scan) {
      for (const id2 of this.#entries.keys()) ids.add(id2);
    } else {
      for (const id2 of this.#overflow) ids.add(id2);
      for (let x = range.minX; x <= range.maxX; x++) {
        for (let y = range.minY; y <= range.maxY; y++) {
          for (const id2 of this.#buckets.get(`${x},${y}`) ?? []) ids.add(id2);
        }
      }
    }
    const targets2 = [];
    for (const id2 of ids) {
      const entry = this.#entries.get(id2);
      if (!entry) throw new Error("Missing spatial entry");
      if (intersects(entry.bounds, bounds)) targets2.push(entry.target);
    }
    return {
      targets: sorted(targets2),
      mode: scan ? "scan" : "cells",
      cellsVisited: scan ? 0 : range.count,
      candidatesTested: ids.size
    };
  }
};
var CollisionIndex = class {
  constructor(fixed, moving, frame) {
    this.fixed = fixed;
    if (fixed.hasMotion) throw new Error("Static collision grid contains moving geometry");
    integer(fixed.targets.length + moving.length, 0, MAX_TARGETS, "collision frame target count");
    integer(frame.geometryRevision, 1, COUNTER_LIMIT - 1, "geometry revision");
    integer(frame.tick, 0, COUNTER_LIMIT - 1, "collision tick");
    this.dynamic = new CollisionGrid(moving, fixed.cellPixels);
    this.targets = sorted([...fixed.targets, ...this.dynamic.targets]);
    if (new Set(this.targets.map((target) => target.id)).size !== this.targets.length)
      throw new Error("Duplicate collision entity ID across static/dynamic grids");
    this.frame = Object.freeze({ ...frame });
    Object.freeze(this);
  }
  fixed;
  dynamic;
  targets;
  frame;
  assertFrame(frame) {
    if (!frame || frame.geometryRevision !== this.frame.geometryRevision || frame.tick !== this.frame.tick)
      throw new Error("Stale or missing collision frame identity");
  }
  query(bounds) {
    return sorted([...this.fixed.query(bounds), ...this.dynamic.query(bounds)]);
  }
  get(id2) {
    return this.fixed.get(id2) ?? this.dynamic.get(id2);
  }
};

// src/game/physics/move.ts
var ZERO2 = { x: 0, y: 0 };
var MAX_CORRECTION = SUBPIXELS;
function translate(rect, delta) {
  const result = { ...rect, x: position(rect.x + delta.x), y: position(rect.y + delta.y) };
  position(result.x + result.w);
  position(result.y + result.h);
  return result;
}
function overlaps(a, b) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}
function inWorld(rect) {
  return rect.x >= -MAX_POSITION && rect.y >= -MAX_POSITION && rect.x + rect.w <= MAX_POSITION && rect.y + rect.h <= MAX_POSITION;
}
function correctOverlap(rect, targets2, ids, ignoredId) {
  if (ids.length === 0) return { ...ZERO2 };
  if (ids.length > 8) return null;
  const overlapping = new Set(ids);
  const candidates = [];
  for (const target of targets2) {
    if (!overlapping.has(target.id)) continue;
    const b = target.rect;
    candidates.push(
      { delta: { x: b.x - rect.x - rect.w, y: 0 }, order: 0, id: target.id },
      { delta: { x: b.x + b.w - rect.x, y: 0 }, order: 1, id: target.id },
      { delta: { x: 0, y: b.y - rect.y - rect.h }, order: 2, id: target.id },
      { delta: { x: 0, y: b.y + b.h - rect.y }, order: 3, id: target.id }
    );
  }
  const distance = (delta) => Math.abs(delta.x) + Math.abs(delta.y);
  candidates.sort(
    (a, b) => distance(a.delta) - distance(b.delta) || a.order - b.order || a.id - b.id
  );
  for (const { delta } of candidates) {
    if (distance(delta) > MAX_CORRECTION) continue;
    const next = { ...rect, x: rect.x + delta.x, y: rect.y + delta.y };
    if (!inWorld(next)) continue;
    if (targets2.some((target) => target.kind === "solid" && overlaps(next, target.rect))) continue;
    const blocked = targets2.some((target) => {
      if (overlapping.has(target.id) || target.kind === "one-way" && target.id === ignoredId)
        return false;
      const hit = target.kind === "solid" ? sweepAabb(rect, delta, target.rect) : sweepOneWay(rect, delta, target.rect);
      return hit?.kind === "hit" && hit.time.numerator < hit.time.denominator;
    });
    if (!blocked) return delta;
  }
  return null;
}
function support(rect, targets2, previousId, credited, ignoredId) {
  const candidates = targets2.filter((target) => {
    if (target.kind === "one-way" && target.id === ignoredId) return false;
    const gap = target.rect.y - rect.y - rect.h;
    return gap >= 0 && gap <= (credited.has(target.id) ? 1 : 0) && rect.x < target.rect.x + target.rect.w && rect.x + rect.w > target.rect.x;
  });
  return candidates.find((target) => target.id === previousId)?.id ?? candidates[0]?.id ?? null;
}
function redundantSeam(rect, corner, constraints, byId) {
  const target = byId.get(corner.id);
  if (!target) return false;
  const axis = corner.normal.x !== 0 ? "y" : "x";
  const extent = axis === "x" ? "w" : "h";
  return constraints.some((face) => {
    const other = byId.get(face.id);
    if (!other || face.normal[axis] === 0 || !touching(rect, other, face.normal, 0)) return false;
    if (target.delta[axis] !== other.delta[axis]) return false;
    if (face.normal[axis] === -1)
      return rect[axis] + rect[extent] === target.rect[axis] && target.rect[axis] === other.rect[axis];
    return rect[axis] === target.rect[axis] + target.rect[extent] && target.rect[axis] + target.rect[extent] === other.rect[axis] + other.rect[extent];
  });
}
function touching(rect, target, normal, tolerance) {
  const b = target.rect;
  const horizontal = rect.x < b.x + b.w && rect.x + rect.w > b.x;
  const vertical = rect.y < b.y + b.h && rect.y + rect.h > b.y;
  const gap = normal.x === -1 ? b.x - rect.x - rect.w : normal.x === 1 ? rect.x - b.x - b.w : normal.y === -1 ? b.y - rect.y - rect.h : rect.y - b.y - b.h;
  return gap >= 0 && gap <= tolerance && (normal.x === 0 ? horizontal : vertical);
}
function contactGap(rect, target, normal) {
  const b = target.rect;
  const gap = normal.x === -1 ? b.x - rect.x - rect.w : normal.x === 1 ? rect.x - b.x - b.w : normal.y === -1 ? b.y - rect.y - rect.h : rect.y - b.y - b.h;
  return Math.max(0, Math.min(1, gap));
}
function closingTrap(rect, active, targets2, byId, remaining, axis) {
  const otherAxis = axis === "x" ? "y" : "x";
  const otherSize = otherAxis === "x" ? "w" : "h";
  let lower = -MAX_MOTION;
  let upper = MAX_MOTION;
  for (const constraint of active) {
    if (constraint.normal[otherAxis] === 1) lower = Math.max(lower, constraint.delta[otherAxis]);
    if (constraint.normal[otherAxis] === -1) upper = Math.min(upper, constraint.delta[otherAxis]);
  }
  if (lower > upper) return false;
  const sideways = Math.max(lower, Math.min(upper, remaining[otherAxis]));
  return active.some((a) => {
    const left = byId.get(a.id);
    if (a.normal[axis] !== 1 || !left || !touching(rect, left, a.normal, 1)) return false;
    return active.some((b) => {
      const right = byId.get(b.id);
      if (b.normal[axis] !== -1 || !right || !touching(rect, right, b.normal, 1)) return false;
      const size = axis === "x" ? "w" : "h";
      const space = right.rect[axis] - left.rect[axis] - left.rect[size] - rect[size];
      const closing = a.delta[axis] - b.delta[axis];
      if (closing <= space) return false;
      for (const target of [left, right]) {
        const relative = sideways - target.delta[otherAxis];
        if ((rect[otherAxis] - target.rect[otherAxis] - target.rect[otherSize]) * closing + relative * space >= 0 || (rect[otherAxis] + rect[otherSize] - target.rect[otherAxis]) * closing + relative * space <= 0)
          return false;
      }
      return !targets2.some((target) => {
        const relative = sideways - target.delta[otherAxis];
        if (relative === 0) return false;
        const distance = relative > 0 ? target.rect[otherAxis] - rect[otherAxis] - rect[otherSize] : rect[otherAxis] - target.rect[otherAxis] - target.rect[otherSize];
        return distance >= 0 && distance * closing <= space * Math.abs(relative);
      });
    });
  });
}
function moveKinematic(state, terrain, options = {}) {
  const limit = integer(options.maxIterations ?? 4, 1, 4, "movement contact limit");
  if (state.supportId !== null) integer(state.supportId, 1, COUNTER_LIMIT - 1, "support ID");
  if (options.ignoredOneWayId !== void 0)
    integer(options.ignoredOneWayId, 1, COUNTER_LIMIT - 1, "ignored support ID");
  integer(state.rect.w, 1, MAX_POSITION, "body width");
  integer(state.rect.h, 1, MAX_POSITION, "body height");
  const index = terrain instanceof CollisionIndex ? terrain : void 0;
  index?.assertFrame(options.frame);
  const source = terrain instanceof CollisionIndex ? terrain.targets : terrain;
  const targets2 = source.map((target) => ({ ...target, rect: { ...target.rect }, delta: { ...target.delta } })).sort((a, b) => a.id - b.id);
  const byId = new Map(targets2.map((target) => [target.id, target]));
  const query = (rect, delta) => {
    const candidates = index ? index.query(sweepBounds(rect, delta)).map((target) => {
      const current = byId.get(target.id);
      if (!current) throw new Error("Missing current collision target");
      return current;
    }) : targets2;
    return earliestSweep(rect, delta, candidates, options.ignoredOneWayId);
  };
  const initial = query(state.rect, state.motion);
  const correction = correctOverlap(state.rect, targets2, initial.overlaps, options.ignoredOneWayId);
  const result = {
    rect: { ...state.rect },
    motion: { ...state.motion },
    supportId: null,
    status: "complete",
    contacts: [],
    path: [],
    correction: correction ?? { ...ZERO2 },
    remaining: { ...state.motion },
    iterations: 0,
    diagnosticIds: []
  };
  if (!correction) return { ...result, status: "initial-overlap", diagnosticIds: initial.overlaps };
  result.rect = translate(result.rect, correction);
  const credited = new Set(state.supportId === null ? [] : [state.supportId]);
  const startingSupport = state.motion.y < 0 ? null : support(result.rect, targets2, state.supportId, credited, options.ignoredOneWayId);
  const carry = options.carrySupport === false ? ZERO2 : byId.get(startingSupport ?? 0)?.delta ?? ZERO2;
  result.remaining = { x: motion(state.motion.x + carry.x), y: motion(state.motion.y + carry.y) };
  if (startingSupport !== null) credited.add(startingSupport);
  let active = [];
  for (let iteration = 0; iteration < limit; iteration++) {
    const hits = query(result.rect, result.remaining);
    if (hits.overlaps.length)
      return { ...result, status: "residual-overlap", diagnosticIds: hits.overlaps };
    if (!hits.contacts.length) {
      result.path.push({
        rect: { ...result.rect },
        motion: { ...result.remaining },
        until: { numerator: 1, denominator: 1 }
      });
      result.rect = translate(result.rect, result.remaining);
      for (const target of targets2) target.rect = translate(target.rect, target.delta);
      result.remaining = { ...ZERO2 };
      result.supportId = result.motion.y < 0 ? null : support(result.rect, targets2, startingSupport, credited, options.ignoredOneWayId);
      return result;
    }
    const first = hits.contacts[0];
    if (!first) throw new Error("Missing movement contact");
    result.iterations++;
    result.path.push({
      rect: { ...result.rect },
      motion: { ...result.remaining },
      until: { ...first.time }
    });
    const moved = displacementAtContact(result.remaining, first.time);
    result.rect = translate(result.rect, moved);
    result.remaining = { x: result.remaining.x - moved.x, y: result.remaining.y - moved.y };
    for (const target of targets2) {
      const movedTarget = displacementAtContact(target.delta, first.time);
      target.rect = translate(target.rect, movedTarget);
      target.delta = { x: target.delta.x - movedTarget.x, y: target.delta.y - movedTarget.y };
    }
    const current = hits.contacts.map((contact) => {
      result.contacts.push({ ...contact, iteration });
      if (contact.normal.y === -1) credited.add(contact.otherId);
      const target = byId.get(contact.otherId);
      if (!target) throw new Error("Missing contact target");
      return { id: target.id, normal: contact.normal, delta: target.delta };
    });
    active = active.flatMap((constraint) => {
      const target = byId.get(constraint.id);
      return target && touching(result.rect, target, constraint.normal, 1) ? [{ ...constraint, delta: target.delta }] : [];
    });
    const witnessed = [...active, ...current];
    for (const constraint of current) {
      if (redundantSeam(result.rect, constraint, witnessed, byId)) continue;
      if (!active.some(
        (item) => item.id === constraint.id && item.normal.x === constraint.normal.x && item.normal.y === constraint.normal.y
      ))
        active.push(constraint);
    }
    for (const axis of ["x", "y"]) {
      let lower = -MAX_MOTION;
      let upper = MAX_MOTION;
      for (const constraint of active) {
        const normal = constraint.normal[axis];
        const target = byId.get(constraint.id);
        if (!target) throw new Error("Missing active contact target");
        const gap = contactGap(result.rect, target, constraint.normal);
        if (normal === 1) lower = Math.max(lower, constraint.delta[axis] - gap);
        if (normal === -1) upper = Math.min(upper, constraint.delta[axis] + gap);
        if (result.motion[axis] * normal < 0) result.motion[axis] = 0;
      }
      if (lower > upper) {
        const exact = active.filter((constraint) => {
          const target = byId.get(constraint.id);
          return target && touching(result.rect, target, constraint.normal, 0);
        });
        const crush = exact.some(
          (a) => a.normal[axis] === 1 && exact.some((b) => b.normal[axis] === -1 && a.delta[axis] > b.delta[axis])
        ) || closingTrap(result.rect, active, targets2, byId, result.remaining, axis);
        return {
          ...result,
          status: crush ? "crushed" : "unresolved-contact",
          diagnosticIds: [
            ...new Set(
              active.filter((constraint) => constraint.normal[axis] !== 0).map((constraint) => constraint.id)
            )
          ].sort((a, b) => a - b)
        };
      }
      result.remaining[axis] = Math.max(lower, Math.min(upper, result.remaining[axis]));
    }
    if (result.remaining.x === 0 && result.remaining.y === 0 && targets2.every((target) => target.delta.x === 0 && target.delta.y === 0)) {
      result.path.push({
        rect: { ...result.rect },
        motion: { ...ZERO2 },
        until: { numerator: 1, denominator: 1 }
      });
      result.supportId = support(
        result.rect,
        targets2,
        startingSupport,
        credited,
        options.ignoredOneWayId
      );
      return result;
    }
  }
  return {
    ...result,
    status: "contact-limit",
    diagnosticIds: [...new Set(result.contacts.map((contact) => contact.otherId))].sort(
      (a, b) => a - b
    )
  };
}

// src/game/physics/body.ts
var ZERO3 = { x: 0, y: 0 };
var NORMALS = [
  { x: -1, y: 0 },
  { x: 1, y: 0 },
  { x: 0, y: -1 },
  { x: 0, y: 1 }
];
function validateLocalRect(rect) {
  integer(rect.x, -MAX_SHAPE, MAX_SHAPE, "local x");
  integer(rect.y, -MAX_SHAPE, MAX_SHAPE, "local y");
  integer(rect.w, 1, MAX_SHAPE, "local width");
  integer(rect.h, 1, MAX_SHAPE, "local height");
  integer(rect.x + rect.w, -MAX_SHAPE, MAX_SHAPE, "local right edge");
  integer(rect.y + rect.h, -MAX_SHAPE, MAX_SHAPE, "local bottom edge");
}
function facing(value) {
  if (value !== -1 && value !== 1) throw new Error("Invalid body facing");
}
function worldRect(root, local, direction) {
  facing(direction);
  validateLocalRect(local);
  position(root.x);
  position(root.y);
  const rect = {
    x: position(root.x + (direction === 1 ? local.x : -local.x - local.w)),
    y: position(root.y + local.y),
    w: local.w,
    h: local.h
  };
  position(rect.x + rect.w);
  position(rect.y + rect.h);
  return rect;
}
function worldSocket(root, local, direction) {
  facing(direction);
  position(root.x);
  position(root.y);
  integer(local.x, -MAX_SHAPE, MAX_SHAPE, "socket x");
  integer(local.y, -MAX_SHAPE, MAX_SHAPE, "socket y");
  return { x: position(root.x + local.x * direction), y: position(root.y + local.y) };
}
function bodyRect(body, shape, direction) {
  integer(body.id, 1, COUNTER_LIMIT - 1, "body ID");
  integer(shape.id, 1, COUNTER_LIMIT - 1, "shape ID");
  if (body.shapeId !== shape.id) throw new Error("Body/shape identity mismatch");
  if (body.grounded !== (body.supportId !== null)) throw new Error("Ground/support mismatch");
  if (body.supportId !== null) integer(body.supportId, 1, COUNTER_LIMIT - 1, "body support ID");
  motion(body.vx);
  motion(body.vy);
  motion(body.remainderX);
  motion(body.remainderY);
  return worldRect(body, shape.rect, direction);
}
function targetRect(rect, delta, phase) {
  return phase === "start" ? rect : { ...rect, x: rect.x + delta.x, y: rect.y + delta.y };
}
function poseCandidates(rect, index) {
  return index.query({
    minX: Math.max(-MAX_POSITION, rect.x - 1),
    minY: Math.max(-MAX_POSITION, rect.y - 1),
    maxX: Math.min(MAX_POSITION, rect.x + rect.w + 1),
    maxY: Math.min(MAX_POSITION, rect.y + rect.h + 1)
  });
}
function blockingShapes(root, local, direction, index, frame, phase = "start") {
  index.assertFrame(frame);
  const proposed = worldRect(root, local, direction);
  return index.query(sweepBounds(proposed)).filter(
    (target) => target.kind === "solid" && sweepAabb(proposed, ZERO3, targetRect(target.rect, target.delta, phase))?.kind === "overlap"
  ).map((target) => target.id);
}
function tryBodyShape(body, current, desired, oldFacing, nextFacing, index, frame, phase = "start") {
  bodyRect(body, current, oldFacing);
  validateLocalRect(desired.rect);
  integer(desired.id, 1, COUNTER_LIMIT - 1, "desired shape ID");
  if (current.rect.y + current.rect.h !== desired.rect.y + desired.rect.h)
    throw new Error("Stance changes the feet anchor");
  const blockedBy = blockingShapes(body, desired.rect, nextFacing, index, frame, phase);
  return blockedBy.length ? { accepted: false, blockedBy, body, facing: oldFacing } : {
    accepted: true,
    blockedBy,
    body: {
      ...body,
      shapeId: desired.id,
      contacts: desired.id !== current.id || oldFacing !== nextFacing ? [] : body.contacts
    },
    facing: nextFacing
  };
}
function startSupport(body, shape, direction, index, frame, ignoredId) {
  index.assertFrame(frame);
  const rect = bodyRect(body, shape, direction);
  const candidates = poseCandidates(rect, index).filter((target) => {
    if (target.kind === "one-way" && target.id === ignoredId) return false;
    const gap = target.rect.y - rect.y - rect.h;
    return gap >= 0 && gap <= (target.id === body.supportId ? 1 : 0) && rect.x < target.rect.x + target.rect.w && rect.x + rect.w > target.rect.x;
  });
  return candidates.find((target) => target.id === body.supportId)?.id ?? candidates[0]?.id ?? null;
}
function endContacts(rect, movement, index) {
  const result = [];
  const candidates = poseCandidates(rect, index);
  const witnesses = new Set(
    movement.contacts.map(
      (contact) => `${contact.otherId}:${contact.normal.x}:${contact.normal.y}`
    )
  );
  for (const normal of NORMALS) {
    const matching = candidates.filter((target2) => {
      const witnessed = witnesses.has(`${target2.id}:${normal.x}:${normal.y}`);
      const supported2 = normal.y === -1 && movement.supportId === target2.id;
      if (target2.kind === "one-way" && !(normal.y === -1 && (witnessed || supported2))) return false;
      const b = targetRect(target2.rect, target2.delta, "end");
      const gap = normal.x === -1 ? b.x - rect.x - rect.w : normal.x === 1 ? rect.x - b.x - b.w : normal.y === -1 ? b.y - rect.y - rect.h : rect.y - b.y - b.h;
      return gap >= 0 && gap <= (witnessed || supported2 ? 1 : 0) && (normal.x === 0 ? rect.x < b.x + b.w && rect.x + rect.w > b.x : rect.y < b.y + b.h && rect.y + rect.h > b.y);
    });
    const target = (normal.y === -1 ? matching.find((target2) => target2.id === movement.supportId) : void 0) ?? matching[0];
    if (target)
      result.push({
        otherId: target.id,
        normalX: normal.x,
        normalY: normal.y,
        toiNumerator: 1,
        toiDenominator: 1,
        kind: target.kind
      });
  }
  return result.sort(
    (a, b) => a.otherId - b.otherId || a.normalX - b.normalX || a.normalY - b.normalY
  );
}
function stepBody(body, shape, direction, index, options) {
  const rect = bodyRect(body, shape, direction);
  const movement = moveKinematic(
    { rect, motion: { x: body.vx, y: body.vy }, supportId: body.supportId },
    index,
    options
  );
  if (movement.status !== "complete")
    return { status: "failed", reason: movement.status, movement };
  return {
    status: "complete",
    movement,
    body: {
      ...body,
      x: position(body.x + movement.rect.x - rect.x),
      y: position(body.y + movement.rect.y - rect.y),
      vx: movement.motion.x,
      vy: movement.motion.y,
      supportId: movement.supportId,
      grounded: movement.supportId !== null,
      contacts: endContacts(movement.rect, movement, index)
    }
  };
}

// src/game/actors/grounded.ts
function hasLeadingSupport(body, shape, facing2, speed, supportId, index, frame) {
  index.assertFrame(frame);
  const support2 = index.get(supportId);
  if (!support2) return false;
  const projected = worldRect(
    {
      x: position(body.x + speed * facing2 + support2.delta.x),
      y: position(body.y + support2.delta.y)
    },
    shape.rect,
    facing2
  );
  const lead = facing2 === 1 ? projected.x + projected.w - 1 : projected.x;
  const feet = projected.y + projected.h;
  const previousLead = lead - speed * facing2;
  const first = Math.min(previousLead, lead);
  const last = Math.max(previousLead, lead);
  const spans = index.query(sweepBounds({ x: first, y: feet, w: last - first + 1, h: 1 })).filter((target) => {
    if (target.delta.x !== support2.delta.x || target.delta.y !== support2.delta.y) return false;
    const gap = target.rect.y + target.delta.y - feet;
    return gap >= 0 && gap <= (target.id === supportId ? 1 : 0);
  }).map((target) => ({
    start: target.rect.x + target.delta.x,
    end: target.rect.x + target.delta.x + target.rect.w
  })).sort((a, b) => a.start - b.start || a.end - b.end);
  let cursor = first;
  for (const span of spans) {
    if (span.end <= cursor) continue;
    if (span.start > cursor) return false;
    cursor = span.end;
    if (cursor > last) return true;
  }
  return false;
}
function stepGroundedEnemy(current, definition, shape, index, frame) {
  index.assertFrame(frame);
  if (current.geometryRevision !== frame.geometryRevision)
    throw new Error("Enemy geometry revision mismatch");
  integer(current.turns, 0, COUNTER_LIMIT - 2, "enemy turns");
  motion(definition.speed);
  motion(definition.gravity);
  motion(definition.terminalVelocity);
  if (definition.speed < 0 || definition.gravity <= 0 || definition.terminalVelocity <= 0)
    throw new Error("Invalid grounded patrol motion");
  for (const value of [
    definition.bounds.x,
    definition.bounds.y,
    definition.bounds.x + definition.bounds.w,
    definition.bounds.y + definition.bounds.h
  ])
    position(value);
  if (definition.bounds.w <= 0 || definition.bounds.h <= 0)
    throw new Error("Invalid patrol bounds");
  if (current.life === "removed")
    return { status: "complete", enemy: current, decision: "removed", physics: null };
  const body = { ...current.body, contacts: [...current.body.contacts] };
  if (body.remainderX !== 0 || body.remainderY !== 0)
    throw new Error("Patrol requires integral motion");
  const supportId = body.vy >= 0 ? startSupport(body, shape, current.facing, index, frame, null) : null;
  body.supportId = supportId;
  body.grounded = supportId !== null;
  let facing2 = current.facing;
  let decision = supportId === null ? "fall" : "walk";
  let turns = current.turns;
  if (supportId !== null) {
    const rect = worldRect(body, shape.rect, facing2);
    const blocked = body.contacts.some((contact) => {
      const target = index.get(contact.otherId);
      if (target?.kind !== "solid" || contact.normalX !== -facing2) return false;
      const gap = facing2 === 1 ? target.rect.x - rect.x - rect.w : rect.x - target.rect.x - target.rect.w;
      return gap >= 0 && gap <= 1 && rect.y < target.rect.y + target.rect.h && rect.y + rect.h > target.rect.y;
    });
    if (blocked || !hasLeadingSupport(body, shape, facing2, definition.speed, supportId, index, frame)) {
      decision = "turn";
      const nextFacing = definition.turnAtBoundary === false ? facing2 : facing2 === 1 ? -1 : 1;
      const turn = tryBodyShape(body, shape, shape, facing2, nextFacing, index, frame);
      if (turn.accepted && nextFacing !== facing2) {
        facing2 = nextFacing;
        body.contacts = [];
        turns++;
      }
      body.vx = 0;
    } else body.vx = definition.speed === 0 ? 0 : definition.speed * facing2;
    body.vy = 0;
  }
  body.vy = motion(Math.min(definition.terminalVelocity, body.vy + definition.gravity));
  const physics = stepBody(body, shape, facing2, index, { frame });
  if (physics.status === "failed") {
    if (physics.reason !== "crushed") return { status: "failed", physics };
    return {
      status: "complete",
      enemy: { ...current, life: "removed", removalReason: "crushed" },
      decision: "removed",
      physics
    };
  }
  const next = physics.body;
  const bounds = definition.bounds;
  const outside = next.x < bounds.x || next.x > bounds.x + bounds.w || next.y < bounds.y || next.y > bounds.y + bounds.h;
  return {
    status: "complete",
    enemy: {
      ...current,
      body: next,
      facing: facing2,
      turns,
      life: outside ? "removed" : "alive",
      removalReason: outside ? "out-of-bounds" : null
    },
    decision: outside ? "removed" : decision,
    physics
  };
}

// src/game/content/materials.ts
var ATTACK_MATERIALS = [
  "bullet",
  "explosive",
  "heat",
  "energy",
  "blade",
  "blunt"
];
var SURFACE_MATERIAL_IDS = ["concrete", "timber", "armor-steel", "open-grating"];
var opaque = {
  bullet: true,
  explosive: true,
  heat: true,
  energy: true,
  blade: true,
  blunt: true
};
var SURFACE_MATERIALS = [
  {
    id: "concrete",
    damageScale: { bullet: 0, explosive: 0, heat: 0, energy: 0, blade: 0, blunt: 0 },
    blocks: { ...opaque }
  },
  {
    id: "timber",
    damageScale: { bullet: 1, explosive: 1, heat: 1, energy: 1, blade: 1, blunt: 1 },
    blocks: { ...opaque }
  },
  {
    id: "armor-steel",
    damageScale: { bullet: 0, explosive: 1, heat: 0, energy: 2, blade: 0, blunt: 0 },
    blocks: { ...opaque }
  },
  {
    id: "open-grating",
    damageScale: { bullet: 1, explosive: 1, heat: 0, energy: 1, blade: 0, blunt: 1 },
    blocks: {
      bullet: true,
      explosive: false,
      heat: false,
      energy: false,
      blade: true,
      blunt: true
    }
  }
];
function validateSurfaceMaterials(definitions2) {
  if (definitions2.length !== SURFACE_MATERIAL_IDS.length)
    throw new Error("Material roster mismatch");
  for (const [index, material] of definitions2.entries()) {
    if (material.id !== SURFACE_MATERIAL_IDS[index] || Object.keys(material).sort().join() !== "blocks,damageScale,id")
      throw new Error("Unknown or malformed surface material");
    for (const table of [material.damageScale, material.blocks])
      if (Object.keys(table).sort().join() !== [...ATTACK_MATERIALS].sort().join())
        throw new Error("Incomplete material response table");
    for (const attack2 of ATTACK_MATERIALS) {
      integer(material.damageScale[attack2], 0, 4, "material damage scale");
      if (typeof material.blocks[attack2] !== "boolean")
        throw new Error("Invalid material blocking policy");
    }
  }
}
validateSurfaceMaterials(SURFACE_MATERIALS);
function surfaceMaterial(id2) {
  const material = SURFACE_MATERIALS.find((material2) => material2.id === id2);
  if (!material) throw new Error("Unknown surface material");
  return material;
}
function surfaceMaterialFor(target) {
  return surfaceMaterial(target.materialId === void 0 ? "concrete" : target.materialId);
}
function materialBlocks(target, attack2) {
  if (!ATTACK_MATERIALS.includes(attack2)) throw new Error("Unknown attack material");
  return surfaceMaterialFor(target).blocks[attack2];
}
function materialDamage(damage, attack2, materialId) {
  integer(damage, 0, 65535, "material incoming damage");
  if (!ATTACK_MATERIALS.includes(attack2)) throw new Error("Unknown attack material");
  return Math.min(65535, damage * surfaceMaterial(materialId).damageScale[attack2]);
}

// src/game/combat/projectile.ts
function sweepProjectile(projectile, definition, shape, terrain, hurtboxes) {
  if (definition.id !== projectile.definitionId || definition.shapeId !== shape.id || definition.kind !== "swept-projectile" || definition.maxTargets !== 1 || definition.material !== "bullet")
    throw new Error("Unsupported ballistic policy");
  return projectileImpact(
    projectile,
    shape,
    definition.damage,
    terrain.filter((target) => materialBlocks(target, definition.material)),
    hurtboxes.filter((target) => !target.solid || materialBlocks(target, definition.material))
  );
}
function projectileImpact(projectile, shape, bodyDamage, terrain, hurtboxes) {
  integer(bodyDamage, 0, 65535, "projectile body damage");
  integer(terrain.length + hurtboxes.length, 0, 4096, "projectile candidate count");
  const bounds = worldRect(projectile.position, shape.rect, 1);
  sweepBounds(bounds, projectile.velocity);
  const candidates = [
    ...terrain.map((target2) => ({
      ...target2,
      entityId: null,
      priority: 0,
      kind: "terrain"
    })),
    ...hurtboxes.filter(
      (target2) => target2.entityId !== projectile.ownerId && (target2.solid || target2.team !== projectile.team)
    ).map((target2) => ({
      ...target2,
      priority: target2.solid ? 0 : target2.kind === "shield" ? 1 : 2
    }))
  ];
  const ids = /* @__PURE__ */ new Set();
  let first = null;
  for (const target2 of candidates) {
    surfaceMaterialFor(target2);
    integer(target2.id, 1, COUNTER_LIMIT - 1, "projectile collision ID");
    if (ids.has(target2.id)) throw new Error("Duplicate projectile collision ID");
    ids.add(target2.id);
    const hit = sweepAabb(bounds, projectile.velocity, target2.rect, target2.delta);
    if (!hit) continue;
    const time2 = hit.kind === "overlap" ? { numerator: 0, denominator: 1 } : hit.time;
    const order = first ? compareContactTime(
      time2.numerator,
      time2.denominator,
      first.time.numerator,
      first.time.denominator
    ) : -1;
    if (order < 0 || order === 0 && first && (target2.priority < first.target.priority || target2.priority === first.target.priority && target2.id < first.target.id))
      first = { target: target2, time: time2 };
  }
  if (!first) return null;
  const { target, time } = first;
  return {
    sourceId: projectile.id,
    definitionId: projectile.definitionId,
    actionInstanceId: projectile.actionInstanceId,
    ownerId: projectile.ownerId,
    colliderId: target.id,
    entityId: target.entityId,
    kind: target.kind,
    damage: target.kind === "body" ? bodyDamage : 0,
    position: {
      x: position(
        projectile.position.x + divide(projectile.velocity.x * time.numerator, time.denominator).quotient
      ),
      y: position(
        projectile.position.y + divide(projectile.velocity.y * time.numerator, time.denominator).quotient
      )
    },
    time
  };
}
function muzzleBlocked(hand, muzzle, shape, terrain, material = "bullet") {
  const bounds = worldRect(hand, shape.rect, 1);
  const delta = { x: muzzle.x - hand.x, y: muzzle.y - hand.y };
  return terrain.some(
    (target) => materialBlocks(target, material) && sweepAabb(bounds, delta, {
      ...target.rect,
      x: target.rect.x + target.delta.x,
      y: target.rect.y + target.delta.y
    }) !== null
  );
}

// src/game/combat/timeline.ts
function actionPose(catalog, definitionId, age2) {
  const timeline = catalog.timelines.get(definitionId);
  if (!timeline) throw new Error("Missing action timeline");
  integer(age2, 0, COUNTER_LIMIT - 1, "action age");
  if (age2 >= timeline.durationTicks) return null;
  let remaining = age2;
  for (const id2 of timeline.poses) {
    const pose = catalog.poses.get(id2);
    if (!pose) throw new Error("Missing action pose");
    if (remaining < pose.durationTicks) return pose;
    remaining -= pose.durationTicks;
  }
  throw new Error("Action pose exposures do not cover timeline");
}
function stepAction(current, tick2, catalog) {
  integer(tick2, current.stateStartTick, COUNTER_LIMIT - 1, "action tick");
  const definition = catalog.timelines.get(current.definitionId);
  if (!definition) throw new Error("Missing action definition");
  const age2 = tick2 - current.stateStartTick;
  integer(current.nextMarkerIndex, 0, definition.markers.length, "action marker cursor");
  if (definition.markers.slice(0, current.nextMarkerIndex).some((marker) => marker.tickOffset > age2))
    throw new Error("Action cursor acknowledges a future marker");
  if ((definition.markers[current.nextMarkerIndex]?.tickOffset ?? age2) < age2)
    throw new Error("Action timeline skipped an unprocessed marker");
  const action = { ...current };
  const markers = [];
  const pose = actionPose(catalog, current.definitionId, age2);
  while (definition.markers[action.nextMarkerIndex]?.tickOffset === age2) {
    const marker = definition.markers[action.nextMarkerIndex];
    if (!marker || !pose) throw new Error("Marker outside active pose");
    markers.push({
      actionInstanceId: action.actionInstanceId,
      markerIndex: action.nextMarkerIndex++,
      marker,
      pose
    });
  }
  return { action, markers, pose, finished: age2 >= definition.durationTicks };
}

// src/game/actors/rifle.ts
function createRifleState() {
  return {
    action: {
      kind: "ready",
      actionInstanceId: 0,
      stateStartTick: 0,
      definitionId: 0,
      nextMarkerIndex: 0
    },
    targetId: null,
    aim: 0,
    facing: -1
  };
}
function cancelRifle(state) {
  state.action.kind = "ready";
  state.targetId = null;
}
function stepRifleAttack(current, enemy, players, tick2, nextActionId, catalog, profile, bullet, terrain) {
  integer(tick2, 1, COUNTER_LIMIT - 1, "rifle tick");
  const state = structuredClone(current);
  let facing2 = current.action.kind === "fire" ? current.facing : enemy.facing;
  if (enemy.life !== "alive") {
    cancelRifle(state);
    return { state, facing: facing2, nextActionId, markers: [] };
  }
  if (state.action.kind === "ready" && enemy.body.grounded) {
    const candidates = players.filter((player) => player.life === "alive" && player.invulnerableTicks === 0).map((player) => ({
      player,
      distance: Math.abs(player.body.x - enemy.body.x) + Math.abs(player.body.y - enemy.body.y)
    })).filter(({ distance }) => distance <= profile.range).sort((a, b) => a.distance - b.distance || a.player.playerId - b.player.playerId);
    for (const { player } of candidates) {
      const dx = player.body.x - enemy.body.x;
      const aim = Math.abs(dx) <= profile.upAlignment && enemy.body.y - player.body.y >= profile.upHeight ? 1 : 0;
      const direction = dx === 0 ? facing2 : dx < 0 ? -1 : 1;
      const timeline = catalog.timelines.get(profile.timelineIds[aim]);
      const pose = timeline && catalog.poses.get(timeline.poses[0] ?? 0);
      const socket = pose?.sockets.find((socket2) => socket2.name === "muzzle");
      if (!socket) throw new Error("Missing authored rifle raise socket");
      const muzzle = worldSocket(enemy.body, socket.point, direction);
      const end = aim === 1 ? { x: muzzle.x, y: player.body.y - profile.aimHeight } : { x: player.body.x, y: muzzle.y };
      if (muzzleBlocked(muzzle, end, bullet, terrain)) continue;
      facing2 = direction;
      state.facing = direction;
      state.aim = aim;
      state.targetId = player.playerId;
      state.action = {
        kind: "fire",
        actionInstanceId: nextActionId,
        stateStartTick: tick2,
        definitionId: profile.timelineIds[aim],
        nextMarkerIndex: 0
      };
      nextActionId = nextCounter(nextActionId);
      break;
    }
  }
  if (state.action.kind === "ready") return { state, facing: facing2, nextActionId, markers: [] };
  const action = stepAction(state.action, tick2, catalog);
  state.action = action.action;
  if (action.finished) cancelRifle(state);
  return { state, facing: facing2, nextActionId, markers: action.markers };
}

// src/game/actors/shield.ts
function createShieldState(profile) {
  return {
    phase: "brace",
    integrity: profile.integrity,
    facing: -1,
    turnFacing: -1,
    targetId: null,
    action: { actionInstanceId: 0, stateStartTick: 0, definitionId: 0, nextMarkerIndex: 0 },
    hitIds: []
  };
}
function cancelShield(state) {
  state.phase = "dead";
  state.targetId = null;
  state.hitIds = [];
}
function shieldProtected(state, tick2, profile) {
  return state.integrity > 0 && (state.phase === "brace" || state.phase === "advance" || state.phase === "bash" && tick2 - state.action.stateStartTick < profile.bashActiveTick);
}
function begin(state, phase, tick2, nextActionId, profile) {
  state.phase = phase;
  state.hitIds = [];
  state.action = {
    actionInstanceId: nextActionId,
    stateStartTick: tick2,
    definitionId: profile.timelineIds[phase],
    nextMarkerIndex: 0
  };
  return nextCounter(nextActionId);
}
function evaluate(state, tick2, nextActionId, catalog, profile) {
  const advanced = stepAction(state.action, tick2, catalog);
  state.action = advanced.action;
  for (const item of advanced.markers)
    if (item.marker.kind === "face") state.facing = state.turnFacing;
  return {
    state,
    nextActionId,
    markers: advanced.markers,
    speed: state.phase === "advance" ? profile.speed : 0
  };
}
function stepShield(current, enemy, players, tick2, nextActionId, catalog, profile) {
  integer(tick2, 1, COUNTER_LIMIT - 1, "shield tick");
  const state = structuredClone(current);
  if (enemy.life !== "alive") {
    cancelShield(state);
    return { state, nextActionId, markers: [], speed: 0 };
  }
  const duration2 = catalog.timelines.get(state.action.definitionId)?.durationTicks ?? 0;
  const finished = tick2 - state.action.stateStartTick >= duration2;
  if (["turn", "bash", "stunned"].includes(state.phase) && !finished)
    return evaluate(state, tick2, nextActionId, catalog, profile);
  const target = players.filter((player) => player.life === "alive" && player.invulnerableTicks === 0).map((player) => ({
    player,
    distance: Math.abs(player.body.x - enemy.body.x) + Math.abs(player.body.y - enemy.body.y)
  })).filter(({ distance }) => distance <= profile.sightRange).sort((a, b) => a.distance - b.distance || a.player.playerId - b.player.playerId)[0]?.player;
  const dx = target ? target.body.x - enemy.body.x : 0;
  const direction = dx === 0 ? state.facing : dx < 0 ? -1 : 1;
  if (enemy.body.grounded && target && direction !== state.facing) {
    state.targetId = target.playerId;
    state.turnFacing = direction;
    nextActionId = begin(state, "turn", tick2, nextActionId, profile);
  } else if (enemy.body.grounded && target && Math.abs(dx) <= profile.bashRange && Math.abs(target.body.y - enemy.body.y) <= profile.bashHeight) {
    state.targetId = target.playerId;
    nextActionId = begin(state, "bash", tick2, nextActionId, profile);
  } else if (state.action.actionInstanceId === 0 || finished) {
    const phase = target && enemy.body.grounded && state.phase !== "advance" ? "advance" : "brace";
    state.targetId = target?.playerId ?? null;
    state.turnFacing = state.facing;
    nextActionId = begin(
      state,
      state.action.actionInstanceId === 0 ? "brace" : phase,
      tick2,
      nextActionId,
      profile
    );
  }
  return evaluate(state, tick2, nextActionId, catalog, profile);
}
function damageShield(current, attack2, tick2, nextActionId, catalog, profile) {
  const state = structuredClone(current);
  const damage = profile.damageByMaterial[attack2.material];
  integer(damage, 0, 65535, "shield material damage");
  if (state.phase === "dead" || state.integrity === 0 || damage === 0)
    return { state, nextActionId, broken: false, markers: [] };
  state.integrity = Math.max(0, state.integrity - damage);
  if (state.integrity > 0) return { state, nextActionId, broken: false, markers: [] };
  state.targetId = null;
  state.turnFacing = state.facing;
  nextActionId = begin(state, "stunned", tick2, nextActionId, profile);
  return { ...evaluate(state, tick2, nextActionId, catalog, profile), broken: true };
}

// src/game/rules.ts
var ARCADE = Object.freeze({
  width: 384,
  height: 216,
  simulationHz: 60,
  snapshotHz: 20,
  maxPlayers: 4,
  staleInputMs: 250,
  reservationMs: 9e4,
  initialLives: 3,
  initialGrenades: 10,
  respawnProtectionTicks: 120,
  deathTicks: 30,
  respawnEntryTicks: 12,
  boardingTicks: 12,
  reboardCooldownTicks: 30,
  vehicleSpecialHoldTicks: 30,
  jumpBufferTicks: 5,
  coyoteTicks: 4,
  dropThroughTicks: 12
});
var RULE_PRESETS = Object.freeze({
  classic: Object.freeze({ footHealth: 1, tankArmor: 3, sharedContinues: 3 }),
  accessible: Object.freeze({ footHealth: 3, tankArmor: 3, sharedContinues: 9 })
});
var DEFAULT_BINDINGS = Object.freeze({
  left: ["ArrowLeft", "KeyA"],
  right: ["ArrowRight", "KeyD"],
  up: ["ArrowUp", "KeyW"],
  down: ["ArrowDown", "KeyS"],
  fire: ["KeyJ", "KeyZ"],
  jump: ["Space", "KeyK", "KeyX"],
  grenade: ["KeyL", "KeyC"],
  interact: ["KeyE"],
  vehicleSpecial: ["KeyV"]
});
var DEFAULT_GAMEPAD = Object.freeze({
  jump: 0,
  fire: 2,
  grenade: 1,
  interact: 3,
  vehicleSpecial: 4
});

// src/game/campaign/life.ts
function check(ok, reason) {
  if (!ok) throw new Error(`Player life: ${reason}`);
}
function validBodyPresence(actor) {
  if (actor.life !== "alive" && (actor.vehicleId !== null || actor.action.kind !== "ready"))
    return false;
  if (actor.bodyPresence === "present") return actor.life !== "spectating";
  if (actor.life === "alive") return false;
  const body = actor.body;
  return actor.bodyPresence === "removed" && actor.locomotion === "airborne" && body.vx === 0 && body.vy === 0 && body.remainderX === 0 && body.remainderY === 0 && !body.grounded && body.supportId === null && body.contacts.length === 0;
}
function validatePlayerLife(actor, tick2, ruleset) {
  integer(tick2, 0, COUNTER_LIMIT - 1, "life tick");
  integer(actor.lifeStartTick, 0, tick2, "life phase tick");
  integer(actor.lives, 0, ARCADE.initialLives, "player lives");
  const rule = RULE_PRESETS[ruleset];
  check(rule, "unknown ruleset");
  integer(actor.health, 0, rule.footHealth, "foot health");
  integer(actor.invulnerableTicks, 0, ARCADE.respawnProtectionTicks, "entry protection");
  check(validBodyPresence(actor), "inconsistent body presence");
  check(
    actor.life === "alive" || actor.life === "respawning" ? actor.health > 0 && actor.lives > 0 : actor.life === "death" || actor.life === "spectating" ? actor.health === 0 && (actor.life !== "spectating" || actor.lives === 0) : false,
    "inconsistent life state"
  );
}
function notice(actor, tick2, kind) {
  return { kind, tick: tick2, playerId: actor.playerId, lives: actor.lives };
}
function clearAction(actor, tick2) {
  actor.firearmAim = { pitch: 0, nextStepTick: 0 };
  actor.action = {
    kind: "ready",
    actionInstanceId: 0,
    stateStartTick: tick2,
    definitionId: 0,
    nextMarkerIndex: 0
  };
  actor.jumpBufferTicks = 0;
  actor.coyoteTicks = 0;
  actor.ignoredSupportId = null;
  actor.ignoredSupportTicks = 0;
}
function removeBody(actor) {
  actor.bodyPresence = "removed";
  actor.body.vx = actor.body.vy = actor.body.remainderX = actor.body.remainderY = 0;
  actor.body.grounded = false;
  actor.body.supportId = null;
  actor.body.contacts = [];
  actor.locomotion = "airborne";
}
function stepPassiveBody(actor, context) {
  if (actor.bodyPresence !== "present") return false;
  const { definition, shapes, index, frame, fallBoundary } = context;
  position(fallBoundary);
  check(
    definition.locomotion === "grounded" && definition.gravity > 0 && definition.terminalVelocity > 0,
    "invalid passive body physics"
  );
  motion(definition.gravity);
  motion(definition.terminalVelocity);
  check(
    actor.body.remainderX === 0 && actor.body.remainderY === 0,
    "unsupported passive body remainder"
  );
  const shape = shapes.get(actor.body.shapeId);
  check(
    shape && (shape.id === definition.standingShapeId || shape.id === definition.crouchedShapeId),
    "unknown passive body shape"
  );
  if (actor.body.y > fallBoundary) {
    removeBody(actor);
    return false;
  }
  const support2 = actor.body.vy < 0 ? null : startSupport(actor.body, shape, actor.facing, index, frame, null);
  actor.body.supportId = support2;
  actor.body.grounded = support2 !== null;
  if (support2 !== null) actor.body.vx = 0;
  actor.body.vy = Math.min(definition.terminalVelocity, actor.body.vy + definition.gravity);
  const result = stepBody(actor.body, shape, actor.facing, index, { frame });
  if (result.status === "failed") {
    removeBody(actor);
    return false;
  }
  actor.body = result.body;
  if (actor.body.y > fallBoundary) removeBody(actor);
  else {
    actor.locomotion = actor.body.grounded ? "grounded" : "airborne";
    if (actor.body.grounded) actor.body.vx = 0;
  }
  return actor.bodyPresence === "present";
}
function damagePlayer(current, tick2, damage, ruleset, cause = "hit") {
  validatePlayerLife(current, tick2, ruleset);
  integer(damage, 1, 65535, "player damage");
  check(cause === "hit" || cause === "fall" || cause === "crush", "unknown damage cause");
  const actor = structuredClone(current);
  if (actor.life !== "alive" || cause === "hit" && actor.invulnerableTicks > 0)
    return { actor, notice: null };
  check(actor.vehicleId === null, "vehicle damage requires the vehicle owner");
  actor.health = cause === "hit" ? Math.max(0, actor.health - damage) : 0;
  if (actor.health > 0) return { actor, notice: null };
  actor.lives--;
  actor.life = "death";
  actor.bodyPresence = "present";
  actor.lifeStartTick = tick2;
  actor.invulnerableTicks = 0;
  clearAction(actor, tick2);
  if (cause !== "hit") removeBody(actor);
  else if (actor.body.grounded) actor.body.vx = 0;
  return { actor, notice: notice(actor, tick2, "death") };
}
function entryBody(actor, context) {
  context.index.assertFrame(context.frame);
  position(context.fallBoundary);
  integer(context.anchors.length, 1, 16, "checkpoint anchor count");
  check(context.shape.rect.y + context.shape.rect.h === 0, "entry shape must use a feet anchor");
  for (const point2 of context.anchors) {
    if (blockingShapes(point2, context.shape.rect, actor.facing, context.index, context.frame).length)
      continue;
    const body = {
      ...actor.body,
      ...point2,
      vx: 0,
      vy: 0,
      remainderX: 0,
      remainderY: 0,
      shapeId: context.shape.id,
      supportId: null,
      grounded: false,
      contacts: []
    };
    const support2 = startSupport(
      body,
      context.shape,
      actor.facing,
      context.index,
      context.frame,
      null
    );
    if (support2 === null) continue;
    body.supportId = support2;
    body.grounded = true;
    const moved = stepBody(body, context.shape, actor.facing, context.index, {
      frame: context.frame
    });
    if (moved.status === "complete" && moved.body.grounded && moved.body.y <= context.fallBoundary)
      return moved.body;
  }
  return null;
}
function enterPlayer(current, tick2, ruleset, context) {
  integer(current.lives, 1, ARCADE.initialLives, "entry lives");
  integer(tick2, current.lifeStartTick, COUNTER_LIMIT - 1, "entry tick");
  check(context.frame.tick === tick2, "entry collision tick mismatch");
  check(RULE_PRESETS[ruleset], "unknown ruleset");
  check(current.vehicleId === null, "vehicle seat must be released before entry");
  const body = entryBody(current, context);
  if (!body) return null;
  const actor = structuredClone(current);
  actor.body = body;
  actor.geometryRevision = context.frame.geometryRevision;
  actor.life = "respawning";
  actor.bodyPresence = "present";
  actor.lifeStartTick = tick2;
  actor.locomotion = "grounded";
  actor.health = RULE_PRESETS[ruleset].footHealth;
  actor.invulnerableTicks = ARCADE.respawnProtectionTicks;
  actor.weapon = {
    id: "sidearm",
    ammo: 0,
    cooldownTicks: 0,
    shotOrdinal: current.weapon.shotOrdinal,
    lastActionInstanceId: current.weapon.lastActionInstanceId
  };
  actor.grenadeStock = ARCADE.initialGrenades;
  actor.grenadeCooldownTicks = actor.meleeCooldownTicks = actor.reboardCooldownTicks = actor.vehicleSpecialTicks = 0;
  clearAction(actor, tick2);
  return actor;
}
function stepPlayerLife(current, tick2, ruleset, context) {
  validatePlayerLife(current, tick2, ruleset);
  check(context.frame.tick === tick2, "entry collision tick mismatch");
  context.index.assertFrame(context.frame);
  check(
    current.geometryRevision === context.frame.geometryRevision,
    "life geometry revision mismatch"
  );
  const actor = structuredClone(current);
  actor.invulnerableTicks = Math.max(0, actor.invulnerableTicks - 1);
  actor.reboardCooldownTicks = Math.max(0, actor.reboardCooldownTicks - 1);
  if (actor.life === "death" && tick2 - actor.lifeStartTick >= ARCADE.deathTicks) {
    if (actor.lives === 0) {
      removeBody(actor);
      actor.life = "spectating";
      actor.lifeStartTick = tick2;
      return { actor, notice: notice(actor, tick2, "spectate") };
    }
    const entered = enterPlayer(actor, tick2, ruleset, context);
    if (entered) return { actor: entered, notice: notice(entered, tick2, "respawn") };
  }
  if (actor.life === "respawning") {
    if (actor.bodyPresence === "removed") {
      const entered = enterPlayer(actor, tick2, ruleset, context);
      return entered ? { actor: entered, notice: notice(entered, tick2, "respawn") } : { actor, notice: null };
    }
    if (tick2 - actor.lifeStartTick >= ARCADE.respawnEntryTicks) {
      actor.life = "alive";
      actor.lifeStartTick = tick2;
      return { actor, notice: notice(actor, tick2, "ready") };
    }
    if (!stepPassiveBody(actor, context)) actor.invulnerableTicks = 0;
    return { actor, notice: null };
  }
  if (actor.life === "death") stepPassiveBody(actor, context);
  return { actor, notice: null };
}

// src/game/combat/volume.ts
var END2 = { numerator: 1, denominator: 1 };
function validateQuery(source, terrain, hurtboxes) {
  for (const id2 of [source.id, source.ownerId, source.actionInstanceId, source.definitionId])
    integer(id2, 1, COUNTER_LIMIT - 1, "attack identity");
  integer(source.team, 0, 255, "attack team");
  integer(terrain.length + hurtboxes.length, 0, 4096, "volume candidates");
  const ids = /* @__PURE__ */ new Set();
  for (const target of terrain) validateSweepTarget(target);
  for (const target of hurtboxes) {
    integer(target.entityId, 1, COUNTER_LIMIT - 1, "hurt entity");
    integer(target.team, 0, 255, "hurt team");
    if (target.kind !== "body" && target.kind !== "shield") throw new Error("Invalid hurt kind");
    sweepBounds(target.rect, target.delta);
    integer(target.rect.w, 1, 2 ** 24, "hurt width");
    integer(target.rect.h, 1, 2 ** 24, "hurt height");
  }
  for (const target of [...terrain, ...hurtboxes]) {
    surfaceMaterialFor(target);
    integer(target.id, 1, COUNTER_LIMIT - 1, "volume collision ID");
    if (ids.has(target.id)) throw new Error("Duplicate volume collision ID");
    ids.add(target.id);
  }
}
var at = (origin, delta, time) => ({
  x: origin.x + divide(delta.x * time.numerator, time.denominator).quotient,
  y: origin.y + divide(delta.y * time.numerator, time.denominator).quotient
});
function nearest(origin, rect) {
  return {
    x: Math.max(rect.x, Math.min(origin.x, rect.x + rect.w)),
    y: Math.max(rect.y, Math.min(origin.y, rect.y + rect.h))
  };
}
function targets(source, hurtboxes) {
  return hurtboxes.filter(
    (target) => (target.solid || target.team !== source.team) && target.entityId !== source.ownerId
  );
}
function occluder(from, to, time, terrain, shields, material) {
  const candidates = [
    ...terrain.filter((target) => target.kind === "solid" && materialBlocks(target, material)).map((target) => ({ ...target, entityId: null, kind: "terrain", priority: 0 })),
    ...shields.filter((target) => materialBlocks(target, material)).map((target) => ({ ...target, priority: target.solid ? 0 : 1 }))
  ];
  let first = null;
  for (const target of candidates) {
    const point2 = at(target.rect, target.delta, time);
    const hit = sweepAabb(
      { ...from, w: 0, h: 0 },
      { x: to.x - from.x, y: to.y - from.y },
      { ...target.rect, ...point2 }
    );
    if (!hit) continue;
    const hitTime = hit.kind === "overlap" ? { numerator: 0, denominator: 1 } : hit.time;
    const order = first ? compareContactTime(
      hitTime.numerator,
      hitTime.denominator,
      first.time.numerator,
      first.time.denominator
    ) : -1;
    if (order < 0 || order === 0 && first && (target.priority < first.target.priority || target.priority === first.target.priority && target.id < first.target.id))
      first = { target, time: hitTime };
  }
  return first;
}
function impact(source, target, time, point2, damage) {
  return {
    sourceId: source.id,
    definitionId: source.definitionId,
    ownerId: source.ownerId,
    actionInstanceId: source.actionInstanceId,
    colliderId: target.id,
    entityId: target.entityId,
    kind: target.kind,
    damage,
    time,
    position: point2
  };
}
function solidFaceContact(volume, delta, target) {
  if (!target.solid) return null;
  for (const time of [{ numerator: 0, denominator: 1 }, END2]) {
    const a = { ...volume, ...at(volume, delta, time) };
    const b = { ...target.rect, ...at(target.rect, target.delta, time) };
    const overlapX = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
    const overlapY = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
    if (overlapX === 0 && overlapY > 0 || overlapY === 0 && overlapX > 0) return time;
  }
  return null;
}
function ordered(hits, maximum, excluded, primaryTarget = null) {
  const seen = new Set(excluded);
  return hits.sort(
    (a, b) => compareContactTime(
      a.time.numerator,
      a.time.denominator,
      b.time.numerator,
      b.time.denominator
    ) || (primaryTarget === null ? 0 : Number(b.entityId === primaryTarget) - Number(a.entityId === primaryTarget)) || a.colliderId - b.colliderId
  ).filter((hit) => {
    if (hit.entityId === null || seen.has(hit.entityId) || seen.size >= maximum) return false;
    seen.add(hit.entityId);
    return true;
  });
}
function meleeHits(source, definition, shape, hand, delta, facing2, occlusionOrigin, terrain, hurtboxes, hitIds = []) {
  if (definition.kind !== "melee" || definition.material !== "blade" && definition.material !== "blunt" || definition.id !== source.definitionId || definition.shapeId !== shape.id)
    throw new Error("Invalid melee policy");
  return rectangularHits(
    source,
    definition,
    worldRect(hand, shape.rect, facing2),
    delta,
    occlusionOrigin,
    terrain,
    hurtboxes,
    hitIds
  );
}
function rectangularHits(source, definition, volume, delta, occlusionOrigin, terrain, hurtboxes, hitIds = []) {
  if (definition.id !== source.definitionId || !["melee", "shot-volume", "flame-volumes"].includes(definition.kind))
    throw new Error("Invalid rectangular attack policy");
  validateQuery(source, terrain, hurtboxes);
  integer(hitIds.length, 0, definition.maxTargets, "melee hit budget");
  for (const id2 of hitIds) integer(id2, 1, COUNTER_LIMIT - 1, "melee hit identity");
  if (new Set(hitIds).size !== hitIds.length) throw new Error("Duplicate melee hit identity");
  sweepBounds(volume, delta);
  sweepBounds({ ...occlusionOrigin, w: 0, h: 0 }, delta);
  const enemies = targets(source, hurtboxes), shields = enemies.filter((target) => target.kind === "shield" || target.solid), hits = [];
  for (const target of enemies.filter(
    (target2) => target2.kind === "body" || definition.kind !== "melee"
  )) {
    const hit = sweepAabb(volume, delta, target.rect, target.delta);
    const time = hit ? hit.kind === "overlap" ? { numerator: 0, denominator: 1 } : hit.time : solidFaceContact(volume, delta, target);
    if (!time) continue;
    const origin = at(occlusionOrigin, delta, time);
    const exposed = { ...target.rect, ...at(target.rect, target.delta, time) };
    const currentVolume = { ...volume, ...at(volume, delta, time) };
    const x = Math.max(exposed.x, currentVolume.x), y = Math.max(exposed.y, currentVolume.y);
    const point2 = nearest(origin, {
      x,
      y,
      w: Math.max(0, Math.min(exposed.x + exposed.w, currentVolume.x + currentVolume.w) - x),
      h: Math.max(0, Math.min(exposed.y + exposed.h, currentVolume.y + currentVolume.h) - y)
    });
    const blocked = occluder(origin, point2, time, terrain, shields, definition.material);
    if (blocked?.target.kind === "terrain") continue;
    if (blocked && definition.kind !== "melee") {
      const shield = {
        ...blocked.target.rect,
        ...at(blocked.target.rect, blocked.target.delta, time)
      };
      if (shield.x > currentVolume.x + currentVolume.w || shield.x + shield.w < currentVolume.x || shield.y > currentVolume.y + currentVolume.h || shield.y + shield.h < currentVolume.y)
        continue;
    }
    hits.push(
      blocked ? impact(
        source,
        blocked.target,
        time,
        at(origin, { x: point2.x - origin.x, y: point2.y - origin.y }, blocked.time),
        blocked.target.kind === "body" ? definition.damage : 0
      ) : impact(source, target, time, point2, target.kind === "shield" ? 0 : definition.damage)
    );
  }
  return ordered(hits, definition.maxTargets, hitIds);
}
function explosionHits(source, definition, center, radius, terrain, hurtboxes, options = {}) {
  const { time = END2, primaryTarget = null } = options;
  if (definition.id !== source.definitionId || definition.kind !== "explosion" || definition.material !== "explosive")
    throw new Error("Invalid explosion policy");
  integer(radius, 1, 2 ** 16, "blast radius");
  integer(time.denominator, 1, 2 ** 17, "blast contact denominator");
  integer(time.numerator, 0, time.denominator, "blast contact numerator");
  if (primaryTarget !== null) integer(primaryTarget, 1, COUNTER_LIMIT - 1, "blast primary target");
  position(center.x);
  position(center.y);
  validateQuery(source, terrain, hurtboxes);
  const enemies = targets(source, hurtboxes), shields = enemies.filter((target) => target.kind === "shield" || target.solid), hits = [];
  for (const target of enemies.filter((target2) => target2.kind === "body")) {
    const point2 = nearest(center, {
      ...target.rect,
      ...at(target.rect, target.delta, time)
    });
    const dx = point2.x - center.x, dy = point2.y - center.y;
    if (dx * dx + dy * dy > radius * radius) continue;
    const blocked = occluder(center, point2, time, terrain, shields, definition.material);
    if (blocked?.target.kind === "terrain") continue;
    hits.push(
      blocked ? impact(
        source,
        blocked.target,
        time,
        at(center, { x: point2.x - center.x, y: point2.y - center.y }, blocked.time),
        blocked.target.kind === "body" ? definition.damage : 0
      ) : impact(source, target, time, point2, definition.damage)
    );
  }
  return ordered(hits, definition.maxTargets, [], primaryTarget);
}

// src/game/combat/area-attack.ts
var zero = { x: 0, y: 0 };
function areaEndTick(attack2, profile) {
  return attack2.startTick + (profile.emissionOffsets.at(-1) ?? 0) + profile.frames.length;
}
function cardinalRect(origin, rect, heading) {
  if (heading === 0) return { ...rect, x: origin.x + rect.x, y: origin.y + rect.y };
  if (heading === 3) return { ...rect, x: origin.x - rect.x - rect.w, y: origin.y + rect.y };
  if (heading === 1)
    return { x: origin.x + rect.y, y: origin.y - rect.x - rect.w, w: rect.h, h: rect.w };
  return { x: origin.x + rect.y, y: origin.y + rect.x, w: rect.h, h: rect.w };
}
function forward(rect, origin, heading) {
  if (heading === 0) return { ...rect, x: rect.x - origin.x, y: rect.y - origin.y };
  if (heading === 3) return { ...rect, x: origin.x - rect.x - rect.w, y: rect.y - origin.y };
  if (heading === 1)
    return { x: origin.y - rect.y - rect.h, y: rect.x - origin.x, w: rect.h, h: rect.w };
  return { x: rect.y - origin.y, y: rect.x - origin.x, w: rect.h, h: rect.w };
}
function clippedGeometry(geometry, lobe, terrain, material) {
  let reach = lobe.reach;
  let top = geometry.y, bottom = geometry.y + geometry.h;
  for (const wall of terrain) {
    if (wall.kind !== "solid" || !materialBlocks(wall, material)) continue;
    const rect = forward(
      { ...wall.rect, x: wall.rect.x + wall.delta.x, y: wall.rect.y + wall.delta.y },
      lobe.origin,
      lobe.heading
    );
    if (rect.y < geometry.y + geometry.h && rect.y + rect.h > geometry.y && rect.x + rect.w > 0 && rect.x <= geometry.x + geometry.w) {
      if (rect.y <= 0 && rect.y + rect.h >= 0) reach = Math.min(reach, Math.max(0, rect.x));
      else if (rect.y > 0) bottom = Math.min(bottom, rect.y);
      else top = Math.max(top, rect.y + rect.h);
    }
  }
  const width = Math.min(geometry.w, reach - geometry.x);
  return {
    reach,
    rect: width > 0 && bottom > top ? { ...geometry, y: top, h: bottom - top, w: width } : null
  };
}
function emitArea(attack2, tick2, profile, anchor, blocked) {
  const index = profile.emissionOffsets.indexOf(tick2 - attack2.startTick);
  if (index < 0 || index !== attack2.emitted || attack2.cancelledTick !== null)
    throw new Error("Area emission cursor mismatch");
  attack2.emitted++;
  if (!blocked)
    attack2.lobes.push({
      index,
      origin: { ...anchor.origin },
      heading: anchor.heading,
      reach: profile.maximumReach
    });
}
function cancelArea(attack2, tick2, profile) {
  if (profile.kind !== "flame-volumes") return;
  attack2.cancelledTick ??= tick2;
  attack2.lobes = attack2.lobes.filter(
    (lobe) => tick2 - attack2.startTick - (profile.emissionOffsets[lobe.index] ?? 0) >= profile.attachedTicks
  );
}
function stepArea(current, tick2, definition, profile, anchor, terrain, hurtboxes) {
  const attack2 = structuredClone(current), impacts = [], candidatesForAction = [];
  if (definition.kind !== profile.kind || definition.id !== attack2.definitionId)
    throw new Error("Area definition mismatch");
  if (tick2 >= areaEndTick(attack2, profile)) return { attack: null, impacts };
  if (!anchor) cancelArea(attack2, tick2, profile);
  attack2.lobes = attack2.lobes.filter(
    (lobe) => tick2 - attack2.startTick - (profile.emissionOffsets[lobe.index] ?? 0) < profile.frames.length
  );
  for (const lobe of attack2.lobes) {
    const born = attack2.startTick + (profile.emissionOffsets[lobe.index] ?? 0), age2 = tick2 - born;
    const frame = profile.frames[age2];
    if (!frame) throw new Error("Unknown area exposure");
    const previous = structuredClone(lobe);
    if (age2 < profile.attachedTicks && anchor) {
      lobe.origin = { ...anchor.origin };
      lobe.heading = anchor.heading;
    }
    const endpoint = age2 === 0 || previous.heading !== lobe.heading;
    const delta = endpoint ? zero : { x: lobe.origin.x - previous.origin.x, y: lobe.origin.y - previous.origin.y };
    const origin = endpoint ? lobe.origin : previous.origin;
    const clipped = clippedGeometry(
      frame,
      lobe,
      [
        ...terrain,
        ...hurtboxes.filter((target) => target.solid).map((target) => ({ ...target, kind: "solid" }))
      ],
      definition.material
    );
    lobe.reach = clipped.reach;
    if (!clipped.rect) continue;
    const excluded = attack2.hits.filter((hit) => definition.repeatDamageTicks === 0 || tick2 < hit.nextTick).map((hit) => hit.entityId);
    const remaining = definition.maxTargets - attack2.hits.length;
    const candidates = hurtboxes.filter(
      (hurt) => remaining > 0 || attack2.hits.some((hit) => hit.entityId === hurt.entityId)
    );
    const collisionTerrain = endpoint ? terrain.map((wall) => ({
      ...wall,
      rect: { ...wall.rect, x: wall.rect.x + wall.delta.x, y: wall.rect.y + wall.delta.y },
      delta: zero
    })) : terrain;
    const hits = rectangularHits(
      attack2,
      definition,
      cardinalRect(origin, clipped.rect, lobe.heading),
      delta,
      origin,
      collisionTerrain,
      endpoint ? candidates.map((hurt) => ({
        ...hurt,
        rect: { ...hurt.rect, x: hurt.rect.x + hurt.delta.x, y: hurt.rect.y + hurt.delta.y },
        delta: zero
      })) : candidates,
      excluded
    );
    candidatesForAction.push(...hits);
  }
  const granted = /* @__PURE__ */ new Set();
  candidatesForAction.sort(
    (a, b) => compareContactTime(
      a.time.numerator,
      a.time.denominator,
      b.time.numerator,
      b.time.denominator
    ) || a.colliderId - b.colliderId
  );
  for (const hit of candidatesForAction) {
    if (hit.entityId === null) continue;
    if (granted.has(hit.entityId)) continue;
    let receipt = attack2.hits.find((receipt2) => receipt2.entityId === hit.entityId);
    if (!receipt) {
      if (attack2.hits.length >= definition.maxTargets) continue;
      receipt = { entityId: hit.entityId, nextTick: 0 };
      attack2.hits.push(receipt);
    }
    receipt.nextTick = definition.repeatDamageTicks === 0 ? areaEndTick(attack2, profile) : tick2 + definition.repeatDamageTicks;
    granted.add(hit.entityId);
    impacts.push(hit);
  }
  attack2.hits.sort((a, b) => a.entityId - b.entityId);
  return { attack: attack2, impacts };
}
function validateAreaProfile(profile, definition) {
  if (definition.kind !== profile.kind || !["shot-volume", "flame-volumes"].includes(profile.kind))
    throw new Error("Unknown area profile");
  if (definition.material !== (profile.kind === "shot-volume" ? "bullet" : "heat"))
    throw new Error("Area profile material mismatch");
  integer(profile.frames.length, 1, 120, "area frames");
  integer(profile.emissionOffsets.length, 1, 4, "area emissions");
  integer(profile.attachedTicks, 0, profile.frames.length, "area attachment");
  integer(profile.maximumReach, 1, MAX_SHAPE, "area reach");
  for (const [index, offset] of profile.emissionOffsets.entries()) {
    integer(
      offset,
      index === 0 ? 0 : (profile.emissionOffsets[index - 1] ?? 0) + 1,
      120,
      "area emission offset"
    );
    if (index === 0 && offset !== 0) throw new Error("Area must begin at its first emission");
  }
  for (const frame of profile.frames) {
    validateLocalRect(frame);
    if (frame.x < 0 || frame.x + frame.w > profile.maximumReach)
      throw new Error("Area frame exceeds reach");
  }
  if (definition.lifetimeTicks !== (profile.emissionOffsets.at(-1) ?? 0) + profile.frames.length || profile.kind === "shot-volume" && (definition.repeatDamageTicks !== 0 || profile.attachedTicks !== 0 || profile.emissionOffsets.length !== 1) || profile.kind === "flame-volumes" && definition.repeatDamageTicks < 1)
    throw new Error("Area lifetime/damage policy mismatch");
}

// src/game/combat/beam.ts
function validateBeamProfile(profile) {
  integer(profile.range, 1, MAX_SHAPE * 4, "beam range");
  integer(profile.width, 1, 4096, "beam width");
  integer(profile.pulseTicks, 1, 120, "beam pulse interval");
}
function validateBeamPolicy(source, definition, profile) {
  validateBeamProfile(profile);
  for (const id2 of [source.id, source.ownerId, source.actionInstanceId, source.definitionId])
    integer(id2, 1, COUNTER_LIMIT - 1, "beam identity");
  integer(source.team, 1, 255, "beam team");
  if (source.definitionId !== definition.id || definition.kind !== "beam" || definition.material !== "energy" || definition.speed !== 0 || definition.lifetimeTicks !== profile.pulseTicks || definition.repeatDamageTicks !== profile.pulseTicks)
    throw new Error("Invalid beam attack policy");
  integer(definition.damage, 1, 65535, "beam damage");
  integer(definition.maxTargets, 1, 64, "beam penetration budget");
}
function forward2(rect, origin, heading) {
  if (heading === 0) return { ...rect, x: rect.x - origin.x, y: rect.y - origin.y };
  if (heading === 3) return { ...rect, x: origin.x - rect.x - rect.w, y: rect.y - origin.y };
  if (heading === 1)
    return { x: origin.y - rect.y - rect.h, y: rect.x - origin.x, w: rect.h, h: rect.w };
  return { x: rect.y - origin.y, y: rect.x - origin.x, w: rect.h, h: rect.w };
}
function beamSegments(origin, heading, length, width) {
  integer(heading, 0, 3, "beam heading");
  integer(length, 0, MAX_SHAPE * 4, "beam length");
  integer(width, 1, 4096, "beam width");
  const result = [], y = -divide(width, 2).quotient;
  sweepBounds(cardinalRect(origin, { x: 0, y, w: length, h: width }, heading));
  for (let x = 0; x < length; x += MAX_SHAPE)
    result.push(
      cardinalRect(origin, { x, y, w: Math.min(MAX_SHAPE, length - x), h: width }, heading)
    );
  return result;
}
function castBeam(source, definition, profile, origin, heading, terrain, hurtboxes) {
  validateBeamPolicy(source, definition, profile);
  beamSegments(origin, heading, profile.range, profile.width);
  integer(terrain.length + hurtboxes.length, 0, 4096, "beam candidate budget");
  const ids = /* @__PURE__ */ new Set();
  for (const wall of terrain) validateSweepTarget(wall);
  for (const hurt of hurtboxes) {
    integer(hurt.entityId, 1, COUNTER_LIMIT - 1, "beam target identity");
    integer(hurt.team, 0, 255, "beam target team");
    if (hurt.kind !== "body" && hurt.kind !== "shield" || hurt.solid !== void 0 && typeof hurt.solid !== "boolean")
      throw new Error("Invalid beam target material");
    integer(hurt.rect.w, 1, 2 ** 24, "beam target width");
    integer(hurt.rect.h, 1, 2 ** 24, "beam target height");
    sweepBounds(hurt.rect, hurt.delta);
  }
  for (const candidate of [...terrain, ...hurtboxes]) {
    surfaceMaterialFor(candidate);
    integer(candidate.id, 1, COUNTER_LIMIT - 1, "beam collider identity");
    if (ids.has(candidate.id)) throw new Error("Duplicate beam collider identity");
    ids.add(candidate.id);
  }
  const top = -divide(profile.width, 2).quotient, bottom = top + profile.width;
  const candidates = [
    ...terrain.filter((target) => materialBlocks(target, definition.material)).map((target) => ({
      ...target,
      kind: "terrain",
      entityId: null,
      solid: true,
      priority: 0
    })),
    ...hurtboxes.filter(
      (target) => target.entityId !== source.ownerId && (target.solid || target.team !== source.team)
    ).map((target) => ({
      ...target,
      priority: target.kind === "shield" ? 1 : target.solid ? 2 : 3
    }))
  ].flatMap((target) => {
    const rect = forward2(
      { ...target.rect, x: target.rect.x + target.delta.x, y: target.rect.y + target.delta.y },
      origin,
      heading
    );
    if (rect.y >= bottom || rect.y + rect.h <= top || rect.x + rect.w <= 0 || rect.x > profile.range)
      return [];
    return [{ target, rect, distance: Math.max(0, rect.x) }];
  }).sort(
    (a, b) => a.distance - b.distance || a.target.priority - b.target.priority || a.target.id - b.target.id
  );
  const seen = /* @__PURE__ */ new Set(), impacts = [];
  let length = profile.range, stoppedBy = null;
  for (const { target, rect, distance } of candidates) {
    const blocking = (target.kind === "terrain" || target.kind === "shield" || target.solid) && materialBlocks(target, definition.material);
    if (blocking) {
      length = distance;
      stoppedBy = target.kind === "terrain" ? "terrain" : target.kind === "shield" ? "shield" : "solid";
    }
    if (target.entityId === null || !seen.has(target.entityId)) {
      const point2 = cardinalRect(
        origin,
        { x: distance, y: Math.max(rect.y, Math.min(0, rect.y + rect.h)), w: 0, h: 0 },
        heading
      );
      impacts.push({
        sourceId: source.id,
        definitionId: definition.id,
        ownerId: source.ownerId,
        actionInstanceId: source.actionInstanceId,
        colliderId: target.id,
        entityId: target.entityId,
        kind: target.kind,
        damage: target.kind === "body" ? definition.damage : 0,
        time: { numerator: 1, denominator: 1 },
        position: { x: position(point2.x), y: position(point2.y) }
      });
      if (target.entityId !== null) seen.add(target.entityId);
    }
    if (blocking) break;
    if (seen.size === definition.maxTargets) {
      length = distance;
      stoppedBy = "penetration";
      break;
    }
  }
  return {
    origin: { ...origin },
    heading,
    length,
    width: profile.width,
    segments: beamSegments(origin, heading, length, profile.width),
    impacts,
    stoppedBy
  };
}
function validateBeamPulse(beam, definition, profile) {
  validateBeamPolicy(beam, definition, profile);
  integer(beam.spawnTick, 1, COUNTER_LIMIT - 1 - profile.pulseTicks, "beam birth tick");
  integer(beam.tick, beam.spawnTick, beam.spawnTick + profile.pulseTicks - 1, "beam tick");
  integer(beam.length, 0, profile.range, "beam clipped length");
  beamSegments(beam.origin, beam.heading, profile.range, profile.width);
}
function emitBeam(source, tick2, definition, profile, anchor, terrain, hurtboxes) {
  const beam = {
    ...source,
    spawnTick: tick2,
    tick: tick2,
    origin: { ...anchor.origin },
    heading: anchor.heading,
    length: profile.range
  };
  validateBeamPulse(beam, definition, profile);
  const cast = castBeam(
    source,
    definition,
    profile,
    anchor.origin,
    anchor.heading,
    terrain,
    hurtboxes
  );
  beam.length = cast.length;
  return { beam, cast };
}
function stepBeam(current, tick2, definition, profile, anchor, terrain, hurtboxes) {
  validateBeamPulse(current, definition, profile);
  if (tick2 !== current.tick + 1) throw new Error("Beam requires consecutive ticks");
  if (anchor === null || tick2 === current.spawnTick + profile.pulseTicks)
    return { beam: null, cast: null };
  const cast = castBeam(
    current,
    definition,
    profile,
    anchor.origin,
    anchor.heading,
    terrain,
    hurtboxes
  );
  return {
    beam: {
      ...current,
      tick: tick2,
      origin: { ...anchor.origin },
      heading: anchor.heading,
      length: cast.length
    },
    // Moving across a target or restoring this state cannot grant another damage pulse.
    cast: { ...cast, impacts: [] }
  };
}

// src/game/combat/cannon.ts
function stepCannonShell(shell, tick2, definition, body, radius, terrain, hurtboxes) {
  if (definition.id !== shell.definitionId || definition.kind !== "explosion" || definition.material !== "explosive" || definition.repeatDamageTicks !== 0)
    throw new Error("Invalid cannon shell policy");
  integer(tick2 - shell.spawnTick, 1, definition.lifetimeTicks, "cannon flight age");
  integer(radius, 1, 2 ** 16, "cannon blast radius");
  for (const extent of [
    body.rect.x,
    body.rect.y,
    body.rect.x + body.rect.w,
    body.rect.y + body.rect.h
  ])
    integer(extent, -radius, radius, "cannon body inside blast");
  const contact = projectileImpact(shell, body, 0, terrain, hurtboxes);
  if (contact)
    return {
      status: "detonated",
      contact,
      impacts: explosionHits(shell, definition, contact.position, radius, terrain, hurtboxes, {
        time: contact.time,
        primaryTarget: contact.entityId
      })
    };
  const next = {
    ...shell,
    position: {
      x: position(shell.position.x + motion(shell.velocity.x)),
      y: position(shell.position.y + motion(shell.velocity.y))
    }
  };
  return tick2 - shell.spawnTick === definition.lifetimeTicks ? { status: "expired", position: next.position } : { status: "active", shell: next };
}

// src/game/combat/destructible.ts
function createDestructible(definition) {
  surfaceMaterial(definition.materialId);
  return {
    id: definition.id,
    definitionId: definition.definitionId,
    health: definition.health,
    destroyedTick: null,
    destroyerId: null,
    destroyActionId: null
  };
}
function destructibleHurtboxes(props, definitions2) {
  return props.filter((prop) => prop.health > 0).map((prop) => {
    const definition = definitions2.find((definition2) => definition2.id === prop.id);
    if (!definition || definition.definitionId !== prop.definitionId)
      throw new Error("Missing destructible geometry");
    return {
      id: prop.id,
      entityId: prop.id,
      team: 0,
      kind: "body",
      solid: true,
      materialId: definition.materialId,
      rect: { ...definition.rect },
      delta: { x: 0, y: 0 }
    };
  });
}
function damageDestructible(prop, definition, impact2, attack2, tick2) {
  if (definition.id !== prop.id || definition.definitionId !== prop.definitionId)
    throw new Error("Destructible material identity mismatch");
  surfaceMaterial(definition.materialId);
  if (prop.health === 0 || impact2.damage === 0) return false;
  if (impact2.entityId !== prop.id || impact2.kind !== "body" || impact2.definitionId !== attack2.id)
    throw new Error("Destructible damage identity mismatch");
  integer(impact2.damage, 1, attack2.damage, "destructible damage");
  prop.health = Math.max(
    0,
    prop.health - materialDamage(impact2.damage, attack2.material, definition.materialId)
  );
  if (prop.health > 0) return false;
  prop.destroyedTick = tick2;
  prop.destroyerId = impact2.ownerId;
  prop.destroyActionId = impact2.actionInstanceId;
  return true;
}
function detachDestroyedSupport(body, removed) {
  const detached = body.supportId !== null && removed.has(body.supportId);
  if (detached) {
    body.supportId = null;
    body.grounded = false;
  }
  body.contacts = body.contacts.filter((contact) => !removed.has(contact.otherId));
  return detached;
}

// src/game/combat/firearm-aim.ts
function validateFirearmSweep(profile, catalog) {
  const sweep = profile.sweep;
  if (!sweep) return;
  integer(sweep.stepTicks, 1, 60, "firearm heading exposure");
  const reference = catalog.timelines.get(profile.timelineIds[0]);
  if (!reference || sweep.headings.length !== 9) throw new Error("Incomplete firearm sweep");
  for (const [index, heading] of sweep.headings.entries()) {
    if (heading.pitch !== index - 4)
      throw new Error("Firearm headings must cover -4 through 4 in order");
    const timeline = catalog.timelines.get(heading.timelineId);
    if (!timeline || timeline.durationTicks !== reference.durationTicks || canonical(timeline.markers) !== canonical(reference.markers))
      throw new Error("Firearm sweep marker schedules disagree");
    motion(heading.velocity.x);
    motion(heading.velocity.y);
    if (heading.velocity.x < 0 || Math.sign(heading.velocity.y) !== -Math.sign(heading.pitch) || Math.abs(heading.pitch) === 4 !== (heading.velocity.x === 0) || heading.velocity.x === 0 && heading.velocity.y === 0)
      throw new Error("Invalid authored firearm velocity");
    for (const poseId of timeline.poses) {
      const muzzle = catalog.poses.get(poseId)?.sockets.find((socket) => socket.name === "muzzle");
      if (!muzzle || canonical(muzzle.point) !== canonical(heading.muzzle))
        throw new Error("Firearm sweep socket mismatch");
    }
  }
  for (const [pitch, timelineId] of [
    [0, profile.timelineIds[0]],
    [4, profile.timelineIds[1]],
    [-4, profile.timelineIds[2]]
  ])
    if (sweep.headings.find((heading) => heading.pitch === pitch)?.timelineId !== timelineId)
      throw new Error("Firearm cardinal and sweep poses disagree");
}
var cardinalPitch = (actor) => actor.aim === 1 ? 4 : actor.aim === 2 ? -4 : 0;
var lowered = (actor) => actor.life !== "alive" || actor.vehicleId !== null;
var crouched = (actor) => actor.aim === 0 && actor.locomotion === "crouched";
function advanceFirearmAim(actor, tick2, catalog) {
  integer(tick2, 1, COUNTER_LIMIT - 1, "firearm aim tick");
  const profile = catalog.firearms.get(actor.weapon.id);
  if (!profile) throw new Error("Missing firearm aim profile");
  integer(actor.firearmAim.pitch, -4, 4, "firearm pitch");
  integer(
    actor.firearmAim.nextStepTick,
    0,
    tick2 + (profile.sweep?.stepTicks ?? 0),
    "firearm turn tick"
  );
  if (lowered(actor) || crouched(actor)) return { pitch: 0, nextStepTick: 0 };
  const target = cardinalPitch(actor);
  if (!profile.sweep) return { pitch: target, nextStepTick: 0 };
  const aim = { ...actor.firearmAim };
  if (aim.pitch !== target && tick2 >= aim.nextStepTick) {
    aim.pitch += Math.sign(target - aim.pitch);
    aim.nextStepTick = tick2 + profile.sweep.stepTicks;
  }
  return aim;
}
function firearmPoseTimeline(actor, catalog) {
  const profile = catalog.firearms.get(actor.weapon.id);
  if (!profile) throw new Error("Missing firearm profile");
  if (profile.sweep && !crouched(actor)) {
    const heading = profile.sweep.headings.find((value) => value.pitch === actor.firearmAim.pitch);
    if (!heading) throw new Error("Missing authored firearm heading");
    return heading.timelineId;
  }
  return profile.timelineIds[crouched(actor) ? 3 : actor.aim];
}
function firearmVelocity(actor, speed, catalog) {
  const profile = catalog.firearms.get(actor.weapon.id);
  if (!profile) throw new Error("Missing firearm profile");
  if (profile.sweep) {
    const heading = profile.sweep.headings.find((value) => value.pitch === actor.firearmAim.pitch);
    if (!heading) throw new Error("Missing authored firearm velocity");
    return { x: motion(heading.velocity.x * actor.facing), y: heading.velocity.y };
  }
  return {
    x: actor.aim === 0 ? motion(speed * actor.facing) : 0,
    y: actor.aim === 1 ? -speed : actor.aim === 2 ? speed : 0
  };
}

// src/game/combat/firearm.ts
function beginFirearm(current, tick2, nextActionId, catalog) {
  integer(tick2, 1, COUNTER_LIMIT - 1, "firearm tick");
  integer(
    nextActionId,
    current.weapon.lastActionInstanceId + 1,
    COUNTER_LIMIT - 2,
    "firearm allocation"
  );
  if (current.life !== "alive" || current.vehicleId !== null || current.action.kind !== "ready" || current.weapon.cooldownTicks !== 0)
    throw new Error("Firearm action is not ready");
  const actor = structuredClone(current);
  let profile = catalog.firearms.get(actor.weapon.id);
  if (!profile) throw new Error("Missing firearm profile");
  if (actor.weapon.ammo < profile.weapon.ammoPerAction) {
    profile = catalog.firearms.get("sidearm");
    if (profile?.weapon.ammoPerAction !== 0) throw new Error("Missing unlimited sidearm fallback");
    actor.weapon.id = "sidearm";
    actor.weapon.ammo = 0;
    actor.firearmAim = { pitch: actor.aim === 1 ? 4 : actor.aim === 2 ? -4 : 0, nextStepTick: 0 };
  }
  actor.action = {
    kind: "fire",
    actionInstanceId: nextActionId,
    stateStartTick: tick2,
    definitionId: firearmPoseTimeline(actor, catalog),
    nextMarkerIndex: 0
  };
  actor.weapon.ammo -= profile.weapon.ammoPerAction;
  actor.weapon.cooldownTicks = profile.weapon.cadenceTicks;
  actor.weapon.shotOrdinal = nextCounter(actor.weapon.shotOrdinal);
  actor.weapon.lastActionInstanceId = actor.action.actionInstanceId;
  const result = stepAction(actor.action, tick2, catalog);
  actor.action = result.action;
  return { actor, markers: result.markers, nextActionId: nextCounter(nextActionId) };
}
function stepFirearm(current, intent, tick2, nextActionId, catalog) {
  integer(tick2, 1, COUNTER_LIMIT - 1, "firearm tick");
  integer(nextActionId, 1, COUNTER_LIMIT - 2, "next action ID");
  integer(intent.held, 0, HELD_MASK, "firearm held mask");
  if (typeof intent.firePressed !== "boolean") throw new Error("Invalid fire edge");
  if (nextActionId <= current.weapon.lastActionInstanceId)
    throw new Error("Action allocator regressed");
  integer(current.weapon.cooldownTicks, 0, 3600, "weapon cooldown");
  integer(current.weapon.ammo, 0, 65535, "weapon ammunition");
  let actor = structuredClone(current);
  actor.firearmAim = advanceFirearmAim(actor, tick2, catalog);
  actor.weapon.cooldownTicks = Math.max(0, actor.weapon.cooldownTicks - 1);
  let outcome = "none";
  const markers = [];
  const requested = intent.firePressed || Boolean(intent.held & Held.Fire);
  const eligible = actor.life === "alive" && actor.vehicleId === null;
  if (!eligible && actor.action.kind === "fire") actor.action.kind = "ready";
  if (eligible && actor.action.kind === "fire") {
    const nextTimeline = firearmPoseTimeline(actor, catalog);
    if (nextTimeline !== actor.action.definitionId) {
      const prior = catalog.timelines.get(actor.action.definitionId);
      const next = catalog.timelines.get(nextTimeline);
      if (!prior || !next || prior.durationTicks !== next.durationTicks || canonical(prior.markers) !== canonical(next.markers))
        throw new Error("Firearm pose variants disagree on action markers");
      actor.action.definitionId = nextTimeline;
    }
    const result = stepAction(actor.action, tick2, catalog);
    actor.action = result.action;
    markers.push(...result.markers);
    if (result.finished) actor.action.kind = "ready";
  }
  if (requested) {
    if (!eligible || actor.action.kind !== "ready" && actor.action.kind !== "fire")
      outcome = "unavailable";
    else if (actor.weapon.cooldownTicks > 0 || actor.action.kind !== "ready") outcome = "cooldown";
    else {
      const result = beginFirearm(actor, tick2, nextActionId, catalog);
      actor = result.actor;
      nextActionId = result.nextActionId;
      markers.push(...result.markers);
      outcome = "applied";
    }
  }
  return { actor, markers, nextActionId, outcome };
}

// src/game/combat/foot-actions.ts
function stepFootCombatAction(current, intent, tick2, nextActionId, catalog, profiles2, closeTarget) {
  integer(intent.held, 0, HELD_MASK, "foot combat held mask");
  if (typeof intent.firePressed !== "boolean" || typeof intent.grenadePressed !== "boolean" || typeof closeTarget !== "boolean")
    throw new Error("Invalid action arbitration");
  const advanced = stepFirearm(
    current,
    { held: 0, firePressed: false },
    tick2,
    nextActionId,
    catalog
  );
  let actor = advanced.actor;
  const markers = advanced.markers;
  for (const field of ["grenadeCooldownTicks", "meleeCooldownTicks"])
    actor[field] = Math.max(0, integer(actor[field], 0, 3600, field) - 1);
  integer(actor.grenadeStock, 0, 65535, "grenade stock");
  const eligible = actor.life === "alive" && actor.vehicleId === null;
  if (actor.action.kind === "melee" || actor.action.kind === "grenade") {
    if (!eligible) actor.action.kind = "ready";
    else {
      const timeline = profiles2[actor.action.kind].timelineIds[actor.locomotion === "crouched" ? 1 : 0];
      const previous = catalog.timelines.get(actor.action.definitionId), next = catalog.timelines.get(timeline);
      if (!previous || !next || previous.durationTicks !== next.durationTicks || canonical(previous.markers) !== canonical(next.markers))
        throw new Error("Foot action pose markers disagree");
      actor.action.definitionId = timeline;
      const result = stepAction(actor.action, tick2, catalog);
      actor.action = result.action;
      markers.push(...result.markers);
      if (result.finished) actor.action.kind = "ready";
    }
  }
  let fire = "none", grenade = "none";
  const requested = intent.firePressed || Boolean(intent.held & Held.Fire);
  const begin2 = (kind) => {
    const profile = profiles2[kind];
    actor.action = {
      kind,
      actionInstanceId: nextActionId,
      definitionId: profile.timelineIds[actor.locomotion === "crouched" ? 1 : 0],
      stateStartTick: tick2,
      nextMarkerIndex: 0
    };
    nextActionId = nextCounter(nextActionId);
    if (kind === "grenade") {
      actor.grenadeStock--;
      actor.grenadeCooldownTicks = profile.cooldownTicks;
    } else actor.meleeCooldownTicks = profile.cooldownTicks;
    const result = stepAction(actor.action, tick2, catalog);
    actor.action = result.action;
    markers.push(...result.markers);
  };
  if (intent.grenadePressed) {
    if (!eligible || actor.grenadeStock === 0) grenade = "unavailable";
    else if (actor.action.kind !== "ready" || actor.grenadeCooldownTicks > 0) grenade = "cooldown";
    else {
      begin2("grenade");
      grenade = "applied";
    }
  }
  if (requested) {
    if (!eligible) fire = "unavailable";
    else if (actor.action.kind !== "ready" || actor.weapon.cooldownTicks > 0) fire = "cooldown";
    else if (closeTarget && actor.aim === 0 && actor.meleeCooldownTicks === 0) {
      begin2("melee");
      fire = "applied";
    } else {
      const result = beginFirearm(actor, tick2, nextActionId, catalog);
      actor = result.actor;
      nextActionId = result.nextActionId;
      markers.push(...result.markers);
      fire = "applied";
    }
  }
  return { actor, markers, nextActionId, fire, grenade };
}

// src/game/combat/grenade.ts
function grenadeVelocityBounds(profile) {
  return {
    x: Math.max(profile.standingVelocity.x, profile.crouchedVelocity.x) + profile.inheritedVelocityLimit.x,
    up: Math.max(-profile.standingVelocity.y, -profile.crouchedVelocity.y) + profile.inheritedVelocityLimit.y
  };
}
var clamp = (value, limit) => Math.max(-limit, Math.min(limit, value));
function grenadeLaunchVelocity(actor, profile, index, frame) {
  index.assertFrame(frame);
  const support2 = actor.body.supportId === null ? void 0 : index.get(actor.body.supportId);
  if (actor.body.grounded !== (actor.body.supportId !== null) || actor.body.grounded && !support2)
    throw new Error("Grenade launch requires accepted support");
  if (actor.facing !== 1 && actor.facing !== -1) throw new Error("Grenade launch facing");
  const impulse = actor.locomotion === "crouched" ? profile.crouchedVelocity : profile.standingVelocity;
  return {
    x: motion(
      impulse.x * actor.facing + clamp(motion(actor.body.vx) + (support2?.delta.x ?? 0), profile.inheritedVelocityLimit.x)
    ),
    y: motion(
      Math.min(
        profile.terminalVelocity,
        impulse.y + clamp(motion(actor.body.vy) + (support2?.delta.y ?? 0), profile.inheritedVelocityLimit.y)
      )
    )
  };
}
function stepGrenade(current, profile, shape, index, frame) {
  integer(current.spawnTick, 1, frame.tick, "grenade birth");
  integer(current.id, 1, COUNTER_LIMIT - 1, "grenade ID");
  integer(current.bounces, 0, profile.maximumBounces, "grenade bounce count");
  if (shape.id !== profile.bodyShapeId || current.body.id !== current.id)
    throw new Error("Grenade body identity");
  const grenade = structuredClone(current);
  index.assertFrame(frame);
  if (frame.tick === current.spawnTick) return { grenade, status: "active" };
  const vx = grenade.body.vx, vy = motion(Math.min(profile.terminalVelocity, grenade.body.vy + profile.gravity));
  grenade.body.vy = vy;
  const supportId = vy < 0 || !current.body.grounded ? null : startSupport(grenade.body, shape, 1, index, frame, null);
  const carry = supportId === null ? void 0 : index.get(supportId)?.delta;
  const result = stepBody(grenade.body, shape, 1, index, {
    frame,
    carrySupport: current.body.grounded
  });
  if (result.status !== "complete") {
    if (result.reason !== "crushed") throw new Error(`Grenade terrain: ${result.reason}`);
    return {
      status: "crushed",
      position: {
        x: position(result.movement.rect.x - shape.rect.x),
        y: position(result.movement.rect.y - shape.rect.y)
      },
      colliderIds: result.movement.diagnosticIds
    };
  }
  grenade.body = result.body;
  const horizontal = result.movement.contacts.find((contact) => contact.normal.x !== 0);
  const vertical = result.movement.contacts.find((contact) => contact.normal.y !== 0);
  if ((horizontal || vertical) && grenade.bounces < profile.maximumBounces) {
    grenade.bounces++;
    let reboundX = vx + (carry?.x ?? 0), reboundY = vy + (carry?.y ?? 0);
    if (horizontal) {
      const target = index.get(horizontal.otherId);
      if (!target) throw new Error("Missing grenade horizontal contact");
      reboundX = target.delta.x - divide(reboundX - target.delta.x, 2).quotient;
    }
    if (vertical) {
      const target = index.get(vertical.otherId);
      if (!target) throw new Error("Missing grenade vertical contact");
      reboundY = target.delta.y - divide(reboundY - target.delta.y, 2).quotient;
      reboundX = target.delta.x + divide((reboundX - target.delta.x) * 3, 4).quotient;
    }
    const bounds = grenadeVelocityBounds(profile);
    grenade.body.vx = motion(clamp(reboundX, bounds.x));
    grenade.body.vy = motion(Math.max(-bounds.up, Math.min(profile.terminalVelocity, reboundY)));
    grenade.body.grounded = false;
    grenade.body.supportId = null;
  } else if (vertical && grenade.body.grounded)
    grenade.body.vx = divide(grenade.body.vx * 3, 4).quotient;
  return frame.tick - current.spawnTick >= profile.fuseTicks ? { status: "detonated", position: { x: grenade.body.x, y: grenade.body.y } } : { grenade, status: "active" };
}

// src/game/combat/pickups.ts
var MAX_WEAPON_PICKUPS = 64;
function fields(value, expected) {
  if (Object.keys(value).sort().join(" ") !== expected.split(" ").sort().join(" "))
    throw new Error("Unexpected pickup fields");
}
function definitions(defs, catalog) {
  integer(defs.length, 0, MAX_WEAPON_PICKUPS, "pickup budget");
  const ids = /* @__PURE__ */ new Set(), claims = /* @__PURE__ */ new Set(), limits = /* @__PURE__ */ new Map();
  for (const def of defs) {
    fields(
      def,
      "id claimId sourceId kind weaponId ammo ammoLimit activationTick expiresTick supportId rect"
    );
    fields(def.rect, "x y w h");
    for (const value of [def.id, def.claimId, def.sourceId, def.supportId])
      integer(value, 1, COUNTER_LIMIT - 1, "pickup identity");
    if (ids.has(def.id) || claims.has(def.claimId)) throw new Error("Duplicate pickup identity");
    ids.add(def.id);
    claims.add(def.claimId);
    const weapon = catalog.firearms.get(def.weaponId)?.weapon;
    if (def.kind !== "weapon" || !weapon) throw new Error("Unknown pickup content");
    const unlimited = weapon.pickupAmmo === "unlimited";
    integer(def.ammoLimit, unlimited ? 0 : 1, unlimited ? 0 : 65535, "pickup inventory limit");
    integer(def.ammo, unlimited ? 0 : 1, def.ammoLimit, "pickup ammunition");
    if (limits.has(def.weaponId) && limits.get(def.weaponId) !== def.ammoLimit)
      throw new Error("Conflicting pickup inventory limits");
    limits.set(def.weaponId, def.ammoLimit);
    integer(def.activationTick, 1, COUNTER_LIMIT - 2, "pickup activation");
    integer(def.expiresTick, def.activationTick + 1, COUNTER_LIMIT - 1, "pickup expiry");
    integer(def.rect.w, 1, MAX_SHAPE, "pickup width");
    integer(def.rect.h, 1, MAX_SHAPE, "pickup height");
    for (const value of [def.rect.x, def.rect.y, def.rect.x + def.rect.w, def.rect.y + def.rect.h])
      position(value);
  }
}
function supported(def, terrain) {
  const support2 = terrain.find((surface) => surface.id === def.supportId);
  if (support2?.delta.x !== 0 || support2.delta.y !== 0 || def.rect.y + def.rect.h !== support2.rect.y || def.rect.x < support2.rect.x || def.rect.x + def.rect.w > support2.rect.x + support2.rect.w)
    return false;
  return !terrain.some(
    (surface) => surface.kind === "solid" && sweepAabb(def.rect, { x: 0, y: 0 }, surface.rect, surface.delta) !== null
  );
}
function createWeaponPickups(defs, catalog, terrain) {
  definitions(defs, catalog);
  for (const surface of terrain) validateSweepTarget(surface);
  if (defs.some((def) => !supported(def, terrain))) throw new Error("Unsafe pickup spawn");
  return {
    format: 1,
    tick: 0,
    contacts: [],
    items: [...defs].sort((a, b) => a.id - b.id).map((def) => ({
      id: def.id,
      status: "dormant",
      resolvedTick: null,
      claimedBy: null
    }))
  };
}
function validateWeaponPickups(state, defs, catalog, playerIds) {
  definitions(defs, catalog);
  fields(state, "format tick contacts items");
  if (state.format !== 1) throw new Error("Unsupported pickup format");
  integer(state.tick, 0, COUNTER_LIMIT - 1, "pickup tick");
  if (state.items.length !== defs.length) throw new Error("Pickup roster mismatch");
  const ordered2 = [...defs].sort((a, b) => a.id - b.id);
  for (const [index, item] of state.items.entries()) {
    fields(item, "id status resolvedTick claimedBy");
    const def = ordered2[index];
    if (!def || item.id !== def.id) throw new Error("Pickup identity mismatch");
    if (!["dormant", "available", "claimed", "expired", "unsupported"].includes(item.status))
      throw new Error("Unknown pickup status");
    if (item.status === "dormant" || item.status === "available") {
      if (item.resolvedTick !== null || item.claimedBy !== null || state.tick >= def.expiresTick || item.status === "dormant" !== state.tick < def.activationTick)
        throw new Error("Pickup availability mismatch");
    } else {
      integer(
        item.resolvedTick,
        def.activationTick,
        state.tick,
        "pickup resolution tick"
      );
      if (item.status === "expired" ? item.resolvedTick !== def.expiresTick : (item.resolvedTick ?? 0) >= def.expiresTick)
        throw new Error("Pickup lifetime mismatch");
      if (item.status === "claimed" ? !playerIds.has(item.claimedBy) : item.claimedBy !== null)
        throw new Error("Pickup claimant mismatch");
    }
  }
  integer(state.contacts.length, 0, MAX_WEAPON_PICKUPS * 4, "pickup contact budget");
  let previous = { id: 0, playerId: 0 };
  for (const contact of state.contacts) {
    fields(contact, "id playerId");
    if (!playerIds.has(contact.playerId) || !state.items.some((item) => item.id === contact.id && item.status === "available") || contact.id < previous.id || contact.id === previous.id && contact.playerId <= previous.playerId)
      throw new Error("Pickup contact roster/order mismatch");
    previous = contact;
  }
}
function compare2(a, b) {
  const difference2 = a.n * b.d - b.n * a.d;
  return difference2 < 0n ? -1 : difference2 > 0n ? 1 : 0;
}
function firstContact(movement, rect) {
  if (movement.status !== "complete") throw new Error("Unaccepted pickup movement");
  integer(movement.path.length, 1, 5, "pickup movement intervals");
  let elapsed = { n: 0n, d: 1n }, remaining = { n: 1n, d: 1n };
  for (const interval of movement.path) {
    const { numerator: n, denominator: d } = interval.until;
    integer(d, 1, 2 ** 17, "pickup residual denominator");
    integer(n, 0, d, "pickup residual numerator");
    const hit = sweepAabb(interval.rect, interval.motion, rect);
    const time = hit?.kind === "overlap" ? { numerator: 0, denominator: 1 } : hit?.time;
    if (time && compareContactTime(time.numerator, time.denominator, n, d) <= 0) {
      return {
        n: elapsed.n * remaining.d * BigInt(time.denominator) + remaining.n * BigInt(time.numerator) * elapsed.d,
        d: elapsed.d * remaining.d * BigInt(time.denominator)
      };
    }
    elapsed = {
      n: elapsed.n * remaining.d * BigInt(d) + remaining.n * BigInt(n) * elapsed.d,
      d: elapsed.d * remaining.d * BigInt(d)
    };
    remaining = { n: remaining.n * BigInt(d - n), d: remaining.d * BigInt(d) };
  }
  return null;
}
function grant(actor, def, tick2) {
  const previous = { ...actor.weapon };
  const ammo = previous.id === def.weaponId ? Math.min(def.ammoLimit, previous.ammo + def.ammo) : def.ammo;
  if (previous.id === def.weaponId && ammo <= previous.ammo) return null;
  actor.weapon = { ...previous, id: def.weaponId, ammo };
  if (previous.id !== def.weaponId) {
    if (actor.action.kind === "fire")
      actor.action = {
        kind: "ready",
        actionInstanceId: 0,
        stateStartTick: tick2,
        definitionId: 0,
        nextMarkerIndex: 0
      };
    actor.firearmAim = {
      pitch: actor.locomotion === "crouched" ? 0 : actor.aim === 1 ? 4 : actor.aim === 2 ? -4 : 0,
      nextStepTick: 0
    };
  }
  return {
    id: def.id,
    claimId: def.claimId,
    sourceId: def.sourceId,
    playerId: actor.playerId,
    slot: actor.slot,
    tick: tick2,
    weaponId: def.weaponId,
    previousWeaponId: previous.id,
    previousAmmo: previous.ammo,
    ammo
  };
}
function stepWeaponPickups(current, defs, actors, movements, terrain, catalog) {
  integer(actors.length, 1, 4, "pickup players");
  const playerIds = /* @__PURE__ */ new Set(), slots = /* @__PURE__ */ new Set();
  for (const actor of actors) {
    integer(actor.playerId, 1, COUNTER_LIMIT - 1, "pickup player");
    integer(actor.slot, 0, 3, "pickup player slot");
    integer(actor.weapon.ammo, 0, 65535, "pickup player ammunition");
    if (playerIds.has(actor.playerId) || slots.has(actor.slot))
      throw new Error("Duplicate pickup player");
    playerIds.add(actor.playerId);
    slots.add(actor.slot);
  }
  validateWeaponPickups(current, defs, catalog, playerIds);
  for (const surface of terrain) validateSweepTarget(surface);
  const tick2 = integer(current.tick + 1, 1, COUNTER_LIMIT - 1, "next pickup tick");
  const state = structuredClone(current), players = structuredClone([...actors]);
  const byId = new Map(defs.map((def) => [def.id, def]));
  const candidates = [];
  const contacts = [];
  state.tick = tick2;
  for (const item of state.items) {
    if (item.status !== "available" && item.status !== "dormant") continue;
    const def = byId.get(item.id);
    if (!def) throw new Error("Missing pickup content");
    if (tick2 < def.activationTick) continue;
    if (tick2 >= def.expiresTick || !supported(def, terrain)) {
      item.status = tick2 >= def.expiresTick ? "expired" : "unsupported";
      item.resolvedTick = tick2;
      continue;
    }
    item.status = "available";
    for (const player of players) {
      if (player.life !== "alive" || player.bodyPresence !== "present" || player.vehicleId !== null || ["enter", "exit", "hurt"].includes(player.action.kind))
        continue;
      const movement = movements.get(player.playerId);
      if (!movement) continue;
      const time = firstContact(movement, def.rect);
      const end = movement.rect;
      if (time && end.x <= def.rect.x + def.rect.w && end.x + end.w >= def.rect.x && end.y <= def.rect.y + def.rect.h && end.y + end.h >= def.rect.y)
        contacts.push({ id: def.id, playerId: player.playerId });
      if (time && !current.contacts.some(
        (contact) => contact.id === def.id && contact.playerId === player.playerId
      ))
        candidates.push({ item, def, player, time });
    }
  }
  candidates.sort(
    (a, b) => compare2(a.time, b.time) || a.player.slot - b.player.slot || a.def.claimId - b.def.claimId
  );
  const claims = [];
  for (const { item, def, player } of candidates) {
    if (item.status !== "available") continue;
    const claim = grant(player, def, tick2);
    if (!claim) continue;
    item.status = "claimed";
    item.resolvedTick = tick2;
    item.claimedBy = player.playerId;
    claims.push(claim);
  }
  state.contacts = contacts.filter(
    (contact) => state.items.some((item) => item.id === contact.id && item.status === "available")
  ).sort((a, b) => a.id - b.id || a.playerId - b.playerId);
  validateWeaponPickups(state, defs, catalog, playerIds);
  return { state, players, claims };
}

// src/game/combat/rocket.ts
var QUADRANT = [
  [16384, 0],
  [16069, 3196],
  [15137, 6270],
  [13623, 9102],
  [11585, 11585],
  [9102, 13623],
  [6270, 15137],
  [3196, 16069]
];
var HEADINGS = [0, 1, 2, 3].flatMap(
  (quadrant) => QUADRANT.map(
    ([x, y]) => quadrant === 0 ? [x, y] : quadrant === 1 ? [-y, x] : quadrant === 2 ? [-x, -y] : [y, -x]
  )
);
var difference = (from, to) => (to - from + 48) % 32 - 16;
function velocity(heading, speed) {
  const vector = HEADINGS[integer(heading, 0, 31, "rocket heading")];
  if (!vector || vector[0] === void 0 || vector[1] === void 0)
    throw new Error("Missing rocket heading");
  return {
    x: divide(vector[0] * speed, 16384).quotient,
    y: divide(vector[1] * speed, 16384).quotient
  };
}
function headingTo(delta, fallback) {
  if (delta.x === 0 && delta.y === 0) return fallback;
  let best = 0, score = -Infinity;
  for (const [heading, vector] of HEADINGS.entries()) {
    const dot = (vector[0] ?? 0) * delta.x + (vector[1] ?? 0) * delta.y;
    if (dot > score) {
      best = heading;
      score = dot;
    }
  }
  return best;
}
function validateRocketProfile(profile) {
  integer(profile.bodyShapeId, 1, COUNTER_LIMIT - 1, "rocket shape");
  integer(profile.launchSpeed, 1, MAX_MOTION, "rocket launch speed");
  integer(profile.maximumSpeed, profile.launchSpeed, MAX_MOTION, "rocket maximum speed");
  integer(profile.acceleration, 1, MAX_MOTION, "rocket acceleration");
  integer(profile.lifetimeTicks, 1, 3600, "rocket lifetime");
  integer(profile.blastRadius, 1, 2 ** 16, "rocket blast radius");
  integer(profile.acquireRange, 1, MAX_MOTION, "rocket acquisition range");
  integer(profile.retainRange, profile.acquireRange, MAX_MOTION, "rocket retention range");
  integer(profile.acquireSteps, 0, 7, "rocket acquisition cone");
  integer(profile.retainSteps, profile.acquireSteps, 7, "rocket retention cone");
  integer(profile.launchLeashSteps, 0, 7, "rocket launch leash");
  integer(profile.acquireIntervalTicks, 1, 60, "rocket acquisition interval");
  integer(profile.turnIntervalTicks, 1, 60, "rocket turn interval");
}
function validateRocket(rocket2, profile) {
  for (const id2 of [rocket2.id, rocket2.ownerId, rocket2.actionInstanceId, rocket2.definitionId])
    integer(id2, 1, COUNTER_LIMIT - 1, "rocket identity");
  integer(rocket2.team, 1, 255, "rocket team");
  const tail = profile.lifetimeTicks + Math.max(profile.acquireIntervalTicks, profile.turnIntervalTicks);
  integer(rocket2.spawnTick, 1, COUNTER_LIMIT - 1 - tail, "rocket birth tick");
  integer(
    rocket2.tick,
    rocket2.spawnTick,
    rocket2.spawnTick + profile.lifetimeTicks - 1,
    "rocket tick"
  );
  integer(rocket2.launchHeading, 0, 31, "rocket launch heading");
  integer(rocket2.heading, 0, 31, "rocket heading");
  if (Math.abs(difference(rocket2.launchHeading, rocket2.heading)) > profile.launchLeashSteps)
    throw new Error("Rocket exceeded its launch leash");
  const speed = Math.min(
    profile.maximumSpeed,
    profile.launchSpeed + (rocket2.tick - rocket2.spawnTick) * profile.acceleration
  );
  if (rocket2.speed !== speed) throw new Error("Rocket speed disagrees with its age");
  const expected = velocity(rocket2.heading, speed);
  if (rocket2.velocity.x !== expected.x || rocket2.velocity.y !== expected.y)
    throw new Error("Rocket velocity disagrees with its heading");
  position(rocket2.position.x);
  position(rocket2.position.y);
  if (rocket2.targetId !== null) {
    integer(rocket2.targetId, 1, COUNTER_LIMIT - 1, "rocket target");
    if (rocket2.targetId === rocket2.ownerId) throw new Error("Rocket cannot lock its owner");
  }
  integer(
    rocket2.nextAcquireTick,
    rocket2.tick + 1,
    rocket2.tick + profile.acquireIntervalTicks,
    "rocket acquisition clock"
  );
  integer(
    rocket2.nextTurnTick,
    rocket2.tick + 1,
    rocket2.tick + profile.turnIntervalTicks,
    "rocket turn clock"
  );
  if ((rocket2.nextAcquireTick - rocket2.spawnTick - 1) % profile.acquireIntervalTicks !== 0 || (rocket2.nextTurnTick - rocket2.spawnTick) % profile.turnIntervalTicks !== 0)
    throw new Error("Rocket guidance clock phase disagrees with its birth");
}
function createRocket(source, origin, heading, tick2, profile) {
  validateRocketProfile(profile);
  const rocket2 = {
    ...source,
    position: { ...origin },
    velocity: velocity(heading, profile.launchSpeed),
    spawnTick: tick2,
    tick: tick2,
    launchHeading: heading,
    heading,
    speed: profile.launchSpeed,
    targetId: null,
    nextAcquireTick: tick2 + 1,
    nextTurnTick: tick2 + profile.turnIntervalTicks
  };
  validateRocket(rocket2, profile);
  return rocket2;
}
function validateCandidates(terrain, hurtboxes) {
  integer(terrain.length + hurtboxes.length, 0, 4096, "rocket candidates");
  const ids = /* @__PURE__ */ new Set();
  for (const target of terrain) validateSweepTarget(target);
  for (const target of hurtboxes) {
    integer(target.id, 1, COUNTER_LIMIT - 1, "rocket collision ID");
    integer(target.entityId, 1, COUNTER_LIMIT - 1, "rocket hurt entity");
    integer(target.team, 0, 255, "rocket hurt team");
    if (target.kind !== "body" && target.kind !== "shield")
      throw new Error("Invalid rocket hurt kind");
    if (target.solid !== void 0 && typeof target.solid !== "boolean")
      throw new Error("Invalid rocket solid flag");
    sweepBounds(target.rect, target.delta);
    integer(target.rect.w, 1, 2 ** 24, "rocket hurt width");
    integer(target.rect.h, 1, 2 ** 24, "rocket hurt height");
  }
  for (const target of [...terrain, ...hurtboxes]) {
    surfaceMaterialFor(target);
    if (ids.has(target.id)) throw new Error("Duplicate rocket collision ID");
    ids.add(target.id);
  }
}
function guidanceTargets(rocket2, profile, terrain, hurtboxes, retaining) {
  const range = retaining ? profile.retainRange : profile.acquireRange, steps = retaining ? profile.retainSteps : profile.acquireSteps;
  const candidates = hurtboxes.flatMap((target) => {
    if (target.kind !== "body" || target.solid || target.team === 0 || target.team === rocket2.team || target.entityId === rocket2.ownerId || retaining && target.entityId !== rocket2.targetId)
      return [];
    const center = {
      x: target.rect.x + divide(target.rect.w, 2).quotient,
      y: target.rect.y + divide(target.rect.h, 2).quotient
    }, delta = { x: center.x - rocket2.position.x, y: center.y - rocket2.position.y }, distance = delta.x * delta.x + delta.y * delta.y, heading = headingTo(delta, rocket2.heading);
    if (distance > range * range || Math.abs(difference(rocket2.heading, heading)) > steps || Math.abs(difference(rocket2.launchHeading, heading)) > profile.launchLeashSteps)
      return [];
    return [{ target, delta, distance, heading }];
  }).sort(
    (a, b) => a.distance - b.distance || a.target.entityId - b.target.entityId || a.target.id - b.target.id
  );
  const blockers = [
    ...terrain,
    ...hurtboxes.filter(
      (target) => target.solid || target.kind === "shield" && target.team !== rocket2.team && target.entityId !== rocket2.ownerId
    )
  ];
  for (const candidate of candidates) {
    if (!blockers.some(
      (target) => sweepAabb({ ...rocket2.position, w: 0, h: 0 }, candidate.delta, target.rect)
    ))
      return candidate;
  }
  return null;
}
function stepRocket(current, tick2, definition, shape, profile, terrain, hurtboxes) {
  validateRocketProfile(profile);
  validateRocket(current, profile);
  if (tick2 !== current.tick + 1) throw new Error("Rocket requires consecutive ticks");
  if (definition.id !== current.definitionId || definition.kind !== "explosion" || definition.material !== "explosive" || definition.lifetimeTicks !== profile.lifetimeTicks || definition.speed !== profile.launchSpeed || definition.repeatDamageTicks !== 0 || shape.id !== profile.bodyShapeId)
    throw new Error("Invalid rocket attack policy");
  integer(definition.damage, 1, 65535, "rocket damage");
  integer(definition.maxTargets, 1, 64, "rocket blast targets");
  worldRect(current.position, shape.rect, 1);
  const extentX = Math.max(Math.abs(shape.rect.x), Math.abs(shape.rect.x + shape.rect.w)), extentY = Math.max(Math.abs(shape.rect.y), Math.abs(shape.rect.y + shape.rect.h));
  if (extentX * extentX + extentY * extentY > profile.blastRadius * profile.blastRadius)
    throw new Error("Rocket blast must enclose its flight body");
  validateCandidates(terrain, hurtboxes);
  const rocket2 = structuredClone(current);
  let lock = rocket2.targetId === null ? null : guidanceTargets(rocket2, profile, terrain, hurtboxes, true);
  if (!lock) rocket2.targetId = null;
  if (tick2 >= rocket2.nextAcquireTick) {
    if (!lock) lock = guidanceTargets(rocket2, profile, terrain, hurtboxes, false);
    rocket2.nextAcquireTick = tick2 + profile.acquireIntervalTicks;
  }
  rocket2.targetId = lock?.target.entityId ?? null;
  if (tick2 >= rocket2.nextTurnTick) {
    if (lock)
      rocket2.heading = (rocket2.heading + Math.sign(difference(rocket2.heading, lock.heading)) + 32) % 32;
    rocket2.nextTurnTick = tick2 + profile.turnIntervalTicks;
  }
  rocket2.speed = Math.min(profile.maximumSpeed, rocket2.speed + profile.acceleration);
  rocket2.velocity = velocity(rocket2.heading, rocket2.speed);
  const contact = projectileImpact(rocket2, shape, 0, terrain, hurtboxes);
  if (contact)
    return {
      status: "detonated",
      contact,
      // Contact selects the blast origin/time; it never grants a second direct-hit debit.
      impacts: explosionHits(
        rocket2,
        definition,
        contact.position,
        profile.blastRadius,
        terrain,
        hurtboxes,
        { time: contact.time, primaryTarget: contact.entityId }
      )
    };
  rocket2.position = {
    x: position(rocket2.position.x + motion(rocket2.velocity.x)),
    y: position(rocket2.position.y + motion(rocket2.velocity.y))
  };
  rocket2.tick = tick2;
  return tick2 - rocket2.spawnTick >= profile.lifetimeTicks ? { status: "expired", position: rocket2.position } : { status: "active", rocket: rocket2 };
}

// src/game/content/scenarios/materials.ts
var MATERIAL_LAB_WEAPONS = [
  "sidearm",
  "heavy-machine-gun",
  "shotgun",
  "rocket-launcher",
  "flamethrower",
  "laser",
  "knife",
  "grenade"
];
var MATERIAL_TARGET_MOTIONS = ["stationary", "patrol"];
var MATERIAL_CASES = MATERIAL_LAB_WEAPONS.flatMap(
  (weapon) => SURFACE_MATERIAL_IDS.flatMap(
    (materialId) => MATERIAL_TARGET_MOTIONS.map((targetMotion) => ({ weapon, materialId, targetMotion }))
  )
);
function materialScenario(definition) {
  if (!MATERIAL_LAB_WEAPONS.includes(definition.weapon) || !MATERIAL_TARGET_MOTIONS.includes(definition.targetMotion))
    throw new Error("Unknown material calibration case");
  surfaceMaterial(definition.materialId);
  return `material:${definition.weapon}:${definition.materialId}:${definition.targetMotion}`;
}
var MATERIAL_SCENARIOS = MATERIAL_CASES.map(materialScenario);
var cases = new Map(
  MATERIAL_SCENARIOS.map((scenario, index) => [scenario, MATERIAL_CASES[index]])
);
function materialCase(scenario) {
  return cases.get(scenario) ?? null;
}
var MATERIAL_CALIBRATION = {
  definitionId: 5,
  firstTargetX: pixels(112),
  targetSpacing: pixels(24),
  targetY: pixels(200),
  targetHealth: 32,
  patrolSpeed: 64,
  bounds: { x: 0, y: 0, w: pixels(384), h: pixels(232) },
  fallBoundary: pixels(248)
};
function materialPlayerX(weapon) {
  return pixels(weapon === "knife" ? 70 : weapon === "grenade" ? 10 : 45);
}
function materialLabProp(definition) {
  surfaceMaterial(definition.materialId);
  return {
    id: 200,
    definitionId: 10 + SURFACE_MATERIAL_IDS.indexOf(definition.materialId),
    materialId: definition.materialId,
    rect: { x: pixels(92), y: pixels(80), w: pixels(2), h: pixels(120) },
    health: 8
  };
}

// src/game/content/weapons/laser.ts
var LASER_WEAPON = {
  id: "laser",
  attackId: 18,
  timelineId: 230,
  cadenceTicks: 6,
  ammoPerAction: 1,
  pickupAmmo: 120,
  aimPolicy: "cardinal",
  visualFamily: "fixture-laser",
  audioFamily: "fixture-laser"
};
var LASER_PROFILE = { range: pixels(512), width: pixels(4), pulseTicks: 6 };
var LASER_SHAPE = {
  id: 21,
  rect: { x: 0, y: -pixels(2), w: pixels(256), h: pixels(4) }
};
var LASER_ATTACK = {
  id: LASER_WEAPON.attackId,
  kind: "beam",
  shapeId: LASER_SHAPE.id,
  damage: 2,
  lifetimeTicks: 6,
  speed: 0,
  maxTargets: 8,
  repeatDamageTicks: 6,
  material: "energy"
};
validateBeamProfile(LASER_PROFILE);

// src/game/content/weapons/rocket-launcher.ts
var ROCKET_WEAPON = {
  id: "rocket-launcher",
  attackId: 17,
  timelineId: 220,
  cadenceTicks: 24,
  ammoPerAction: 1,
  pickupAmmo: 20,
  aimPolicy: "cardinal",
  visualFamily: "fixture-rocket",
  audioFamily: "fixture-rocket"
};
var ROCKET_SHAPE = {
  id: 19,
  rect: { x: -pixels(2), y: -pixels(2), w: pixels(4), h: pixels(4) }
};
var ROCKET_BLAST_SHAPE = {
  id: 20,
  rect: { x: -pixels(48), y: -pixels(48), w: pixels(96), h: pixels(96) }
};
var ROCKET_PROFILE = {
  bodyShapeId: ROCKET_SHAPE.id,
  launchSpeed: pixels(2),
  acceleration: 128,
  maximumSpeed: pixels(6),
  lifetimeTicks: 90,
  blastRadius: pixels(48),
  acquireRange: pixels(240),
  retainRange: pixels(256),
  acquireSteps: 2,
  retainSteps: 4,
  launchLeashSteps: 4,
  acquireIntervalTicks: 6,
  turnIntervalTicks: 3
};
var ROCKET_ATTACK = {
  id: ROCKET_WEAPON.attackId,
  kind: "explosion",
  shapeId: ROCKET_BLAST_SHAPE.id,
  damage: 4,
  lifetimeTicks: ROCKET_PROFILE.lifetimeTicks,
  speed: ROCKET_PROFILE.launchSpeed,
  maxTargets: 16,
  repeatDamageTicks: 0,
  material: "explosive"
};
validateRocketProfile(ROCKET_PROFILE);

// src/game/content/weapons/tank-cannon.ts
var CANNON_SHAPE = {
  id: 22,
  rect: { x: pixels(-4), y: pixels(-4), w: pixels(8), h: pixels(8) }
};
var CANNON_BLAST_SHAPE = {
  id: 23,
  rect: { x: pixels(-56), y: pixels(-56), w: pixels(112), h: pixels(112) }
};
var CANNON_ATTACK = {
  id: 19,
  kind: "explosion",
  shapeId: CANNON_BLAST_SHAPE.id,
  damage: 6,
  lifetimeTicks: 90,
  speed: pixels(12),
  maxTargets: 16,
  repeatDamageTicks: 0,
  material: "explosive"
};
var CANNON_PROFILE = {
  attackId: CANNON_ATTACK.id,
  bodyShapeId: CANNON_SHAPE.id,
  stock: 10,
  cadenceTicks: 45,
  blastRadius: pixels(56),
  fireTimelineIds: Array.from({ length: 8 }, (_, heading) => 240 + heading),
  releaseTick: 3,
  // The muzzle stays extended through release, then the barrel recoils and returns.
  recoil: [0, 0, 0, 0, 3, 4, 3, 2, 1, 0, 0, 0].map(pixels),
  hardpoint: { x: 0, y: pixels(-14) },
  headings: [
    [30, -14, 12, 0],
    [22, -36, 8, -8],
    [0, -44, 0, -12],
    [-22, -36, -8, -8],
    [-30, -14, -12, 0],
    [-22, 8, -8, 8],
    [0, 16, 0, 12],
    [22, 8, 8, 8]
  ].map(([x = 0, y = 0, vx = 0, vy = 0]) => ({
    muzzle: { x: pixels(x), y: pixels(y) },
    velocity: { x: pixels(vx), y: pixels(vy) }
  }))
};

// src/game/controller/foot.ts
function clone(actor) {
  return {
    ...actor,
    body: { ...actor.body, contacts: actor.body.contacts.map((contact) => ({ ...contact })) },
    action: { ...actor.action }
  };
}
function required(shapes, id2) {
  const value = shapes.get(id2);
  if (!value || value.id !== id2) throw new Error(`Missing controller shape ${id2}`);
  return value;
}
function stepFootController(current, intent, definition, shapes, index, frame, controlsLocked = false) {
  index.assertFrame(frame);
  integer(intent.held, 0, HELD_MASK, "controller held mask");
  if (typeof intent.jumpPressed !== "boolean") throw new Error("Invalid jump edge intent");
  if (current.geometryRevision !== index.frame.geometryRevision)
    throw new Error("Controller geometry revision mismatch");
  integer(current.jumpBufferTicks, 0, ARCADE.jumpBufferTicks, "jump buffer");
  integer(current.coyoteTicks, 0, ARCADE.coyoteTicks, "coyote timer");
  integer(current.ignoredSupportTicks, 0, ARCADE.dropThroughTicks, "drop timer");
  if (current.ignoredSupportId !== null)
    integer(current.ignoredSupportId, 1, COUNTER_LIMIT - 1, "ignored support ID");
  const actor = clone(current);
  if (actor.life !== "alive" || actor.vehicleId !== null || actor.locomotion === "seated" || actor.action.kind === "enter" || actor.action.kind === "exit")
    return { status: "inactive", actor };
  if (definition.locomotion !== "grounded" || definition.gravity <= 0 || definition.jumpVelocity + definition.gravity >= 0 || definition.terminalVelocity <= 0 || definition.runSpeed < 0)
    throw new Error("Invalid foot controller definition");
  for (const value of [
    definition.gravity,
    definition.jumpVelocity,
    definition.terminalVelocity,
    definition.runSpeed
  ])
    motion(value);
  const standing = required(shapes, definition.standingShapeId);
  const crouched2 = required(shapes, definition.crouchedShapeId);
  if (standing.rect.y + standing.rect.h !== 0 || crouched2.rect.y + crouched2.rect.h !== 0 || crouched2.rect.y < standing.rect.y || crouched2.rect.x < standing.rect.x || crouched2.rect.x + crouched2.rect.w > standing.rect.x + standing.rect.w)
    throw new Error("Controller stances must share feet and crouch within standing bounds");
  if (actor.body.shapeId !== standing.id && actor.body.shapeId !== crouched2.id)
    throw new Error("Unknown controller stance");
  if (actor.body.remainderX !== 0 || actor.body.remainderY !== 0)
    throw new Error("Unsupported controller motion remainder");
  let shape = required(shapes, actor.body.shapeId);
  if (actor.ignoredSupportTicks === 0 || !index.get(actor.ignoredSupportId ?? 0)) {
    actor.ignoredSupportId = null;
    actor.ignoredSupportTicks = 0;
  }
  const touchingSupport = startSupport(
    actor.body,
    shape,
    actor.facing,
    index,
    frame,
    actor.ignoredSupportId
  );
  const support2 = actor.body.vy < 0 ? null : touchingSupport;
  const wasGrounded = current.body.grounded;
  actor.body.supportId = support2;
  actor.body.grounded = support2 !== null;
  const locked = controlsLocked || actor.action.kind === "hurt";
  const held = locked ? 0 : intent.held;
  const direction = directionalIntent(held, actor.facing, support2 !== null);
  if (locked) actor.jumpBufferTicks = 0;
  else if (intent.jumpPressed) actor.jumpBufferTicks = ARCADE.jumpBufferTicks;
  if (support2 !== null) actor.coyoteTicks = ARCADE.coyoteTicks;
  let jumpRequest = intent.jumpPressed ? locked ? "unavailable" : "buffered" : "none";
  const supportTarget = index.get(support2 ?? 0);
  const canJump = !locked && actor.jumpBufferTicks > 0 && (support2 !== null || actor.coyoteTicks > 0);
  let dropping = canJump && direction.vertical > 0 && supportTarget?.kind === "one-way";
  let dropQueuedAtEnd = false;
  let isCrouched = actor.locomotion === "crouched" || crouched2.id !== standing.id && shape.id === crouched2.id;
  const wantsCrouch = locked ? isCrouched : direction.crouch && (!canJump || dropping);
  const desired = wantsCrouch ? crouched2 : standing;
  const nextFacing = locked ? actor.facing : direction.facing;
  let changed = tryBodyShape(actor.body, shape, desired, actor.facing, nextFacing, index, frame);
  if (!changed.accepted && desired.id === standing.id && isCrouched)
    changed = tryBodyShape(actor.body, shape, crouched2, actor.facing, nextFacing, index, frame);
  if (changed.accepted) {
    actor.body = changed.body;
    actor.facing = changed.facing;
    shape = required(shapes, actor.body.shapeId);
    isCrouched = shape.id === crouched2.id && (standing.id !== crouched2.id || wantsCrouch);
  }
  actor.body.vx = locked ? actor.action.kind === "hurt" ? actor.body.vx : 0 : isCrouched && support2 !== null ? 0 : direction.horizontal * definition.runSpeed;
  actor.body.vy = Math.min(definition.terminalVelocity, actor.body.vy + definition.gravity);
  const events = [];
  let jumped = false;
  if (dropping) {
    actor.ignoredSupportId = support2;
    actor.ignoredSupportTicks = ARCADE.dropThroughTicks;
    actor.body.supportId = null;
    actor.body.grounded = false;
    actor.body.vy = Math.max(definition.gravity, actor.body.vy);
    actor.jumpBufferTicks = 0;
    actor.coyoteTicks = 0;
    jumpRequest = "consumed";
    events.push({ kind: "drop", tick: frame.tick, supportId: support2 });
  } else if (canJump && !isCrouched) {
    actor.body.vy = definition.jumpVelocity + definition.gravity;
    actor.body.supportId = null;
    actor.body.grounded = false;
    actor.jumpBufferTicks = 0;
    actor.coyoteTicks = 0;
    jumped = true;
    jumpRequest = "consumed";
    events.push({ kind: "jump", tick: frame.tick, supportId: support2 });
  }
  const physics = stepBody(actor.body, shape, actor.facing, index, {
    frame,
    ...actor.ignoredSupportId === null ? {} : { ignoredOneWayId: actor.ignoredSupportId }
  });
  if (physics.status !== "complete") return { status: "failed", physics };
  actor.body = physics.body;
  const landed = support2 === null && actor.body.grounded;
  if (landed) events.push({ kind: "land", tick: frame.tick, supportId: actor.body.supportId });
  if ((support2 !== null || wasGrounded) && !actor.body.grounded && !jumped && !dropping)
    events.push({
      kind: "leave-support",
      tick: frame.tick,
      supportId: support2 ?? current.body.supportId
    });
  if (!locked && actor.body.grounded && direction.vertical > 0) {
    const crouchAtEnd = tryBodyShape(
      actor.body,
      shape,
      crouched2,
      actor.facing,
      actor.facing,
      index,
      frame,
      "end"
    );
    if (crouchAtEnd.accepted) {
      actor.body = crouchAtEnd.body;
      shape = crouched2;
      isCrouched = true;
    }
  }
  if (!locked && actor.body.grounded && actor.jumpBufferTicks > 0) {
    const landedOn = actor.body.supportId;
    const landedTarget = index.get(landedOn ?? 0);
    if (direction.vertical > 0 && landedTarget?.kind === "one-way") {
      actor.ignoredSupportId = landedOn;
      actor.ignoredSupportTicks = ARCADE.dropThroughTicks;
      actor.body = { ...actor.body, vy: 0, grounded: false, supportId: null };
      actor.jumpBufferTicks = 0;
      actor.coyoteTicks = 0;
      dropping = true;
      dropQueuedAtEnd = true;
      jumpRequest = "consumed";
      events.push({ kind: "drop", tick: frame.tick, supportId: landedOn });
    } else {
      const standingAtEnd = tryBodyShape(
        actor.body,
        shape,
        standing,
        actor.facing,
        actor.facing,
        index,
        frame,
        "end"
      );
      if (standingAtEnd.accepted) {
        actor.body = {
          ...standingAtEnd.body,
          vy: definition.jumpVelocity,
          supportId: null,
          grounded: false
        };
        shape = standing;
        isCrouched = false;
        actor.jumpBufferTicks = 0;
        actor.coyoteTicks = 0;
        jumped = true;
        jumpRequest = "consumed";
        events.push({ kind: "jump", tick: frame.tick, supportId: landedOn });
      }
    }
  }
  if (!jumped && !dropping)
    actor.coyoteTicks = actor.body.grounded || support2 !== null ? ARCADE.coyoteTicks : Math.max(0, actor.coyoteTicks - 1);
  actor.jumpBufferTicks = Math.max(0, actor.jumpBufferTicks - 1);
  if (actor.ignoredSupportId !== null) {
    if (!dropQueuedAtEnd) actor.ignoredSupportTicks = Math.max(0, actor.ignoredSupportTicks - 1);
    const ignored = index.get(actor.ignoredSupportId);
    const feet = worldRect(actor.body, shape.rect, actor.facing);
    if (!ignored || actor.ignoredSupportTicks === 0 || feet.y + feet.h > ignored.rect.y + ignored.delta.y + ignored.rect.h) {
      actor.ignoredSupportId = null;
      actor.ignoredSupportTicks = 0;
    }
  }
  actor.locomotion = actor.body.grounded ? isCrouched ? "crouched" : "grounded" : "airborne";
  if (!locked) actor.aim = directionalIntent(held, actor.facing, actor.body.grounded).aim;
  return { status: "complete", actor, events, jumpRequest, physics };
}

// src/game/encounters/lifecycle.ts
var POSE_FAULTS = ["initial-overlap", "residual-overlap", "contact-limit", "unresolved-contact"];
function check2(ok, message) {
  if (!ok) throw new Error(`Encounter: ${message}`);
}
function id(value) {
  return integer(value, 1, COUNTER_LIMIT - 1, "encounter ID");
}
function tick(value) {
  return integer(value, 0, COUNTER_LIMIT - 2, "encounter tick");
}
function unique(values) {
  for (const value of values) id(value);
  check2(new Set(values).size === values.length, "duplicate ID");
}
function encounterCounts(state) {
  return {
    pending: state.members.filter((m) => m.status === "pending").length,
    alive: state.members.filter((m) => m.status === "alive").length,
    resolved: state.members.filter((m) => m.status === "resolved").length
  };
}
var EncounterLifecycle = class {
  #definition;
  #key;
  constructor(definition) {
    id(definition.id);
    integer(definition.participants.length, 1, 4, "participant count");
    integer(definition.members.length, 0, 256, "member count");
    integer(definition.objectives.length, 0, 64, "objective count");
    unique(definition.participants);
    unique(definition.members.map((m) => m.id));
    unique(definition.objectives);
    for (const member of definition.members) {
      for (const flag of [member.required, member.critical, member.retreatAllowed])
        check2(typeof flag === "boolean", "member flag");
      integer(member.watchdogTicks, 1, 36e3, "watchdog duration");
      check2(
        !member.critical || member.required && !member.retreatAllowed,
        "critical actor policy"
      );
      if (member.ambientCleanupTicks !== null) {
        integer(
          member.ambientCleanupTicks,
          member.watchdogTicks,
          36e3,
          "ambient cleanup duration"
        );
        check2(!member.required && !member.critical, "required actor cannot use ambient cleanup");
      }
    }
    this.#definition = structuredClone(definition);
    this.#definition.members.sort((a, b) => a.id - b.id);
    this.#definition.participants.sort((a, b) => a - b);
    this.#definition.objectives.sort((a, b) => a - b);
    this.#key = canonical(this.#definition);
    Object.freeze(this);
  }
  begin(startTick = 0) {
    tick(startTick);
    return {
      definitionKey: this.#key,
      tick: startTick,
      phase: "active",
      members: this.#definition.members.map((m) => ({
        id: m.id,
        status: "pending",
        activatedTick: null,
        resolvedTick: null,
        reason: null,
        killerId: null,
        progressKey: null,
        unchangedSince: null,
        unreachableSince: null,
        warnedUnchanged: false,
        warnedUnreachable: false
      })),
      objectives: this.#definition.objectives.map((id2) => ({ id: id2, completedTick: null })),
      kills: this.#definition.participants.map((playerId) => ({ playerId, count: 0 })),
      receipts: [],
      failure: null
    };
  }
  remaining(state) {
    if (state.phase === "retired") return 0;
    return state.members.filter(
      (m, i) => this.#definition.members[i]?.required && m.status !== "resolved"
    ).length + state.objectives.filter((o) => o.completedTick === null).length;
  }
  /** Check a saved continuation without advancing clocks, watchdogs or event receipts. */
  restore(state) {
    this.#validate(state);
    return structuredClone(state);
  }
  step(current, atTick, events, observations, failureMode = "record") {
    this.#validate(current);
    tick(atTick);
    check2(atTick === current.tick + 1, "nonconsecutive tick");
    check2(failureMode === "record" || failureMode === "throw", "failure mode");
    integer(events.length, 0, 1024, "event batch size");
    integer(observations.length, 0, 256, "observation count");
    const state = structuredClone(current);
    state.tick = atTick;
    const notices = [];
    const fail = (memberId, reason, cause) => {
      if (state.failure) return;
      state.failure = { id: memberId, tick: atTick, reason, cause };
      state.phase = "failed";
      notices.push({
        kind: "failed",
        encounterId: this.#definition.id,
        failure: { ...state.failure }
      });
    };
    for (const event of [...events].sort((a, b) => a.sequence - b.sequence)) {
      integer(event.sequence, 1, 1024, "event sequence");
      tick(event.tick);
      const signature = canonical(event);
      if (event.sequence <= state.receipts.length) {
        check2(state.receipts[event.sequence - 1] === signature, "conflicting duplicate event");
        continue;
      }
      check2(event.sequence === state.receipts.length + 1, "event sequence gap");
      check2(event.tick === atTick, "event effective tick mismatch");
      check2(
        state.phase !== "retired" && current.phase !== "failed",
        "event after terminal encounter"
      );
      if (event.kind === "retire") {
        check2(!state.failure, "cannot retire failed encounter");
        check2(Object.keys(event).length === 3, "retire event fields");
        for (const member of state.members)
          if (member.status !== "resolved") {
            member.status = "resolved";
            member.reason = "checkpoint-retired";
            member.resolvedTick = atTick;
          }
        state.phase = "retired";
        notices.push({ kind: "retired", tick: atTick, encounterId: this.#definition.id });
      } else if (event.kind === "objective") {
        check2(Object.keys(event).length === 4, "objective event fields");
        const objective = state.objectives.find((o) => o.id === event.id);
        check2(objective && objective.completedTick === null, "unknown/completed objective");
        objective.completedTick = atTick;
      } else {
        const index = state.members.findIndex((m) => m.id === event.id), member = state.members[index], policy = this.#definition.members[index];
        check2(member && policy, "unknown member");
        if (event.kind === "activate") {
          check2(Object.keys(event).length === 4, "activation fields");
          check2(member.status === "pending", "member already activated/resolved");
          member.status = "alive";
          member.activatedTick = atTick;
        } else if (event.kind === "fault") {
          check2(
            Object.keys(event).length === 5 && POSE_FAULTS.includes(event.reason),
            "pose fault fields"
          );
          check2(member.status === "alive", "fault of nonliving member");
          fail(event.id, policy.critical ? "critical-loss" : "invalid-pose", event.reason);
        } else {
          check2(event.kind === "resolve" && Object.keys(event).length === 6, "resolution fields");
          check2(member.status === "alive", "resolution of nonliving member");
          check2(
            ["killed", "retreated", "crushed", "out-of-bounds"].includes(event.reason),
            "resolution reason"
          );
          check2(
            event.killerId === null || event.reason === "killed" && this.#definition.participants.includes(event.killerId),
            "invalid kill attribution"
          );
          member.status = "resolved";
          member.resolvedTick = atTick;
          member.reason = event.reason;
          member.killerId = event.killerId;
          if (event.killerId !== null) {
            const credit = state.kills.find((k) => k.playerId === event.killerId);
            check2(credit, "unknown participant");
            credit.count++;
          }
          if (policy.critical && event.reason !== "killed")
            fail(event.id, "critical-loss", event.reason);
          else if (event.reason === "retreated" && !policy.retreatAllowed)
            fail(event.id, "forbidden-retreat", event.reason);
        }
      }
      state.receipts.push(signature);
    }
    const observed = /* @__PURE__ */ new Map();
    for (const observation of observations) {
      id(observation.id);
      check2(!observed.has(observation.id), "duplicate observation");
      check2(
        typeof observation.progressKey === "string" && observation.progressKey.length > 0 && observation.progressKey.length <= 256 && typeof observation.unreachable === "boolean",
        "invalid progress observation"
      );
      check2(
        state.members.some((m) => m.id === observation.id),
        "unknown observed member"
      );
      observed.set(observation.id, observation);
    }
    if (state.phase !== "failed" && state.phase !== "retired") {
      for (let i = 0; i < state.members.length; i++) {
        const member = state.members[i], policy = this.#definition.members[i];
        check2(member && policy, "missing member policy");
        if (member.status !== "alive") continue;
        const observation = observed.get(member.id);
        check2(observation, "missing living member observation");
        if (member.progressKey !== observation.progressKey) {
          member.progressKey = observation.progressKey;
          member.unchangedSince = atTick;
          member.warnedUnchanged = false;
        }
        if (!observation.unreachable) {
          member.unreachableSince = null;
          member.warnedUnreachable = false;
        } else if (member.unreachableSince === null) member.unreachableSince = atTick;
        for (const reason of ["unchanged", "unreachable"]) {
          const since = reason === "unchanged" ? member.unchangedSince : member.unreachableSince;
          const warned = reason === "unchanged" ? member.warnedUnchanged : member.warnedUnreachable;
          if (since !== null && atTick - since >= policy.watchdogTicks && !warned) {
            notices.push({
              kind: "watchdog",
              tick: atTick,
              encounterId: this.#definition.id,
              id: member.id,
              sinceTick: since,
              reason,
              progressKey: observation.progressKey
            });
            if (reason === "unchanged") member.warnedUnchanged = true;
            else member.warnedUnreachable = true;
          }
        }
        const stalledSince = member.unreachableSince ?? member.unchangedSince;
        if (policy.ambientCleanupTicks !== null && stalledSince !== null && atTick - stalledSince >= policy.ambientCleanupTicks) {
          member.status = "resolved";
          member.resolvedTick = atTick;
          member.reason = "ambient-timeout";
          notices.push({
            kind: "remove-ambient",
            tick: atTick,
            id: member.id,
            reason: "ambient-timeout"
          });
        }
      }
      if (state.phase === "active" && this.remaining(state) === 0) {
        state.phase = "complete";
        notices.push({ kind: "complete", tick: atTick, encounterId: this.#definition.id });
      }
    }
    if (failureMode === "throw" && state.failure)
      throw new Error(
        `Encounter ${this.#definition.id} ${state.failure.reason}: ${state.failure.id} at ${state.failure.tick}`
      );
    return { state, notices, remaining: this.remaining(state), counts: encounterCounts(state) };
  }
  #validate(state) {
    check2(state.definitionKey === this.#key, "definition mismatch");
    tick(state.tick);
    check2(["active", "complete", "retired", "failed"].includes(state.phase), "phase");
    check2(
      state.members.length === this.#definition.members.length && state.members.every((m, i) => m.id === this.#definition.members[i]?.id),
      "roster mismatch"
    );
    check2(
      state.objectives.length === this.#definition.objectives.length && state.objectives.every((o, i) => o.id === this.#definition.objectives[i]),
      "objective roster mismatch"
    );
    check2(
      state.kills.length === this.#definition.participants.length && state.kills.every((k, i) => k.playerId === this.#definition.participants[i]),
      "participant mismatch"
    );
    integer(state.receipts.length, 0, 1024, "receipt count");
    for (let i = 0; i < state.receipts.length; i++) {
      const receipt = state.receipts[i];
      check2(typeof receipt === "string" && receipt.length <= 512, "receipt length");
      const event = JSON.parse(receipt);
      tick(event.tick);
      check2(
        event.sequence === i + 1 && event.tick <= state.tick && canonical(event) === receipt,
        "receipt continuation"
      );
    }
    for (const member of state.members) {
      check2(["pending", "alive", "resolved"].includes(member.status), "member status");
      for (const value of [
        member.activatedTick,
        member.resolvedTick,
        member.unchangedSince,
        member.unreachableSince
      ])
        if (value !== null) {
          tick(value);
          check2(value <= state.tick, "future member tick");
        }
      check2(
        member.status === "resolved" === (member.reason !== null) && member.status === "resolved" === (member.resolvedTick !== null),
        "resolution state"
      );
      check2(
        member.reason === null || [
          "killed",
          "retreated",
          "crushed",
          "out-of-bounds",
          "ambient-timeout",
          "checkpoint-retired"
        ].includes(member.reason),
        "unknown saved resolution"
      );
      check2(
        member.killerId === null || member.reason === "killed" && this.#definition.participants.includes(member.killerId),
        "saved kill attribution"
      );
      check2(member.status !== "alive" || member.activatedTick !== null, "missing activation");
      check2(
        member.status !== "pending" || member.activatedTick === null && member.progressKey === null && member.unchangedSince === null && member.unreachableSince === null,
        "pending member continuation"
      );
      check2(
        member.progressKey === null || typeof member.progressKey === "string" && member.progressKey.length > 0 && member.progressKey.length <= 256,
        "saved progress key"
      );
      check2(
        typeof member.warnedUnchanged === "boolean" && typeof member.warnedUnreachable === "boolean",
        "saved watchdog flags"
      );
      check2(
        member.progressKey === null === (member.unchangedSince === null),
        "saved progress timer"
      );
    }
    for (const objective of state.objectives)
      if (objective.completedTick !== null) {
        tick(objective.completedTick);
        check2(objective.completedTick <= state.tick, "future objective tick");
      }
    for (const credit of state.kills) {
      integer(credit.count, 0, 256, "kill count");
      check2(
        credit.count === state.members.filter((m) => m.reason === "killed" && m.killerId === credit.playerId).length,
        "kill count mismatch"
      );
    }
    check2(state.phase === "failed" === (state.failure !== null), "failure state");
    if (state.failure) {
      tick(state.failure.tick);
      check2(
        state.failure.tick <= state.tick && state.members.some((m) => m.id === state.failure?.id) && ["critical-loss", "forbidden-retreat", "invalid-pose"].includes(state.failure.reason) && [...POSE_FAULTS, "retreated", "crushed", "out-of-bounds"].includes(state.failure.cause),
        "invalid failure continuation"
      );
    }
    check2(state.phase !== "complete" || this.remaining(state) === 0, "premature completion");
  }
};

// src/game/vehicles/tank-special.ts
var idleTankSpecial = () => ({
  phase: "ready",
  actionInstanceId: 0,
  ownerId: null,
  ownerControlEpoch: null,
  startTick: 0,
  commitTick: null,
  endTick: null,
  direction: 1
});
function cancelTankSpecial(tank, tick2) {
  if (tank.special.phase !== "arming") return;
  tank.special.phase = "canceled";
  tank.special.endTick = tick2;
}
function finishTankCharge(tank, tick2) {
  if (tank.special.phase !== "charging") throw new Error("Inactive tank charge");
  tank.special.phase = "spent";
  tank.special.endTick = tick2;
  tank.lifecycle = "wreck";
  tank.body.vx = tank.body.vy = tank.invulnerableTicks = 0;
}
function stepTankCharge(previous, tank, tick2, definition, shape, profile, terrain, hurtboxes) {
  const special = tank.special;
  if (special.phase !== "charging" || special.commitTick === tick2) return null;
  if (special.commitTick === null || special.ownerId === null)
    throw new Error("Missing charge owner");
  integer(tick2 - special.commitTick, 1, profile.chargeTicks, "tank charge age");
  const attack2 = {
    id: tank.body.id,
    ownerId: special.ownerId,
    team: 1,
    actionInstanceId: special.actionInstanceId,
    definitionId: definition.id,
    position: { x: previous.body.x, y: previous.body.y },
    velocity: { x: tank.body.x - previous.body.x, y: tank.body.y - previous.body.y },
    spawnTick: special.commitTick
  };
  const contact = projectileImpact(attack2, shape, 0, terrain, hurtboxes);
  const blocked = tank.body.contacts.some(
    (contact2) => contact2.normalX !== 0 || contact2.normalY > 0
  );
  if (!contact && !blocked && tick2 - special.commitTick < profile.chargeTicks) return null;
  const anchor = contact?.position ?? { x: tank.body.x, y: tank.body.y };
  const point2 = {
    x: anchor.x + shape.rect.x + Math.trunc(shape.rect.w / 2),
    y: anchor.y + shape.rect.y + Math.trunc(shape.rect.h / 2)
  };
  const time = contact?.time ?? { numerator: 1, denominator: 1 };
  const impacts = explosionHits(
    attack2,
    definition,
    point2,
    profile.blastRadius,
    terrain,
    hurtboxes,
    {
      time,
      primaryTarget: contact?.entityId ?? null
    }
  );
  if (contact) {
    tank.body.x = anchor.x;
    tank.body.y = anchor.y;
    tank.body.supportId = null;
    tank.body.grounded = false;
    tank.body.contacts = [];
  }
  finishTankCharge(tank, tick2);
  return { position: point2, impacts };
}

// src/game/vehicles/tank.ts
var tankOwner = (tank) => tank.occupantId ?? tank.reservedBy;
var idleTankAction = (tick2) => ({
  kind: "ready",
  actionInstanceId: 0,
  stateStartTick: tick2,
  definitionId: 0,
  nextMarkerIndex: 0
});
var zero2 = { x: 0, y: 0 };
function createTank(id2, point2, supportId, profile) {
  return {
    body: {
      id: id2,
      ...point2,
      vx: 0,
      vy: 0,
      remainderX: 0,
      remainderY: 0,
      shapeId: profile.locomotion.standingShapeId,
      supportId,
      grounded: supportId !== null,
      contacts: []
    },
    definitionId: profile.definition.id,
    kind: "tank",
    lifecycle: "available",
    occupantId: null,
    reservedBy: null,
    controlEpoch: 1,
    ownerControlEpoch: null,
    facing: 1,
    heading: 0,
    invulnerableTicks: 0,
    armor: profile.definition.armor,
    action: idleTankAction(0),
    components: [],
    weapon: {
      id: profile.definition.weaponId,
      ammo: 0,
      cooldownTicks: 0,
      shotOrdinal: 0,
      lastActionInstanceId: 0
    },
    special: idleTankSpecial(),
    secondary: {
      ammo: profile.cannon.stock,
      shotsFired: 0,
      cooldownTicks: 0,
      shotOrdinal: 0,
      lastActionInstanceId: 0,
      action: idleTankAction(0)
    },
    jumpBufferTicks: 0,
    coyoteTicks: 0,
    turnTicks: 0,
    disconnectedTicks: 0,
    lastGunOwnerId: null,
    lastGunControlEpoch: null,
    lastCannonOwnerId: null,
    lastCannonControlEpoch: null
  };
}
function attachTankDriver(tank, actor, profile) {
  if (tankOwner(tank) !== actor.playerId) throw new Error("Tank attachment owner mismatch");
  const point2 = worldSocket(tank.body, profile.definition.seat.socket, tank.facing);
  actor.body = {
    ...actor.body,
    ...point2,
    vx: tank.body.vx,
    vy: tank.body.vy,
    remainderX: 0,
    remainderY: 0,
    grounded: false,
    supportId: null,
    contacts: []
  };
  actor.vehicleId = tank.body.id;
  actor.locomotion = "seated";
  actor.facing = tank.facing;
  actor.jumpBufferTicks = actor.coyoteTicks = actor.ignoredSupportTicks = 0;
  actor.ignoredSupportId = null;
}
function moveTank(current, intent, profile, shapes, index, frame) {
  const tank = structuredClone(current);
  if (tank.lifecycle === "wreck") return { tank, jumpAccepted: false, fault: null };
  tank.invulnerableTicks = Math.max(0, tank.invulnerableTicks - 1);
  tank.weapon.cooldownTicks = Math.max(0, tank.weapon.cooldownTicks - 1);
  tank.secondary.cooldownTicks = Math.max(0, tank.secondary.cooldownTicks - 1);
  tank.turnTicks = Math.max(0, tank.turnTicks - 1);
  const driving = tank.lifecycle === "occupied";
  const charging = tank.special.phase === "charging";
  const actor = {
    body: tank.body,
    life: "alive",
    locomotion: tank.body.grounded ? "grounded" : "airborne",
    action: idleTankAction(frame.tick),
    facing: tank.facing,
    aim: 0,
    jumpBufferTicks: tank.jumpBufferTicks,
    coyoteTicks: tank.coyoteTicks,
    ignoredSupportId: null,
    ignoredSupportTicks: 0,
    vehicleId: null,
    geometryRevision: frame.geometryRevision
  };
  const result = stepFootController(
    actor,
    {
      held: charging ? tank.special.direction === 1 ? Held.Right : Held.Left : driving ? intent.held & (Held.Left | Held.Right) : 0,
      jumpPressed: driving && intent.jumpPressed
    },
    charging ? { ...profile.locomotion, runSpeed: profile.special.speed } : profile.locomotion,
    shapes,
    index,
    frame
  );
  if (result.status === "failed") return { tank, jumpAccepted: false, fault: result.physics };
  tank.body = result.actor.body;
  tank.facing = result.actor.facing;
  tank.jumpBufferTicks = result.actor.jumpBufferTicks;
  tank.coyoteTicks = result.actor.coyoteTicks;
  if (driving && tank.turnTicks === 0) {
    const x = Number(Boolean(intent.held & Held.Right)) - Number(Boolean(intent.held & Held.Left));
    const y = Number(Boolean(intent.held & Held.Down)) - Number(Boolean(intent.held & Held.Up));
    const target = y < 0 ? x > 0 ? 1 : x < 0 ? 3 : 2 : y > 0 ? x > 0 ? 7 : x < 0 ? 5 : 6 : x < 0 ? 4 : x > 0 ? 0 : tank.heading;
    if (target !== tank.heading) {
      const clockwise = (target - tank.heading + 8) % 8;
      tank.heading = (tank.heading + (clockwise <= 4 ? 1 : 7)) % 8;
      tank.turnTicks = profile.turnTicks;
    }
  }
  return {
    tank,
    jumpAccepted: result.status === "complete" && ["consumed", "buffered"].includes(result.jumpRequest),
    fault: null
  };
}
function clearPath(actor, point2, shape, index, frame) {
  if (blockingShapes(point2, shape.rect, actor.facing, index, frame, "end").length) return false;
  const start = worldRect(actor.body, shape.rect, actor.facing), delta = { x: point2.x - actor.body.x, y: point2.y - actor.body.y };
  const terrain = index.query(sweepBounds(start, delta)).filter((target) => target.kind === "solid").map((target) => ({
    ...target,
    rect: {
      ...target.rect,
      x: target.rect.x + target.delta.x,
      y: target.rect.y + target.delta.y
    },
    delta: zero2
  }));
  const result = earliestSweep(start, delta, terrain);
  return result.overlaps.length === 0 && result.contacts.every((contact) => contact.time.numerator === contact.time.denominator);
}
function tankExitBody(tank, actor, profile, shape, index, frame) {
  const candidates = profile.definition.seat.ejectionCandidates;
  for (const [candidateIndex, offset] of candidates.entries()) {
    const point2 = worldSocket(tank.body, offset, tank.facing);
    if (point2.y > profile.fallBoundary || !clearPath(actor, point2, shape, index, frame)) continue;
    const body = {
      ...actor.body,
      ...point2,
      shapeId: shape.id,
      vx: 0,
      vy: 0,
      remainderX: 0,
      remainderY: 0,
      supportId: null,
      grounded: false,
      contacts: []
    };
    const bounds = sweepBounds(worldRect(body, shape.rect, actor.facing));
    const endTerrain = index.query({
      minX: bounds.minX - 1,
      minY: bounds.minY - 1,
      maxX: bounds.maxX + 1,
      maxY: bounds.maxY + 1
    }).map((target) => ({
      ...target,
      rect: {
        ...target.rect,
        x: target.rect.x + target.delta.x,
        y: target.rect.y + target.delta.y
      },
      delta: zero2
    }));
    const endIndex = new CollisionIndex(new CollisionGrid(endTerrain), [], frame);
    const supportId = startSupport(body, shape, actor.facing, endIndex, frame, null);
    if (candidateIndex < candidates.length - 1 && supportId === null) continue;
    body.supportId = supportId;
    body.grounded = supportId !== null;
    return body;
  }
  return null;
}
function reserveTank(tank, actor, tick2, actionId, profile, shapes, index, frame) {
  if (actor.life !== "alive" || actor.vehicleId !== null || actor.reboardCooldownTicks > 0 || !["ready", "fire"].includes(actor.action.kind) || !actor.body.grounded || tank.lifecycle !== "available" || tank.armor === 0 || !tank.body.grounded || Math.abs(tank.body.vx) > pixels(1))
    return false;
  const sensor = shapes.get(profile.definition.seat.boardingSensorShapeId), shape = shapes.get(actor.body.shapeId);
  if (!sensor || !shape) throw new Error("Missing tank boarding geometry");
  if (sweepAabb(
    worldRect(actor.body, shape.rect, actor.facing),
    zero2,
    worldRect(tank.body, sensor.rect, tank.facing)
  )?.kind !== "overlap")
    return false;
  const seat = worldSocket(tank.body, profile.definition.seat.socket, tank.facing);
  if (!clearPath(actor, seat, shape, index, frame)) return false;
  tank.lifecycle = "boarding";
  tank.reservedBy = actor.playerId;
  tank.controlEpoch = nextCounter(tank.controlEpoch);
  tank.ownerControlEpoch = actor.controlEpoch;
  tank.action = {
    kind: "enter",
    actionInstanceId: actionId,
    stateStartTick: tick2,
    definitionId: profile.definition.seat.boardingTimelineId,
    nextMarkerIndex: 0
  };
  actor.action = { ...tank.action };
  attachTankDriver(tank, actor, profile);
  return true;
}
function requestTankExit(tank, actor, tick2, actionId, profile, shape, index, frame) {
  if (tank.lifecycle !== "occupied" || tank.occupantId !== actor.playerId || !tankExitBody(tank, actor, profile, shape, index, frame))
    return false;
  cancelTankSpecial(tank, tick2);
  actor.vehicleSpecialTicks = 0;
  tank.lifecycle = "exiting";
  tank.secondary.action = idleTankAction(tick2);
  tank.action = {
    kind: "exit",
    actionInstanceId: actionId,
    stateStartTick: tick2,
    definitionId: profile.exitTimelineId,
    nextMarkerIndex: 0
  };
  actor.action = { ...tank.action };
  return true;
}
function releaseTank(tank, actor, tick2, profile, shape, index, frame) {
  if (tankOwner(tank) !== actor.playerId) throw new Error("Tank release owner mismatch");
  const body = tankExitBody(tank, actor, profile, shape, index, frame);
  cancelTankSpecial(tank, tick2);
  actor.vehicleSpecialTicks = 0;
  tank.occupantId = tank.reservedBy = null;
  tank.ownerControlEpoch = null;
  tank.controlEpoch = nextCounter(tank.controlEpoch);
  tank.lifecycle = tank.armor > 0 ? "available" : "wreck";
  tank.action = idleTankAction(tick2);
  tank.secondary.action = idleTankAction(tick2);
  tank.jumpBufferTicks = tank.coyoteTicks = tank.disconnectedTicks = 0;
  actor.vehicleId = null;
  actor.body = body ?? {
    ...actor.body,
    vx: 0,
    vy: 0,
    supportId: null,
    grounded: false,
    contacts: []
  };
  actor.locomotion = actor.body.grounded ? "grounded" : "airborne";
  actor.action = idleTankAction(tick2);
  actor.reboardCooldownTicks = profile.reboardTicks;
  actor.invulnerableTicks = Math.max(actor.invulnerableTicks, profile.exitProtectionTicks);
  return body !== null;
}
function stepTankTransfer(tank, actor, tick2, profile, catalog, shape, index, frame) {
  if (tank.lifecycle !== "boarding" && tank.lifecycle !== "exiting") return null;
  const step = stepAction(tank.action, tick2, catalog);
  tank.action = step.action;
  actor.action = { ...step.action };
  if (!step.markers.some(({ marker }) => marker.kind === "seat-transfer")) return null;
  if (tank.lifecycle === "boarding") {
    tank.occupantId = tank.reservedBy;
    tank.reservedBy = null;
    tank.lifecycle = "occupied";
    tank.action = actor.action = idleTankAction(tick2);
    return "board";
  }
  if (!tankExitBody(tank, actor, profile, shape, index, frame)) {
    tank.lifecycle = "occupied";
    tank.action = actor.action = idleTankAction(tick2);
    return "exit-blocked";
  }
  releaseTank(tank, actor, tick2, profile, shape, index, frame);
  return "exit";
}
function stepTankGun(tank, intent, tick2, nextActionId, profile, catalog) {
  const requested = intent.firePressed || Boolean(intent.held & Held.Fire);
  let outcome = "none";
  const markers = [];
  if (tank.lifecycle !== "occupied" || tank.occupantId === null)
    return { outcome: requested ? "unavailable" : outcome, nextActionId, markers };
  if (tank.action.kind === "fire") {
    const step = stepAction(tank.action, tick2, catalog);
    tank.action = step.finished ? idleTankAction(tick2) : step.action;
    markers.push(...step.markers);
  }
  if (requested) {
    if (tank.action.kind !== "ready" || tank.weapon.cooldownTicks > 0) outcome = "cooldown";
    else {
      integer(
        nextActionId,
        Math.max(tank.weapon.lastActionInstanceId, tank.secondary.lastActionInstanceId) + 1,
        COUNTER_LIMIT - 2,
        "tank gun allocation"
      );
      const definitionId = profile.fireTimelineIds[tank.heading];
      if (definitionId === void 0) throw new Error("Missing tank gun heading");
      tank.action = {
        kind: "fire",
        actionInstanceId: nextActionId,
        stateStartTick: tick2,
        definitionId,
        nextMarkerIndex: 0
      };
      tank.weapon.cooldownTicks = profile.fireCadenceTicks;
      tank.weapon.shotOrdinal = nextCounter(
        Math.max(tank.weapon.shotOrdinal, tank.secondary.shotOrdinal)
      );
      tank.weapon.lastActionInstanceId = nextActionId;
      tank.lastGunOwnerId = tank.occupantId;
      tank.lastGunControlEpoch = tank.ownerControlEpoch;
      nextActionId = nextCounter(nextActionId);
      const step = stepAction(tank.action, tick2, catalog);
      tank.action = step.action;
      markers.push(...step.markers);
      outcome = "applied";
    }
  }
  return { outcome, nextActionId, markers };
}
function stepTankCannon(tank, requested, tick2, nextActionId, profile, catalog) {
  const cannon = tank.secondary;
  const markers = [];
  let outcome = "none";
  if (tank.lifecycle !== "occupied" || tank.occupantId === null) {
    cannon.action = idleTankAction(tick2);
    return { outcome: requested ? "unavailable" : outcome, nextActionId, markers };
  }
  if (cannon.action.kind === "fire") {
    const step = stepAction(cannon.action, tick2, catalog);
    cannon.action = step.finished ? idleTankAction(tick2) : step.action;
    markers.push(...step.markers);
  }
  if (requested) {
    if (cannon.ammo === 0) outcome = "unavailable";
    else if (cannon.action.kind !== "ready" || cannon.cooldownTicks > 0) outcome = "cooldown";
    else {
      integer(
        nextActionId,
        Math.max(tank.weapon.lastActionInstanceId, cannon.lastActionInstanceId) + 1,
        COUNTER_LIMIT - 2,
        "cannon allocation"
      );
      const definitionId = profile.cannon.fireTimelineIds[tank.heading];
      if (definitionId === void 0) throw new Error("Missing cannon heading");
      cannon.action = {
        kind: "fire",
        actionInstanceId: nextActionId,
        stateStartTick: tick2,
        definitionId,
        nextMarkerIndex: 0
      };
      cannon.ammo--;
      cannon.shotsFired++;
      cannon.cooldownTicks = profile.cannon.cadenceTicks;
      cannon.shotOrdinal = nextCounter(Math.max(tank.weapon.shotOrdinal, cannon.shotOrdinal));
      cannon.lastActionInstanceId = nextActionId;
      tank.lastCannonOwnerId = tank.occupantId;
      tank.lastCannonControlEpoch = tank.ownerControlEpoch;
      nextActionId = nextCounter(nextActionId);
      const step = stepAction(cannon.action, tick2, catalog);
      cannon.action = step.action;
      markers.push(...step.markers);
      outcome = "applied";
    }
  }
  return { outcome, nextActionId, markers };
}
function validateTankProfile(profile, shapes, catalog) {
  if (profile.definition.kind !== "tank" || profile.definition.actorId !== profile.locomotion.id || profile.locomotion.standingShapeId !== profile.locomotion.crouchedShapeId)
    throw new Error("Invalid tank controller definition");
  integer(profile.headings.length, 8, 8, "tank headings");
  integer(profile.fireTimelineIds.length, 8, 8, "tank fire poses");
  for (const id2 of [
    profile.definition.seat.boardingSensorShapeId,
    profile.locomotion.standingShapeId
  ])
    if (!shapes.has(id2)) throw new Error("Missing tank shape");
  for (const id2 of [
    profile.definition.seat.boardingTimelineId,
    profile.exitTimelineId,
    ...profile.fireTimelineIds
  ])
    if (!catalog.timelines.has(id2)) throw new Error("Missing tank timeline");
  for (const ticks of [
    profile.fireCadenceTicks,
    profile.turnTicks,
    profile.damageProtectionTicks,
    profile.reboardTicks,
    profile.exitProtectionTicks,
    profile.disconnectGraceTicks
  ])
    integer(ticks, 1, 120, "tank timing");
  integer(profile.special.armTicks, 2, 120, "tank arming time");
  integer(profile.special.chargeTicks, 1, 120, "tank charge duration");
  integer(profile.special.speed, 1, MAX_MOTION, "tank charge speed");
  integer(profile.special.blastRadius, 1, 2 ** 16, "tank sacrifice radius");
  const cannon = profile.cannon;
  integer(cannon.stock, 1, 65535, "cannon stock");
  integer(cannon.recoil.length, 1, 120, "cannon action duration");
  integer(cannon.cadenceTicks, cannon.recoil.length, 120, "cannon cadence");
  integer(cannon.releaseTick, 0, cannon.recoil.length - 1, "cannon release tick");
  integer(cannon.blastRadius, 1, 2 ** 16, "cannon blast radius");
  integer(cannon.headings.length, 8, 8, "cannon headings");
  integer(cannon.fireTimelineIds.length, 8, 8, "cannon fire poses");
  if (!shapes.has(cannon.bodyShapeId) || (/* @__PURE__ */ new Set([...profile.fireTimelineIds, ...cannon.fireTimelineIds])).size !== 16)
    throw new Error("Invalid cannon content identity");
  position(cannon.hardpoint.x);
  position(cannon.hardpoint.y);
  for (const [age2, recoil] of cannon.recoil.entries()) {
    integer(recoil, 0, pixels(16), "cannon recoil");
    if (age2 <= cannon.releaseTick && recoil !== 0) throw new Error("Cannon recoils before release");
  }
  for (const [index, heading] of cannon.headings.entries()) {
    position(heading.muzzle.x);
    position(heading.muzzle.y);
    motion(heading.velocity.x);
    motion(heading.velocity.y);
    integer(
      Math.abs(heading.velocity.x) + Math.abs(heading.velocity.y),
      1,
      MAX_MOTION,
      "cannon flight speed"
    );
    const id2 = cannon.fireTimelineIds[index], timeline = id2 === void 0 ? void 0 : catalog.timelines.get(id2);
    if (!timeline || timeline.durationTicks !== cannon.recoil.length || timeline.markers.length !== 2 || timeline.markers.some(
      (marker, i) => marker.kind !== (i === 0 ? "spawn-attack" : "sound") || marker.tickOffset !== cannon.releaseTick || marker.payloadId !== cannon.attackId || marker.socket !== "muzzle"
    ))
      throw new Error("Invalid cannon release timeline");
    const socket = actionPose(catalog, timeline.id, cannon.releaseTick)?.sockets.find(
      (socket2) => socket2.name === "muzzle"
    );
    if (!socket || canonical(socket.point) !== canonical(heading.muzzle))
      throw new Error("Cannon release socket mismatch");
  }
}

// src/game/content/contract-fixture.ts
var CONTRACT_FIXTURE = {
  format: 1,
  simulationHz: 60,
  shapes: [
    { id: 1, rect: { x: pixels(-7), y: pixels(-34), w: pixels(14), h: pixels(34) } },
    { id: 2, rect: { x: pixels(-7), y: pixels(-20), w: pixels(14), h: pixels(20) } },
    { id: 3, rect: { x: pixels(-5), y: pixels(-32), w: pixels(10), h: pixels(30) } },
    { id: 4, rect: { x: pixels(-1), y: pixels(-1), w: pixels(2), h: pixels(2) } },
    { id: 5, rect: { x: pixels(-40), y: pixels(-32), w: pixels(80), h: pixels(32) } },
    { id: 6, rect: { x: pixels(-24), y: pixels(-30), w: pixels(48), h: pixels(30) } }
  ],
  poses: [
    {
      id: 1,
      frame: "fixture-operative-idle",
      durationTicks: 6,
      sockets: [
        { name: "muzzle", point: { x: pixels(15), y: pixels(-23) } },
        { name: "hand", point: { x: pixels(10), y: pixels(-20) } }
      ],
      hurtShapeIds: [3]
    },
    {
      id: 2,
      frame: "fixture-tank-idle",
      durationTicks: 12,
      sockets: [
        { name: "seat", point: { x: 0, y: pixels(-20) } },
        { name: "ejection", point: { x: pixels(-40), y: 0 } }
      ],
      hurtShapeIds: [6]
    }
  ],
  timelines: [
    {
      id: 1,
      durationTicks: 6,
      poses: [1],
      markers: [{ tickOffset: 0, kind: "spawn-attack", payloadId: 1, socket: "muzzle" }]
    },
    {
      id: 2,
      durationTicks: 12,
      poses: [2],
      markers: [{ tickOffset: 11, kind: "seat-transfer", payloadId: 1, socket: "seat" }]
    }
  ],
  attacks: [
    {
      id: 1,
      kind: "swept-projectile",
      shapeId: 4,
      damage: 1,
      lifetimeTicks: 30,
      speed: pixels(12),
      maxTargets: 1,
      repeatDamageTicks: 0,
      material: "bullet"
    }
  ],
  weapons: [
    {
      id: "sidearm",
      attackId: 1,
      timelineId: 1,
      cadenceTicks: 10,
      ammoPerAction: 0,
      pickupAmmo: "unlimited",
      aimPolicy: "cardinal",
      visualFamily: "fixture-sidearm",
      audioFamily: "fixture-sidearm"
    }
  ],
  actors: [
    {
      id: 1,
      locomotion: "grounded",
      standingShapeId: 1,
      crouchedShapeId: 2,
      idlePoseId: 1,
      runSpeed: 768,
      jumpVelocity: -1430,
      gravity: 55,
      terminalVelocity: 2048
    },
    {
      id: 2,
      locomotion: "grounded",
      standingShapeId: 6,
      crouchedShapeId: 6,
      idlePoseId: 2,
      runSpeed: 640,
      jumpVelocity: -1200,
      gravity: 60,
      terminalVelocity: 2048
    }
  ],
  vehicles: [
    {
      id: 1,
      kind: "tank",
      actorId: 2,
      armor: 3,
      weaponId: "sidearm",
      seat: {
        socket: { x: 0, y: pixels(-20) },
        ejectionCandidates: [
          { x: pixels(-40), y: 0 },
          { x: pixels(40), y: 0 }
        ],
        boardingSensorShapeId: 5,
        boardingTimelineId: 2
      }
    }
  ],
  terrain: [
    {
      id: 100,
      kind: "solid",
      rect: { x: 0, y: pixels(200), w: pixels(384), h: pixels(16) },
      visibleSurfaceId: "fixture-floor"
    },
    {
      id: 101,
      kind: "one-way",
      rect: { x: pixels(100), y: pixels(145), w: pixels(80), h: pixels(8) },
      visibleSurfaceId: "fixture-platform"
    }
  ],
  encounters: [
    {
      id: 1,
      camera: { x: 0, y: 0, w: pixels(384), h: pixels(216) },
      killBounds: { x: pixels(-64), y: pixels(-64), w: pixels(512), h: pixels(320) },
      checkpoint: { x: pixels(32), y: pixels(200) },
      spawns: [
        {
          id: 102,
          actorId: 1,
          point: { x: pixels(50), y: pixels(200) },
          required: true,
          retreatAllowed: false
        }
      ],
      vehicleSpawns: [{ id: 103, definitionId: 1, point: { x: pixels(250), y: pixels(200) } }]
    }
  ]
};

// src/game/content/validate.ts
function check3(condition, message) {
  if (!condition) throw new Error(`Invalid content: ${message}`);
}
function unique2(values, label) {
  check3(values.length <= 4096, `${label} count`);
  const table = /* @__PURE__ */ new Map();
  for (const value of values) {
    if (typeof value.id === "number") integer(value.id, 1, COUNTER_LIMIT - 1, label);
    check3(!table.has(value.id), `duplicate ${label} ID ${value.id}`);
    table.set(value.id, value);
  }
  return table;
}
function point(value, local = false) {
  const maximum = local ? MAX_SHAPE : 2 ** 24;
  integer(value.x, -maximum, maximum, "point x");
  integer(value.y, -maximum, maximum, "point y");
}
function rectangle(rect, local = false) {
  if (local) validateLocalRect(rect);
  point(rect, local);
  integer(rect.w, 1, local ? MAX_SHAPE : 2 ** 24, "rectangle width");
  integer(rect.h, 1, local ? MAX_SHAPE : 2 ** 24, "rectangle height");
  position(rect.x + rect.w);
  position(rect.y + rect.h);
}
function validateContent(content) {
  canonical(content);
  check3(content.format === 1 && content.simulationHz === 60, "format/tick rate");
  const shapes = unique2(content.shapes, "shape");
  const poses = unique2(content.poses, "pose");
  const timelines = unique2(content.timelines, "timeline");
  const attacks = unique2(content.attacks, "attack");
  const weapons = unique2(content.weapons, "weapon");
  const actors = unique2(content.actors, "actor");
  const vehicles = unique2(content.vehicles, "vehicle");
  const entities = new Set(unique2(content.terrain, "terrain").keys());
  unique2(content.encounters, "encounter");
  for (const shape of content.shapes) rectangle(shape.rect, true);
  for (const pose of content.poses) {
    integer(pose.durationTicks, 1, 3600, "pose duration");
    check3(pose.frame.length > 0, "missing frame identity");
    check3(
      pose.sockets.length <= 8 && new Set(pose.sockets.map((socket) => socket.name)).size === pose.sockets.length,
      "duplicate/excess sockets"
    );
    for (const socket of pose.sockets) point(socket.point, true);
    check3(
      pose.hurtShapeIds.length <= 16 && pose.hurtShapeIds.every((id2) => shapes.has(id2)),
      "unknown/excess hurt shapes"
    );
  }
  for (const timeline of content.timelines) {
    integer(timeline.durationTicks, 1, 3600, "timeline duration");
    check3(
      timeline.poses.length > 0 && timeline.poses.length <= 256 && timeline.poses.every((id2) => poses.has(id2)),
      "missing/excess timeline poses"
    );
    const duration2 = timeline.poses.reduce(
      (sum, id2) => sum + (poses.get(id2)?.durationTicks ?? 0),
      0
    );
    check3(duration2 === timeline.durationTicks, "timeline exposure duration mismatch");
    check3(timeline.markers.length <= 128, "excess markers");
    let previous = -1;
    for (const marker of timeline.markers) {
      integer(marker.tickOffset, 0, timeline.durationTicks - 1, "marker tick");
      check3(marker.tickOffset >= previous, "unordered markers");
      previous = marker.tickOffset;
      let age2 = marker.tickOffset;
      const pose = timeline.poses.map((id2) => poses.get(id2)).find((candidate) => {
        if (!candidate) return false;
        if (age2 < candidate.durationTicks) return true;
        age2 -= candidate.durationTicks;
        return false;
      });
      check3(
        Boolean(pose?.sockets.some((socket) => socket.name === marker.socket)),
        "missing active pose socket"
      );
      if (marker.kind === "spawn-attack" || marker.kind === "activate-hitbox")
        check3(attacks.has(marker.payloadId), "unknown marker attack");
      if (marker.kind === "seat-transfer")
        check3(vehicles.has(marker.payloadId), "unknown marker vehicle");
    }
  }
  for (const attack2 of content.attacks) {
    check3(ATTACK_MATERIALS.includes(attack2.material), "unknown attack material");
    check3(shapes.has(attack2.shapeId), "unknown attack shape");
    motion(attack2.speed);
    integer(attack2.damage, 1, 65535, "damage");
    integer(attack2.lifetimeTicks, 1, 3600, "attack lifetime");
    integer(attack2.maxTargets, 1, 256, "attack target limit");
    integer(attack2.repeatDamageTicks, 0, 3600, "damage interval");
  }
  for (const weapon of content.weapons) {
    check3(
      attacks.has(weapon.attackId) && timelines.has(weapon.timelineId),
      "unknown weapon action"
    );
    integer(weapon.cadenceTicks, 1, 3600, "weapon cadence");
    integer(weapon.ammoPerAction, 0, 65535, "ammo cost");
    if (weapon.pickupAmmo !== "unlimited")
      integer(weapon.pickupAmmo, 1, 65535, "pickup ammunition");
    check3(
      weapon.pickupAmmo === "unlimited" ? weapon.ammoPerAction === 0 : weapon.ammoPerAction > 0,
      "inconsistent ammo policy"
    );
    check3(
      weapon.visualFamily.length > 0 && weapon.audioFamily.length > 0,
      "missing weapon media family"
    );
  }
  for (const actor of content.actors) {
    check3(
      shapes.has(actor.standingShapeId) && shapes.has(actor.crouchedShapeId) && poses.has(actor.idlePoseId),
      "unknown actor shape/pose"
    );
    for (const value of [actor.runSpeed, actor.jumpVelocity, actor.gravity, actor.terminalVelocity])
      motion(value);
    check3(
      actor.runSpeed >= 0 && actor.gravity >= 0 && actor.terminalVelocity > 0 && actor.jumpVelocity <= 0,
      "actor movement signs"
    );
  }
  for (const vehicle of content.vehicles) {
    check3(
      actors.has(vehicle.actorId) && weapons.has(vehicle.weaponId) && shapes.has(vehicle.seat.boardingSensorShapeId) && timelines.has(vehicle.seat.boardingTimelineId),
      "unknown vehicle reference"
    );
    integer(vehicle.armor, 1, 65535, "vehicle armor");
    point(vehicle.seat.socket, true);
    check3(
      vehicle.seat.ejectionCandidates.length > 0 && vehicle.seat.ejectionCandidates.length <= 8,
      "ejection candidates"
    );
    for (const candidate of vehicle.seat.ejectionCandidates) point(candidate, true);
  }
  for (const terrain of content.terrain) {
    rectangle(terrain.rect);
    check3(terrain.visibleSurfaceId.length > 0, "invisible terrain");
  }
  for (const encounter of content.encounters) {
    rectangle(encounter.camera);
    rectangle(encounter.killBounds);
    point(encounter.checkpoint);
    check3(
      encounter.spawns.length <= 256 && encounter.vehicleSpawns.length <= 16,
      "encounter entity budget"
    );
    for (const spawn of [...encounter.spawns, ...encounter.vehicleSpawns]) {
      integer(spawn.id, 1, COUNTER_LIMIT - 1, "spawn ID");
      check3(!entities.has(spawn.id), "reused world entity ID");
      entities.add(spawn.id);
      point(spawn.point);
      if ("actorId" in spawn) check3(actors.has(spawn.actorId), "unknown spawn actor");
      else check3(vehicles.has(spawn.definitionId), "unknown spawn vehicle");
    }
  }
}

// src/game/content/weapons/tank-special.ts
var TANK_SPECIAL_SHAPE = {
  id: 24,
  rect: { x: pixels(-72), y: pixels(-72), w: pixels(144), h: pixels(144) }
};
var TANK_SPECIAL_ATTACK = {
  id: 20,
  kind: "explosion",
  shapeId: TANK_SPECIAL_SHAPE.id,
  damage: 8,
  lifetimeTicks: 60,
  speed: pixels(6),
  maxTargets: 16,
  repeatDamageTicks: 0,
  material: "explosive"
};
var TANK_SPECIAL_PROFILE = {
  armTicks: 30,
  attackId: TANK_SPECIAL_ATTACK.id,
  chargeTicks: TANK_SPECIAL_ATTACK.lifetimeTicks,
  speed: TANK_SPECIAL_ATTACK.speed,
  blastRadius: pixels(72)
};

// src/game/labs/foot-fixture.ts
var FOOT_SHAPES = new Map(CONTRACT_FIXTURE.shapes.map((shape) => [shape.id, shape]));
var FOOT_DEFINITION = CONTRACT_FIXTURE.actors[0];
if (!FOOT_DEFINITION) throw new Error("Missing foot fixture definition");
function footState(x = 0, y = 0) {
  return {
    body: {
      id: 1,
      x: pixels(x),
      y: pixels(y),
      vx: 0,
      vy: 0,
      remainderX: 0,
      remainderY: 0,
      shapeId: 1,
      supportId: 100,
      grounded: true,
      contacts: []
    },
    life: "alive",
    locomotion: "grounded",
    action: {
      kind: "ready",
      actionInstanceId: 0,
      stateStartTick: 0,
      definitionId: 0,
      nextMarkerIndex: 0
    },
    facing: 1,
    aim: 0,
    jumpBufferTicks: 0,
    coyoteTicks: 4,
    ignoredSupportId: null,
    ignoredSupportTicks: 0,
    vehicleId: null,
    geometryRevision: 1
  };
}
function footActor(x = 0, y = 0) {
  return {
    ...footState(x, y),
    playerId: 1,
    slot: 0,
    controlEpoch: 1,
    lifeStartTick: 0,
    bodyPresence: "present",
    invulnerableTicks: 0,
    reboardCooldownTicks: 0,
    vehicleSpecialTicks: 0,
    weapon: { id: "sidearm", ammo: 0, cooldownTicks: 0, shotOrdinal: 0, lastActionInstanceId: 0 },
    firearmAim: { pitch: 0, nextStepTick: 0 },
    grenadeStock: 10,
    grenadeCooldownTicks: 0,
    meleeCooldownTicks: 0,
    health: 1,
    lives: 3,
    lastRallyMission: 0,
    processedEdgeIds: [0, 0, 0, 0, 0]
  };
}
function footTerrain(id2, x, y, w, h, kind = "solid") {
  return {
    id: id2,
    rect: { x: pixels(x), y: pixels(y), w: pixels(w), h: pixels(h) },
    kind,
    delta: { x: 0, y: 0 }
  };
}
var FOOT_FLOOR = footTerrain(100, -200, 0, 400, 16);

// src/game/labs/combat-terrain.ts
var COMBAT_SUPPORT = [
  {
    id: 104,
    definitionId: 1,
    rect: { x: pixels(176), y: pixels(160), w: pixels(152), h: pixels(56) },
    health: 8,
    materialId: "timber"
  }
];
function combatGeometryRevision(props) {
  return 1 + props.filter((prop) => prop.health === 0).length;
}
function combatDestructibles(scenario) {
  const definition = materialCase(scenario);
  return definition ? [materialLabProp(definition)] : scenario === "support" ? COMBAT_SUPPORT : [];
}
function materialCombatStage(world) {
  const definition = materialCase(world.scenario);
  if (!definition) return;
  return {
    terrain: combatTerrain(world.scenario, world.tick + 1, world.props),
    destructibles: combatDestructibles(world.scenario),
    enemyBounds: { ...MATERIAL_CALIBRATION.bounds },
    fallBoundary: MATERIAL_CALIBRATION.fallBoundary,
    entry: { x: materialPlayerX(definition.weapon), y: MATERIAL_CALIBRATION.targetY },
    activeEnemyIds: new Set(world.targets.map((target) => target.enemy.body.id)),
    patrolSpeed: definition.targetMotion === "stationary" ? 0 : MATERIAL_CALIBRATION.patrolSpeed,
    extraHurtboxes: []
  };
}
var COMBAT_ORDNANCE = [
  {
    id: 102,
    shapeId: 17,
    x: pixels(24),
    y: pixels(160),
    w: pixels(240),
    h: pixels(8),
    start: 0,
    end: 50,
    dx: pixels(1),
    dy: 0
  },
  {
    id: 103,
    shapeId: 18,
    x: pixels(190),
    y: pixels(90),
    w: pixels(132),
    h: pixels(10),
    start: 55,
    end: 85,
    dx: 0,
    dy: pixels(2)
  }
];
function ordnancePlatforms(tick2) {
  integer(tick2, 0, 3601, "ordnance trajectory tick");
  return COMBAT_ORDNANCE.map((platform, i) => {
    const age2 = Math.max(0, Math.min(platform.end, tick2) - platform.start);
    const previous = Math.max(0, Math.min(platform.end, Math.max(0, tick2 - 1)) - platform.start);
    return {
      id: platform.id,
      x: platform.x + age2 * platform.dx,
      y: platform.y + age2 * platform.dy,
      vx: (age2 - previous) * platform.dx,
      vy: (age2 - previous) * platform.dy,
      shapeId: platform.shapeId,
      trajectoryId: i + 1,
      trajectoryTick: tick2
    };
  });
}
function combatTerrain(scenario, tick2 = 0, props = []) {
  const material = materialCase(scenario);
  if (material) {
    const definition = materialLabProp(material);
    if (props.length !== 1 || props[0]?.id !== definition.id || props[0].definitionId !== definition.definitionId)
      throw new Error("Missing material geometry state");
    return [
      footTerrain(100, 0, 200, 384, 16),
      ...props.filter((prop) => prop.health > 0).map((prop) => ({
        id: prop.id,
        kind: "solid",
        materialId: definition.materialId,
        rect: { ...definition.rect },
        delta: { x: 0, y: 0 }
      }))
    ];
  }
  if (scenario === "support") {
    if (props.length !== COMBAT_SUPPORT.length) throw new Error("Missing support state");
    return [
      footTerrain(100, 0, 200, 152, 16),
      ...props.filter((prop) => prop.health > 0).map((prop) => {
        const definition = COMBAT_SUPPORT.find((definition2) => definition2.id === prop.id);
        if (!definition) throw new Error("Unknown support geometry");
        return {
          id: prop.id,
          kind: "solid",
          materialId: definition.materialId,
          rect: { ...definition.rect },
          delta: { x: 0, y: 0 }
        };
      }),
      footTerrain(105, 352, 200, 32, 16)
    ];
  }
  const terrain = [
    footTerrain(100, 0, 200, 384, 16),
    ...scenario === "wall" ? [footTerrain(101, 140, 130, 3, 70)] : []
  ];
  if (scenario === "ordnance")
    for (const [i, platform] of ordnancePlatforms(tick2).entries()) {
      const definition = COMBAT_ORDNANCE[i];
      if (!definition) throw new Error("Missing ordnance platform");
      terrain.push({
        id: platform.id,
        kind: "solid",
        rect: {
          x: platform.x - platform.vx,
          y: platform.y - platform.vy,
          w: definition.w,
          h: definition.h
        },
        delta: { x: platform.vx, y: platform.vy }
      });
    }
  return terrain;
}
function combatCollisionIndex(scenario, frame, props = [], terrainOverride) {
  const terrain = terrainOverride ?? combatTerrain(scenario, frame.tick, props);
  const moving = (target) => target.delta.x !== 0 || target.delta.y !== 0;
  return new CollisionIndex(
    new CollisionGrid(terrain.filter((target) => !moving(target))),
    terrain.filter(moving),
    frame
  );
}

// src/game/labs/combat-content.ts
var COMBAT_CONTENT = structuredClone(CONTRACT_FIXTURE);
COMBAT_CONTENT.shapes.push(
  { id: 7, rect: { x: pixels(-5), y: pixels(-18), w: pixels(10), h: pixels(16) } },
  { id: 8, rect: { x: pixels(5), y: pixels(-30), w: pixels(4), h: pixels(28) } },
  { id: 9, rect: { x: pixels(-10), y: pixels(-8), w: pixels(34), h: pixels(16) } },
  { id: 10, rect: { x: pixels(-3), y: pixels(-3), w: pixels(6), h: pixels(6) } },
  { id: 11, rect: { x: pixels(-48), y: pixels(-48), w: pixels(96), h: pixels(96) } },
  { id: 12, rect: { x: 0, y: pixels(-10), w: pixels(30), h: pixels(24) } },
  { id: 13, rect: { x: 0, y: pixels(-3), w: pixels(20), h: pixels(6) } },
  { id: 14, rect: { x: 0, y: pixels(-8), w: pixels(14), h: pixels(8) } },
  structuredClone(ROCKET_SHAPE),
  structuredClone(ROCKET_BLAST_SHAPE),
  structuredClone(LASER_SHAPE)
);
var sidearm = COMBAT_CONTENT.weapons[0];
var attack = COMBAT_CONTENT.attacks[0];
if (!sidearm || !attack) throw new Error("Missing baseline firearm content");
sidearm.cadenceTicks = 8;
var hmg = {
  ...sidearm,
  id: "heavy-machine-gun",
  attackId: 2,
  cadenceTicks: 5,
  ammoPerAction: 1,
  pickupAmmo: 150,
  timelineId: 14,
  visualFamily: "fixture-hmg",
  audioFamily: "fixture-hmg"
};
COMBAT_CONTENT.weapons.push(hmg);
COMBAT_CONTENT.attacks.push({ ...attack, id: 2, speed: pixels(18) });
var HMG_SWEEP = {
  stepTicks: 2,
  headings: [
    [-4, 16, 2, 0, 0, 4608],
    [-3, 200, 6, -7, 1763, 4257],
    [-2, 201, 11, -12, 3258, 3258],
    [-1, 202, 14, -17, 4257, 1763],
    [0, 14, 15, -23, 4608, 0],
    [1, 203, 14, -29, 4257, -1763],
    [2, 204, 11, -34, 3258, -3258],
    [3, 205, 6, -37, 1763, -4257],
    [4, 15, 2, -38, 0, -4608]
  ].map(([pitch = 0, timelineId = 0, x = 0, y = 0, vx = 0, vy = 0]) => ({
    pitch,
    timelineId,
    muzzle: { x: pixels(x), y: pixels(y) },
    velocity: { x: vx, y: vy }
  }))
};
var shotgun = {
  ...sidearm,
  id: "shotgun",
  attackId: 10,
  cadenceTicks: 28,
  ammoPerAction: 1,
  pickupAmmo: 24,
  visualFamily: "fixture-shotgun",
  audioFamily: "fixture-shotgun"
};
var flame = {
  ...sidearm,
  id: "flamethrower",
  attackId: 11,
  cadenceTicks: 30,
  ammoPerAction: 1,
  pickupAmmo: 30,
  visualFamily: "fixture-flame",
  audioFamily: "fixture-flame"
};
var rocket = structuredClone(ROCKET_WEAPON);
var laser = structuredClone(LASER_WEAPON);
COMBAT_CONTENT.weapons.push(shotgun, flame, rocket, laser);
COMBAT_CONTENT.attacks.push(
  structuredClone(ROCKET_ATTACK),
  structuredClone(LASER_ATTACK),
  {
    id: 10,
    kind: "shot-volume",
    shapeId: 13,
    damage: 4,
    lifetimeTicks: 6,
    speed: 0,
    maxTargets: 16,
    repeatDamageTicks: 0,
    material: "bullet"
  },
  {
    id: 11,
    kind: "flame-volumes",
    shapeId: 14,
    damage: 1,
    lifetimeTicks: 30,
    speed: 0,
    maxTargets: 16,
    repeatDamageTicks: 6,
    material: "heat"
  }
);
var AREA_PROFILES = /* @__PURE__ */ new Map([
  [
    10,
    {
      kind: "shot-volume",
      emissionOffsets: [0],
      attachedTicks: 0,
      maximumReach: pixels(110),
      frames: [20, 40, 60, 80, 100, 110].map((length, age2) => ({
        x: 0,
        y: -pixels(3 + age2 * 2),
        w: pixels(length),
        h: pixels(6 + age2 * 4)
      }))
    }
  ],
  [
    11,
    {
      kind: "flame-volumes",
      emissionOffsets: [0, 6, 12],
      attachedTicks: 6,
      maximumReach: pixels(90),
      frames: Array.from({ length: 18 }, (_, age2) => {
        const width = age2 < 6 ? [14, 18, 24, 28, 32, 36][age2] ?? 0 : 36;
        const height = age2 < 6 ? 8 + Math.min(age2, 3) * 2 : age2 < 14 ? 14 : 10;
        return {
          x: age2 < 6 ? 0 : (age2 - 5) * (pixels(4) + 128),
          y: pixels((age2 < 6 ? [-4, -2, 0, 2, 4, 2][age2] ?? 0 : 2) - height / 2),
          w: pixels(width),
          h: pixels(height)
        };
      })
    }
  ]
]);
var FOOT_ACTION_PROFILES = {
  melee: { timelineIds: [40, 41], cooldownTicks: 18 },
  grenade: { timelineIds: [50, 51], cooldownTicks: 20 }
};
var GRENADE_PROFILE = {
  bodyShapeId: 10,
  fuseTicks: 90,
  gravity: 55,
  terminalVelocity: 2048,
  maximumBounces: 3,
  radius: pixels(48),
  standingVelocity: { x: pixels(2) + 128, y: -pixels(4) - 128 },
  crouchedVelocity: { x: pixels(4), y: -pixels(1) - 128 },
  inheritedVelocityLimit: { x: pixels(8), y: pixels(8) }
};
COMBAT_CONTENT.attacks.push(
  {
    id: 4,
    kind: "melee",
    shapeId: 9,
    damage: 1,
    lifetimeTicks: 4,
    speed: 0,
    maxTargets: 4,
    repeatDamageTicks: 0,
    material: "blade"
  },
  {
    id: 5,
    kind: "explosion",
    shapeId: 11,
    damage: 1,
    lifetimeTicks: GRENADE_PROFILE.fuseTicks,
    speed: GRENADE_PROFILE.standingVelocity.x,
    maxTargets: 16,
    repeatDamageTicks: 0,
    material: "explosive"
  }
);
for (const kind of ["melee", "grenade"]) {
  const profile = FOOT_ACTION_PROFILES[kind];
  for (const [stance, id2] of profile.timelineIds.entries()) {
    const durations = kind === "melee" ? [5, 4, 9] : [4, 1, 15];
    const poseIds = [id2, id2 + 2, id2 + 4];
    for (const [phase, poseId] of poseIds.entries())
      COMBAT_CONTENT.poses.push({
        id: poseId,
        frame: `engineering-${kind}-${stance}-${phase}`,
        durationTicks: durations[phase] ?? 0,
        sockets: [
          {
            name: "hand",
            point: { x: pixels(10), y: pixels(stance === 1 ? -12 : kind === "melee" ? -20 : -24) }
          }
        ],
        hurtShapeIds: [stance === 1 ? 7 : 3]
      });
    COMBAT_CONTENT.timelines.push({
      id: id2,
      durationTicks: profile.cooldownTicks,
      poses: poseIds,
      markers: [
        {
          tickOffset: durations[0] ?? 0,
          kind: kind === "melee" ? "activate-hitbox" : "spawn-attack",
          payloadId: kind === "melee" ? 4 : 5,
          socket: "hand"
        },
        {
          tickOffset: durations[0] ?? 0,
          kind: "sound",
          payloadId: kind === "melee" ? 4 : 5,
          socket: "hand"
        }
      ]
    });
  }
}
var RIFLE_PROFILE = {
  timelineIds: [30, 31],
  raiseTicks: 24,
  lastReleaseTick: 36,
  range: pixels(240),
  upAlignment: pixels(24),
  upHeight: pixels(48),
  aimHeight: pixels(16)
};
COMBAT_CONTENT.attacks.push({ ...attack, id: 3, speed: pixels(3), lifetimeTicks: 150 });
for (const [aim, id2] of RIFLE_PROFILE.timelineIds.entries()) {
  const muzzle = aim === 0 ? { x: pixels(15), y: pixels(-23) } : { x: pixels(2), y: pixels(-36) };
  const poseIds = [id2, id2 + 2, id2 + 4];
  for (const [phase, poseId] of poseIds.entries())
    COMBAT_CONTENT.poses.push({
      id: poseId,
      frame: `engineering-rifle-${aim}-${phase}`,
      durationTicks: [24, 13, 35][phase] ?? 0,
      sockets: [
        { name: "muzzle", point: muzzle },
        { name: "hand", point: { x: 0, y: pixels(-23) } }
      ],
      hurtShapeIds: [3]
    });
  COMBAT_CONTENT.timelines.push({
    id: id2,
    durationTicks: 72,
    poses: poseIds,
    markers: [24, 30, 36].flatMap((tickOffset) => [
      { tickOffset, kind: "spawn-attack", payloadId: 3, socket: "muzzle" },
      { tickOffset, kind: "sound", payloadId: 3, socket: "muzzle" }
    ])
  });
}
var SHIELD_PROFILE = {
  timelineIds: { brace: 100, advance: 101, turn: 102, bash: 103, stunned: 104 },
  integrity: 2,
  speed: pixels(1),
  sightRange: pixels(384),
  bashRange: pixels(29),
  bashHeight: pixels(24),
  bashActiveTick: 12,
  bashActiveTicks: 4,
  damageByMaterial: { bullet: 0, explosive: 2, heat: 1, energy: 1, blade: 0, blunt: 1 }
};
COMBAT_CONTENT.attacks.push({
  id: 6,
  kind: "melee",
  shapeId: 12,
  damage: 1,
  lifetimeTicks: 4,
  speed: 0,
  maxTargets: 4,
  repeatDamageTicks: 0,
  material: "blunt"
});
for (const [index, durationTicks] of [24, 36, 9, 9, 12, 4, 14, 36].entries())
  COMBAT_CONTENT.poses.push({
    id: 100 + index,
    frame: `engineering-shield-${index}`,
    durationTicks,
    sockets: [{ name: "hand", point: { x: 0, y: pixels(-18) } }],
    hurtShapeIds: [3]
  });
COMBAT_CONTENT.timelines.push(
  { id: 100, durationTicks: 24, poses: [100], markers: [] },
  { id: 101, durationTicks: 36, poses: [101], markers: [] },
  {
    id: 102,
    durationTicks: 18,
    poses: [102, 103],
    markers: [
      { tickOffset: 9, kind: "face", payloadId: 1, socket: "hand" },
      { tickOffset: 9, kind: "sound", payloadId: 8, socket: "hand" }
    ]
  },
  {
    id: 103,
    durationTicks: 30,
    poses: [104, 105, 106],
    markers: [
      { tickOffset: 12, kind: "activate-hitbox", payloadId: 6, socket: "hand" },
      { tickOffset: 12, kind: "sound", payloadId: 6, socket: "hand" }
    ]
  },
  {
    id: 104,
    durationTicks: 36,
    poses: [107],
    markers: [{ tickOffset: 0, kind: "sound", payloadId: 7, socket: "hand" }]
  }
);
var profiles = [];
for (const [index, weapon] of [sidearm, hmg, shotgun, flame, rocket, laser].entries()) {
  const base = weapon.id === "laser" ? LASER_WEAPON.timelineId : weapon.id === "rocket-launcher" ? ROCKET_WEAPON.timelineId : 10 + index * 4;
  const timelineIds = [base, base + 1, base + 2, base + 3];
  weapon.timelineId = base;
  const duration2 = weapon.id === "laser" ? LASER_WEAPON.cadenceTicks : weapon.id === "flamethrower" ? 30 : weapon.id === "shotgun" || weapon.id === "rocket-launcher" ? 12 : 4;
  const emissions = AREA_PROFILES.get(weapon.attackId)?.emissionOffsets ?? [0];
  for (const [poseIndex, id2] of timelineIds.entries()) {
    const muzzle = (weapon.id === "heavy-machine-gun" && poseIndex !== 3 ? HMG_SWEEP.headings.find((heading) => heading.timelineId === id2)?.muzzle : void 0) ?? [
      { x: pixels(15), y: pixels(-23) },
      { x: pixels(2), y: pixels(-36) },
      { x: pixels(2), y: 0 },
      { x: pixels(15), y: pixels(-12) }
    ][poseIndex];
    if (!muzzle) throw new Error("Missing firearm socket");
    COMBAT_CONTENT.poses.push({
      id: id2,
      frame: `engineering-${weapon.id}-${poseIndex}`,
      durationTicks: duration2,
      sockets: [
        { name: "muzzle", point: muzzle },
        { name: "hand", point: { x: 0, y: poseIndex === 3 ? pixels(-12) : pixels(-23) } }
      ],
      hurtShapeIds: [poseIndex === 3 ? 7 : 3]
    });
    COMBAT_CONTENT.timelines.push({
      id: id2,
      durationTicks: duration2,
      poses: [id2],
      markers: [
        ...emissions.flatMap((tickOffset) => [
          {
            tickOffset,
            kind: "spawn-attack",
            payloadId: weapon.attackId,
            socket: "muzzle"
          },
          {
            tickOffset,
            kind: "sound",
            payloadId: weapon.attackId,
            socket: "muzzle"
          }
        ]),
        ...["flamethrower", "laser"].includes(weapon.id) ? [] : [
          {
            tickOffset: 2,
            kind: "sound",
            payloadId: weapon.attackId,
            socket: "hand"
          }
        ]
      ]
    });
  }
  profiles.push({
    weapon,
    timelineIds,
    ...weapon.id === "heavy-machine-gun" ? { sweep: HMG_SWEEP } : {}
  });
}
for (const heading of HMG_SWEEP.headings.filter((heading2) => heading2.timelineId >= 200)) {
  const reference = COMBAT_CONTENT.timelines.find((timeline) => timeline.id === 14);
  if (!reference) throw new Error("Missing HMG timing");
  COMBAT_CONTENT.poses.push({
    id: heading.timelineId,
    frame: `engineering-heavy-machine-gun-pitch-${heading.pitch}`,
    durationTicks: reference.durationTicks,
    sockets: [
      { name: "muzzle", point: heading.muzzle },
      { name: "hand", point: { x: 0, y: pixels(-23) } }
    ],
    hurtShapeIds: [3]
  });
  COMBAT_CONTENT.timelines.push({
    ...structuredClone(reference),
    id: heading.timelineId,
    poses: [heading.timelineId]
  });
}
var tankActor = {
  id: 2,
  locomotion: "grounded",
  standingShapeId: 15,
  crouchedShapeId: 15,
  idlePoseId: 130,
  runSpeed: pixels(3),
  jumpVelocity: -pixels(5),
  gravity: 64,
  terminalVelocity: pixels(8)
};
var tankDefinition = {
  id: 1,
  kind: "tank",
  actorId: 2,
  armor: 3,
  weaponId: "heavy-machine-gun",
  seat: {
    socket: { x: 0, y: -pixels(6) },
    ejectionCandidates: [
      { x: pixels(30), y: 0 },
      { x: -pixels(30), y: 0 },
      { x: 0, y: -pixels(38) }
    ],
    boardingSensorShapeId: 16,
    boardingTimelineId: 130
  }
};
var TANK_PROFILE = {
  cannon: CANNON_PROFILE,
  special: TANK_SPECIAL_PROFILE,
  definition: tankDefinition,
  locomotion: tankActor,
  exitTimelineId: 131,
  fireTimelineIds: Array.from({ length: 8 }, (_, i) => 140 + i),
  attackId: 16,
  fireCadenceTicks: 5,
  turnTicks: 3,
  damageProtectionTicks: 30,
  reboardTicks: 30,
  exitProtectionTicks: 12,
  disconnectGraceTicks: 15,
  fallBoundary: pixels(248),
  hardpoint: { x: 0, y: -pixels(24) },
  headings: [
    [26, -24, 20, 0],
    [20, -44, 14, -14],
    [0, -50, 0, -20],
    [-20, -44, -14, -14],
    [-26, -24, -20, 0],
    [-20, -4, -14, 14],
    [0, 2, 0, 20],
    [20, -4, 14, 14]
  ].map(([x = 0, y = 0, vx = 0, vy = 0]) => ({
    muzzle: { x: pixels(x), y: pixels(y) },
    velocity: { x: pixels(vx), y: pixels(vy) }
  }))
};
COMBAT_CONTENT.actors = COMBAT_CONTENT.actors.map((actor) => actor.id === 2 ? tankActor : actor);
COMBAT_CONTENT.vehicles = [tankDefinition];
COMBAT_CONTENT.shapes.push(
  { id: 15, rect: { x: -pixels(20), y: -pixels(24), w: pixels(40), h: pixels(24) } },
  { id: 16, rect: { x: -pixels(40), y: -pixels(40), w: pixels(80), h: pixels(40) } },
  structuredClone(CANNON_SHAPE),
  structuredClone(CANNON_BLAST_SHAPE),
  structuredClone(TANK_SPECIAL_SHAPE)
);
COMBAT_CONTENT.attacks.push(structuredClone(CANNON_ATTACK), structuredClone(TANK_SPECIAL_ATTACK));
COMBAT_CONTENT.attacks.push({
  id: 16,
  kind: "swept-projectile",
  shapeId: 4,
  damage: 1,
  lifetimeTicks: 40,
  speed: pixels(20),
  maxTargets: 1,
  repeatDamageTicks: 0,
  material: "bullet"
});
for (const [id2, duration2] of [
  [130, 12],
  [131, 8]
]) {
  COMBAT_CONTENT.poses.push({
    id: id2,
    frame: `engineering-tank-${id2 === 130 ? "board" : "exit"}`,
    durationTicks: duration2,
    sockets: [
      { name: "seat", point: tankDefinition.seat.socket },
      { name: "ejection", point: { x: pixels(30), y: 0 } }
    ],
    hurtShapeIds: [15]
  });
  COMBAT_CONTENT.timelines.push({
    id: id2,
    durationTicks: duration2,
    poses: [id2],
    markers: [
      {
        tickOffset: duration2 - 1,
        kind: "seat-transfer",
        payloadId: 1,
        socket: id2 === 130 ? "seat" : "ejection"
      }
    ]
  });
}
for (const [heading, exposure] of TANK_PROFILE.headings.entries()) {
  const id2 = 140 + heading;
  COMBAT_CONTENT.poses.push({
    id: id2,
    frame: `engineering-tank-fire-${heading}`,
    durationTicks: 3,
    sockets: [{ name: "muzzle", point: exposure.muzzle }],
    hurtShapeIds: [15]
  });
  COMBAT_CONTENT.timelines.push({
    id: id2,
    durationTicks: 3,
    poses: [id2],
    markers: [
      { tickOffset: 0, kind: "spawn-attack", payloadId: 16, socket: "muzzle" },
      { tickOffset: 0, kind: "sound", payloadId: 16, socket: "muzzle" }
    ]
  });
}
for (const [heading, exposure] of CANNON_PROFILE.headings.entries()) {
  const id2 = CANNON_PROFILE.fireTimelineIds[heading];
  if (id2 === void 0) throw new Error("Missing cannon timeline");
  COMBAT_CONTENT.poses.push({
    id: id2,
    frame: `engineering-tank-cannon-${heading}`,
    durationTicks: CANNON_PROFILE.recoil.length,
    sockets: [{ name: "muzzle", point: exposure.muzzle }],
    hurtShapeIds: [15]
  });
  COMBAT_CONTENT.timelines.push({
    id: id2,
    durationTicks: CANNON_PROFILE.recoil.length,
    poses: [id2],
    markers: [
      {
        tickOffset: CANNON_PROFILE.releaseTick,
        kind: "spawn-attack",
        payloadId: CANNON_ATTACK.id,
        socket: "muzzle"
      },
      {
        tickOffset: CANNON_PROFILE.releaseTick,
        kind: "sound",
        payloadId: CANNON_ATTACK.id,
        socket: "muzzle"
      }
    ]
  });
}
for (const platform of COMBAT_ORDNANCE)
  COMBAT_CONTENT.shapes.push({
    id: platform.shapeId,
    rect: { x: 0, y: 0, w: platform.w, h: platform.h }
  });
validateContent(COMBAT_CONTENT);
for (const [id2, profile] of AREA_PROFILES) {
  const definition = COMBAT_CONTENT.attacks.find((attack2) => attack2.id === id2);
  if (!definition) throw new Error("Missing area attack definition");
  validateAreaProfile(profile, definition);
}
var COMBAT_CATALOG = {
  firearms: new Map(profiles.map((profile) => [profile.weapon.id, profile])),
  timelines: new Map(COMBAT_CONTENT.timelines.map((timeline) => [timeline.id, timeline])),
  poses: new Map(COMBAT_CONTENT.poses.map((pose) => [pose.id, pose]))
};
var COMBAT_SHAPES = new Map(COMBAT_CONTENT.shapes.map((shape) => [shape.id, shape]));
for (const profile of profiles) validateFirearmSweep(profile, COMBAT_CATALOG);
validateTankProfile(TANK_PROFILE, COMBAT_SHAPES, COMBAT_CATALOG);
var COMBAT_ATTACKS = new Map(
  COMBAT_CONTENT.attacks.map((definition) => [definition.id, definition])
);

// src/game/labs/combat-pickups.ts
var SUPPLIES = [
  { weaponId: "heavy-machine-gun", ammo: 150, x: 90 },
  { weaponId: "shotgun", ammo: 24, x: 145 },
  { weaponId: "flamethrower", ammo: 30, x: 200 },
  { weaponId: "rocket-launcher", ammo: 20, x: 255 },
  { weaponId: "laser", ammo: 120, x: 310 }
];
function combatPickupDefinitions(scenario, players) {
  integer(players, 1, 4, "combat supply party size");
  if (scenario !== "pickups" && scenario !== "support") return [];
  const definition = (id2, sourceId, weaponId, ammo, x, y, supportId, expiresTick = 3600) => ({
    id: id2,
    claimId: id2,
    sourceId,
    kind: "weapon",
    weaponId,
    ammo,
    ammoLimit: ammo,
    activationTick: 1,
    expiresTick,
    supportId,
    rect: { x: pixels(x - 12), y: pixels(y - 23), w: pixels(24), h: pixels(23) }
  });
  if (scenario === "support") return [definition(620, 505, "shotgun", 24, 250, 160, 104)];
  return [
    ...SUPPLIES.flatMap(
      (supply, station) => Array.from(
        { length: players },
        (_, slot) => definition(
          600 + station * 4 + slot,
          500 + station,
          supply.weaponId,
          supply.ammo,
          supply.x,
          200,
          100
        )
      )
    ),
    // The rear item expires while the group travels forward, independently of any claim.
    definition(621, 506, "shotgun", 24, 12, 200, 100, 24)
  ];
}

// src/game/labs/combat-scenarios.ts
var COMBAT_SCENARIOS = [
  "range",
  "wall",
  "shield",
  "rifle",
  "guard",
  "shotgun",
  "flame",
  "tank",
  "ordnance",
  "hmg",
  "support",
  "rocket",
  "laser",
  "pickups",
  ...MATERIAL_SCENARIOS
];
function isCombatScenario(value) {
  return typeof value === "string" && COMBAT_SCENARIOS.some((scenario) => scenario === value);
}

// src/game/labs/combat-tanks.ts
var neutral = { held: 0, jumpPressed: false, firePressed: false, grenadePressed: false };
function exitShape() {
  const shape = FOOT_DEFINITION && COMBAT_SHAPES.get(FOOT_DEFINITION.standingShapeId);
  if (!shape) throw new Error("Missing tank ejection shape");
  return shape;
}
function releaseCombatTank(world, tank, reason, changes, lifeNotices, index, frame) {
  const id2 = tankOwner(tank);
  if (reason === "destroyed") tank.armor = 0;
  if (id2 === null) {
    if (reason === "destroyed") tank.controlEpoch = nextCounter(tank.controlEpoch);
    tank.lifecycle = tank.armor === 0 ? "wreck" : "available";
    tank.action = idleTankAction(frame.tick);
    tank.secondary.action = idleTankAction(frame.tick);
    if (tank.armor === 0) tank.body.vx = tank.body.vy = tank.invulnerableTicks = 0;
    return;
  }
  const slot = world.players.findIndex((player) => player.playerId === id2);
  const actor = world.players[slot];
  if (!actor) throw new Error("Missing tank release owner");
  const safe = releaseTank(tank, actor, frame.tick, TANK_PROFILE, exitShape(), index, frame);
  if (tank.armor === 0) tank.body.vx = tank.body.vy = tank.invulnerableTicks = 0;
  changes.set(id2, reason);
  if (!safe || tank.body.y > TANK_PROFILE.fallBoundary) {
    const death = damagePlayer(actor, frame.tick, 1, "classic", "fall");
    world.players[slot] = death.actor;
    if (death.notice) lifeNotices.push(death.notice);
  }
}
function advanceCombatTanks(world, commands, connections, changes, lifeNotices, index, frame) {
  const outcomes = /* @__PURE__ */ new Map();
  for (const player of world.players) {
    if (player.vehicleId !== null && !world.tanks.some(
      (tank) => tank.body.id === player.vehicleId && tankOwner(tank) === player.playerId
    ))
      throw new Error("Combat vehicle owner mismatch");
    outcomes.set(player.playerId, {
      jumpAccepted: false,
      interact: "none",
      special: commands[player.slot]?.specialPressed ? "unavailable" : "none"
    });
  }
  for (const [tankIndex, before] of world.tanks.entries()) {
    if (before.lifecycle === "wreck") continue;
    const id2 = tankOwner(before), actor = world.players.find((player) => player.playerId === id2), slot = actor?.slot;
    const connected = id2 !== null && connections.connectedPlayerIds.includes(id2);
    const forced = id2 !== null && connections.releasePlayerIds.includes(id2);
    const intent = connected && !forced && slot !== void 0 ? commands[slot] ?? neutral : neutral;
    const moved = moveTank(before, intent, TANK_PROFILE, COMBAT_SHAPES, index, frame);
    const tank = moved.tank;
    world.tanks[tankIndex] = tank;
    if (actor) attachTankDriver(tank, actor, TANK_PROFILE);
    if (moved.fault && moved.fault.reason !== "crushed")
      throw new Error(`Combat tank: ${moved.fault.reason}`);
    if (moved.fault || tank.body.y > TANK_PROFILE.fallBoundary) {
      if (tank.special.phase === "charging") {
        finishTankCharge(tank, frame.tick);
        continue;
      }
      releaseCombatTank(world, tank, "destroyed", changes, lifeNotices, index, frame);
      continue;
    }
    if (id2 === null || !actor) continue;
    tank.disconnectedTicks = connected ? 0 : tank.disconnectedTicks + 1;
    if (forced || tank.disconnectedTicks >= TANK_PROFILE.disconnectGraceTicks) {
      releaseCombatTank(world, tank, "disconnect", changes, lifeNotices, index, frame);
      continue;
    }
    const outcome = outcomes.get(id2);
    if (outcome) outcome.jumpAccepted = moved.jumpAccepted;
    const transfer = stepTankTransfer(
      tank,
      actor,
      frame.tick,
      TANK_PROFILE,
      COMBAT_CATALOG,
      exitShape(),
      index,
      frame
    );
    if (transfer) changes.set(id2, transfer === "board" ? "board" : "exit");
  }
  for (const actor of [...world.players].sort((a, b) => a.slot - b.slot)) {
    const command = commands[actor.slot], outcome = outcomes.get(actor.playerId);
    if (!command?.interactPressed || !outcome) continue;
    outcome.interact = "unavailable";
    if (changes.has(actor.playerId) || !connections.connectedPlayerIds.includes(actor.playerId))
      continue;
    const owned = world.tanks.find((tank) => tankOwner(tank) === actor.playerId);
    if (owned) {
      if (requestTankExit(
        owned,
        actor,
        frame.tick,
        world.nextActionId,
        TANK_PROFILE,
        exitShape(),
        index,
        frame
      )) {
        changes.set(actor.playerId, "exit");
        world.nextActionId = nextCounter(world.nextActionId);
        outcome.interact = "applied";
      }
    } else {
      const candidates = [...world.tanks].sort(
        (a, b) => Math.abs(a.body.x - actor.body.x) + Math.abs(a.body.y - actor.body.y) - Math.abs(b.body.x - actor.body.x) - Math.abs(b.body.y - actor.body.y) || a.body.id - b.body.id
      );
      for (const tank of candidates) {
        if (!reserveTank(
          tank,
          actor,
          frame.tick,
          world.nextActionId,
          TANK_PROFILE,
          COMBAT_SHAPES,
          index,
          frame
        ))
          continue;
        changes.set(actor.playerId, "board");
        world.nextActionId = nextCounter(world.nextActionId);
        outcome.interact = "applied";
        break;
      }
    }
  }
  for (const tank of world.tanks) {
    const ownerId = tankOwner(tank), actor = world.players.find((player) => player.playerId === ownerId);
    const command = actor && commands[actor.slot], outcome = actor && outcomes.get(actor.playerId);
    const permitted = actor?.life === "alive" && tank.lifecycle === "occupied" && !changes.has(actor.playerId) && connections.connectedPlayerIds.includes(actor.playerId) && !connections.releasePlayerIds.includes(actor.playerId) && Boolean((command?.held ?? 0) & Held.VehicleSpecial);
    if (!permitted) {
      cancelTankSpecial(tank, frame.tick);
      if (actor) actor.vehicleSpecialTicks = 0;
      continue;
    }
    if (!actor || !command || !outcome) throw new Error("Missing special owner");
    if (command.specialPressed) {
      if (tank.special.phase === "arming") outcome.special = "cooldown";
      else {
        tank.special = {
          phase: "arming",
          actionInstanceId: world.nextActionId,
          ownerId: actor.playerId,
          ownerControlEpoch: actor.controlEpoch,
          startTick: frame.tick,
          commitTick: null,
          endTick: null,
          direction: tank.facing
        };
        world.nextActionId = nextCounter(world.nextActionId);
        outcome.special = "applied";
      }
    }
    actor.vehicleSpecialTicks = tank.special.phase === "arming" ? frame.tick - tank.special.startTick + 1 : 0;
  }
  return outcomes;
}
function commitCombatSpecials(world, changes, index, frame) {
  for (const tank of world.tanks) {
    const special = tank.special;
    if (special.phase !== "arming" || frame.tick - special.startTick + 1 < TANK_PROFILE.special.armTicks)
      continue;
    const actor = world.players.find((player) => player.playerId === special.ownerId);
    if (actor?.life !== "alive" || tank.lifecycle !== "occupied" || !tankExitBody(tank, actor, TANK_PROFILE, exitShape(), index, frame)) {
      cancelTankSpecial(tank, frame.tick);
      if (actor) actor.vehicleSpecialTicks = 0;
      continue;
    }
    const direction = tank.facing;
    if (!releaseTank(tank, actor, frame.tick, TANK_PROFILE, exitShape(), index, frame))
      throw new Error("Special ejection changed within one boundary");
    tank.special = {
      ...special,
      phase: "charging",
      commitTick: frame.tick,
      endTick: null,
      direction
    };
    tank.armor = tank.invulnerableTicks = 0;
    tank.lifecycle = "destroying";
    changes.set(actor.playerId, "special");
  }
}
function fireCombatTanks(world, commands, changes, terrain) {
  const outcomes = /* @__PURE__ */ new Map();
  for (const tank of world.tanks) {
    const ownerId = tank.occupantId;
    if (ownerId === null) continue;
    const actor = world.players.find((player) => player.playerId === ownerId), command = actor && commands[actor.slot];
    if (!actor || !command) throw new Error("Missing tank fire owner");
    const changed = changes.has(ownerId);
    const result = stepTankGun(
      tank,
      changed ? neutral : command,
      world.tick,
      world.nextActionId,
      TANK_PROFILE,
      COMBAT_CATALOG
    );
    world.nextActionId = result.nextActionId;
    const cannon = stepTankCannon(
      tank,
      !changed && command.grenadePressed,
      world.tick,
      world.nextActionId,
      TANK_PROFILE,
      COMBAT_CATALOG
    );
    world.nextActionId = cannon.nextActionId;
    outcomes.set(ownerId, {
      fire: changed && (command.firePressed || command.held & Held.Fire) ? "unavailable" : result.outcome,
      grenade: changed && command.grenadePressed ? "unavailable" : cannon.outcome
    });
    for (const [secondary, release] of [
      [false, result],
      [true, cannon]
    ]) {
      const profile = secondary ? TANK_PROFILE.cannon : TANK_PROFILE;
      const action = secondary ? tank.secondary.action : tank.action;
      const feed = secondary ? tank.secondary : tank.weapon;
      for (const item of release.markers) {
        const socket = item.pose.sockets.find((socket2) => socket2.name === "muzzle"), definition = COMBAT_ATTACKS.get(item.marker.payloadId), heading = profile.headings[profile.fireTimelineIds.indexOf(action.definitionId)], shape = definition && COMBAT_SHAPES.get(secondary ? TANK_PROFILE.cannon.bodyShapeId : definition.shapeId);
        if (!socket || !definition || !shape || !heading)
          throw new Error("Missing tank release content");
        const point2 = worldSocket(tank.body, socket.point, 1);
        const notice2 = {
          kind: "sound",
          ownerId,
          actionInstanceId: item.actionInstanceId,
          markerIndex: item.markerIndex,
          source: {
            definitionId: definition.id,
            controlEpoch: actor.controlEpoch,
            shotOrdinal: feed.shotOrdinal,
            vehicleId: tank.body.id
          },
          position: point2,
          impact: null,
          targetId: null,
          beam: null
        };
        if (item.marker.kind === "spawn-attack") {
          notice2.kind = "shot";
          if (muzzleBlocked(worldSocket(tank.body, profile.hardpoint, 1), point2, shape, terrain))
            notice2.kind = "muzzle-blocked";
          else {
            if (world.projectiles.length >= 256)
              throw new Error("Tank projectile cap requires recovery");
            world.projectiles.push({
              id: world.nextEntityId,
              ownerId,
              team: 1,
              actionInstanceId: item.actionInstanceId,
              definitionId: definition.id,
              position: point2,
              velocity: { ...heading.velocity },
              spawnTick: world.tick
            });
            world.nextEntityId = nextCounter(world.nextEntityId);
          }
        } else if (item.marker.kind !== "sound") throw new Error("Unsupported tank gun marker");
        world.events.push(notice2);
      }
    }
  }
  return outcomes;
}
function tankCombatHurtboxes(tanks, previous = tanks) {
  return tanks.flatMap((tank, i) => {
    if (tank.armor === 0) return [];
    const before = previous[i], shape = COMBAT_SHAPES.get(tank.body.shapeId);
    if (!before || before.body.id !== tank.body.id || !shape)
      throw new Error("Tank hurtbox identity");
    return [
      {
        id: tank.body.id * 2,
        entityId: tank.body.id,
        team: 1,
        kind: "body",
        rect: worldRect(before.body, shape.rect, tank.facing),
        delta: { x: tank.body.x - before.body.x, y: tank.body.y - before.body.y }
      }
    ];
  });
}
function commitCombatSeats(current, world, changes) {
  return [...changes].sort(([a], [b]) => a - b).map(([playerId, reason]) => {
    const before = current.players.find((actor2) => actor2.playerId === playerId), actor = world.players.find((actor2) => actor2.playerId === playerId);
    if (!before || !actor) throw new Error("Missing seat transfer generation");
    actor.controlEpoch = nextCounter(before.controlEpoch);
    const tank = world.tanks.find((tank2) => tankOwner(tank2) === playerId);
    if (tank) tank.ownerControlEpoch = actor.controlEpoch;
    return {
      kind: "seat",
      playerId,
      vehicleId: actor.vehicleId,
      controlEpoch: actor.controlEpoch,
      reason
    };
  });
}

// src/game/labs/combat.ts
var COMBAT_LAB_LIMIT = 3600;
var COMBAT_ENTRY = {
  firstX: pixels(45),
  slotSpacing: pixels(4),
  y: pixels(200),
  fallBoundary: pixels(248)
};
var COMBAT_TANK_DEPOT = {
  firstPlayerX: pixels(36),
  slotSpacing: pixels(56),
  vehicleOffsetX: pixels(24),
  y: pixels(200)
};
function combatEntryContext(actor, index, frame, scenario = "range") {
  if (!FOOT_DEFINITION) throw new Error("Missing life physics definition");
  const shape = COMBAT_SHAPES.get(FOOT_DEFINITION.standingShapeId);
  if (!shape) throw new Error("Missing life entry shape");
  const lift = scenario === "ordnance" ? index.get(COMBAT_ORDNANCE[0].id)?.rect : void 0;
  const material = materialCase(scenario);
  return {
    shape,
    definition: FOOT_DEFINITION,
    shapes: COMBAT_SHAPES,
    fallBoundary: COMBAT_ENTRY.fallBoundary,
    anchors: [
      {
        x: material ? materialPlayerX(material.weapon) + actor.slot * COMBAT_ENTRY.slotSpacing : scenario === "tank" ? COMBAT_TANK_DEPOT.firstPlayerX + actor.slot * COMBAT_TANK_DEPOT.slotSpacing : COMBAT_ENTRY.firstX + actor.slot * COMBAT_ENTRY.slotSpacing + (lift ? lift.x - pixels(24) : 0),
        y: lift?.y ?? COMBAT_ENTRY.y
      }
    ],
    index,
    frame
  };
}
function combatEncounterDefinition(world) {
  return {
    id: 1,
    participants: world.players.map((player) => player.playerId),
    members: world.targets.map(({ enemy }) => ({
      id: enemy.body.id,
      required: true,
      critical: false,
      retreatAllowed: false,
      watchdogTicks: 600,
      ambientCleanupTicks: null
    })),
    objectives: []
  };
}
function lifecycle(world) {
  return new EncounterLifecycle(combatEncounterDefinition(world));
}
function createCombatLab(scenario, count = 1) {
  if (!isCombatScenario(scenario)) throw new Error("Unknown combat scenario");
  const material = materialCase(scenario);
  integer(count, 1, 4, "combat players");
  const players = Array.from({ length: count }, (_, slot) => {
    const actor = footActor(
      material ? materialPlayerX(material.weapon) / 256 : scenario === "tank" ? (COMBAT_TANK_DEPOT.firstPlayerX + slot * COMBAT_TANK_DEPOT.slotSpacing) / 256 : 45 + slot * 4,
      scenario === "ordnance" ? 160 : 200
    );
    actor.playerId = actor.body.id = slot + 1;
    actor.slot = slot;
    if (scenario === "ordnance") actor.body.supportId = 102;
    if (slot === 1 && scenario !== "pickups")
      actor.weapon = { ...actor.weapon, id: "heavy-machine-gun", ammo: 150 };
    if (scenario === "hmg") actor.weapon = { ...actor.weapon, id: "heavy-machine-gun", ammo: 150 };
    if (scenario === "shotgun") actor.weapon = { ...actor.weapon, id: "shotgun", ammo: 24 };
    if (scenario === "flame") actor.weapon = { ...actor.weapon, id: "flamethrower", ammo: 30 };
    if (scenario === "rocket") actor.weapon = { ...actor.weapon, id: "rocket-launcher", ammo: 20 };
    if (scenario === "laser") actor.weapon = { ...actor.weapon, id: "laser", ammo: 120 };
    if (material) {
      const weapon = COMBAT_CONTENT.weapons.find(
        (weapon2) => weapon2.id === (material.weapon === "knife" || material.weapon === "grenade" ? "sidearm" : material.weapon)
      );
      if (!weapon) throw new Error("Missing material weapon content");
      actor.weapon = {
        ...actor.weapon,
        id: weapon.id,
        ammo: weapon.pickupAmmo === "unlimited" ? 0 : weapon.pickupAmmo
      };
    }
    return actor;
  });
  const props = combatDestructibles(scenario).map(createDestructible);
  const targets2 = Array.from({ length: 2 }, (_, index) => ({
    enemy: {
      body: {
        ...footActor(
          material ? (MATERIAL_CALIBRATION.firstTargetX + index * MATERIAL_CALIBRATION.targetSpacing) / 256 : scenario === "support" ? 220 + index * 60 : scenario === "ordnance" ? 340 + index * 26 : scenario === "tank" ? 300 + index * 40 : scenario === "shotgun" ? 140 + index * 30 : (scenario === "guard" || scenario === "flame") && index === 0 ? 140 : scenario === "flame" ? 220 : 220 + index * 60,
          scenario === "support" ? 160 : 200
        ).body,
        ...scenario === "support" ? { supportId: 104 } : {},
        id: 20 + index
      },
      facing: -1,
      geometryRevision: 1,
      life: "alive",
      removalReason: null,
      turns: 0
    },
    health: material ? MATERIAL_CALIBRATION.targetHealth : 1,
    shield: scenario === "shield" && index === 0,
    rifle: scenario === "tank" || scenario === "rifle" || (scenario === "guard" || scenario === "flame" || scenario === "support") && index === 1 ? createRifleState() : null,
    guard: (scenario === "guard" || scenario === "flame" || scenario === "support") && index === 0 ? createShieldState(SHIELD_PROFILE) : null
  }));
  return {
    format: 16,
    scenario,
    tick: 0,
    nextActionId: 1,
    nextEntityId: 1e3,
    eventSequence: 0,
    players,
    tanks: scenario === "tank" ? players.map(
      (actor) => createTank(
        30 + actor.slot,
        {
          x: COMBAT_TANK_DEPOT.firstPlayerX + actor.slot * COMBAT_TANK_DEPOT.slotSpacing + COMBAT_TANK_DEPOT.vehicleOffsetX,
          y: COMBAT_TANK_DEPOT.y
        },
        100,
        TANK_PROFILE
      )
    ) : [],
    targets: targets2,
    props,
    pickups: createWeaponPickups(
      combatPickupDefinitions(scenario, count),
      COMBAT_CATALOG,
      combatTerrain(scenario, 0, props)
    ),
    pickupClaims: [],
    projectiles: [],
    rockets: [],
    beams: [],
    strikes: [],
    grenades: [],
    areas: [],
    encounter: lifecycle({ players, targets: targets2 }).begin(),
    events: []
  };
}
function combatAreaAnchor(world, area) {
  const actor = world.players.find((actor2) => actor2.playerId === area.ownerId);
  if (actor?.life !== "alive" || actor.vehicleId !== null || actor.action.kind !== "fire" || actor.action.actionInstanceId !== area.actionInstanceId)
    return null;
  const pose = actionPose(
    COMBAT_CATALOG,
    actor.action.definitionId,
    world.tick - actor.action.stateStartTick
  );
  const socket = pose?.sockets.find((socket2) => socket2.name === "muzzle");
  if (!socket) throw new Error("Missing attached volume socket");
  return {
    origin: worldSocket(actor.body, socket.point, actor.facing),
    heading: actor.aim === 1 ? 1 : actor.aim === 2 ? 2 : actor.facing === 1 ? 0 : 3
  };
}
function actionHand(actor, tick2) {
  const pose = actionPose(
    COMBAT_CATALOG,
    actor.action.definitionId,
    tick2 - actor.action.stateStartTick
  );
  const socket = pose?.sockets.find((socket2) => socket2.name === "hand");
  if (!socket) throw new Error("Missing combat hand socket");
  return socket.point;
}
function appendShieldMarkers(world, target, markers) {
  const guard = target.guard;
  if (!guard || target.health === 0) return;
  for (const item of markers) {
    if (item.marker.kind === "face") continue;
    if (item.marker.kind !== "sound" && item.marker.kind !== "activate-hitbox")
      throw new Error("Unsupported shield marker");
    const socket = item.pose.sockets.find((socket2) => socket2.name === item.marker.socket);
    if (!socket) throw new Error("Missing shield marker socket");
    world.events.push({
      kind: item.marker.kind === "sound" ? "action-sound" : "melee",
      ownerId: target.enemy.body.id,
      actionInstanceId: item.actionInstanceId,
      markerIndex: item.markerIndex,
      source: {
        definitionId: item.marker.payloadId,
        timelineId: guard.action.definitionId,
        stateStartTick: guard.action.stateStartTick
      },
      position: worldSocket(target.enemy.body, socket.point, target.enemy.facing),
      impact: null,
      targetId: null,
      beam: null
    });
  }
}
function combatMeleeEligible(actor, terrain, hurtboxes) {
  const definition = COMBAT_ATTACKS.get(4), shape = COMBAT_SHAPES.get(9);
  if (!definition || !shape) throw new Error("Missing contextual melee content");
  const pose = COMBAT_CATALOG.poses.get(
    FOOT_ACTION_PROFILES.melee.timelineIds[actor.locomotion === "crouched" ? 1 : 0]
  );
  const socket = pose?.sockets.find((socket2) => socket2.name === "hand");
  if (!socket) throw new Error("Missing melee ready socket");
  const hand = worldSocket(actor.body, socket.point, actor.facing);
  return actor.aim === 0 && meleeHits(
    { id: actor.body.id, ownerId: actor.playerId, team: 1, actionInstanceId: 1, definitionId: 4 },
    definition,
    shape,
    hand,
    { x: 0, y: 0 },
    actor.facing,
    { x: actor.body.x, y: hand.y },
    terrain,
    hurtboxes
  ).some((hit) => hit.damage > 0);
}
function combatHurtboxes(targets2, tick2, previous = targets2) {
  return targets2.flatMap((target, index) => {
    if (target.health === 0 || target.enemy.life !== "alive") return [];
    const body = target.enemy.body, before = previous[index]?.enemy.body;
    if (!before || before.id !== body.id) throw new Error("Target motion identity mismatch");
    const protectedBody = target.shield || target.guard !== null && shieldProtected(target.guard, tick2, SHIELD_PROFILE);
    const kinds = protectedBody ? ["body", "shield"] : ["body"];
    return kinds.map((kind) => {
      const shape = COMBAT_SHAPES.get(kind === "body" ? 3 : 8);
      if (!shape) throw new Error("Missing target hurt shape");
      return {
        id: body.id * 2 + (kind === "shield" ? 1 : 0),
        entityId: body.id,
        team: 2,
        kind,
        rect: worldRect(before, shape.rect, target.enemy.facing),
        delta: { x: body.x - before.x, y: body.y - before.y }
      };
    });
  });
}
function playerCombatHurtboxes(players, previous = players) {
  return players.flatMap((player, slot) => {
    if (player.life !== "alive" || player.invulnerableTicks > 0 || player.vehicleId !== null)
      return [];
    const before = previous[slot];
    const shape = COMBAT_SHAPES.get(
      player.body.shapeId === FOOT_DEFINITION?.crouchedShapeId ? 7 : 3
    );
    if (!before || before.body.id !== player.body.id || !shape)
      throw new Error("Player hurtbox identity");
    return [
      {
        id: player.body.id * 2,
        entityId: player.body.id,
        team: 1,
        kind: "body",
        rect: worldRect(before.body, shape.rect, player.facing),
        delta: { x: player.body.x - before.body.x, y: player.body.y - before.body.y }
      }
    ];
  });
}
function advanceCombatLab(current, commands, connections = {
  connectedPlayerIds: current.players.map((p) => p.playerId),
  releasePlayerIds: []
}, stage) {
  integer(current.tick, 0, COMBAT_LAB_LIMIT - 1, "combat tick");
  if (current.format !== 16 || current.pickups.tick !== current.tick)
    throw new Error("Combat supply format/boundary mismatch");
  stage ??= materialCombatStage(current);
  if (commands.length !== current.players.length) throw new Error("Missing combat input owner");
  for (const command of commands) {
    integer(command.held, 0, HELD_MASK, "combat held mask");
    if (typeof command.firePressed !== "boolean" || typeof command.jumpPressed !== "boolean" || typeof command.grenadePressed !== "boolean" || typeof command.interactPressed !== "boolean" || typeof command.specialPressed !== "boolean")
      throw new Error("Invalid combat edges");
  }
  const world = structuredClone(current);
  const tick2 = ++world.tick;
  world.events = [];
  const physicalTerrain = stage?.terrain ?? combatTerrain(world.scenario, tick2, world.props);
  const active = (target) => !stage || stage.activeEnemyIds.has(target.enemy.body.id);
  const destructibles = stage?.destructibles ?? combatDestructibles(world.scenario);
  const terrain = physicalTerrain.filter(
    (target) => !world.props.some((prop) => prop.id === target.id)
  );
  const frame = { tick: tick2, geometryRevision: combatGeometryRevision(world.props) };
  const index = combatCollisionIndex(world.scenario, frame, world.props, physicalTerrain);
  const encounterEvents = [];
  const activatedIds = /* @__PURE__ */ new Set();
  const activateTarget = (id2) => {
    if (!activatedIds.has(id2) && world.encounter.members.some((member) => member.id === id2 && member.status === "pending")) {
      activatedIds.add(id2);
      encounterEvents.push({ kind: "activate", id: id2, sequence: ++world.eventSequence, tick: tick2 });
    }
  };
  const lifeNotices = [];
  const seatChanges = /* @__PURE__ */ new Map();
  const playerMovement = /* @__PURE__ */ new Map();
  const outcomes = [];
  for (const [slot, actor] of world.players.entries()) {
    const command = commands[slot];
    if (!command || !FOOT_DEFINITION) throw new Error("Missing combat controller");
    const life = stepPlayerLife(actor, tick2, "classic", {
      ...combatEntryContext(actor, index, frame, world.scenario),
      ...stage ? {
        fallBoundary: stage.fallBoundary,
        anchors: [{ x: stage.entry.x + actor.slot * pixels(24), y: stage.entry.y }]
      } : {}
    });
    if (life.notice) lifeNotices.push(life.notice);
    const result = stepFootController(
      life.actor,
      command,
      FOOT_DEFINITION,
      COMBAT_SHAPES,
      index,
      frame
    );
    if (result.status === "failed") {
      if (result.physics.reason !== "crushed")
        throw new Error(`Combat body: ${result.physics.reason}`);
      const killed = damagePlayer(life.actor, tick2, 1, "classic", "crush");
      world.players[slot] = killed.actor;
      if (killed.notice) lifeNotices.push(killed.notice);
    } else {
      world.players[slot] = result.actor;
      if (result.status === "complete" && actor.life === "alive" && actor.controlEpoch === life.actor.controlEpoch)
        playerMovement.set(actor.playerId, result.physics.movement);
    }
    outcomes.push({
      playerId: actor.playerId,
      jumpAccepted: result.status === "complete" && (result.jumpRequest === "consumed" || result.jumpRequest === "buffered"),
      fire: "none",
      grenade: "none",
      interact: "none",
      special: "none"
    });
  }
  const tankOutcomes = advanceCombatTanks(
    world,
    commands,
    connections,
    seatChanges,
    lifeNotices,
    index,
    frame
  );
  for (const outcome of outcomes) {
    const tank = tankOutcomes.get(outcome.playerId);
    if (!tank) throw new Error("Missing tank input outcome");
    outcome.jumpAccepted ||= tank.jumpAccepted;
    outcome.interact = tank.interact;
    outcome.special = tank.special;
  }
  for (const target of world.targets) {
    if (!active(target)) continue;
    activateTarget(target.enemy.body.id);
    if (target.health === 0) continue;
    const shieldStep = target.guard && stepShield(
      target.guard,
      target.enemy,
      world.players,
      tick2,
      world.nextActionId,
      COMBAT_CATALOG,
      SHIELD_PROFILE
    );
    if (shieldStep) {
      target.guard = shieldStep.state;
      target.enemy.facing = shieldStep.state.facing;
      world.nextActionId = shieldStep.nextActionId;
    }
    const shape = COMBAT_SHAPES.get(target.enemy.body.shapeId);
    if (!shape) throw new Error("Missing enemy body");
    const result = stepGroundedEnemy(
      target.enemy,
      {
        speed: shieldStep ? shieldStep.speed : target.rifle?.action.kind === "fire" ? 0 : stage?.patrolSpeed ?? 64,
        turnAtBoundary: !target.guard && target.rifle?.action.kind !== "fire",
        gravity: 55,
        terminalVelocity: 2048,
        bounds: stage?.enemyBounds ?? { x: 0, y: 0, w: pixels(384), h: pixels(220) }
      },
      shape,
      index,
      frame
    );
    if (result.status === "failed") throw new Error(`Combat enemy: ${result.physics.reason}`);
    target.enemy = result.enemy;
    if (target.enemy.removalReason) {
      target.health = 0;
      if (target.rifle) cancelRifle(target.rifle);
      if (target.guard) cancelShield(target.guard);
      encounterEvents.push({
        kind: "resolve",
        id: target.enemy.body.id,
        reason: target.enemy.removalReason,
        killerId: null,
        sequence: ++world.eventSequence,
        tick: tick2
      });
    }
    if (shieldStep) appendShieldMarkers(world, target, shieldStep.markers);
  }
  for (const [slot, actor] of world.players.entries()) {
    const command = commands[slot];
    if (!command) throw new Error("Missing firearm input");
    const result = stepFootCombatAction(
      actor,
      seatChanges.has(actor.playerId) ? { held: 0, firePressed: false, grenadePressed: false } : command,
      tick2,
      world.nextActionId,
      COMBAT_CATALOG,
      FOOT_ACTION_PROFILES,
      combatMeleeEligible(actor, terrain, [
        ...combatHurtboxes(world.targets, tick2),
        ...destructibleHurtboxes(world.props, destructibles),
        ...stage?.extraHurtboxes ?? []
      ])
    );
    world.players[slot] = result.actor;
    world.nextActionId = result.nextActionId;
    const outcome = outcomes.find((item) => item.playerId === actor.playerId);
    if (!outcome) throw new Error("Missing combat action owner");
    outcome.fire = result.fire;
    outcome.grenade = result.grenade;
    for (const item of result.markers) {
      const local = item.pose.sockets.find((socket) => socket.name === item.marker.socket)?.point;
      if (!local) throw new Error("Missing marker socket");
      const position2 = worldSocket(actor.body, local, actor.facing);
      if (item.marker.payloadId === 4 || item.marker.payloadId === 5) {
        const notice3 = {
          kind: "action-sound",
          ownerId: actor.playerId,
          actionInstanceId: item.actionInstanceId,
          markerIndex: item.markerIndex,
          source: {
            definitionId: item.marker.payloadId,
            timelineId: result.actor.action.definitionId,
            stateStartTick: result.actor.action.stateStartTick
          },
          position: position2,
          impact: null,
          targetId: null,
          beam: null
        };
        if (item.marker.kind === "activate-hitbox") {
          notice3.kind = "melee";
          world.strikes.push({
            id: world.nextEntityId,
            ownerId: actor.playerId,
            team: 1,
            actionInstanceId: item.actionInstanceId,
            definitionId: 4,
            spawnTick: tick2,
            endTick: tick2 + (COMBAT_ATTACKS.get(4)?.lifetimeTicks ?? 0),
            hitIds: []
          });
          world.nextEntityId = nextCounter(world.nextEntityId);
        } else if (item.marker.kind === "spawn-attack") {
          notice3.kind = "throw";
          const shape = COMBAT_SHAPES.get(GRENADE_PROFILE.bodyShapeId);
          if (!shape) throw new Error("Missing grenade body");
          const handRoot = { x: actor.body.x, y: position2.y };
          const delta = { x: position2.x - handRoot.x, y: 0 };
          const blocking = earliestSweep(
            worldRect(handRoot, shape.rect, 1),
            delta,
            physicalTerrain.map((target) => ({
              ...target,
              rect: {
                ...target.rect,
                x: target.rect.x + target.delta.x,
                y: target.rect.y + target.delta.y
              },
              delta: { x: 0, y: 0 }
            }))
          );
          if (blocking.overlaps.length) throw new Error("Grenade hand starts inside terrain");
          const contact = blocking.contacts[0];
          const releaseDelta = contact ? displacementAtContact(delta, contact.time) : delta;
          const release = { x: handRoot.x + releaseDelta.x, y: handRoot.y + releaseDelta.y };
          notice3.position = release;
          const velocity2 = grenadeLaunchVelocity(actor, GRENADE_PROFILE, index, frame);
          world.grenades.push({
            id: world.nextEntityId,
            ownerId: actor.playerId,
            team: 1,
            actionInstanceId: item.actionInstanceId,
            definitionId: 5,
            spawnTick: tick2,
            bounces: 0,
            body: {
              id: world.nextEntityId,
              x: release.x,
              y: release.y,
              vx: velocity2.x,
              vy: velocity2.y,
              remainderX: 0,
              remainderY: 0,
              shapeId: shape.id,
              grounded: false,
              supportId: null,
              contacts: []
            }
          });
          world.nextEntityId = nextCounter(world.nextEntityId);
        } else if (item.marker.kind !== "sound") throw new Error("Unsupported foot action marker");
        world.events.push(notice3);
        continue;
      }
      const notice2 = {
        kind: "sound",
        ownerId: actor.playerId,
        actionInstanceId: item.actionInstanceId,
        markerIndex: item.markerIndex,
        source: {
          definitionId: item.marker.payloadId,
          controlEpoch: result.actor.controlEpoch,
          shotOrdinal: result.actor.weapon.shotOrdinal
        },
        position: position2,
        impact: null,
        targetId: null,
        beam: null
      };
      if (item.marker.kind === "spawn-attack") {
        const definition = COMBAT_ATTACKS.get(item.marker.payloadId);
        const shape = definition && COMBAT_SHAPES.get(definition.shapeId);
        const hand = item.pose.sockets.find((socket) => socket.name === "hand")?.point;
        if (!definition || !shape || !hand) throw new Error("Missing release definition");
        notice2.kind = "shot";
        const areaProfile = AREA_PROFILES.get(definition.id);
        const rocket2 = definition.id === ROCKET_ATTACK.id;
        const laser2 = definition.id === LASER_ATTACK.id;
        const clearance = rocket2 ? ROCKET_SHAPE : areaProfile || laser2 ? COMBAT_SHAPES.get(4) : shape;
        if (!clearance) throw new Error("Missing muzzle clearance shape");
        const blocked = muzzleBlocked(
          worldSocket(actor.body, hand, actor.facing),
          position2,
          clearance,
          physicalTerrain,
          rocket2 ? "bullet" : definition.material
        );
        if (areaProfile) {
          let area = world.areas.find((area2) => area2.actionInstanceId === item.actionInstanceId);
          if (!area) {
            if (world.areas.length >= 16) throw new Error("Area attack cap requires recovery");
            area = {
              id: world.nextEntityId,
              ownerId: actor.playerId,
              team: 1,
              actionInstanceId: item.actionInstanceId,
              definitionId: definition.id,
              startTick: result.actor.action.stateStartTick,
              emitted: 0,
              cancelledTick: null,
              lobes: [],
              hits: []
            };
            world.areas.push(area);
            world.nextEntityId = nextCounter(world.nextEntityId);
          }
          emitArea(
            area,
            tick2,
            areaProfile,
            {
              origin: position2,
              heading: actor.aim === 1 ? 1 : actor.aim === 2 ? 2 : actor.facing === 1 ? 0 : 3
            },
            blocked
          );
          if (blocked) notice2.kind = "muzzle-blocked";
        } else if (blocked) notice2.kind = "muzzle-blocked";
        else if (laser2) {
          if (world.beams.length >= 8) throw new Error("Beam cap requires recovery");
          world.beams.push({
            id: world.nextEntityId,
            ownerId: actor.playerId,
            team: 1,
            actionInstanceId: item.actionInstanceId,
            definitionId: definition.id,
            spawnTick: tick2,
            tick: tick2,
            origin: { ...position2 },
            heading: actor.aim === 1 ? 1 : actor.aim === 2 ? 2 : actor.facing === 1 ? 0 : 3,
            length: LASER_PROFILE.range
          });
          world.nextEntityId = nextCounter(world.nextEntityId);
        } else if (rocket2) {
          if (world.rockets.length >= 32) throw new Error("Rocket cap requires recovery");
          world.rockets.push(
            createRocket(
              {
                id: world.nextEntityId,
                ownerId: actor.playerId,
                team: 1,
                actionInstanceId: item.actionInstanceId,
                definitionId: definition.id
              },
              position2,
              actor.aim === 1 ? 24 : actor.aim === 2 ? 8 : actor.facing === 1 ? 0 : 16,
              tick2,
              ROCKET_PROFILE
            )
          );
          world.nextEntityId = nextCounter(world.nextEntityId);
        } else {
          if (world.projectiles.length >= 256) throw new Error("Projectile cap requires recovery");
          world.projectiles.push({
            id: world.nextEntityId,
            ownerId: actor.playerId,
            team: 1,
            actionInstanceId: item.actionInstanceId,
            definitionId: definition.id,
            position: position2,
            velocity: firearmVelocity(result.actor, definition.speed, COMBAT_CATALOG),
            spawnTick: tick2
          });
          world.nextEntityId = nextCounter(world.nextEntityId);
        }
      } else if (item.marker.kind !== "sound") throw new Error("Unsupported firearm marker");
      world.events.push(notice2);
    }
  }
  const tankFire = fireCombatTanks(world, commands, seatChanges, physicalTerrain);
  for (const outcome of outcomes) {
    const fire = tankFire.get(outcome.playerId);
    if (fire !== void 0) {
      outcome.fire = fire.fire;
      outcome.grenade = fire.grenade;
    }
  }
  for (const target of world.targets) {
    if (!active(target) || !target.rifle || target.health === 0) continue;
    const shape = COMBAT_SHAPES.get(4);
    if (!shape) throw new Error("Missing rifle projectile shape");
    const result = stepRifleAttack(
      target.rifle,
      target.enemy,
      world.players,
      tick2,
      world.nextActionId,
      COMBAT_CATALOG,
      RIFLE_PROFILE,
      shape,
      physicalTerrain
    );
    target.rifle = result.state;
    target.enemy.facing = result.facing;
    world.nextActionId = result.nextActionId;
    for (const item of result.markers) {
      const muzzle = item.pose.sockets.find((socket) => socket.name === "muzzle")?.point;
      const hand = item.pose.sockets.find((socket) => socket.name === "hand")?.point;
      const definition = COMBAT_ATTACKS.get(item.marker.payloadId);
      if (!muzzle || !hand || !definition) throw new Error("Missing rifle release content");
      const position2 = worldSocket(target.enemy.body, muzzle, target.enemy.facing);
      const notice2 = {
        kind: "sound",
        ownerId: target.enemy.body.id,
        actionInstanceId: item.actionInstanceId,
        markerIndex: item.markerIndex,
        source: {
          definitionId: definition.id,
          timelineId: target.rifle.action.definitionId,
          stateStartTick: target.rifle.action.stateStartTick
        },
        position: position2,
        impact: null,
        targetId: null,
        beam: null
      };
      if (item.marker.kind === "spawn-attack") {
        notice2.kind = "shot";
        if (muzzleBlocked(
          worldSocket(target.enemy.body, hand, target.enemy.facing),
          position2,
          shape,
          physicalTerrain
        ))
          notice2.kind = "muzzle-blocked";
        else {
          if (world.projectiles.length >= 256) throw new Error("Projectile cap requires recovery");
          world.projectiles.push({
            id: world.nextEntityId,
            ownerId: target.enemy.body.id,
            team: 2,
            actionInstanceId: item.actionInstanceId,
            definitionId: definition.id,
            position: position2,
            velocity: {
              x: target.rifle.aim === 0 ? definition.speed * target.enemy.facing : 0,
              y: target.rifle.aim === 1 ? -definition.speed : 0
            },
            spawnTick: tick2
          });
          world.nextEntityId = nextCounter(world.nextEntityId);
        }
      } else if (item.marker.kind !== "sound") throw new Error("Unsupported rifle marker");
      world.events.push(notice2);
    }
  }
  const hurtboxes = [
    // Authored actors remain material before AI activation. A long-range round must
    // meet an intact shield before it can enter the body behind it.
    ...combatHurtboxes(world.targets, tick2, current.targets),
    ...playerCombatHurtboxes(world.players, current.players),
    ...tankCombatHurtboxes(world.tanks, current.tanks),
    ...destructibleHurtboxes(world.props, destructibles),
    ...stage?.extraHurtboxes ?? []
  ];
  const impacts = [];
  world.beams = world.beams.flatMap((beam) => {
    const index2 = world.players.findIndex((player) => player.playerId === beam.ownerId);
    let anchor = index2 >= 0 && ((commands[index2]?.held ?? 0) & Held.Fire) !== 0 ? combatAreaAnchor(world, beam) : null;
    if (anchor) {
      const actor = world.players[index2], clearance = COMBAT_SHAPES.get(4);
      if (!actor || !clearance) throw new Error("Missing beam muzzle clearance");
      if (muzzleBlocked(
        worldSocket(actor.body, actionHand(actor, tick2), actor.facing),
        anchor.origin,
        clearance,
        physicalTerrain,
        "energy"
      ))
        anchor = null;
    }
    const result = beam.spawnTick === tick2 ? emitBeam(
      beam,
      tick2,
      LASER_ATTACK,
      LASER_PROFILE,
      { origin: beam.origin, heading: beam.heading },
      terrain,
      hurtboxes
    ) : stepBeam(beam, tick2, LASER_ATTACK, LASER_PROFILE, anchor, terrain, hurtboxes);
    if (result.cast) {
      impacts.push(...result.cast.impacts);
      if (beam.spawnTick === tick2) {
        const notice2 = world.events.find(
          (event) => event.kind === "shot" && event.actionInstanceId === beam.actionInstanceId
        );
        if (!notice2) throw new Error("Missing laser birth event");
        notice2.beam = {
          heading: result.cast.heading,
          length: result.cast.length,
          width: result.cast.width
        };
      }
    }
    return result.beam ? [result.beam] : [];
  });
  world.rockets = world.rockets.flatMap((rocket2) => {
    if (rocket2.spawnTick === tick2) return [rocket2];
    const result = stepRocket(
      rocket2,
      tick2,
      ROCKET_ATTACK,
      ROCKET_SHAPE,
      ROCKET_PROFILE,
      terrain,
      hurtboxes
    );
    if (result.status === "active") return [result.rocket];
    if (result.status === "detonated") {
      world.events.push({
        kind: "explosion",
        ownerId: rocket2.ownerId,
        actionInstanceId: rocket2.actionInstanceId,
        markerIndex: 0,
        source: {
          definitionId: rocket2.definitionId,
          spawnTick: rocket2.spawnTick,
          sourceId: rocket2.id
        },
        position: result.contact.position,
        impact: null,
        targetId: null,
        beam: null
      });
      impacts.push(...result.impacts);
    }
    return [];
  });
  world.areas = world.areas.flatMap((area) => {
    const definition = COMBAT_ATTACKS.get(area.definitionId), profile = AREA_PROFILES.get(area.definitionId);
    if (!definition || !profile) throw new Error("Missing area policy");
    const result = stepArea(
      area,
      tick2,
      definition,
      profile,
      combatAreaAnchor(world, area),
      terrain,
      hurtboxes
    );
    impacts.push(...result.impacts);
    return result.attack ? [result.attack] : [];
  });
  for (const target of world.targets) {
    const guard = target.guard;
    if (!active(target) || !guard || target.health === 0 || guard.phase !== "bash") continue;
    const age2 = tick2 - guard.action.stateStartTick;
    if (age2 < SHIELD_PROFILE.bashActiveTick || age2 >= SHIELD_PROFILE.bashActiveTick + SHIELD_PROFILE.bashActiveTicks)
      continue;
    const pose = actionPose(COMBAT_CATALOG, guard.action.definitionId, age2);
    const socket = pose?.sockets.find((socket2) => socket2.name === "hand");
    const definition = COMBAT_ATTACKS.get(6), shape = COMBAT_SHAPES.get(12);
    const previous = current.targets.find(
      (candidate) => candidate.enemy.body.id === target.enemy.body.id
    );
    if (!socket || !definition || !shape || !previous) throw new Error("Missing bash volume");
    const moving = age2 > SHIELD_PROFILE.bashActiveTick;
    const body = moving ? previous.enemy.body : target.enemy.body;
    const hand = worldSocket(body, socket.point, guard.facing);
    const delta = moving ? { x: target.enemy.body.x - body.x, y: target.enemy.body.y - body.y } : { x: 0, y: 0 };
    const candidates = moving ? hurtboxes : hurtboxes.map((hurt) => ({
      ...hurt,
      rect: { ...hurt.rect, x: hurt.rect.x + hurt.delta.x, y: hurt.rect.y + hurt.delta.y },
      delta: { x: 0, y: 0 }
    }));
    const hits = meleeHits(
      {
        id: target.enemy.body.id,
        ownerId: target.enemy.body.id,
        team: 2,
        actionInstanceId: guard.action.actionInstanceId,
        definitionId: 6
      },
      definition,
      shape,
      hand,
      delta,
      guard.facing,
      { x: body.x, y: hand.y },
      terrain,
      candidates,
      guard.hitIds
    );
    for (const hit of hits) if (hit.entityId !== null) guard.hitIds.push(hit.entityId);
    guard.hitIds.sort((a, b) => a - b);
    impacts.push(...hits);
  }
  world.strikes = world.strikes.filter((strike) => {
    const owner = world.players.find((player) => player.playerId === strike.ownerId);
    const before = current.players.find((player) => player.playerId === strike.ownerId);
    if (!owner || !before) throw new Error("Missing melee owner");
    if (tick2 >= strike.endTick || owner.life !== "alive" || owner.action.actionInstanceId !== strike.actionInstanceId || owner.action.kind !== "melee")
      return false;
    const definition = COMBAT_ATTACKS.get(strike.definitionId), shape = definition && COMBAT_SHAPES.get(definition.shapeId);
    if (!definition || !shape) throw new Error("Missing melee volume");
    const hand = actionHand(owner, tick2);
    const sameFacing = owner.facing === before.facing && strike.spawnTick !== tick2;
    const start = worldSocket(sameFacing ? before.body : owner.body, hand, owner.facing);
    const delta = sameFacing ? { x: owner.body.x - before.body.x, y: owner.body.y - before.body.y } : { x: 0, y: 0 };
    const candidates = sameFacing ? hurtboxes : hurtboxes.map((target) => ({
      ...target,
      rect: {
        ...target.rect,
        x: target.rect.x + target.delta.x,
        y: target.rect.y + target.delta.y
      },
      delta: { x: 0, y: 0 }
    }));
    const hits = meleeHits(
      strike,
      definition,
      shape,
      start,
      delta,
      owner.facing,
      { x: sameFacing ? before.body.x : owner.body.x, y: start.y },
      terrain,
      candidates,
      strike.hitIds
    );
    for (const hit of hits) if (hit.entityId !== null) strike.hitIds.push(hit.entityId);
    strike.hitIds.sort((a, b) => a - b);
    impacts.push(...hits);
    return true;
  });
  world.grenades = world.grenades.filter((grenade) => {
    const shape = COMBAT_SHAPES.get(GRENADE_PROFILE.bodyShapeId), definition = COMBAT_ATTACKS.get(grenade.definitionId);
    if (!shape || !definition) throw new Error("Missing grenade policy");
    const result = stepGrenade(grenade, GRENADE_PROFILE, shape, index, frame);
    if (result.status === "active") {
      Object.assign(grenade, result.grenade);
      return true;
    }
    const position2 = result.position;
    if (result.status === "crushed") {
      const colliderId = result.colliderIds[0];
      if (colliderId === void 0) throw new Error("Grenade crush lacks a terrain witness");
      world.events.push({
        kind: "impact",
        ownerId: grenade.ownerId,
        actionInstanceId: grenade.actionInstanceId,
        markerIndex: 0,
        source: null,
        position: position2,
        targetId: null,
        beam: null,
        impact: {
          sourceId: grenade.id,
          definitionId: grenade.definitionId,
          actionInstanceId: grenade.actionInstanceId,
          ownerId: grenade.ownerId,
          colliderId,
          entityId: null,
          kind: "terrain",
          damage: 0,
          position: position2,
          time: { numerator: 1, denominator: 1 }
        }
      });
      return false;
    }
    world.events.push({
      kind: "explosion",
      ownerId: grenade.ownerId,
      actionInstanceId: grenade.actionInstanceId,
      markerIndex: 0,
      source: {
        definitionId: grenade.definitionId,
        spawnTick: grenade.spawnTick,
        sourceId: grenade.id
      },
      position: position2,
      impact: null,
      targetId: null,
      beam: null
    });
    impacts.push(
      ...explosionHits(grenade, definition, position2, GRENADE_PROFILE.radius, terrain, hurtboxes)
    );
    return false;
  });
  if (world.projectiles.length + world.rockets.length + world.beams.length + world.areas.length + world.grenades.length + world.strikes.length > 256)
    throw new Error("Attack entity budget requires recovery");
  world.projectiles = world.projectiles.filter((projectile) => {
    const definition = COMBAT_ATTACKS.get(projectile.definitionId);
    const shape = definition && COMBAT_SHAPES.get(definition.shapeId);
    if (!definition || !shape) throw new Error("Missing projectile definition");
    if (tick2 - projectile.spawnTick > definition.lifetimeTicks) return false;
    if (projectile.spawnTick === tick2) return true;
    if (definition.id === CANNON_ATTACK.id) {
      const result = stepCannonShell(
        projectile,
        tick2,
        definition,
        CANNON_SHAPE,
        CANNON_PROFILE.blastRadius,
        terrain,
        hurtboxes
      );
      if (result.status === "active") {
        projectile.position = result.shell.position;
        return true;
      }
      if (result.status === "detonated") {
        world.events.push({
          kind: "explosion",
          ownerId: projectile.ownerId,
          actionInstanceId: projectile.actionInstanceId,
          markerIndex: 0,
          source: {
            definitionId: definition.id,
            spawnTick: projectile.spawnTick,
            sourceId: projectile.id
          },
          position: result.contact.position,
          impact: null,
          targetId: null,
          beam: null
        });
        impacts.push(...result.impacts);
      }
      return false;
    }
    const impact2 = sweepProjectile(projectile, definition, shape, terrain, hurtboxes);
    if (impact2) {
      impacts.push(impact2);
      return false;
    }
    projectile.position = {
      x: position(projectile.position.x + projectile.velocity.x),
      y: position(projectile.position.y + projectile.velocity.y)
    };
    return tick2 - projectile.spawnTick < definition.lifetimeTicks;
  });
  for (const tank of world.tanks) {
    const before = current.tanks.find((candidate) => candidate.body.id === tank.body.id);
    const definition = COMBAT_ATTACKS.get(TANK_PROFILE.special.attackId), shape = COMBAT_SHAPES.get(tank.body.shapeId);
    if (!before || !definition || !shape) throw new Error("Missing sacrifice content");
    const blast = stepTankCharge(
      before,
      tank,
      tick2,
      definition,
      shape,
      TANK_PROFILE.special,
      terrain,
      hurtboxes
    );
    if (blast) {
      impacts.push(...blast.impacts);
      world.events.push({
        kind: "explosion",
        ownerId: tank.special.ownerId ?? 0,
        actionInstanceId: tank.special.actionInstanceId,
        markerIndex: 0,
        source: {
          definitionId: definition.id,
          spawnTick: tank.special.commitTick ?? 0,
          sourceId: tank.body.id
        },
        position: blast.position,
        impact: null,
        targetId: null,
        beam: null
      });
    }
  }
  impacts.sort(
    (a, b) => compareContactTime(
      a.time.numerator,
      a.time.denominator,
      b.time.numerator,
      b.time.denominator
    ) || a.actionInstanceId - b.actionInstanceId || a.sourceId - b.sourceId || a.colliderId - b.colliderId
  );
  for (const impact2 of impacts) {
    const notice2 = {
      kind: "impact",
      ownerId: impact2.ownerId,
      actionInstanceId: impact2.actionInstanceId,
      markerIndex: 0,
      source: null,
      position: impact2.position,
      impact: impact2,
      targetId: impact2.entityId,
      beam: null
    };
    world.events.push(notice2);
    const prop = world.props.find((prop2) => prop2.id === impact2.entityId);
    if (prop) {
      const attack2 = COMBAT_ATTACKS.get(impact2.definitionId);
      const definition = destructibles.find((definition2) => definition2.id === prop.id);
      if (!attack2 || !definition) throw new Error("Missing prop attack/material definition");
      if (damageDestructible(prop, definition, impact2, attack2, tick2))
        world.events.push({ ...notice2, kind: "prop-destroyed" });
      continue;
    }
    const tank = world.tanks.find((tank2) => tank2.body.id === impact2.entityId);
    if (tank) {
      if (impact2.damage > 0 && tank.armor > 0 && tank.invulnerableTicks === 0) {
        cancelTankSpecial(tank, tick2);
        const driver = world.players.find((player2) => player2.playerId === tank.occupantId);
        if (driver) driver.vehicleSpecialTicks = 0;
        tank.armor--;
        tank.invulnerableTicks = TANK_PROFILE.damageProtectionTicks;
        if (tank.armor === 0) {
          releaseCombatTank(world, tank, "destroyed", seatChanges, lifeNotices, index, frame);
          world.events.push({ ...notice2, kind: "killed" });
        }
      }
      continue;
    }
    const slot = world.players.findIndex((player2) => player2.body.id === impact2.entityId);
    const player = world.players[slot];
    if (player && impact2.damage > 0) {
      const damage = damagePlayer(player, tick2, impact2.damage, "classic");
      world.players[slot] = damage.actor;
      if (damage.notice) {
        lifeNotices.push(damage.notice);
        world.events.push({ ...notice2, kind: "killed" });
      }
      continue;
    }
    const target = world.targets.find((candidate) => candidate.enemy.body.id === impact2.entityId);
    if (target && target.health > 0) activateTarget(target.enemy.body.id);
    if (target?.guard && target.health > 0 && impact2.kind === "shield") {
      const definition = COMBAT_ATTACKS.get(impact2.definitionId);
      if (!definition) throw new Error("Unknown shield damage definition");
      const damage = damageShield(
        target.guard,
        definition,
        tick2,
        world.nextActionId,
        COMBAT_CATALOG,
        SHIELD_PROFILE
      );
      target.guard = damage.state;
      world.nextActionId = damage.nextActionId;
      if (damage.broken) world.events.push({ ...notice2, kind: "shield-break" });
      appendShieldMarkers(world, target, damage.markers);
    }
    if (!target || target.health === 0 || impact2.damage === 0) continue;
    target.health = Math.max(0, target.health - impact2.damage);
    if (target.health === 0) {
      target.enemy.life = "removed";
      if (target.rifle) cancelRifle(target.rifle);
      if (target.guard) cancelShield(target.guard);
      world.events.push({ ...notice2, kind: "killed" });
      encounterEvents.push({
        kind: "resolve",
        id: target.enemy.body.id,
        reason: "killed",
        killerId: impact2.ownerId,
        sequence: ++world.eventSequence,
        tick: tick2
      });
    }
  }
  const geometryRevision = combatGeometryRevision(world.props);
  if (geometryRevision !== frame.geometryRevision) {
    const removed = new Set(world.props.filter((prop) => prop.health === 0).map((prop) => prop.id));
    for (const actor of world.players) {
      const detached = detachDestroyedSupport(actor.body, removed);
      actor.geometryRevision = geometryRevision;
      if (detached && actor.locomotion !== "seated") actor.locomotion = "airborne";
      if (actor.ignoredSupportId !== null && removed.has(actor.ignoredSupportId)) {
        actor.ignoredSupportId = null;
        actor.ignoredSupportTicks = 0;
      }
    }
    for (const { enemy } of world.targets) {
      detachDestroyedSupport(enemy.body, removed);
      enemy.geometryRevision = geometryRevision;
    }
    for (const tank of world.tanks) detachDestroyedSupport(tank.body, removed);
    for (const grenade of world.grenades) detachDestroyedSupport(grenade.body, removed);
  }
  for (const [slot, actor] of world.players.entries()) {
    if (actor.life !== "alive" || actor.body.y <= (stage?.fallBoundary ?? COMBAT_ENTRY.fallBoundary))
      continue;
    const death = damagePlayer(actor, tick2, 1, "classic", "fall");
    world.players[slot] = death.actor;
    if (death.notice) lifeNotices.push(death.notice);
  }
  const supplies = stepWeaponPickups(
    current.pickups,
    combatPickupDefinitions(world.scenario, world.players.length),
    world.players,
    playerMovement,
    physicalTerrain.filter(
      (surface) => !world.props.some((prop) => prop.id === surface.id && prop.health === 0)
    ),
    COMBAT_CATALOG
  );
  world.pickups = supplies.state;
  world.players = supplies.players;
  world.pickupClaims = supplies.claims;
  world.strikes = world.strikes.filter(
    (strike) => world.players.some(
      (player) => player.playerId === strike.ownerId && player.life === "alive" && player.action.actionInstanceId === strike.actionInstanceId
    )
  );
  for (const area of world.areas) {
    const profile = AREA_PROFILES.get(area.definitionId);
    if (!profile) throw new Error("Missing area cancellation policy");
    if (!combatAreaAnchor(world, area)) cancelArea(area, tick2, profile);
  }
  world.beams = world.beams.filter((beam) => combatAreaAnchor(world, beam) !== null);
  world.encounter = lifecycle(world).step(
    world.encounter,
    tick2,
    encounterEvents,
    world.targets.filter(
      (target) => target.health > 0 && (active(target) || activatedIds.has(target.enemy.body.id))
    ).map((target) => ({
      id: target.enemy.body.id,
      progressKey: canonical([
        target.enemy.body.x,
        target.enemy.body.y,
        target.enemy.body.vx,
        target.enemy.body.vy,
        target.enemy.body.supportId,
        target.enemy.facing
      ]),
      unreachable: false
    })),
    "throw"
  ).state;
  commitCombatSpecials(world, seatChanges, index, frame);
  const seatEvents = commitCombatSeats(current, world, seatChanges);
  return { state: world, outcomes, lifeNotices, seatEvents, impacts, playerMovement };
}

// test/fixtures/tank-terrain-proof.ts
var TANK_TERRAIN_CASES = [
  "lower-depot",
  "lower-special",
  "lower-damage",
  "ledge-landing",
  "ledge-fall",
  "step",
  "ceiling",
  "narrow-pass",
  "narrow-block",
  "lift",
  "crush",
  "blocked-exit",
  "blocked-disconnect",
  "crossing"
];
var idle = {
  held: 0,
  jumpPressed: false,
  firePressed: false,
  grenadePressed: false,
  interactPressed: false,
  specialPressed: false
};
function check4(value, message) {
  if (!value) throw new Error(`Tank terrain: ${message}`);
}
function required2(value) {
  check4(value !== void 0, "missing fixture value");
  return value;
}
var overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
var lane = (name, slot) => slot * (name === "crossing" ? 56 : 1024);
var floorY = (name) => name.startsWith("lower-") ? 360 : 200;
var duration = (name) => ["crush", "blocked-disconnect"].includes(name) ? 180 : 130;
var age = (tick2, start, length) => Math.max(0, Math.min(length, tick2 - start));
function tankTerrainStage(name, tick2, players) {
  const floor = floorY(name), height = -required2(COMBAT_SHAPES.get(TANK_PROFILE.locomotion.standingShapeId)).rect.y / 256;
  const terrain = Array.from({ length: name === "crossing" ? 1 : players }, (_, slot) => {
    const x = lane(name, slot), id2 = 100 + slot;
    if (name === "crossing") return [footTerrain(id2, -256, floor, 1536, 16)];
    if (name === "ledge-landing" || name === "ledge-fall")
      return [
        footTerrain(id2, x, floor, 120, 16),
        ...name === "ledge-landing" ? [footTerrain(200 + slot, x + 120, floor + 32, 392, 16)] : []
      ];
    if (name === "lift" || name === "crush") {
      const displacement = (t) => age(t, 30, name === "lift" ? 70 : 20) * (name === "lift" ? 2 : -2);
      return [
        {
          ...footTerrain(id2, x, floor + displacement(tick2 - 1), 384, 16),
          delta: { x: 0, y: pixels(displacement(tick2) - displacement(tick2 - 1)) }
        },
        ...name === "crush" ? [footTerrain(200 + slot, x, 120, 384, 24)] : []
      ];
    }
    if (name === "blocked-exit" || name === "blocked-disconnect") {
      const closed = (t) => age(t, 12, 16) - age(t, 50, 16);
      const previous = closed(tick2 - 1) * 2, delta = pixels((closed(tick2) - closed(tick2 - 1)) * 2);
      return [
        footTerrain(id2, x, floor, 512, 16),
        { ...footTerrain(200 + slot * 3, x + previous, 140, 4, 60), delta: { x: delta, y: 0 } },
        {
          ...footTerrain(201 + slot * 3, x + 116 - previous, 140, 4, 60),
          delta: { x: -delta, y: 0 }
        },
        {
          ...footTerrain(202 + slot * 3, x + 32, 108 + previous, 56, 4),
          delta: { x: 0, y: delta }
        }
      ];
    }
    return [
      footTerrain(id2, x, floor, 512, 16),
      ...name === "step" ? [footTerrain(200 + slot, x + 128, 168, 64, 32)] : [],
      ...name === "ceiling" ? [footTerrain(200 + slot, x + 114, 138, 140, 18)] : [],
      ...name.startsWith("narrow-") ? [
        footTerrain(
          200 + slot,
          x + 128,
          120,
          128,
          floor - height - 120 + Number(name === "narrow-block")
        )
      ] : []
    ];
  }).flat();
  if (["crush", "blocked-disconnect"].includes(name))
    terrain.push(footTerrain(900, 550, 200, 384, 16));
  return {
    terrain,
    destructibles: [],
    enemyBounds: { x: pixels(-256), y: 0, w: pixels(players * 1024 + 256), h: pixels(512) },
    fallBoundary: pixels(name === "ledge-fall" ? 232 : name === "lift" ? 388 : floor + 48),
    entry: {
      x: pixels(["crush", "blocked-disconnect"].includes(name) ? 600 : 36),
      y: pixels(floor)
    },
    activeEnemyIds: /* @__PURE__ */ new Set(),
    extraHurtboxes: []
  };
}
function tankTerrainInitial(name, players) {
  const world = createCombatLab("tank", players), floor = floorY(name);
  for (const actor of world.players) {
    actor.body.x = pixels(36 + lane(name, actor.slot));
    actor.body.y = pixels(floor);
    actor.body.supportId = name === "crossing" ? 100 : 100 + actor.slot;
    const tank = required2(world.tanks[actor.slot]);
    tank.body.x = pixels(60 + lane(name, actor.slot));
    tank.body.y = pixels(floor);
    tank.body.supportId = actor.body.supportId;
  }
  return world;
}
function tankTerrainCommands(name, tick2, players) {
  return Array.from({ length: players }, (_, slot) => {
    const driving = [
      "ledge-landing",
      "ledge-fall",
      "step",
      "ceiling",
      "narrow-pass",
      "narrow-block",
      "crossing"
    ].includes(name);
    let held = driving && tick2 >= 13 && tick2 <= 90 ? Held.Right : 0;
    if (name === "lower-depot" && tick2 >= 13 && tick2 <= 25) held = Held.Right;
    if (name === "crossing" && tick2 >= 13 && tick2 <= 70)
      held = (slot < players / 2 ? Held.Right : Held.Left) | Held.Fire;
    if (name === "crossing" && tick2 > 70) held = 0;
    if (name === "narrow-block" && tick2 >= 50) held = tick2 < 66 ? Held.Left : 0;
    if (name === "lower-special" && tick2 >= 13 && tick2 <= 42) held = Held.VehicleSpecial;
    return {
      ...idle,
      held,
      jumpPressed: name === "step" && tick2 === 35 || name === "ceiling" && tick2 === 25,
      interactPressed: tick2 === 1 || name === "lower-depot" && tick2 === 32 || name === "ledge-landing" && tick2 === 100 || name === "lift" && tick2 === 110 || name === "blocked-exit" && [30, 80].includes(tick2) || name === "narrow-block" && tick2 === 70,
      specialPressed: name === "lower-special" && tick2 === 13,
      grenadePressed: name === "crossing" && tick2 === 17,
      firePressed: name === "crossing" && tick2 === 13
    };
  });
}
function advance(name, current) {
  const tick2 = current.tick + 1, players = current.players.length;
  const before = structuredClone(current);
  if (name === "lower-damage" && [30, 61, 92].includes(tick2))
    for (const tank of before.tanks)
      before.projectiles.push({
        id: before.nextEntityId++,
        ownerId: 20,
        team: 2,
        actionInstanceId: before.nextActionId++,
        definitionId: 3,
        position: { x: tank.body.x + pixels(21), y: tank.body.y - pixels(12) },
        velocity: { x: -pixels(8), y: 0 },
        spawnTick: before.tick
      });
  const connections = {
    connectedPlayerIds: before.players.map((player) => player.playerId),
    releasePlayerIds: name === "blocked-disconnect" && tick2 === 30 ? before.players.map((player) => player.playerId) : []
  };
  const stage = tankTerrainStage(name, tick2, players), saved = stateHash(before);
  const result = advanceCombatLab(
    before,
    tankTerrainCommands(name, tick2, players),
    connections,
    stage
  );
  check4(stateHash(before) === saved, `${name} mutated accepted state at ${tick2}`);
  const world = result.state;
  for (const tank of world.tanks) {
    if (tank.lifecycle !== "wreck") {
      const rect = worldRect(
        tank.body,
        required2(COMBAT_SHAPES.get(tank.body.shapeId)).rect,
        tank.facing
      );
      check4(
        !stage.terrain.some(
          (target) => target.kind === "solid" && overlap(rect, {
            ...target.rect,
            x: target.rect.x + target.delta.x,
            y: target.rect.y + target.delta.y
          })
        ),
        `${name} accepted overlapping hull at ${tick2}`
      );
    }
    const owner = world.players.find((player) => player.playerId === tankOwner(tank));
    check4(
      owner ? owner.vehicleId === tank.body.id && owner.body.x === tank.body.x && owner.body.y === tank.body.y - pixels(6) : world.players.every((player) => player.vehicleId !== tank.body.id),
      `${name} lost bilateral seat at ${tick2}`
    );
  }
  return result;
}
function recordTankTerrain(name, players) {
  let world = tankTerrainInitial(name, players);
  const states = [structuredClone(world)], observations = [];
  for (let tick2 = 1; tick2 <= duration(name); tick2++) {
    const result = advance(name, world);
    world = result.state;
    states.push(structuredClone(world));
    observations.push({
      tick: tick2,
      hash: stateHash(world),
      tanks: world.tanks.map((tank) => ({
        id: tank.body.id,
        lifecycle: tank.lifecycle,
        owner: tankOwner(tank),
        controlEpoch: tank.controlEpoch,
        armor: tank.armor,
        body: tank.body,
        special: tank.special.phase,
        shells: tank.secondary.ammo
      })),
      players: world.players.map((player) => ({
        id: player.playerId,
        vehicleId: player.vehicleId,
        life: player.life,
        lives: player.lives,
        body: player.body
      })),
      outcomes: result.outcomes,
      events: world.events.map((event) => ({
        kind: event.kind,
        targetId: event.targetId,
        definitionId: event.source?.definitionId ?? null
      }))
    });
  }
  return { name, players, states, observations, final: world };
}
function assertTankTerrain(record) {
  const { name, players, states, final, observations } = record;
  const at2 = (tick2) => required2(states[tick2]);
  check4(
    at2(12).tanks.every((tank) => tank.lifecycle === "occupied"),
    `${name} did not board every driver`
  );
  if (["ledge-fall", "crush", "blocked-disconnect"].includes(name)) {
    check4(
      final.players.every((player) => player.lives === 2 && player.vehicleId === null),
      `${name} did not consume exactly one life`
    );
    check4(
      final.tanks.every(
        (tank) => tank.lifecycle === (name === "blocked-disconnect" ? "available" : "wreck")
      ),
      `${name} did not settle every hull`
    );
  } else
    check4(
      final.players.every((player) => player.lives === 3),
      `${name} consumed a life`
    );
  if (name === "lower-depot")
    check4(
      final.players.every((player) => player.vehicleId === null && player.body.y === pixels(360)),
      "lower depot ejection failed"
    );
  if (name === "lower-special") {
    check4(
      at2(42).tanks.every((tank) => tank.special.phase === "charging"),
      "lower sacrifice did not commit"
    );
    check4(
      observations.flatMap((step) => step.events).filter((event) => event.kind === "explosion" && event.definitionId === 20).length === players,
      "lower sacrifice did not blast once per hull"
    );
  }
  if (name === "lower-damage") {
    check4(
      final.tanks.every((tank) => tank.lifecycle === "wreck"),
      "lower incoming damage did not destroy hulls"
    );
    check4(
      final.players.every((player) => player.vehicleId === null && player.body.y === pixels(360)),
      "lower destruction did not eject safely"
    );
  }
  if (name === "ledge-landing")
    check4(
      final.tanks.every((tank) => tank.body.grounded && tank.body.y === pixels(232)),
      "ledge landing lost support"
    );
  if (name === "step") {
    check4(
      at2(34).tanks.every((tank, slot) => tank.body.x === pixels(lane(name, slot) + 108)),
      "step did not stop unjumped hulls"
    );
    check4(
      observations.some(
        (step) => step.tanks.every((tank) => tank.body.supportId !== null && tank.body.supportId >= 200)
      ),
      "tank never landed on step"
    );
    check4(
      final.tanks.every(
        (tank, slot) => tank.body.x > pixels(lane(name, slot) + 212) && tank.body.y === pixels(200)
      ),
      "step route failed"
    );
  }
  if (name === "ceiling")
    check4(
      observations.some(
        (step) => step.tanks.every((tank) => tank.body.contacts.some((contact) => contact.normalY === 1))
      ),
      "jump did not touch ceiling"
    );
  if (name === "narrow-pass")
    check4(
      final.tanks.every((tank, slot) => tank.body.x > pixels(lane(name, slot) + 276)),
      "exact-height passage blocked hulls"
    );
  if (name === "narrow-block") {
    check4(
      at2(49).tanks.every((tank, slot) => tank.body.x === pixels(lane(name, slot) + 108)),
      "undersized passage failed to block hulls"
    );
    check4(
      final.players.every((player) => player.vehicleId === null),
      "blocked route prevented retreat and exit"
    );
  }
  if (name === "lift")
    check4(
      final.players.every((player) => player.vehicleId === null && player.body.y === pixels(340)),
      "moving support exit failed"
    );
  if (["crush", "blocked-disconnect"].includes(name))
    check4(
      final.players.every((player) => player.life === "alive" && player.body.x >= pixels(600)),
      "forced exit failed to return players at safe checkpoint"
    );
  if (name === "blocked-exit") {
    check4(
      at2(30).tanks.every((tank) => tank.lifecycle === "occupied"),
      "blocked voluntary exit lost control"
    );
    check4(
      required2(observations[29]).outcomes.every((outcome) => outcome.interact === "unavailable"),
      "blocked exit incorrectly acknowledged"
    );
    check4(
      final.players.every((player) => player.vehicleId === null),
      "opened exit remained blocked"
    );
  }
  if (name === "crossing") {
    check4(
      final.tanks.every((tank) => tank.armor === 3 && tank.secondary.ammo === 9),
      "friendly crossing caused damage or lost ordnance"
    );
    if (players === 4)
      check4(
        required2(final.tanks[0]).body.x > required2(final.tanks[3]).body.x && required2(final.tanks[1]).body.x > required2(final.tanks[2]).body.x,
        "friendly tanks blocked crossing"
      );
  }
}
function tankTerrainProof() {
  return [1, 4].flatMap(
    (players) => TANK_TERRAIN_CASES.map((name) => {
      const record = recordTankTerrain(name, players);
      assertTankTerrain(record);
      const checkpoints = [12, 29, 42, 70, 100].map((tick2) => {
        let restored = JSON.parse(JSON.stringify(required2(record.states[tick2])));
        for (let step = 0; step < 8; step++) restored = advance(name, restored).state;
        const hash = stateHash(restored);
        check4(
          hash === stateHash(required2(record.states[tick2 + 8])),
          `${name} diverged after restore at ${tick2}`
        );
        return { tick: tick2, resumedTick: restored.tick, hash };
      });
      return {
        name,
        players,
        ticks: record.final.tick,
        finalHash: stateHash(record.final),
        traceHash: stateHash(record.observations),
        checkpoints,
        observations: record.observations
      };
    })
  );
}
export {
  TANK_TERRAIN_CASES,
  assertTankTerrain,
  recordTankTerrain,
  tankTerrainCommands,
  tankTerrainInitial,
  tankTerrainProof,
  tankTerrainStage
};
