import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {relative,resolve} from 'node:path';
const {build}=createRequire(resolve('package.json'))('esbuild');
const baseCommit='e8df4946887c687378965f64ca9af6f6bf9a3343';
const output='dist/tank-terrain-before-proof';
await mkdir(output);
const paths=['src/game/labs/combat.ts','src/game/labs/combat-tanks.ts'];
const originals=Object.fromEntries(paths.map(path=>[path,execFileSync('git',['show',`${baseCommit}:${path}`],{encoding:'utf8'})]));
const bundle=await build({entryPoints:['test/fixtures/tank-terrain-proof.ts'],bundle:true,format:'esm',platform:'neutral',write:false,metafile:true,
 plugins:[{name:'previous-stage-policy',setup(plugin){plugin.onLoad({filter:/combat(?:-tanks)?\.ts$/},args=>{
   const path=relative(process.cwd(),args.path);return originals[path]?{contents:originals[path],loader:'ts',resolveDir:resolve('src/game/labs')}:undefined;
 });}}],
});
const bytes=bundle.outputFiles[0].contents;
const hash=value=>createHash('sha256').update(value).digest('hex');
await writeFile(`${output}/worker.js`,bytes);
const fixture=await import(`data:text/javascript;base64,${Buffer.from(bytes).toString('base64')}`);
const cases=[];
for(const players of [1,4])for(const name of ['lower-depot','lower-special','lower-damage','lift','ledge-fall','step']){
 let record=null,error=null;
 try{record=fixture.recordTankTerrain(name,players);fixture.assertTankTerrain(record);}catch(failure){error=String(failure);}
 if(name==='step')assert.equal(error,null,'Control broke the unchanged ordinary step route');
 else assert(error,`${name} failed to detect the previous policy`);
 cases.push({name,players,expectedFailure:name!=='step',error,
  ...(record?{tickOne:record.states[1].tanks.map(t=>({armor:t.armor,lifecycle:t.lifecycle,y:t.body.y})),finalLives:record.final.players.map(p=>p.lives),finalTanks:record.final.tanks.map(t=>({armor:t.armor,lifecycle:t.lifecycle,y:t.body.y}))}:{}),
 });
}
const sources=[];
for(const path of Object.keys(bundle.metafile.inputs).sort()){
 const bytes=Buffer.from(originals[path]??await readFile(path));sources.push({path,bytes:bytes.length,sha256:hash(bytes),...(originals[path]?{baseCommit}:{})});
}
await writeFile(`${output}/report.json`,JSON.stringify({status:'pass',baseCommit,scope:'Ten expected failures against the previous hard-coded tank fall policy, plus two unchanged step-route controls. Current fixture and exact prior combat sources are bundled; no runtime source edits.',bundleSha256:hash(bytes),sources,cases},null,2)+'\n');
for(const [path,source] of Object.entries(originals))await writeFile(`${output}/${path.split('/').at(-1)}`,source);
await writeFile(`${output}/control.mjs`,await readFile(import.meta.filename));
console.log(JSON.stringify(cases.map(({name,players,error})=>({name,players,error}))));
