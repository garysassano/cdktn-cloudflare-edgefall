// src/worker/diagnostics/room-probe.ts
import { DurableObject } from "cloudflare:workers";

// src/game/core/numeric.ts
var SUBPIXELS = 256;
var MAX_POSITION = 2 ** 24;
var MAX_SHAPE = 2 ** 16;
var MAX_MOTION = 2 ** 16;
var COUNTER_LIMIT = 4294963200;
function integer(value, minimum, maximum, label) {
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
    throw new RangeError(`${label} must be an integer in [${minimum}, ${maximum}]`);
  }
  return value;
}
function position(value) {
  return integer(value, -MAX_POSITION, MAX_POSITION, "position");
}
function motion(value) {
  return integer(value, -MAX_MOTION, MAX_MOTION, "motion");
}
function pixels(value) {
  return position(
    integer(value, -MAX_POSITION / SUBPIXELS, MAX_POSITION / SUBPIXELS, "pixels") * SUBPIXELS
  );
}
function divide(numerator, denominator) {
  integer(numerator, -Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER, "numerator");
  integer(denominator, 1, Number.MAX_SAFE_INTEGER, "denominator");
  const quotient = Math.trunc(numerator / denominator) || 0;
  return { quotient, remainder: numerator - quotient * denominator };
}
function compareContactTime(an, ad, bn, bd) {
  for (const n of [an, bn]) integer(n, -(2 ** 26), 2 ** 26, "contact numerator");
  for (const d of [ad, bd]) integer(d, 1, 2 ** 17, "contact denominator");
  const left = an * bd;
  const right = bn * ad;
  return left < right ? -1 : left > right ? 1 : 0;
}
function nextCounter(current) {
  integer(current, 0, COUNTER_LIMIT - 2, "counter requiring session rotation");
  return current + 1;
}

// src/game/physics/sweep.ts
var ZERO = { x: 0, y: 0 };
var START = { numerator: 0, denominator: 1 };
var END = { numerator: 1, denominator: 1 };
function compare(a, b) {
  return compareContactTime(a.numerator, a.denominator, b.numerator, b.denominator);
}
function validate(rect, delta, segment) {
  position(rect.x);
  position(rect.y);
  integer(rect.w, segment ? 0 : 1, MAX_POSITION, "sweep width");
  integer(rect.h, segment ? 0 : 1, MAX_POSITION, "sweep height");
  position(rect.x + rect.w);
  position(rect.y + rect.h);
  motion(delta.x);
  motion(delta.y);
  position(rect.x + delta.x);
  position(rect.y + delta.y);
  position(rect.x + rect.w + delta.x);
  position(rect.y + rect.h + delta.y);
}
function validateSweepTarget(target) {
  integer(target.id, 1, COUNTER_LIMIT - 1, "collision entity ID");
  if (target.kind !== "solid" && target.kind !== "one-way")
    throw new Error("Unsupported collision terrain");
  validate(target.rect, target.delta, false);
}
function sweepBounds(rect, delta = ZERO) {
  validate(rect, delta, true);
  return {
    minX: rect.x + Math.min(0, delta.x),
    minY: rect.y + Math.min(0, delta.y),
    maxX: rect.x + rect.w + Math.max(0, delta.x),
    maxY: rect.y + rect.h + Math.max(0, delta.y)
  };
}
function slab(min, max, targetMin, targetMax, delta) {
  if (delta === 0) return min < targetMax && max > targetMin ? "inside" : null;
  const denominator = Math.abs(delta);
  return delta > 0 ? {
    enter: { numerator: targetMin - max, denominator },
    exit: { numerator: targetMax - min, denominator },
    normal: -1
  } : {
    enter: { numerator: min - targetMax, denominator },
    exit: { numerator: max - targetMin, denominator },
    normal: 1
  };
}
function sweepAabb(body2, delta, target, targetDelta = ZERO) {
  validate(body2, delta, true);
  validate(target, targetDelta, false);
  if (body2.x < target.x + target.w && body2.x + body2.w > target.x && body2.y < target.y + target.h && body2.y + body2.h > target.y)
    return { kind: "overlap" };
  const axes = [
    slab(body2.x, body2.x + body2.w, target.x, target.x + target.w, delta.x - targetDelta.x),
    slab(body2.y, body2.y + body2.h, target.y, target.y + target.h, delta.y - targetDelta.y)
  ];
  let enter2;
  let exit;
  const normals = [];
  for (const [index, axis] of axes.entries()) {
    if (axis === null) return null;
    if (axis === "inside") continue;
    if (!enter2 || compare(axis.enter, enter2) > 0) enter2 = axis.enter;
    if (!exit || compare(axis.exit, exit) < 0) exit = axis.exit;
    normals.push({
      time: axis.enter,
      normal: index === 0 ? { x: axis.normal, y: 0 } : { x: 0, y: axis.normal }
    });
  }
  if (!enter2 || !exit || compare(enter2, START) < 0 || compare(enter2, END) > 0 || compare(enter2, exit) >= 0)
    return null;
  return {
    kind: "hit",
    time: enter2,
    normals: normals.filter((item) => compare(item.time, enter2) === 0).map((item) => item.normal)
  };
}
function sweepOneWay(body2, delta, target, targetDelta = ZERO) {
  validate(body2, delta, true);
  validate(target, targetDelta, false);
  const distance = target.y - (body2.y + body2.h);
  const relativeY = delta.y - targetDelta.y;
  if (distance < 0 || relativeY <= 0 || distance > relativeY) return null;
  const time2 = { numerator: distance, denominator: relativeY };
  const relativeX = delta.x - targetDelta.x;
  if ((body2.x - target.x - target.w) * relativeY + relativeX * distance >= 0 || (body2.x + body2.w - target.x) * relativeY + relativeX * distance <= 0)
    return null;
  return { kind: "hit", time: time2, normals: [{ x: 0, y: -1 }] };
}
function earliestSweep(body2, delta, targets2, ignoredOneWayId) {
  validate(body2, delta, true);
  integer(targets2.length, 0, 4096, "sweep candidate count");
  const ids2 = /* @__PURE__ */ new Set();
  const overlaps2 = [];
  let contacts = [];
  let earliest;
  for (const target of [...targets2].sort((a, b) => a.id - b.id)) {
    validateSweepTarget(target);
    if (ids2.has(target.id)) throw new Error("Duplicate collision entity ID");
    ids2.add(target.id);
    if (target.kind === "one-way" && target.id === ignoredOneWayId) continue;
    const result = target.kind === "solid" ? sweepAabb(body2, delta, target.rect, target.delta) : sweepOneWay(body2, delta, target.rect, target.delta);
    if (result?.kind === "overlap") {
      overlaps2.push(target.id);
      continue;
    }
    if (!result || earliest && compare(result.time, earliest) > 0) continue;
    if (!earliest || compare(result.time, earliest) < 0) contacts = [];
    earliest = result.time;
    for (const normal of result.normals)
      contacts.push({ otherId: target.id, kind: target.kind, time: result.time, normal });
  }
  return { overlaps: overlaps2, contacts };
}
function displacementAtContact(delta, time2) {
  motion(delta.x);
  motion(delta.y);
  integer(time2.denominator, 1, MAX_MOTION * 2, "contact denominator");
  integer(time2.numerator, 0, time2.denominator, "contact numerator");
  return {
    x: Math.trunc(delta.x * time2.numerator / time2.denominator) || 0,
    y: Math.trunc(delta.y * time2.numerator / time2.denominator) || 0
  };
}

// src/game/physics/grid.ts
var MAX_TARGETS = 4096;
var MAX_ENTRY_CELLS = 256;
var MAX_GRID_REFERENCES = 65536;
var MAX_QUERY_CELLS = 4096;
function validateBounds(bounds) {
  for (const value of [bounds.minX, bounds.minY, bounds.maxX, bounds.maxY]) position(value);
  if (bounds.minX > bounds.maxX || bounds.minY > bounds.maxY)
    throw new Error("Inverted spatial bounds");
}
function intersects(a, b) {
  return a.minX <= b.maxX && a.maxX >= b.minX && a.minY <= b.maxY && a.maxY >= b.minY;
}
function sorted(values) {
  return Object.freeze([...values].sort((a, b) => a.id - b.id));
}
var CollisionGrid = class {
  constructor(targets2, cellPixels = 64) {
    this.cellPixels = cellPixels;
    if (cellPixels !== 32 && cellPixels !== 64)
      throw new Error("Spatial cell size must be 32 or 64 pixels");
    integer(targets2.length, 0, MAX_TARGETS, "spatial target count");
    let references = 0;
    for (const value of [...targets2].sort((a, b) => a.id - b.id)) {
      validateSweepTarget(value);
      if (this.#entries.has(value.id)) throw new Error("Duplicate collision entity ID");
      const target = Object.freeze({
        ...value,
        rect: Object.freeze({ ...value.rect }),
        delta: Object.freeze({ ...value.delta })
      });
      const bounds = sweepBounds(target.rect, target.delta);
      this.#entries.set(target.id, { target, bounds });
      const range = this.#range(bounds);
      if (range.count > MAX_ENTRY_CELLS || references + range.count > MAX_GRID_REFERENCES) {
        this.#overflow.push(target.id);
        continue;
      }
      references += range.count;
      for (let x = range.minX; x <= range.maxX; x++) {
        for (let y = range.minY; y <= range.maxY; y++) {
          const key2 = `${x},${y}`;
          const bucket = this.#buckets.get(key2) ?? [];
          bucket.push(target.id);
          this.#buckets.set(key2, bucket);
        }
      }
    }
    this.targets = sorted([...this.#entries.values()].map((entry) => entry.target));
    this.hasMotion = this.targets.some((target) => target.delta.x !== 0 || target.delta.y !== 0);
    this.statistics = Object.freeze({
      targets: targets2.length,
      cells: this.#buckets.size,
      references,
      overflow: this.#overflow.length
    });
    Object.freeze(this);
  }
  cellPixels;
  targets;
  hasMotion;
  statistics;
  #buckets = /* @__PURE__ */ new Map();
  #entries = /* @__PURE__ */ new Map();
  #overflow = [];
  #range(bounds) {
    const size = this.cellPixels * SUBPIXELS;
    const minX = Math.floor(bounds.minX / size);
    const minY = Math.floor(bounds.minY / size);
    const maxX = Math.floor(bounds.maxX / size);
    const maxY = Math.floor(bounds.maxY / size);
    return { minX, minY, maxX, maxY, count: (maxX - minX + 1) * (maxY - minY + 1) };
  }
  query(bounds) {
    return this.inspectQuery(bounds).targets;
  }
  get(id2) {
    return this.#entries.get(id2)?.target;
  }
  inspectQuery(bounds) {
    validateBounds(bounds);
    const range = this.#range(bounds);
    const ids2 = /* @__PURE__ */ new Set();
    const scan = range.count > MAX_QUERY_CELLS;
    if (scan) {
      for (const id2 of this.#entries.keys()) ids2.add(id2);
    } else {
      for (const id2 of this.#overflow) ids2.add(id2);
      for (let x = range.minX; x <= range.maxX; x++) {
        for (let y = range.minY; y <= range.maxY; y++) {
          for (const id2 of this.#buckets.get(`${x},${y}`) ?? []) ids2.add(id2);
        }
      }
    }
    const targets2 = [];
    for (const id2 of ids2) {
      const entry = this.#entries.get(id2);
      if (!entry) throw new Error("Missing spatial entry");
      if (intersects(entry.bounds, bounds)) targets2.push(entry.target);
    }
    return {
      targets: sorted(targets2),
      mode: scan ? "scan" : "cells",
      cellsVisited: scan ? 0 : range.count,
      candidatesTested: ids2.size
    };
  }
};
var CollisionIndex = class {
  constructor(fixed, moving, frame) {
    this.fixed = fixed;
    if (fixed.hasMotion) throw new Error("Static collision grid contains moving geometry");
    integer(fixed.targets.length + moving.length, 0, MAX_TARGETS, "collision frame target count");
    integer(frame.geometryRevision, 1, COUNTER_LIMIT - 1, "geometry revision");
    integer(frame.tick, 0, COUNTER_LIMIT - 1, "collision tick");
    this.dynamic = new CollisionGrid(moving, fixed.cellPixels);
    this.targets = sorted([...fixed.targets, ...this.dynamic.targets]);
    if (new Set(this.targets.map((target) => target.id)).size !== this.targets.length)
      throw new Error("Duplicate collision entity ID across static/dynamic grids");
    this.frame = Object.freeze({ ...frame });
    Object.freeze(this);
  }
  fixed;
  dynamic;
  targets;
  frame;
  assertFrame(frame) {
    if (!frame || frame.geometryRevision !== this.frame.geometryRevision || frame.tick !== this.frame.tick)
      throw new Error("Stale or missing collision frame identity");
  }
  query(bounds) {
    return sorted([...this.fixed.query(bounds), ...this.dynamic.query(bounds)]);
  }
  get(id2) {
    return this.fixed.get(id2) ?? this.dynamic.get(id2);
  }
};

// src/game/physics/move.ts
var ZERO2 = { x: 0, y: 0 };
var MAX_CORRECTION = SUBPIXELS;
function translate(rect, delta) {
  const result = { ...rect, x: position(rect.x + delta.x), y: position(rect.y + delta.y) };
  position(result.x + result.w);
  position(result.y + result.h);
  return result;
}
function overlaps(a, b) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}
function inWorld(rect) {
  return rect.x >= -MAX_POSITION && rect.y >= -MAX_POSITION && rect.x + rect.w <= MAX_POSITION && rect.y + rect.h <= MAX_POSITION;
}
function correctOverlap(rect, targets2, ids2, ignoredId) {
  if (ids2.length === 0) return { ...ZERO2 };
  if (ids2.length > 8) return null;
  const overlapping = new Set(ids2);
  const candidates = [];
  for (const target of targets2) {
    if (!overlapping.has(target.id)) continue;
    const b = target.rect;
    candidates.push(
      { delta: { x: b.x - rect.x - rect.w, y: 0 }, order: 0, id: target.id },
      { delta: { x: b.x + b.w - rect.x, y: 0 }, order: 1, id: target.id },
      { delta: { x: 0, y: b.y - rect.y - rect.h }, order: 2, id: target.id },
      { delta: { x: 0, y: b.y + b.h - rect.y }, order: 3, id: target.id }
    );
  }
  const distance = (delta) => Math.abs(delta.x) + Math.abs(delta.y);
  candidates.sort(
    (a, b) => distance(a.delta) - distance(b.delta) || a.order - b.order || a.id - b.id
  );
  for (const { delta } of candidates) {
    if (distance(delta) > MAX_CORRECTION) continue;
    const next = { ...rect, x: rect.x + delta.x, y: rect.y + delta.y };
    if (!inWorld(next)) continue;
    if (targets2.some((target) => target.kind === "solid" && overlaps(next, target.rect))) continue;
    const blocked = targets2.some((target) => {
      if (overlapping.has(target.id) || target.kind === "one-way" && target.id === ignoredId)
        return false;
      const hit = target.kind === "solid" ? sweepAabb(rect, delta, target.rect) : sweepOneWay(rect, delta, target.rect);
      return hit?.kind === "hit" && hit.time.numerator < hit.time.denominator;
    });
    if (!blocked) return delta;
  }
  return null;
}
function support(rect, targets2, previousId, credited, ignoredId) {
  const candidates = targets2.filter((target) => {
    if (target.kind === "one-way" && target.id === ignoredId) return false;
    const gap = target.rect.y - rect.y - rect.h;
    return gap >= 0 && gap <= (credited.has(target.id) ? 1 : 0) && rect.x < target.rect.x + target.rect.w && rect.x + rect.w > target.rect.x;
  });
  return candidates.find((target) => target.id === previousId)?.id ?? candidates[0]?.id ?? null;
}
function redundantSeam(rect, corner, constraints, byId) {
  const target = byId.get(corner.id);
  if (!target) return false;
  const axis = corner.normal.x !== 0 ? "y" : "x";
  const extent = axis === "x" ? "w" : "h";
  return constraints.some((face) => {
    const other = byId.get(face.id);
    if (!other || face.normal[axis] === 0 || !touching(rect, other, face.normal, 0)) return false;
    if (target.delta[axis] !== other.delta[axis]) return false;
    if (face.normal[axis] === -1)
      return rect[axis] + rect[extent] === target.rect[axis] && target.rect[axis] === other.rect[axis];
    return rect[axis] === target.rect[axis] + target.rect[extent] && target.rect[axis] + target.rect[extent] === other.rect[axis] + other.rect[extent];
  });
}
function touching(rect, target, normal, tolerance) {
  const b = target.rect;
  const horizontal = rect.x < b.x + b.w && rect.x + rect.w > b.x;
  const vertical = rect.y < b.y + b.h && rect.y + rect.h > b.y;
  const gap = normal.x === -1 ? b.x - rect.x - rect.w : normal.x === 1 ? rect.x - b.x - b.w : normal.y === -1 ? b.y - rect.y - rect.h : rect.y - b.y - b.h;
  return gap >= 0 && gap <= tolerance && (normal.x === 0 ? horizontal : vertical);
}
function contactGap(rect, target, normal) {
  const b = target.rect;
  const gap = normal.x === -1 ? b.x - rect.x - rect.w : normal.x === 1 ? rect.x - b.x - b.w : normal.y === -1 ? b.y - rect.y - rect.h : rect.y - b.y - b.h;
  return Math.max(0, Math.min(1, gap));
}
function closingTrap(rect, active, targets2, byId, remaining, axis) {
  const otherAxis = axis === "x" ? "y" : "x";
  const otherSize = otherAxis === "x" ? "w" : "h";
  let lower = -MAX_MOTION;
  let upper = MAX_MOTION;
  for (const constraint of active) {
    if (constraint.normal[otherAxis] === 1) lower = Math.max(lower, constraint.delta[otherAxis]);
    if (constraint.normal[otherAxis] === -1) upper = Math.min(upper, constraint.delta[otherAxis]);
  }
  if (lower > upper) return false;
  const sideways = Math.max(lower, Math.min(upper, remaining[otherAxis]));
  return active.some((a) => {
    const left = byId.get(a.id);
    if (a.normal[axis] !== 1 || !left || !touching(rect, left, a.normal, 1)) return false;
    return active.some((b) => {
      const right = byId.get(b.id);
      if (b.normal[axis] !== -1 || !right || !touching(rect, right, b.normal, 1)) return false;
      const size = axis === "x" ? "w" : "h";
      const space = right.rect[axis] - left.rect[axis] - left.rect[size] - rect[size];
      const closing = a.delta[axis] - b.delta[axis];
      if (closing <= space) return false;
      for (const target of [left, right]) {
        const relative = sideways - target.delta[otherAxis];
        if ((rect[otherAxis] - target.rect[otherAxis] - target.rect[otherSize]) * closing + relative * space >= 0 || (rect[otherAxis] + rect[otherSize] - target.rect[otherAxis]) * closing + relative * space <= 0)
          return false;
      }
      return !targets2.some((target) => {
        const relative = sideways - target.delta[otherAxis];
        if (relative === 0) return false;
        const distance = relative > 0 ? target.rect[otherAxis] - rect[otherAxis] - rect[otherSize] : rect[otherAxis] - target.rect[otherAxis] - target.rect[otherSize];
        return distance >= 0 && distance * closing <= space * Math.abs(relative);
      });
    });
  });
}
function moveKinematic(state, terrain, options = {}) {
  const limit = integer(options.maxIterations ?? 4, 1, 4, "movement contact limit");
  if (state.supportId !== null) integer(state.supportId, 1, COUNTER_LIMIT - 1, "support ID");
  if (options.ignoredOneWayId !== void 0)
    integer(options.ignoredOneWayId, 1, COUNTER_LIMIT - 1, "ignored support ID");
  integer(state.rect.w, 1, MAX_POSITION, "body width");
  integer(state.rect.h, 1, MAX_POSITION, "body height");
  const index = terrain instanceof CollisionIndex ? terrain : void 0;
  index?.assertFrame(options.frame);
  const source = terrain instanceof CollisionIndex ? terrain.targets : terrain;
  const targets2 = source.map((target) => ({ ...target, rect: { ...target.rect }, delta: { ...target.delta } })).sort((a, b) => a.id - b.id);
  const byId = new Map(targets2.map((target) => [target.id, target]));
  const query = (rect, delta) => {
    const candidates = index ? index.query(sweepBounds(rect, delta)).map((target) => {
      const current = byId.get(target.id);
      if (!current) throw new Error("Missing current collision target");
      return current;
    }) : targets2;
    return earliestSweep(rect, delta, candidates, options.ignoredOneWayId);
  };
  const initial = query(state.rect, state.motion);
  const correction = correctOverlap(state.rect, targets2, initial.overlaps, options.ignoredOneWayId);
  const result = {
    rect: { ...state.rect },
    motion: { ...state.motion },
    supportId: null,
    status: "complete",
    contacts: [],
    path: [],
    correction: correction ?? { ...ZERO2 },
    remaining: { ...state.motion },
    iterations: 0,
    diagnosticIds: []
  };
  if (!correction) return { ...result, status: "initial-overlap", diagnosticIds: initial.overlaps };
  result.rect = translate(result.rect, correction);
  const credited = new Set(state.supportId === null ? [] : [state.supportId]);
  const startingSupport = state.motion.y < 0 ? null : support(result.rect, targets2, state.supportId, credited, options.ignoredOneWayId);
  const carry = options.carrySupport === false ? ZERO2 : byId.get(startingSupport ?? 0)?.delta ?? ZERO2;
  result.remaining = { x: motion(state.motion.x + carry.x), y: motion(state.motion.y + carry.y) };
  if (startingSupport !== null) credited.add(startingSupport);
  let active = [];
  for (let iteration = 0; iteration < limit; iteration++) {
    const hits = query(result.rect, result.remaining);
    if (hits.overlaps.length)
      return { ...result, status: "residual-overlap", diagnosticIds: hits.overlaps };
    if (!hits.contacts.length) {
      result.path.push({
        rect: { ...result.rect },
        motion: { ...result.remaining },
        until: { numerator: 1, denominator: 1 }
      });
      result.rect = translate(result.rect, result.remaining);
      for (const target of targets2) target.rect = translate(target.rect, target.delta);
      result.remaining = { ...ZERO2 };
      result.supportId = result.motion.y < 0 ? null : support(result.rect, targets2, startingSupport, credited, options.ignoredOneWayId);
      return result;
    }
    const first = hits.contacts[0];
    if (!first) throw new Error("Missing movement contact");
    result.iterations++;
    result.path.push({
      rect: { ...result.rect },
      motion: { ...result.remaining },
      until: { ...first.time }
    });
    const moved = displacementAtContact(result.remaining, first.time);
    result.rect = translate(result.rect, moved);
    result.remaining = { x: result.remaining.x - moved.x, y: result.remaining.y - moved.y };
    for (const target of targets2) {
      const movedTarget = displacementAtContact(target.delta, first.time);
      target.rect = translate(target.rect, movedTarget);
      target.delta = { x: target.delta.x - movedTarget.x, y: target.delta.y - movedTarget.y };
    }
    const current = hits.contacts.map((contact) => {
      result.contacts.push({ ...contact, iteration });
      if (contact.normal.y === -1) credited.add(contact.otherId);
      const target = byId.get(contact.otherId);
      if (!target) throw new Error("Missing contact target");
      return { id: target.id, normal: contact.normal, delta: target.delta };
    });
    active = active.flatMap((constraint) => {
      const target = byId.get(constraint.id);
      return target && touching(result.rect, target, constraint.normal, 1) ? [{ ...constraint, delta: target.delta }] : [];
    });
    const witnessed = [...active, ...current];
    for (const constraint of current) {
      if (redundantSeam(result.rect, constraint, witnessed, byId)) continue;
      if (!active.some(
        (item) => item.id === constraint.id && item.normal.x === constraint.normal.x && item.normal.y === constraint.normal.y
      ))
        active.push(constraint);
    }
    for (const axis of ["x", "y"]) {
      let lower = -MAX_MOTION;
      let upper = MAX_MOTION;
      for (const constraint of active) {
        const normal = constraint.normal[axis];
        const target = byId.get(constraint.id);
        if (!target) throw new Error("Missing active contact target");
        const gap = contactGap(result.rect, target, constraint.normal);
        if (normal === 1) lower = Math.max(lower, constraint.delta[axis] - gap);
        if (normal === -1) upper = Math.min(upper, constraint.delta[axis] + gap);
        if (result.motion[axis] * normal < 0) result.motion[axis] = 0;
      }
      if (lower > upper) {
        const exact = active.filter((constraint) => {
          const target = byId.get(constraint.id);
          return target && touching(result.rect, target, constraint.normal, 0);
        });
        const crush = exact.some(
          (a) => a.normal[axis] === 1 && exact.some((b) => b.normal[axis] === -1 && a.delta[axis] > b.delta[axis])
        ) || closingTrap(result.rect, active, targets2, byId, result.remaining, axis);
        return {
          ...result,
          status: crush ? "crushed" : "unresolved-contact",
          diagnosticIds: [
            ...new Set(
              active.filter((constraint) => constraint.normal[axis] !== 0).map((constraint) => constraint.id)
            )
          ].sort((a, b) => a - b)
        };
      }
      result.remaining[axis] = Math.max(lower, Math.min(upper, result.remaining[axis]));
    }
    if (result.remaining.x === 0 && result.remaining.y === 0 && targets2.every((target) => target.delta.x === 0 && target.delta.y === 0)) {
      result.path.push({
        rect: { ...result.rect },
        motion: { ...ZERO2 },
        until: { numerator: 1, denominator: 1 }
      });
      result.supportId = support(
        result.rect,
        targets2,
        startingSupport,
        credited,
        options.ignoredOneWayId
      );
      return result;
    }
  }
  return {
    ...result,
    status: "contact-limit",
    diagnosticIds: [...new Set(result.contacts.map((contact) => contact.otherId))].sort(
      (a, b) => a - b
    )
  };
}

// src/game/physics/body.ts
var ZERO3 = { x: 0, y: 0 };
var NORMALS = [
  { x: -1, y: 0 },
  { x: 1, y: 0 },
  { x: 0, y: -1 },
  { x: 0, y: 1 }
];
function validateLocalRect(rect) {
  integer(rect.x, -MAX_SHAPE, MAX_SHAPE, "local x");
  integer(rect.y, -MAX_SHAPE, MAX_SHAPE, "local y");
  integer(rect.w, 1, MAX_SHAPE, "local width");
  integer(rect.h, 1, MAX_SHAPE, "local height");
  integer(rect.x + rect.w, -MAX_SHAPE, MAX_SHAPE, "local right edge");
  integer(rect.y + rect.h, -MAX_SHAPE, MAX_SHAPE, "local bottom edge");
}
function facing(value) {
  if (value !== -1 && value !== 1) throw new Error("Invalid body facing");
}
function worldRect(root, local, direction) {
  facing(direction);
  validateLocalRect(local);
  position(root.x);
  position(root.y);
  const rect = {
    x: position(root.x + (direction === 1 ? local.x : -local.x - local.w)),
    y: position(root.y + local.y),
    w: local.w,
    h: local.h
  };
  position(rect.x + rect.w);
  position(rect.y + rect.h);
  return rect;
}
function worldSocket(root, local, direction) {
  facing(direction);
  position(root.x);
  position(root.y);
  integer(local.x, -MAX_SHAPE, MAX_SHAPE, "socket x");
  integer(local.y, -MAX_SHAPE, MAX_SHAPE, "socket y");
  return { x: position(root.x + local.x * direction), y: position(root.y + local.y) };
}
function bodyRect(body2, shape, direction) {
  integer(body2.id, 1, COUNTER_LIMIT - 1, "body ID");
  integer(shape.id, 1, COUNTER_LIMIT - 1, "shape ID");
  if (body2.shapeId !== shape.id) throw new Error("Body/shape identity mismatch");
  if (body2.grounded !== (body2.supportId !== null)) throw new Error("Ground/support mismatch");
  if (body2.supportId !== null) integer(body2.supportId, 1, COUNTER_LIMIT - 1, "body support ID");
  motion(body2.vx);
  motion(body2.vy);
  motion(body2.remainderX);
  motion(body2.remainderY);
  return worldRect(body2, shape.rect, direction);
}
function targetRect(rect, delta, phase) {
  return phase === "start" ? rect : { ...rect, x: rect.x + delta.x, y: rect.y + delta.y };
}
function poseCandidates(rect, index) {
  return index.query({
    minX: Math.max(-MAX_POSITION, rect.x - 1),
    minY: Math.max(-MAX_POSITION, rect.y - 1),
    maxX: Math.min(MAX_POSITION, rect.x + rect.w + 1),
    maxY: Math.min(MAX_POSITION, rect.y + rect.h + 1)
  });
}
function blockingShapes(root, local, direction, index, frame, phase = "start") {
  index.assertFrame(frame);
  const proposed = worldRect(root, local, direction);
  return index.query(sweepBounds(proposed)).filter(
    (target) => target.kind === "solid" && sweepAabb(proposed, ZERO3, targetRect(target.rect, target.delta, phase))?.kind === "overlap"
  ).map((target) => target.id);
}
function tryBodyShape(body2, current, desired, oldFacing, nextFacing, index, frame, phase = "start") {
  bodyRect(body2, current, oldFacing);
  validateLocalRect(desired.rect);
  integer(desired.id, 1, COUNTER_LIMIT - 1, "desired shape ID");
  if (current.rect.y + current.rect.h !== desired.rect.y + desired.rect.h)
    throw new Error("Stance changes the feet anchor");
  const blockedBy = blockingShapes(body2, desired.rect, nextFacing, index, frame, phase);
  return blockedBy.length ? { accepted: false, blockedBy, body: body2, facing: oldFacing } : {
    accepted: true,
    blockedBy,
    body: {
      ...body2,
      shapeId: desired.id,
      contacts: desired.id !== current.id || oldFacing !== nextFacing ? [] : body2.contacts
    },
    facing: nextFacing
  };
}
function startSupport(body2, shape, direction, index, frame, ignoredId) {
  index.assertFrame(frame);
  const rect = bodyRect(body2, shape, direction);
  const candidates = poseCandidates(rect, index).filter((target) => {
    if (target.kind === "one-way" && target.id === ignoredId) return false;
    const gap = target.rect.y - rect.y - rect.h;
    return gap >= 0 && gap <= (target.id === body2.supportId ? 1 : 0) && rect.x < target.rect.x + target.rect.w && rect.x + rect.w > target.rect.x;
  });
  return candidates.find((target) => target.id === body2.supportId)?.id ?? candidates[0]?.id ?? null;
}
function endContacts(rect, movement, index) {
  const result = [];
  const candidates = poseCandidates(rect, index);
  const witnesses = new Set(
    movement.contacts.map(
      (contact) => `${contact.otherId}:${contact.normal.x}:${contact.normal.y}`
    )
  );
  for (const normal of NORMALS) {
    const matching = candidates.filter((target2) => {
      const witnessed = witnesses.has(`${target2.id}:${normal.x}:${normal.y}`);
      const supported2 = normal.y === -1 && movement.supportId === target2.id;
      if (target2.kind === "one-way" && !(normal.y === -1 && (witnessed || supported2))) return false;
      const b = targetRect(target2.rect, target2.delta, "end");
      const gap = normal.x === -1 ? b.x - rect.x - rect.w : normal.x === 1 ? rect.x - b.x - b.w : normal.y === -1 ? b.y - rect.y - rect.h : rect.y - b.y - b.h;
      return gap >= 0 && gap <= (witnessed || supported2 ? 1 : 0) && (normal.x === 0 ? rect.x < b.x + b.w && rect.x + rect.w > b.x : rect.y < b.y + b.h && rect.y + rect.h > b.y);
    });
    const target = (normal.y === -1 ? matching.find((target2) => target2.id === movement.supportId) : void 0) ?? matching[0];
    if (target)
      result.push({
        otherId: target.id,
        normalX: normal.x,
        normalY: normal.y,
        toiNumerator: 1,
        toiDenominator: 1,
        kind: target.kind
      });
  }
  return result.sort(
    (a, b) => a.otherId - b.otherId || a.normalX - b.normalX || a.normalY - b.normalY
  );
}
function stepBody(body2, shape, direction, index, options) {
  const rect = bodyRect(body2, shape, direction);
  const movement = moveKinematic(
    { rect, motion: { x: body2.vx, y: body2.vy }, supportId: body2.supportId },
    index,
    options
  );
  if (movement.status !== "complete")
    return { status: "failed", reason: movement.status, movement };
  return {
    status: "complete",
    movement,
    body: {
      ...body2,
      x: position(body2.x + movement.rect.x - rect.x),
      y: position(body2.y + movement.rect.y - rect.y),
      vx: movement.motion.x,
      vy: movement.motion.y,
      supportId: movement.supportId,
      grounded: movement.supportId !== null,
      contacts: endContacts(movement.rect, movement, index)
    }
  };
}

// src/game/actors/grounded.ts
function hasLeadingSupport(body2, shape, facing2, speed, supportId, index, frame) {
  index.assertFrame(frame);
  const support2 = index.get(supportId);
  if (!support2) return false;
  const projected = worldRect(
    {
      x: position(body2.x + speed * facing2 + support2.delta.x),
      y: position(body2.y + support2.delta.y)
    },
    shape.rect,
    facing2
  );
  const lead = facing2 === 1 ? projected.x + projected.w - 1 : projected.x;
  const feet = projected.y + projected.h;
  const previousLead = lead - speed * facing2;
  const first = Math.min(previousLead, lead);
  const last = Math.max(previousLead, lead);
  const spans = index.query(sweepBounds({ x: first, y: feet, w: last - first + 1, h: 1 })).filter((target) => {
    if (target.delta.x !== support2.delta.x || target.delta.y !== support2.delta.y) return false;
    const gap = target.rect.y + target.delta.y - feet;
    return gap >= 0 && gap <= (target.id === supportId ? 1 : 0);
  }).map((target) => ({
    start: target.rect.x + target.delta.x,
    end: target.rect.x + target.delta.x + target.rect.w
  })).sort((a, b) => a.start - b.start || a.end - b.end);
  let cursor = first;
  for (const span of spans) {
    if (span.end <= cursor) continue;
    if (span.start > cursor) return false;
    cursor = span.end;
    if (cursor > last) return true;
  }
  return false;
}
function stepGroundedEnemy(current, definition2, shape, index, frame) {
  index.assertFrame(frame);
  if (current.geometryRevision !== frame.geometryRevision)
    throw new Error("Enemy geometry revision mismatch");
  integer(current.turns, 0, COUNTER_LIMIT - 2, "enemy turns");
  motion(definition2.speed);
  motion(definition2.gravity);
  motion(definition2.terminalVelocity);
  if (definition2.speed < 0 || definition2.gravity <= 0 || definition2.terminalVelocity <= 0)
    throw new Error("Invalid grounded patrol motion");
  for (const value of [
    definition2.bounds.x,
    definition2.bounds.y,
    definition2.bounds.x + definition2.bounds.w,
    definition2.bounds.y + definition2.bounds.h
  ])
    position(value);
  if (definition2.bounds.w <= 0 || definition2.bounds.h <= 0)
    throw new Error("Invalid patrol bounds");
  if (current.life === "removed")
    return { status: "complete", enemy: current, decision: "removed", physics: null };
  const body2 = { ...current.body, contacts: [...current.body.contacts] };
  if (body2.remainderX !== 0 || body2.remainderY !== 0)
    throw new Error("Patrol requires integral motion");
  const supportId = body2.vy >= 0 ? startSupport(body2, shape, current.facing, index, frame, null) : null;
  body2.supportId = supportId;
  body2.grounded = supportId !== null;
  let facing2 = current.facing;
  let decision = supportId === null ? "fall" : "walk";
  let turns = current.turns;
  if (supportId !== null) {
    const rect = worldRect(body2, shape.rect, facing2);
    const blocked = body2.contacts.some((contact) => {
      const target = index.get(contact.otherId);
      if (target?.kind !== "solid" || contact.normalX !== -facing2) return false;
      const gap = facing2 === 1 ? target.rect.x - rect.x - rect.w : rect.x - target.rect.x - target.rect.w;
      return gap >= 0 && gap <= 1 && rect.y < target.rect.y + target.rect.h && rect.y + rect.h > target.rect.y;
    });
    if (blocked || !hasLeadingSupport(body2, shape, facing2, definition2.speed, supportId, index, frame)) {
      decision = "turn";
      const nextFacing = definition2.turnAtBoundary === false ? facing2 : facing2 === 1 ? -1 : 1;
      const turn = tryBodyShape(body2, shape, shape, facing2, nextFacing, index, frame);
      if (turn.accepted && nextFacing !== facing2) {
        facing2 = nextFacing;
        body2.contacts = [];
        turns++;
      }
      body2.vx = 0;
    } else body2.vx = definition2.speed === 0 ? 0 : definition2.speed * facing2;
    body2.vy = 0;
  }
  body2.vy = motion(Math.min(definition2.terminalVelocity, body2.vy + definition2.gravity));
  const physics = stepBody(body2, shape, facing2, index, { frame });
  if (physics.status === "failed") {
    if (physics.reason !== "crushed") return { status: "failed", physics };
    return {
      status: "complete",
      enemy: { ...current, life: "removed", removalReason: "crushed" },
      decision: "removed",
      physics
    };
  }
  const next = physics.body;
  const bounds = definition2.bounds;
  const outside = next.x < bounds.x || next.x > bounds.x + bounds.w || next.y < bounds.y || next.y > bounds.y + bounds.h;
  return {
    status: "complete",
    enemy: {
      ...current,
      body: next,
      facing: facing2,
      turns,
      life: outside ? "removed" : "alive",
      removalReason: outside ? "out-of-bounds" : null
    },
    decision: outside ? "removed" : decision,
    physics
  };
}

// src/game/content/materials.ts
var ATTACK_MATERIALS = [
  "bullet",
  "explosive",
  "heat",
  "energy",
  "blade",
  "blunt"
];
var SURFACE_MATERIAL_IDS = ["concrete", "timber", "armor-steel", "open-grating"];
var opaque = {
  bullet: true,
  explosive: true,
  heat: true,
  energy: true,
  blade: true,
  blunt: true
};
var SURFACE_MATERIALS = [
  {
    id: "concrete",
    damageScale: { bullet: 0, explosive: 0, heat: 0, energy: 0, blade: 0, blunt: 0 },
    blocks: { ...opaque }
  },
  {
    id: "timber",
    damageScale: { bullet: 1, explosive: 1, heat: 1, energy: 1, blade: 1, blunt: 1 },
    blocks: { ...opaque }
  },
  {
    id: "armor-steel",
    damageScale: { bullet: 0, explosive: 1, heat: 0, energy: 2, blade: 0, blunt: 0 },
    blocks: { ...opaque }
  },
  {
    id: "open-grating",
    damageScale: { bullet: 1, explosive: 1, heat: 0, energy: 1, blade: 0, blunt: 1 },
    blocks: {
      bullet: true,
      explosive: false,
      heat: false,
      energy: false,
      blade: true,
      blunt: true
    }
  }
];
function validateSurfaceMaterials(definitions2) {
  if (definitions2.length !== SURFACE_MATERIAL_IDS.length)
    throw new Error("Material roster mismatch");
  for (const [index, material] of definitions2.entries()) {
    if (material.id !== SURFACE_MATERIAL_IDS[index] || Object.keys(material).sort().join() !== "blocks,damageScale,id")
      throw new Error("Unknown or malformed surface material");
    for (const table of [material.damageScale, material.blocks])
      if (Object.keys(table).sort().join() !== [...ATTACK_MATERIALS].sort().join())
        throw new Error("Incomplete material response table");
    for (const attack2 of ATTACK_MATERIALS) {
      integer(material.damageScale[attack2], 0, 4, "material damage scale");
      if (typeof material.blocks[attack2] !== "boolean")
        throw new Error("Invalid material blocking policy");
    }
  }
}
validateSurfaceMaterials(SURFACE_MATERIALS);
function surfaceMaterial(id2) {
  const material = SURFACE_MATERIALS.find((material2) => material2.id === id2);
  if (!material) throw new Error("Unknown surface material");
  return material;
}
function surfaceMaterialFor(target) {
  return surfaceMaterial(target.materialId === void 0 ? "concrete" : target.materialId);
}
function materialBlocks(target, attack2) {
  if (!ATTACK_MATERIALS.includes(attack2)) throw new Error("Unknown attack material");
  return surfaceMaterialFor(target).blocks[attack2];
}
function materialDamage(damage, attack2, materialId) {
  integer(damage, 0, 65535, "material incoming damage");
  if (!ATTACK_MATERIALS.includes(attack2)) throw new Error("Unknown attack material");
  return Math.min(65535, damage * surfaceMaterial(materialId).damageScale[attack2]);
}

// src/game/combat/projectile.ts
function sweepProjectile(projectile, definition2, shape, terrain, hurtboxes) {
  if (definition2.id !== projectile.definitionId || definition2.shapeId !== shape.id || definition2.kind !== "swept-projectile" || definition2.maxTargets !== 1 || definition2.material !== "bullet")
    throw new Error("Unsupported ballistic policy");
  return projectileImpact(
    projectile,
    shape,
    definition2.damage,
    terrain.filter((target) => materialBlocks(target, definition2.material)),
    hurtboxes.filter((target) => !target.solid || materialBlocks(target, definition2.material))
  );
}
function projectileImpact(projectile, shape, bodyDamage, terrain, hurtboxes) {
  integer(bodyDamage, 0, 65535, "projectile body damage");
  integer(terrain.length + hurtboxes.length, 0, 4096, "projectile candidate count");
  const bounds = worldRect(projectile.position, shape.rect, 1);
  sweepBounds(bounds, projectile.velocity);
  const candidates = [
    ...terrain.map((target2) => ({
      ...target2,
      entityId: null,
      priority: 0,
      kind: "terrain"
    })),
    ...hurtboxes.filter(
      (target2) => target2.entityId !== projectile.ownerId && (target2.solid || target2.team !== projectile.team)
    ).map((target2) => ({
      ...target2,
      priority: target2.solid ? 0 : target2.kind === "shield" ? 1 : 2
    }))
  ];
  const ids2 = /* @__PURE__ */ new Set();
  let first = null;
  for (const target2 of candidates) {
    surfaceMaterialFor(target2);
    integer(target2.id, 1, COUNTER_LIMIT - 1, "projectile collision ID");
    if (ids2.has(target2.id)) throw new Error("Duplicate projectile collision ID");
    ids2.add(target2.id);
    const hit = sweepAabb(bounds, projectile.velocity, target2.rect, target2.delta);
    if (!hit) continue;
    const time3 = hit.kind === "overlap" ? { numerator: 0, denominator: 1 } : hit.time;
    const order = first ? compareContactTime(
      time3.numerator,
      time3.denominator,
      first.time.numerator,
      first.time.denominator
    ) : -1;
    if (order < 0 || order === 0 && first && (target2.priority < first.target.priority || target2.priority === first.target.priority && target2.id < first.target.id))
      first = { target: target2, time: time3 };
  }
  if (!first) return null;
  const { target, time: time2 } = first;
  return {
    sourceId: projectile.id,
    definitionId: projectile.definitionId,
    actionInstanceId: projectile.actionInstanceId,
    ownerId: projectile.ownerId,
    colliderId: target.id,
    entityId: target.entityId,
    kind: target.kind,
    damage: target.kind === "body" ? bodyDamage : 0,
    position: {
      x: position(
        projectile.position.x + divide(projectile.velocity.x * time2.numerator, time2.denominator).quotient
      ),
      y: position(
        projectile.position.y + divide(projectile.velocity.y * time2.numerator, time2.denominator).quotient
      )
    },
    time: time2
  };
}
function muzzleBlocked(hand, muzzle, shape, terrain, material = "bullet") {
  const bounds = worldRect(hand, shape.rect, 1);
  const delta = { x: muzzle.x - hand.x, y: muzzle.y - hand.y };
  return terrain.some(
    (target) => materialBlocks(target, material) && sweepAabb(bounds, delta, {
      ...target.rect,
      x: target.rect.x + target.delta.x,
      y: target.rect.y + target.delta.y
    }) !== null
  );
}

// src/game/combat/timeline.ts
function actionPose(catalog, definitionId, age) {
  const timeline = catalog.timelines.get(definitionId);
  if (!timeline) throw new Error("Missing action timeline");
  integer(age, 0, COUNTER_LIMIT - 1, "action age");
  if (age >= timeline.durationTicks) return null;
  let remaining = age;
  for (const id2 of timeline.poses) {
    const pose = catalog.poses.get(id2);
    if (!pose) throw new Error("Missing action pose");
    if (remaining < pose.durationTicks) return pose;
    remaining -= pose.durationTicks;
  }
  throw new Error("Action pose exposures do not cover timeline");
}
function stepAction(current, tick2, catalog) {
  integer(tick2, current.stateStartTick, COUNTER_LIMIT - 1, "action tick");
  const definition2 = catalog.timelines.get(current.definitionId);
  if (!definition2) throw new Error("Missing action definition");
  const age = tick2 - current.stateStartTick;
  integer(current.nextMarkerIndex, 0, definition2.markers.length, "action marker cursor");
  if (definition2.markers.slice(0, current.nextMarkerIndex).some((marker) => marker.tickOffset > age))
    throw new Error("Action cursor acknowledges a future marker");
  if ((definition2.markers[current.nextMarkerIndex]?.tickOffset ?? age) < age)
    throw new Error("Action timeline skipped an unprocessed marker");
  const action2 = { ...current };
  const markers = [];
  const pose = actionPose(catalog, current.definitionId, age);
  while (definition2.markers[action2.nextMarkerIndex]?.tickOffset === age) {
    const marker = definition2.markers[action2.nextMarkerIndex];
    if (!marker || !pose) throw new Error("Marker outside active pose");
    markers.push({
      actionInstanceId: action2.actionInstanceId,
      markerIndex: action2.nextMarkerIndex++,
      marker,
      pose
    });
  }
  return { action: action2, markers, pose, finished: age >= definition2.durationTicks };
}

// src/game/actors/rifle.ts
function createRifleState() {
  return {
    action: {
      kind: "ready",
      actionInstanceId: 0,
      stateStartTick: 0,
      definitionId: 0,
      nextMarkerIndex: 0
    },
    targetId: null,
    aim: 0,
    facing: -1
  };
}
function cancelRifle(state) {
  state.action.kind = "ready";
  state.targetId = null;
}
function rifleMode(state, tick2, profile) {
  if (state.action.kind === "ready") return 0;
  const age = tick2 - state.action.stateStartTick;
  return age < profile.raiseTicks ? 1 : age <= profile.lastReleaseTick ? 2 : 3;
}
function validateRifleState(state, enemy, tick2, nextActionId, players, catalog, profile) {
  integer(state.aim, 0, 1, "rifle aim");
  if (state.facing !== -1 && state.facing !== 1) throw new Error("Invalid rifle facing");
  integer(state.action.actionInstanceId, 0, nextActionId - 1, "rifle action allocation");
  integer(state.action.stateStartTick, 0, tick2, "rifle start tick");
  if (state.action.kind !== "ready" && state.action.kind !== "fire")
    throw new Error("Invalid rifle action");
  if (state.action.actionInstanceId === 0) {
    if (state.action.definitionId !== 0 || state.action.nextMarkerIndex !== 0 || state.action.stateStartTick !== 0 || state.aim !== 0 || state.targetId !== null || state.action.kind !== "ready")
      throw new Error("Invalid idle rifle");
    return;
  }
  if (state.action.definitionId !== profile.timelineIds[state.aim])
    throw new Error("Rifle pose/aim mismatch");
  const timeline = catalog.timelines.get(state.action.definitionId);
  if (!timeline) throw new Error("Missing rifle timeline");
  integer(state.action.nextMarkerIndex, 0, timeline.markers.length, "rifle marker cursor");
  const age = tick2 - state.action.stateStartTick;
  if (timeline.markers.slice(0, state.action.nextMarkerIndex).some((marker) => marker.tickOffset > age))
    throw new Error("Future rifle marker");
  if (state.action.kind === "fire") {
    if (enemy.life !== "alive" || enemy.facing !== state.facing || !players.some((player2) => player2.playerId === state.targetId) || age >= timeline.durationTicks || timeline.markers.slice(state.action.nextMarkerIndex).some((marker) => marker.tickOffset <= age))
      throw new Error("Invalid active rifle continuation");
  } else if (state.targetId !== null || enemy.life === "alive" && age < timeline.durationTicks)
    throw new Error("Unexplained rifle cancellation");
}
function stepRifleAttack(current, enemy, players, tick2, nextActionId, catalog, profile, bullet, terrain) {
  integer(tick2, 1, COUNTER_LIMIT - 1, "rifle tick");
  const state = structuredClone(current);
  let facing2 = current.action.kind === "fire" ? current.facing : enemy.facing;
  if (enemy.life !== "alive") {
    cancelRifle(state);
    return { state, facing: facing2, nextActionId, markers: [] };
  }
  if (state.action.kind === "ready" && enemy.body.grounded) {
    const candidates = players.filter((player2) => player2.life === "alive" && player2.invulnerableTicks === 0).map((player2) => ({
      player: player2,
      distance: Math.abs(player2.body.x - enemy.body.x) + Math.abs(player2.body.y - enemy.body.y)
    })).filter(({ distance }) => distance <= profile.range).sort((a, b) => a.distance - b.distance || a.player.playerId - b.player.playerId);
    for (const { player: player2 } of candidates) {
      const dx = player2.body.x - enemy.body.x;
      const aim = Math.abs(dx) <= profile.upAlignment && enemy.body.y - player2.body.y >= profile.upHeight ? 1 : 0;
      const direction = dx === 0 ? facing2 : dx < 0 ? -1 : 1;
      const timeline = catalog.timelines.get(profile.timelineIds[aim]);
      const pose = timeline && catalog.poses.get(timeline.poses[0] ?? 0);
      const socket = pose?.sockets.find((socket2) => socket2.name === "muzzle");
      if (!socket) throw new Error("Missing authored rifle raise socket");
      const muzzle = worldSocket(enemy.body, socket.point, direction);
      const end = aim === 1 ? { x: muzzle.x, y: player2.body.y - profile.aimHeight } : { x: player2.body.x, y: muzzle.y };
      if (muzzleBlocked(muzzle, end, bullet, terrain)) continue;
      facing2 = direction;
      state.facing = direction;
      state.aim = aim;
      state.targetId = player2.playerId;
      state.action = {
        kind: "fire",
        actionInstanceId: nextActionId,
        stateStartTick: tick2,
        definitionId: profile.timelineIds[aim],
        nextMarkerIndex: 0
      };
      nextActionId = nextCounter(nextActionId);
      break;
    }
  }
  if (state.action.kind === "ready") return { state, facing: facing2, nextActionId, markers: [] };
  const action2 = stepAction(state.action, tick2, catalog);
  state.action = action2.action;
  if (action2.finished) cancelRifle(state);
  return { state, facing: facing2, nextActionId, markers: action2.markers };
}

// src/game/actors/shield.ts
var SHIELD_PHASES = ["brace", "advance", "turn", "bash", "stunned", "dead"];
function createShieldState(profile) {
  return {
    phase: "brace",
    integrity: profile.integrity,
    facing: -1,
    turnFacing: -1,
    targetId: null,
    action: { actionInstanceId: 0, stateStartTick: 0, definitionId: 0, nextMarkerIndex: 0 },
    hitIds: []
  };
}
function cancelShield(state) {
  state.phase = "dead";
  state.targetId = null;
  state.hitIds = [];
}
function shieldProtected(state, tick2, profile) {
  return state.integrity > 0 && (state.phase === "brace" || state.phase === "advance" || state.phase === "bash" && tick2 - state.action.stateStartTick < profile.bashActiveTick);
}
function shieldMode(state) {
  return SHIELD_PHASES.indexOf(state.phase) + (state.integrity === 0 ? SHIELD_PHASES.length : 0);
}
function begin(state, phase, tick2, nextActionId, profile) {
  state.phase = phase;
  state.hitIds = [];
  state.action = {
    actionInstanceId: nextActionId,
    stateStartTick: tick2,
    definitionId: profile.timelineIds[phase],
    nextMarkerIndex: 0
  };
  return nextCounter(nextActionId);
}
function evaluate(state, tick2, nextActionId, catalog, profile) {
  const advanced = stepAction(state.action, tick2, catalog);
  state.action = advanced.action;
  for (const item of advanced.markers)
    if (item.marker.kind === "face") state.facing = state.turnFacing;
  return {
    state,
    nextActionId,
    markers: advanced.markers,
    speed: state.phase === "advance" ? profile.speed : 0
  };
}
function stepShield(current, enemy, players, tick2, nextActionId, catalog, profile) {
  integer(tick2, 1, COUNTER_LIMIT - 1, "shield tick");
  const state = structuredClone(current);
  if (enemy.life !== "alive") {
    cancelShield(state);
    return { state, nextActionId, markers: [], speed: 0 };
  }
  const duration = catalog.timelines.get(state.action.definitionId)?.durationTicks ?? 0;
  const finished = tick2 - state.action.stateStartTick >= duration;
  if (["turn", "bash", "stunned"].includes(state.phase) && !finished)
    return evaluate(state, tick2, nextActionId, catalog, profile);
  const target = players.filter((player2) => player2.life === "alive" && player2.invulnerableTicks === 0).map((player2) => ({
    player: player2,
    distance: Math.abs(player2.body.x - enemy.body.x) + Math.abs(player2.body.y - enemy.body.y)
  })).filter(({ distance }) => distance <= profile.sightRange).sort((a, b) => a.distance - b.distance || a.player.playerId - b.player.playerId)[0]?.player;
  const dx = target ? target.body.x - enemy.body.x : 0;
  const direction = dx === 0 ? state.facing : dx < 0 ? -1 : 1;
  if (enemy.body.grounded && target && direction !== state.facing) {
    state.targetId = target.playerId;
    state.turnFacing = direction;
    nextActionId = begin(state, "turn", tick2, nextActionId, profile);
  } else if (enemy.body.grounded && target && Math.abs(dx) <= profile.bashRange && Math.abs(target.body.y - enemy.body.y) <= profile.bashHeight) {
    state.targetId = target.playerId;
    nextActionId = begin(state, "bash", tick2, nextActionId, profile);
  } else if (state.action.actionInstanceId === 0 || finished) {
    const phase = target && enemy.body.grounded && state.phase !== "advance" ? "advance" : "brace";
    state.targetId = target?.playerId ?? null;
    state.turnFacing = state.facing;
    nextActionId = begin(
      state,
      state.action.actionInstanceId === 0 ? "brace" : phase,
      tick2,
      nextActionId,
      profile
    );
  }
  return evaluate(state, tick2, nextActionId, catalog, profile);
}
function damageShield(current, attack2, tick2, nextActionId, catalog, profile) {
  const state = structuredClone(current);
  const damage = profile.damageByMaterial[attack2.material];
  integer(damage, 0, 65535, "shield material damage");
  if (state.phase === "dead" || state.integrity === 0 || damage === 0)
    return { state, nextActionId, broken: false, markers: [] };
  state.integrity = Math.max(0, state.integrity - damage);
  if (state.integrity > 0) return { state, nextActionId, broken: false, markers: [] };
  state.targetId = null;
  state.turnFacing = state.facing;
  nextActionId = begin(state, "stunned", tick2, nextActionId, profile);
  return { ...evaluate(state, tick2, nextActionId, catalog, profile), broken: true };
}
function validateShield(state, enemy, tick2, nextActionId, players, catalog, profile, additionalHitIds = []) {
  if (!SHIELD_PHASES.includes(state.phase)) throw new Error("Invalid shield phase");
  integer(state.integrity, 0, profile.integrity, "shield integrity");
  if (![state.facing, state.turnFacing].every((value) => value === -1 || value === 1) || state.facing !== enemy.facing)
    throw new Error("Invalid shield facing");
  if (state.phase === "dead" !== (enemy.life === "removed"))
    throw new Error("Shield life mismatch");
  if (state.targetId !== null && !players.some((player2) => player2.playerId === state.targetId))
    throw new Error("Unknown shield target");
  const action2 = state.action;
  integer(action2.actionInstanceId, 0, nextActionId - 1, "shield action allocation");
  integer(action2.stateStartTick, 0, tick2, "shield start tick");
  if (action2.actionInstanceId === 0) {
    if (state.phase !== "brace" || state.integrity !== profile.integrity || action2.definitionId !== 0 || action2.nextMarkerIndex !== 0 || action2.stateStartTick !== 0 || state.targetId !== null || state.hitIds.length !== 0 || state.turnFacing !== state.facing)
      throw new Error("Invalid initial shield");
    return;
  }
  const timeline = catalog.timelines.get(action2.definitionId);
  if (!timeline || !Object.values(profile.timelineIds).includes(action2.definitionId) || state.phase !== "dead" && action2.definitionId !== profile.timelineIds[state.phase])
    throw new Error("Shield phase/timeline mismatch");
  const age = tick2 - action2.stateStartTick;
  integer(action2.nextMarkerIndex, 0, timeline.markers.length, "shield marker cursor");
  if (timeline.markers.slice(0, action2.nextMarkerIndex).some((marker) => marker.tickOffset > age) || state.phase !== "dead" && (age >= timeline.durationTicks || timeline.markers.slice(action2.nextMarkerIndex).some((marker) => marker.tickOffset <= age)))
    throw new Error("Invalid shield marker continuation");
  if (state.phase === "turn") {
    const flipped = timeline.markers.slice(0, action2.nextMarkerIndex).some((marker) => marker.kind === "face");
    if (state.targetId === null || state.facing !== (flipped ? state.turnFacing : -state.turnFacing))
      throw new Error("Invalid committed shield turn");
  }
  if (state.phase === "bash" && state.targetId === null) throw new Error("Missing bash target");
  if (state.phase === "stunned" && (state.integrity !== 0 || state.targetId !== null))
    throw new Error("Invalid broken shield stun");
  integer(state.hitIds.length, 0, 4, "bash hit budget");
  for (const [index, id2] of state.hitIds.entries()) {
    if (state.phase !== "bash" || age < profile.bashActiveTick || index > 0 && id2 <= (state.hitIds[index - 1] ?? 0) || !players.some((player2) => player2.body.id === id2) && !additionalHitIds.includes(id2))
      throw new Error("Invalid bash hit ledger");
  }
}

// src/game/rules.ts
var ARCADE = Object.freeze({
  width: 384,
  height: 216,
  simulationHz: 60,
  snapshotHz: 20,
  maxPlayers: 4,
  staleInputMs: 250,
  reservationMs: 9e4,
  initialLives: 3,
  initialGrenades: 10,
  respawnProtectionTicks: 120,
  deathTicks: 30,
  respawnEntryTicks: 12,
  boardingTicks: 12,
  reboardCooldownTicks: 30,
  vehicleSpecialHoldTicks: 30,
  jumpBufferTicks: 5,
  coyoteTicks: 4,
  dropThroughTicks: 12
});
var RULE_PRESETS = Object.freeze({
  classic: Object.freeze({ footHealth: 1, tankArmor: 3, sharedContinues: 3 }),
  accessible: Object.freeze({ footHealth: 3, tankArmor: 3, sharedContinues: 9 })
});
var DEFAULT_BINDINGS = Object.freeze({
  left: ["ArrowLeft", "KeyA"],
  right: ["ArrowRight", "KeyD"],
  up: ["ArrowUp", "KeyW"],
  down: ["ArrowDown", "KeyS"],
  fire: ["KeyJ", "KeyZ"],
  jump: ["Space", "KeyK", "KeyX"],
  grenade: ["KeyL", "KeyC"],
  interact: ["KeyE"],
  vehicleSpecial: ["KeyV"]
});
var DEFAULT_GAMEPAD = Object.freeze({
  jump: 0,
  fire: 2,
  grenade: 1,
  interact: 3,
  vehicleSpecial: 4
});

// src/game/campaign/life.ts
function check(ok, reason) {
  if (!ok) throw new Error(`Player life: ${reason}`);
}
function validBodyPresence(actor) {
  if (actor.life !== "alive" && (actor.vehicleId !== null || actor.action.kind !== "ready"))
    return false;
  if (actor.bodyPresence === "present") return actor.life !== "spectating";
  if (actor.life === "alive") return false;
  const body2 = actor.body;
  return actor.bodyPresence === "removed" && actor.locomotion === "airborne" && body2.vx === 0 && body2.vy === 0 && body2.remainderX === 0 && body2.remainderY === 0 && !body2.grounded && body2.supportId === null && body2.contacts.length === 0;
}
function validatePlayerLife(actor, tick2, ruleset) {
  integer(tick2, 0, COUNTER_LIMIT - 1, "life tick");
  integer(actor.lifeStartTick, 0, tick2, "life phase tick");
  integer(actor.lives, 0, ARCADE.initialLives, "player lives");
  const rule = RULE_PRESETS[ruleset];
  check(rule, "unknown ruleset");
  integer(actor.health, 0, rule.footHealth, "foot health");
  integer(actor.invulnerableTicks, 0, ARCADE.respawnProtectionTicks, "entry protection");
  check(validBodyPresence(actor), "inconsistent body presence");
  check(
    actor.life === "alive" || actor.life === "respawning" ? actor.health > 0 && actor.lives > 0 : actor.life === "death" || actor.life === "spectating" ? actor.health === 0 && (actor.life !== "spectating" || actor.lives === 0) : false,
    "inconsistent life state"
  );
}
function notice(actor, tick2, kind) {
  return { kind, tick: tick2, playerId: actor.playerId, lives: actor.lives };
}
function clearAction(actor, tick2) {
  actor.firearmAim = { pitch: 0, nextStepTick: 0 };
  actor.action = {
    kind: "ready",
    actionInstanceId: 0,
    stateStartTick: tick2,
    definitionId: 0,
    nextMarkerIndex: 0
  };
  actor.jumpBufferTicks = 0;
  actor.coyoteTicks = 0;
  actor.ignoredSupportId = null;
  actor.ignoredSupportTicks = 0;
}
function removeBody(actor) {
  actor.bodyPresence = "removed";
  actor.body.vx = actor.body.vy = actor.body.remainderX = actor.body.remainderY = 0;
  actor.body.grounded = false;
  actor.body.supportId = null;
  actor.body.contacts = [];
  actor.locomotion = "airborne";
}
function stepPassiveBody(actor, context) {
  if (actor.bodyPresence !== "present") return false;
  const { definition: definition2, shapes: shapes2, index, frame, fallBoundary } = context;
  position(fallBoundary);
  check(
    definition2.locomotion === "grounded" && definition2.gravity > 0 && definition2.terminalVelocity > 0,
    "invalid passive body physics"
  );
  motion(definition2.gravity);
  motion(definition2.terminalVelocity);
  check(
    actor.body.remainderX === 0 && actor.body.remainderY === 0,
    "unsupported passive body remainder"
  );
  const shape = shapes2.get(actor.body.shapeId);
  check(
    shape && (shape.id === definition2.standingShapeId || shape.id === definition2.crouchedShapeId),
    "unknown passive body shape"
  );
  if (actor.body.y > fallBoundary) {
    removeBody(actor);
    return false;
  }
  const support2 = actor.body.vy < 0 ? null : startSupport(actor.body, shape, actor.facing, index, frame, null);
  actor.body.supportId = support2;
  actor.body.grounded = support2 !== null;
  if (support2 !== null) actor.body.vx = 0;
  actor.body.vy = Math.min(definition2.terminalVelocity, actor.body.vy + definition2.gravity);
  const result = stepBody(actor.body, shape, actor.facing, index, { frame });
  if (result.status === "failed") {
    removeBody(actor);
    return false;
  }
  actor.body = result.body;
  if (actor.body.y > fallBoundary) removeBody(actor);
  else {
    actor.locomotion = actor.body.grounded ? "grounded" : "airborne";
    if (actor.body.grounded) actor.body.vx = 0;
  }
  return actor.bodyPresence === "present";
}
function damagePlayer(current, tick2, damage, ruleset, cause = "hit") {
  validatePlayerLife(current, tick2, ruleset);
  integer(damage, 1, 65535, "player damage");
  check(cause === "hit" || cause === "fall" || cause === "crush", "unknown damage cause");
  const actor = structuredClone(current);
  if (actor.life !== "alive" || cause === "hit" && actor.invulnerableTicks > 0)
    return { actor, notice: null };
  check(actor.vehicleId === null, "vehicle damage requires the vehicle owner");
  actor.health = cause === "hit" ? Math.max(0, actor.health - damage) : 0;
  if (actor.health > 0) return { actor, notice: null };
  actor.lives--;
  actor.life = "death";
  actor.bodyPresence = "present";
  actor.lifeStartTick = tick2;
  actor.invulnerableTicks = 0;
  clearAction(actor, tick2);
  if (cause !== "hit") removeBody(actor);
  else if (actor.body.grounded) actor.body.vx = 0;
  return { actor, notice: notice(actor, tick2, "death") };
}
function entryBody(actor, context) {
  context.index.assertFrame(context.frame);
  position(context.fallBoundary);
  integer(context.anchors.length, 1, 16, "checkpoint anchor count");
  check(context.shape.rect.y + context.shape.rect.h === 0, "entry shape must use a feet anchor");
  for (const point2 of context.anchors) {
    if (blockingShapes(point2, context.shape.rect, actor.facing, context.index, context.frame).length)
      continue;
    const body2 = {
      ...actor.body,
      ...point2,
      vx: 0,
      vy: 0,
      remainderX: 0,
      remainderY: 0,
      shapeId: context.shape.id,
      supportId: null,
      grounded: false,
      contacts: []
    };
    const support2 = startSupport(
      body2,
      context.shape,
      actor.facing,
      context.index,
      context.frame,
      null
    );
    if (support2 === null) continue;
    body2.supportId = support2;
    body2.grounded = true;
    const moved = stepBody(body2, context.shape, actor.facing, context.index, {
      frame: context.frame
    });
    if (moved.status === "complete" && moved.body.grounded && moved.body.y <= context.fallBoundary)
      return moved.body;
  }
  return null;
}
function enterPlayer(current, tick2, ruleset, context) {
  integer(current.lives, 1, ARCADE.initialLives, "entry lives");
  integer(tick2, current.lifeStartTick, COUNTER_LIMIT - 1, "entry tick");
  check(context.frame.tick === tick2, "entry collision tick mismatch");
  check(RULE_PRESETS[ruleset], "unknown ruleset");
  check(current.vehicleId === null, "vehicle seat must be released before entry");
  const body2 = entryBody(current, context);
  if (!body2) return null;
  const actor = structuredClone(current);
  actor.body = body2;
  actor.geometryRevision = context.frame.geometryRevision;
  actor.life = "respawning";
  actor.bodyPresence = "present";
  actor.lifeStartTick = tick2;
  actor.locomotion = "grounded";
  actor.health = RULE_PRESETS[ruleset].footHealth;
  actor.invulnerableTicks = ARCADE.respawnProtectionTicks;
  actor.weapon = {
    id: "sidearm",
    ammo: 0,
    cooldownTicks: 0,
    shotOrdinal: current.weapon.shotOrdinal,
    lastActionInstanceId: current.weapon.lastActionInstanceId
  };
  actor.grenadeStock = ARCADE.initialGrenades;
  actor.grenadeCooldownTicks = actor.meleeCooldownTicks = actor.reboardCooldownTicks = actor.vehicleSpecialTicks = 0;
  clearAction(actor, tick2);
  return actor;
}
function stepPlayerLife(current, tick2, ruleset, context) {
  validatePlayerLife(current, tick2, ruleset);
  check(context.frame.tick === tick2, "entry collision tick mismatch");
  context.index.assertFrame(context.frame);
  check(
    current.geometryRevision === context.frame.geometryRevision,
    "life geometry revision mismatch"
  );
  const actor = structuredClone(current);
  actor.invulnerableTicks = Math.max(0, actor.invulnerableTicks - 1);
  actor.reboardCooldownTicks = Math.max(0, actor.reboardCooldownTicks - 1);
  if (actor.life === "death" && tick2 - actor.lifeStartTick >= ARCADE.deathTicks) {
    if (actor.lives === 0) {
      removeBody(actor);
      actor.life = "spectating";
      actor.lifeStartTick = tick2;
      return { actor, notice: notice(actor, tick2, "spectate") };
    }
    const entered = enterPlayer(actor, tick2, ruleset, context);
    if (entered) return { actor: entered, notice: notice(entered, tick2, "respawn") };
  }
  if (actor.life === "respawning") {
    if (actor.bodyPresence === "removed") {
      const entered = enterPlayer(actor, tick2, ruleset, context);
      return entered ? { actor: entered, notice: notice(entered, tick2, "respawn") } : { actor, notice: null };
    }
    if (tick2 - actor.lifeStartTick >= ARCADE.respawnEntryTicks) {
      actor.life = "alive";
      actor.lifeStartTick = tick2;
      return { actor, notice: notice(actor, tick2, "ready") };
    }
    if (!stepPassiveBody(actor, context)) actor.invulnerableTicks = 0;
    return { actor, notice: null };
  }
  if (actor.life === "death") stepPassiveBody(actor, context);
  return { actor, notice: null };
}

// src/game/combat/volume.ts
var END2 = { numerator: 1, denominator: 1 };
function validateQuery(source, terrain, hurtboxes) {
  for (const id2 of [source.id, source.ownerId, source.actionInstanceId, source.definitionId])
    integer(id2, 1, COUNTER_LIMIT - 1, "attack identity");
  integer(source.team, 0, 255, "attack team");
  integer(terrain.length + hurtboxes.length, 0, 4096, "volume candidates");
  const ids2 = /* @__PURE__ */ new Set();
  for (const target of terrain) validateSweepTarget(target);
  for (const target of hurtboxes) {
    integer(target.entityId, 1, COUNTER_LIMIT - 1, "hurt entity");
    integer(target.team, 0, 255, "hurt team");
    if (target.kind !== "body" && target.kind !== "shield") throw new Error("Invalid hurt kind");
    sweepBounds(target.rect, target.delta);
    integer(target.rect.w, 1, 2 ** 24, "hurt width");
    integer(target.rect.h, 1, 2 ** 24, "hurt height");
  }
  for (const target of [...terrain, ...hurtboxes]) {
    surfaceMaterialFor(target);
    integer(target.id, 1, COUNTER_LIMIT - 1, "volume collision ID");
    if (ids2.has(target.id)) throw new Error("Duplicate volume collision ID");
    ids2.add(target.id);
  }
}
var at = (origin, delta, time2) => ({
  x: origin.x + divide(delta.x * time2.numerator, time2.denominator).quotient,
  y: origin.y + divide(delta.y * time2.numerator, time2.denominator).quotient
});
function nearest(origin, rect) {
  return {
    x: Math.max(rect.x, Math.min(origin.x, rect.x + rect.w)),
    y: Math.max(rect.y, Math.min(origin.y, rect.y + rect.h))
  };
}
function targets(source, hurtboxes) {
  return hurtboxes.filter(
    (target) => (target.solid || target.team !== source.team) && target.entityId !== source.ownerId
  );
}
function occluder(from, to, time2, terrain, shields, material) {
  const candidates = [
    ...terrain.filter((target) => target.kind === "solid" && materialBlocks(target, material)).map((target) => ({ ...target, entityId: null, kind: "terrain", priority: 0 })),
    ...shields.filter((target) => materialBlocks(target, material)).map((target) => ({ ...target, priority: target.solid ? 0 : 1 }))
  ];
  let first = null;
  for (const target of candidates) {
    const point2 = at(target.rect, target.delta, time2);
    const hit = sweepAabb(
      { ...from, w: 0, h: 0 },
      { x: to.x - from.x, y: to.y - from.y },
      { ...target.rect, ...point2 }
    );
    if (!hit) continue;
    const hitTime = hit.kind === "overlap" ? { numerator: 0, denominator: 1 } : hit.time;
    const order = first ? compareContactTime(
      hitTime.numerator,
      hitTime.denominator,
      first.time.numerator,
      first.time.denominator
    ) : -1;
    if (order < 0 || order === 0 && first && (target.priority < first.target.priority || target.priority === first.target.priority && target.id < first.target.id))
      first = { target, time: hitTime };
  }
  return first;
}
function impact(source, target, time2, point2, damage) {
  return {
    sourceId: source.id,
    definitionId: source.definitionId,
    ownerId: source.ownerId,
    actionInstanceId: source.actionInstanceId,
    colliderId: target.id,
    entityId: target.entityId,
    kind: target.kind,
    damage,
    time: time2,
    position: point2
  };
}
function solidFaceContact(volume, delta, target) {
  if (!target.solid) return null;
  for (const time2 of [{ numerator: 0, denominator: 1 }, END2]) {
    const a = { ...volume, ...at(volume, delta, time2) };
    const b = { ...target.rect, ...at(target.rect, target.delta, time2) };
    const overlapX = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
    const overlapY = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
    if (overlapX === 0 && overlapY > 0 || overlapY === 0 && overlapX > 0) return time2;
  }
  return null;
}
function ordered(hits, maximum, excluded, primaryTarget = null) {
  const seen = new Set(excluded);
  return hits.sort(
    (a, b) => compareContactTime(
      a.time.numerator,
      a.time.denominator,
      b.time.numerator,
      b.time.denominator
    ) || (primaryTarget === null ? 0 : Number(b.entityId === primaryTarget) - Number(a.entityId === primaryTarget)) || a.colliderId - b.colliderId
  ).filter((hit) => {
    if (hit.entityId === null || seen.has(hit.entityId) || seen.size >= maximum) return false;
    seen.add(hit.entityId);
    return true;
  });
}
function meleeHits(source, definition2, shape, hand, delta, facing2, occlusionOrigin, terrain, hurtboxes, hitIds = []) {
  if (definition2.kind !== "melee" || definition2.material !== "blade" && definition2.material !== "blunt" || definition2.id !== source.definitionId || definition2.shapeId !== shape.id)
    throw new Error("Invalid melee policy");
  return rectangularHits(
    source,
    definition2,
    worldRect(hand, shape.rect, facing2),
    delta,
    occlusionOrigin,
    terrain,
    hurtboxes,
    hitIds
  );
}
function rectangularHits(source, definition2, volume, delta, occlusionOrigin, terrain, hurtboxes, hitIds = []) {
  if (definition2.id !== source.definitionId || !["melee", "shot-volume", "flame-volumes"].includes(definition2.kind))
    throw new Error("Invalid rectangular attack policy");
  validateQuery(source, terrain, hurtboxes);
  integer(hitIds.length, 0, definition2.maxTargets, "melee hit budget");
  for (const id2 of hitIds) integer(id2, 1, COUNTER_LIMIT - 1, "melee hit identity");
  if (new Set(hitIds).size !== hitIds.length) throw new Error("Duplicate melee hit identity");
  sweepBounds(volume, delta);
  sweepBounds({ ...occlusionOrigin, w: 0, h: 0 }, delta);
  const enemies = targets(source, hurtboxes), shields = enemies.filter((target) => target.kind === "shield" || target.solid), hits = [];
  for (const target of enemies.filter(
    (target2) => target2.kind === "body" || definition2.kind !== "melee"
  )) {
    const hit = sweepAabb(volume, delta, target.rect, target.delta);
    const time2 = hit ? hit.kind === "overlap" ? { numerator: 0, denominator: 1 } : hit.time : solidFaceContact(volume, delta, target);
    if (!time2) continue;
    const origin = at(occlusionOrigin, delta, time2);
    const exposed = { ...target.rect, ...at(target.rect, target.delta, time2) };
    const currentVolume = { ...volume, ...at(volume, delta, time2) };
    const x = Math.max(exposed.x, currentVolume.x), y = Math.max(exposed.y, currentVolume.y);
    const point2 = nearest(origin, {
      x,
      y,
      w: Math.max(0, Math.min(exposed.x + exposed.w, currentVolume.x + currentVolume.w) - x),
      h: Math.max(0, Math.min(exposed.y + exposed.h, currentVolume.y + currentVolume.h) - y)
    });
    const blocked = occluder(origin, point2, time2, terrain, shields, definition2.material);
    if (blocked?.target.kind === "terrain") continue;
    if (blocked && definition2.kind !== "melee") {
      const shield = {
        ...blocked.target.rect,
        ...at(blocked.target.rect, blocked.target.delta, time2)
      };
      if (shield.x > currentVolume.x + currentVolume.w || shield.x + shield.w < currentVolume.x || shield.y > currentVolume.y + currentVolume.h || shield.y + shield.h < currentVolume.y)
        continue;
    }
    hits.push(
      blocked ? impact(
        source,
        blocked.target,
        time2,
        at(origin, { x: point2.x - origin.x, y: point2.y - origin.y }, blocked.time),
        blocked.target.kind === "body" ? definition2.damage : 0
      ) : impact(source, target, time2, point2, target.kind === "shield" ? 0 : definition2.damage)
    );
  }
  return ordered(hits, definition2.maxTargets, hitIds);
}
function explosionHits(source, definition2, center, radius, terrain, hurtboxes, options = {}) {
  const { time: time2 = END2, primaryTarget = null } = options;
  if (definition2.id !== source.definitionId || definition2.kind !== "explosion" || definition2.material !== "explosive")
    throw new Error("Invalid explosion policy");
  integer(radius, 1, 2 ** 16, "blast radius");
  integer(time2.denominator, 1, 2 ** 17, "blast contact denominator");
  integer(time2.numerator, 0, time2.denominator, "blast contact numerator");
  if (primaryTarget !== null) integer(primaryTarget, 1, COUNTER_LIMIT - 1, "blast primary target");
  position(center.x);
  position(center.y);
  validateQuery(source, terrain, hurtboxes);
  const enemies = targets(source, hurtboxes), shields = enemies.filter((target) => target.kind === "shield" || target.solid), hits = [];
  for (const target of enemies.filter((target2) => target2.kind === "body")) {
    const point2 = nearest(center, {
      ...target.rect,
      ...at(target.rect, target.delta, time2)
    });
    const dx = point2.x - center.x, dy = point2.y - center.y;
    if (dx * dx + dy * dy > radius * radius) continue;
    const blocked = occluder(center, point2, time2, terrain, shields, definition2.material);
    if (blocked?.target.kind === "terrain") continue;
    hits.push(
      blocked ? impact(
        source,
        blocked.target,
        time2,
        at(center, { x: point2.x - center.x, y: point2.y - center.y }, blocked.time),
        blocked.target.kind === "body" ? definition2.damage : 0
      ) : impact(source, target, time2, point2, definition2.damage)
    );
  }
  return ordered(hits, definition2.maxTargets, [], primaryTarget);
}

// src/game/combat/area-attack.ts
var zero = { x: 0, y: 0 };
function areaEndTick(attack2, profile) {
  return attack2.startTick + (profile.emissionOffsets.at(-1) ?? 0) + profile.frames.length;
}
function cardinalRect(origin, rect, heading) {
  if (heading === 0) return { ...rect, x: origin.x + rect.x, y: origin.y + rect.y };
  if (heading === 3) return { ...rect, x: origin.x - rect.x - rect.w, y: origin.y + rect.y };
  if (heading === 1)
    return { x: origin.x + rect.y, y: origin.y - rect.x - rect.w, w: rect.h, h: rect.w };
  return { x: origin.x + rect.y, y: origin.y + rect.x, w: rect.h, h: rect.w };
}
function forward(rect, origin, heading) {
  if (heading === 0) return { ...rect, x: rect.x - origin.x, y: rect.y - origin.y };
  if (heading === 3) return { ...rect, x: origin.x - rect.x - rect.w, y: rect.y - origin.y };
  if (heading === 1)
    return { x: origin.y - rect.y - rect.h, y: rect.x - origin.x, w: rect.h, h: rect.w };
  return { x: rect.y - origin.y, y: rect.x - origin.x, w: rect.h, h: rect.w };
}
function clippedGeometry(geometry, lobe, terrain, material) {
  let reach = lobe.reach;
  let top = geometry.y, bottom = geometry.y + geometry.h;
  for (const wall of terrain) {
    if (wall.kind !== "solid" || !materialBlocks(wall, material)) continue;
    const rect = forward(
      { ...wall.rect, x: wall.rect.x + wall.delta.x, y: wall.rect.y + wall.delta.y },
      lobe.origin,
      lobe.heading
    );
    if (rect.y < geometry.y + geometry.h && rect.y + rect.h > geometry.y && rect.x + rect.w > 0 && rect.x <= geometry.x + geometry.w) {
      if (rect.y <= 0 && rect.y + rect.h >= 0) reach = Math.min(reach, Math.max(0, rect.x));
      else if (rect.y > 0) bottom = Math.min(bottom, rect.y);
      else top = Math.max(top, rect.y + rect.h);
    }
  }
  const width = Math.min(geometry.w, reach - geometry.x);
  return {
    reach,
    rect: width > 0 && bottom > top ? { ...geometry, y: top, h: bottom - top, w: width } : null
  };
}
function geometryAt(attack2, lobe, tick2, profile) {
  const spawnTick = attack2.startTick + (profile.emissionOffsets[lobe.index] ?? -COUNTER_LIMIT);
  const geometry = profile.frames[tick2 - spawnTick];
  if (!geometry) return null;
  const width = Math.min(geometry.w, lobe.reach - geometry.x);
  return width > 0 ? { spawnTick, geometry: { ...geometry, w: width } } : null;
}
function areaExposures(attack2, tick2, profile, terrain) {
  return attack2.lobes.flatMap((lobe) => {
    const frame = geometryAt(attack2, lobe, tick2, profile);
    const geometry = frame && clippedGeometry(
      frame.geometry,
      lobe,
      terrain,
      profile.kind === "shot-volume" ? "bullet" : "heat"
    ).rect;
    return frame && geometry ? [
      {
        id: attack2.id,
        ownerId: attack2.ownerId,
        actionInstanceId: attack2.actionInstanceId,
        definitionId: attack2.definitionId,
        lobe: lobe.index,
        spawnTick: frame.spawnTick,
        endTick: frame.spawnTick + profile.frames.length,
        heading: lobe.heading,
        attached: tick2 - frame.spawnTick < profile.attachedTicks,
        rect: cardinalRect(lobe.origin, geometry, lobe.heading)
      }
    ] : [];
  });
}
function emitArea(attack2, tick2, profile, anchor, blocked) {
  const index = profile.emissionOffsets.indexOf(tick2 - attack2.startTick);
  if (index < 0 || index !== attack2.emitted || attack2.cancelledTick !== null)
    throw new Error("Area emission cursor mismatch");
  attack2.emitted++;
  if (!blocked)
    attack2.lobes.push({
      index,
      origin: { ...anchor.origin },
      heading: anchor.heading,
      reach: profile.maximumReach
    });
}
function cancelArea(attack2, tick2, profile) {
  if (profile.kind !== "flame-volumes") return;
  attack2.cancelledTick ??= tick2;
  attack2.lobes = attack2.lobes.filter(
    (lobe) => tick2 - attack2.startTick - (profile.emissionOffsets[lobe.index] ?? 0) >= profile.attachedTicks
  );
}
function stepArea(current, tick2, definition2, profile, anchor, terrain, hurtboxes) {
  const attack2 = structuredClone(current), impacts = [], candidatesForAction = [];
  if (definition2.kind !== profile.kind || definition2.id !== attack2.definitionId)
    throw new Error("Area definition mismatch");
  if (tick2 >= areaEndTick(attack2, profile)) return { attack: null, impacts };
  if (!anchor) cancelArea(attack2, tick2, profile);
  attack2.lobes = attack2.lobes.filter(
    (lobe) => tick2 - attack2.startTick - (profile.emissionOffsets[lobe.index] ?? 0) < profile.frames.length
  );
  for (const lobe of attack2.lobes) {
    const born = attack2.startTick + (profile.emissionOffsets[lobe.index] ?? 0), age = tick2 - born;
    const frame = profile.frames[age];
    if (!frame) throw new Error("Unknown area exposure");
    const previous = structuredClone(lobe);
    if (age < profile.attachedTicks && anchor) {
      lobe.origin = { ...anchor.origin };
      lobe.heading = anchor.heading;
    }
    const endpoint = age === 0 || previous.heading !== lobe.heading;
    const delta = endpoint ? zero : { x: lobe.origin.x - previous.origin.x, y: lobe.origin.y - previous.origin.y };
    const origin = endpoint ? lobe.origin : previous.origin;
    const clipped = clippedGeometry(
      frame,
      lobe,
      [
        ...terrain,
        ...hurtboxes.filter((target) => target.solid).map((target) => ({ ...target, kind: "solid" }))
      ],
      definition2.material
    );
    lobe.reach = clipped.reach;
    if (!clipped.rect) continue;
    const excluded = attack2.hits.filter((hit) => definition2.repeatDamageTicks === 0 || tick2 < hit.nextTick).map((hit) => hit.entityId);
    const remaining = definition2.maxTargets - attack2.hits.length;
    const candidates = hurtboxes.filter(
      (hurt) => remaining > 0 || attack2.hits.some((hit) => hit.entityId === hurt.entityId)
    );
    const collisionTerrain = endpoint ? terrain.map((wall) => ({
      ...wall,
      rect: { ...wall.rect, x: wall.rect.x + wall.delta.x, y: wall.rect.y + wall.delta.y },
      delta: zero
    })) : terrain;
    const hits = rectangularHits(
      attack2,
      definition2,
      cardinalRect(origin, clipped.rect, lobe.heading),
      delta,
      origin,
      collisionTerrain,
      endpoint ? candidates.map((hurt) => ({
        ...hurt,
        rect: { ...hurt.rect, x: hurt.rect.x + hurt.delta.x, y: hurt.rect.y + hurt.delta.y },
        delta: zero
      })) : candidates,
      excluded
    );
    candidatesForAction.push(...hits);
  }
  const granted = /* @__PURE__ */ new Set();
  candidatesForAction.sort(
    (a, b) => compareContactTime(
      a.time.numerator,
      a.time.denominator,
      b.time.numerator,
      b.time.denominator
    ) || a.colliderId - b.colliderId
  );
  for (const hit of candidatesForAction) {
    if (hit.entityId === null) continue;
    if (granted.has(hit.entityId)) continue;
    let receipt = attack2.hits.find((receipt2) => receipt2.entityId === hit.entityId);
    if (!receipt) {
      if (attack2.hits.length >= definition2.maxTargets) continue;
      receipt = { entityId: hit.entityId, nextTick: 0 };
      attack2.hits.push(receipt);
    }
    receipt.nextTick = definition2.repeatDamageTicks === 0 ? areaEndTick(attack2, profile) : tick2 + definition2.repeatDamageTicks;
    granted.add(hit.entityId);
    impacts.push(hit);
  }
  attack2.hits.sort((a, b) => a.entityId - b.entityId);
  return { attack: attack2, impacts };
}
function validateAreaProfile(profile, definition2) {
  if (definition2.kind !== profile.kind || !["shot-volume", "flame-volumes"].includes(profile.kind))
    throw new Error("Unknown area profile");
  if (definition2.material !== (profile.kind === "shot-volume" ? "bullet" : "heat"))
    throw new Error("Area profile material mismatch");
  integer(profile.frames.length, 1, 120, "area frames");
  integer(profile.emissionOffsets.length, 1, 4, "area emissions");
  integer(profile.attachedTicks, 0, profile.frames.length, "area attachment");
  integer(profile.maximumReach, 1, MAX_SHAPE, "area reach");
  for (const [index, offset] of profile.emissionOffsets.entries()) {
    integer(
      offset,
      index === 0 ? 0 : (profile.emissionOffsets[index - 1] ?? 0) + 1,
      120,
      "area emission offset"
    );
    if (index === 0 && offset !== 0) throw new Error("Area must begin at its first emission");
  }
  for (const frame of profile.frames) {
    validateLocalRect(frame);
    if (frame.x < 0 || frame.x + frame.w > profile.maximumReach)
      throw new Error("Area frame exceeds reach");
  }
  if (definition2.lifetimeTicks !== (profile.emissionOffsets.at(-1) ?? 0) + profile.frames.length || profile.kind === "shot-volume" && (definition2.repeatDamageTicks !== 0 || profile.attachedTicks !== 0 || profile.emissionOffsets.length !== 1) || profile.kind === "flame-volumes" && definition2.repeatDamageTicks < 1)
    throw new Error("Area lifetime/damage policy mismatch");
}
function validateArea(attack2, tick2, definition2, profile, targetIds) {
  integer(attack2.startTick, 1, tick2, "area start tick");
  if (tick2 >= areaEndTick(attack2, profile)) throw new Error("Expired area attack");
  const through = attack2.cancelledTick ?? tick2;
  if (attack2.cancelledTick !== null)
    integer(attack2.cancelledTick, attack2.startTick, tick2, "area cancellation tick");
  const expected = profile.emissionOffsets.filter(
    (offset) => attack2.startTick + offset <= through
  ).length;
  const minimum = attack2.cancelledTick === null ? expected : profile.emissionOffsets.filter((offset) => attack2.startTick + offset < through).length;
  integer(attack2.emitted, Math.max(1, minimum), expected, "area emission history");
  integer(attack2.lobes.length, 0, attack2.emitted, "area lobe budget");
  for (const [i, lobe] of attack2.lobes.entries()) {
    integer(
      lobe.index,
      i === 0 ? 0 : (attack2.lobes[i - 1]?.index ?? 0) + 1,
      attack2.emitted - 1,
      "area lobe order"
    );
    integer(lobe.heading, 0, 3, "area heading");
    integer(lobe.reach, 0, profile.maximumReach, "area retained reach");
    position(lobe.origin.x);
    position(lobe.origin.y);
    const age = tick2 - attack2.startTick - (profile.emissionOffsets[lobe.index] ?? 0);
    integer(age, 0, profile.frames.length - 1, "area lobe age");
    if (attack2.cancelledTick !== null && attack2.cancelledTick - attack2.startTick - (profile.emissionOffsets[lobe.index] ?? 0) < profile.attachedTicks)
      throw new Error("Cancelled attached flame");
  }
  integer(attack2.hits.length, 0, definition2.maxTargets, "area target budget");
  for (const [index, hit] of attack2.hits.entries()) {
    if (!targetIds.includes(hit.entityId) || index > 0 && hit.entityId <= (attack2.hits[index - 1]?.entityId ?? 0))
      throw new Error("Invalid area hit history");
    integer(
      hit.nextTick,
      attack2.startTick + 1,
      areaEndTick(attack2, profile) + definition2.repeatDamageTicks,
      "area next damage tick"
    );
    if (definition2.repeatDamageTicks === 0 && hit.nextTick !== areaEndTick(attack2, profile))
      throw new Error("Shotgun hit history expires early");
    if (definition2.repeatDamageTicks > 0 && hit.nextTick > tick2 + definition2.repeatDamageTicks)
      throw new Error("Area damage cooldown precedes its hit");
  }
}

// src/game/combat/beam.ts
function beamExposures(beam, profile) {
  return beamSegments(beam.origin, beam.heading, beam.length, profile.width).map((rect, lobe) => ({
    id: beam.id,
    ownerId: beam.ownerId,
    actionInstanceId: beam.actionInstanceId,
    definitionId: beam.definitionId,
    lobe,
    spawnTick: beam.spawnTick,
    endTick: beam.spawnTick + profile.pulseTicks,
    heading: beam.heading,
    attached: true,
    rect
  }));
}
function validateBeamProfile(profile) {
  integer(profile.range, 1, MAX_SHAPE * 4, "beam range");
  integer(profile.width, 1, 4096, "beam width");
  integer(profile.pulseTicks, 1, 120, "beam pulse interval");
}
function validateBeamPolicy(source, definition2, profile) {
  validateBeamProfile(profile);
  for (const id2 of [source.id, source.ownerId, source.actionInstanceId, source.definitionId])
    integer(id2, 1, COUNTER_LIMIT - 1, "beam identity");
  integer(source.team, 1, 255, "beam team");
  if (source.definitionId !== definition2.id || definition2.kind !== "beam" || definition2.material !== "energy" || definition2.speed !== 0 || definition2.lifetimeTicks !== profile.pulseTicks || definition2.repeatDamageTicks !== profile.pulseTicks)
    throw new Error("Invalid beam attack policy");
  integer(definition2.damage, 1, 65535, "beam damage");
  integer(definition2.maxTargets, 1, 64, "beam penetration budget");
}
function forward2(rect, origin, heading) {
  if (heading === 0) return { ...rect, x: rect.x - origin.x, y: rect.y - origin.y };
  if (heading === 3) return { ...rect, x: origin.x - rect.x - rect.w, y: rect.y - origin.y };
  if (heading === 1)
    return { x: origin.y - rect.y - rect.h, y: rect.x - origin.x, w: rect.h, h: rect.w };
  return { x: rect.y - origin.y, y: rect.x - origin.x, w: rect.h, h: rect.w };
}
function beamSegments(origin, heading, length2, width) {
  integer(heading, 0, 3, "beam heading");
  integer(length2, 0, MAX_SHAPE * 4, "beam length");
  integer(width, 1, 4096, "beam width");
  const result = [], y = -divide(width, 2).quotient;
  sweepBounds(cardinalRect(origin, { x: 0, y, w: length2, h: width }, heading));
  for (let x = 0; x < length2; x += MAX_SHAPE)
    result.push(
      cardinalRect(origin, { x, y, w: Math.min(MAX_SHAPE, length2 - x), h: width }, heading)
    );
  return result;
}
function castBeam(source, definition2, profile, origin, heading, terrain, hurtboxes) {
  validateBeamPolicy(source, definition2, profile);
  beamSegments(origin, heading, profile.range, profile.width);
  integer(terrain.length + hurtboxes.length, 0, 4096, "beam candidate budget");
  const ids2 = /* @__PURE__ */ new Set();
  for (const wall of terrain) validateSweepTarget(wall);
  for (const hurt of hurtboxes) {
    integer(hurt.entityId, 1, COUNTER_LIMIT - 1, "beam target identity");
    integer(hurt.team, 0, 255, "beam target team");
    if (hurt.kind !== "body" && hurt.kind !== "shield" || hurt.solid !== void 0 && typeof hurt.solid !== "boolean")
      throw new Error("Invalid beam target material");
    integer(hurt.rect.w, 1, 2 ** 24, "beam target width");
    integer(hurt.rect.h, 1, 2 ** 24, "beam target height");
    sweepBounds(hurt.rect, hurt.delta);
  }
  for (const candidate of [...terrain, ...hurtboxes]) {
    surfaceMaterialFor(candidate);
    integer(candidate.id, 1, COUNTER_LIMIT - 1, "beam collider identity");
    if (ids2.has(candidate.id)) throw new Error("Duplicate beam collider identity");
    ids2.add(candidate.id);
  }
  const top = -divide(profile.width, 2).quotient, bottom = top + profile.width;
  const candidates = [
    ...terrain.filter((target) => materialBlocks(target, definition2.material)).map((target) => ({
      ...target,
      kind: "terrain",
      entityId: null,
      solid: true,
      priority: 0
    })),
    ...hurtboxes.filter(
      (target) => target.entityId !== source.ownerId && (target.solid || target.team !== source.team)
    ).map((target) => ({
      ...target,
      priority: target.kind === "shield" ? 1 : target.solid ? 2 : 3
    }))
  ].flatMap((target) => {
    const rect = forward2(
      { ...target.rect, x: target.rect.x + target.delta.x, y: target.rect.y + target.delta.y },
      origin,
      heading
    );
    if (rect.y >= bottom || rect.y + rect.h <= top || rect.x + rect.w <= 0 || rect.x > profile.range)
      return [];
    return [{ target, rect, distance: Math.max(0, rect.x) }];
  }).sort(
    (a, b) => a.distance - b.distance || a.target.priority - b.target.priority || a.target.id - b.target.id
  );
  const seen = /* @__PURE__ */ new Set(), impacts = [];
  let length2 = profile.range, stoppedBy = null;
  for (const { target, rect, distance } of candidates) {
    const blocking = (target.kind === "terrain" || target.kind === "shield" || target.solid) && materialBlocks(target, definition2.material);
    if (blocking) {
      length2 = distance;
      stoppedBy = target.kind === "terrain" ? "terrain" : target.kind === "shield" ? "shield" : "solid";
    }
    if (target.entityId === null || !seen.has(target.entityId)) {
      const point2 = cardinalRect(
        origin,
        { x: distance, y: Math.max(rect.y, Math.min(0, rect.y + rect.h)), w: 0, h: 0 },
        heading
      );
      impacts.push({
        sourceId: source.id,
        definitionId: definition2.id,
        ownerId: source.ownerId,
        actionInstanceId: source.actionInstanceId,
        colliderId: target.id,
        entityId: target.entityId,
        kind: target.kind,
        damage: target.kind === "body" ? definition2.damage : 0,
        time: { numerator: 1, denominator: 1 },
        position: { x: position(point2.x), y: position(point2.y) }
      });
      if (target.entityId !== null) seen.add(target.entityId);
    }
    if (blocking) break;
    if (seen.size === definition2.maxTargets) {
      length2 = distance;
      stoppedBy = "penetration";
      break;
    }
  }
  return {
    origin: { ...origin },
    heading,
    length: length2,
    width: profile.width,
    segments: beamSegments(origin, heading, length2, profile.width),
    impacts,
    stoppedBy
  };
}
function validateBeamPulse(beam, definition2, profile) {
  validateBeamPolicy(beam, definition2, profile);
  integer(beam.spawnTick, 1, COUNTER_LIMIT - 1 - profile.pulseTicks, "beam birth tick");
  integer(beam.tick, beam.spawnTick, beam.spawnTick + profile.pulseTicks - 1, "beam tick");
  integer(beam.length, 0, profile.range, "beam clipped length");
  beamSegments(beam.origin, beam.heading, profile.range, profile.width);
}
function emitBeam(source, tick2, definition2, profile, anchor, terrain, hurtboxes) {
  const beam = {
    ...source,
    spawnTick: tick2,
    tick: tick2,
    origin: { ...anchor.origin },
    heading: anchor.heading,
    length: profile.range
  };
  validateBeamPulse(beam, definition2, profile);
  const cast = castBeam(
    source,
    definition2,
    profile,
    anchor.origin,
    anchor.heading,
    terrain,
    hurtboxes
  );
  beam.length = cast.length;
  return { beam, cast };
}
function stepBeam(current, tick2, definition2, profile, anchor, terrain, hurtboxes) {
  validateBeamPulse(current, definition2, profile);
  if (tick2 !== current.tick + 1) throw new Error("Beam requires consecutive ticks");
  if (anchor === null || tick2 === current.spawnTick + profile.pulseTicks)
    return { beam: null, cast: null };
  const cast = castBeam(
    current,
    definition2,
    profile,
    anchor.origin,
    anchor.heading,
    terrain,
    hurtboxes
  );
  return {
    beam: {
      ...current,
      tick: tick2,
      origin: { ...anchor.origin },
      heading: anchor.heading,
      length: cast.length
    },
    // Moving across a target or restoring this state cannot grant another damage pulse.
    cast: { ...cast, impacts: [] }
  };
}

// src/game/combat/destructible.ts
function createDestructible(definition2) {
  surfaceMaterial(definition2.materialId);
  return {
    id: definition2.id,
    definitionId: definition2.definitionId,
    health: definition2.health,
    destroyedTick: null,
    destroyerId: null,
    destroyActionId: null
  };
}
function destructibleHurtboxes(props, definitions2) {
  return props.filter((prop) => prop.health > 0).map((prop) => {
    const definition2 = definitions2.find((definition3) => definition3.id === prop.id);
    if (!definition2 || definition2.definitionId !== prop.definitionId)
      throw new Error("Missing destructible geometry");
    return {
      id: prop.id,
      entityId: prop.id,
      team: 0,
      kind: "body",
      solid: true,
      materialId: definition2.materialId,
      rect: { ...definition2.rect },
      delta: { x: 0, y: 0 }
    };
  });
}
function damageDestructible(prop, definition2, impact2, attack2, tick2) {
  if (definition2.id !== prop.id || definition2.definitionId !== prop.definitionId)
    throw new Error("Destructible material identity mismatch");
  surfaceMaterial(definition2.materialId);
  if (prop.health === 0 || impact2.damage === 0) return false;
  if (impact2.entityId !== prop.id || impact2.kind !== "body" || impact2.definitionId !== attack2.id)
    throw new Error("Destructible damage identity mismatch");
  integer(impact2.damage, 1, attack2.damage, "destructible damage");
  prop.health = Math.max(
    0,
    prop.health - materialDamage(impact2.damage, attack2.material, definition2.materialId)
  );
  if (prop.health > 0) return false;
  prop.destroyedTick = tick2;
  prop.destroyerId = impact2.ownerId;
  prop.destroyActionId = impact2.actionInstanceId;
  return true;
}
function detachDestroyedSupport(body2, removed) {
  const detached = body2.supportId !== null && removed.has(body2.supportId);
  if (detached) {
    body2.supportId = null;
    body2.grounded = false;
  }
  body2.contacts = body2.contacts.filter((contact) => !removed.has(contact.otherId));
  return detached;
}
function validateDestructibles(props, definitions2, tick2, ownerIds, nextActionId) {
  if (props.length !== definitions2.length || props.length > 32)
    throw new Error("Destructible roster mismatch");
  for (const [index, prop] of props.entries()) {
    const definition2 = definitions2[index];
    if (!definition2 || prop.id !== definition2.id || prop.definitionId !== definition2.definitionId)
      throw new Error("Destructible definition mismatch");
    surfaceMaterial(definition2.materialId);
    integer(prop.health, 0, definition2.health, "destructible health");
    if (prop.health > 0) {
      if (prop.destroyedTick !== null || prop.destroyerId !== null || prop.destroyActionId !== null)
        throw new Error("Live prop has destruction attribution");
    } else {
      integer(prop.destroyedTick, 1, tick2, "destruction tick");
      integer(prop.destroyActionId, 1, nextActionId - 1, "destruction action");
      integer(prop.destroyerId, 1, COUNTER_LIMIT - 1, "destruction owner");
      if (!ownerIds.includes(prop.destroyerId))
        throw new Error("Unknown destruction owner");
    }
  }
}

// src/game/core/canonical.ts
function canonical(value) {
  const ancestors = /* @__PURE__ */ new Set();
  let nodes = 0;
  function encode(item, depth) {
    if (++nodes > 1e5 || depth > 64) throw new RangeError("Canonical state exceeds bounds");
    if (item === null || typeof item === "boolean" || typeof item === "string")
      return JSON.stringify(item);
    if (typeof item === "number" && Number.isSafeInteger(item))
      return String(item === 0 ? 0 : item);
    if (typeof item !== "object" || item === null)
      throw new TypeError("Noncanonical authoritative value");
    if (ancestors.has(item)) throw new TypeError("Cyclic authoritative state");
    ancestors.add(item);
    let result;
    if (Array.isArray(item)) {
      const parts = [];
      for (let index = 0; index < item.length; index++) {
        if (!Object.hasOwn(item, index)) throw new TypeError("Sparse authoritative array");
        parts.push(encode(item[index], depth + 1));
      }
      result = `[${parts.join(",")}]`;
    } else {
      if (Object.getPrototypeOf(item) !== Object.prototype && Object.getPrototypeOf(item) !== null) {
        throw new TypeError("Authoritative records must be plain objects");
      }
      if (Object.getOwnPropertySymbols(item).length)
        throw new TypeError("Symbol state keys are unsupported");
      const record = item;
      result = `{${Object.keys(record).sort().map((key2) => `${JSON.stringify(key2)}:${encode(record[key2], depth + 1)}`).join(",")}}`;
    }
    ancestors.delete(item);
    return result;
  }
  return encode(value, 0);
}
function stateHash(value) {
  const text = canonical(value);
  let hash = 2166136261;
  for (let index = 0; index < text.length; index++)
    hash = Math.imul(hash ^ text.charCodeAt(index), 16777619);
  return (hash >>> 0).toString(16).padStart(8, "0");
}

// src/game/combat/firearm-aim.ts
function validateFirearmSweep(profile, catalog) {
  const sweep = profile.sweep;
  if (!sweep) return;
  integer(sweep.stepTicks, 1, 60, "firearm heading exposure");
  const reference = catalog.timelines.get(profile.timelineIds[0]);
  if (!reference || sweep.headings.length !== 9) throw new Error("Incomplete firearm sweep");
  for (const [index, heading] of sweep.headings.entries()) {
    if (heading.pitch !== index - 4)
      throw new Error("Firearm headings must cover -4 through 4 in order");
    const timeline = catalog.timelines.get(heading.timelineId);
    if (!timeline || timeline.durationTicks !== reference.durationTicks || canonical(timeline.markers) !== canonical(reference.markers))
      throw new Error("Firearm sweep marker schedules disagree");
    motion(heading.velocity.x);
    motion(heading.velocity.y);
    if (heading.velocity.x < 0 || Math.sign(heading.velocity.y) !== -Math.sign(heading.pitch) || Math.abs(heading.pitch) === 4 !== (heading.velocity.x === 0) || heading.velocity.x === 0 && heading.velocity.y === 0)
      throw new Error("Invalid authored firearm velocity");
    for (const poseId of timeline.poses) {
      const muzzle = catalog.poses.get(poseId)?.sockets.find((socket) => socket.name === "muzzle");
      if (!muzzle || canonical(muzzle.point) !== canonical(heading.muzzle))
        throw new Error("Firearm sweep socket mismatch");
    }
  }
  for (const [pitch, timelineId] of [
    [0, profile.timelineIds[0]],
    [4, profile.timelineIds[1]],
    [-4, profile.timelineIds[2]]
  ])
    if (sweep.headings.find((heading) => heading.pitch === pitch)?.timelineId !== timelineId)
      throw new Error("Firearm cardinal and sweep poses disagree");
}
var cardinalPitch = (actor) => actor.aim === 1 ? 4 : actor.aim === 2 ? -4 : 0;
var lowered = (actor) => actor.life !== "alive" || actor.vehicleId !== null;
var crouched = (actor) => actor.aim === 0 && actor.locomotion === "crouched";
function advanceFirearmAim(actor, tick2, catalog) {
  integer(tick2, 1, COUNTER_LIMIT - 1, "firearm aim tick");
  const profile = catalog.firearms.get(actor.weapon.id);
  if (!profile) throw new Error("Missing firearm aim profile");
  integer(actor.firearmAim.pitch, -4, 4, "firearm pitch");
  integer(
    actor.firearmAim.nextStepTick,
    0,
    tick2 + (profile.sweep?.stepTicks ?? 0),
    "firearm turn tick"
  );
  if (lowered(actor) || crouched(actor)) return { pitch: 0, nextStepTick: 0 };
  const target = cardinalPitch(actor);
  if (!profile.sweep) return { pitch: target, nextStepTick: 0 };
  const aim = { ...actor.firearmAim };
  if (aim.pitch !== target && tick2 >= aim.nextStepTick) {
    aim.pitch += Math.sign(target - aim.pitch);
    aim.nextStepTick = tick2 + profile.sweep.stepTicks;
  }
  return aim;
}
function firearmPoseTimeline(actor, catalog) {
  const profile = catalog.firearms.get(actor.weapon.id);
  if (!profile) throw new Error("Missing firearm profile");
  if (profile.sweep && !crouched(actor)) {
    const heading = profile.sweep.headings.find((value) => value.pitch === actor.firearmAim.pitch);
    if (!heading) throw new Error("Missing authored firearm heading");
    return heading.timelineId;
  }
  return profile.timelineIds[crouched(actor) ? 3 : actor.aim];
}
function firearmVelocity(actor, speed, catalog) {
  const profile = catalog.firearms.get(actor.weapon.id);
  if (!profile) throw new Error("Missing firearm profile");
  if (profile.sweep) {
    const heading = profile.sweep.headings.find((value) => value.pitch === actor.firearmAim.pitch);
    if (!heading) throw new Error("Missing authored firearm velocity");
    return { x: motion(heading.velocity.x * actor.facing), y: heading.velocity.y };
  }
  return {
    x: actor.aim === 0 ? motion(speed * actor.facing) : 0,
    y: actor.aim === 1 ? -speed : actor.aim === 2 ? speed : 0
  };
}
function validateFirearmAim(actor, tick2, catalog) {
  const profile = catalog.firearms.get(actor.weapon.id);
  if (!profile) throw new Error("Missing firearm profile");
  integer(actor.firearmAim.pitch, -4, 4, "firearm pitch");
  integer(
    actor.firearmAim.nextStepTick,
    0,
    tick2 + (profile.sweep?.stepTicks ?? 0),
    "firearm turn tick"
  );
  if (lowered(actor) || crouched(actor)) {
    if (actor.firearmAim.pitch !== 0 || actor.firearmAim.nextStepTick !== 0)
      throw new Error("Lowered firearm must have neutral aim");
  } else if (!profile.sweep && (actor.firearmAim.pitch !== cardinalPitch(actor) || actor.firearmAim.nextStepTick !== 0))
    throw new Error("Cardinal firearm aim mismatch");
  if (actor.action.kind === "fire" && actor.action.definitionId !== firearmPoseTimeline(actor, catalog))
    throw new Error("Firearm pose and heading disagree");
}

// src/game/input/types.ts
var Held = {
  Left: 1 << 0,
  Right: 1 << 1,
  Up: 1 << 2,
  Down: 1 << 3,
  Fire: 1 << 4,
  VehicleSpecial: 1 << 5
};
var HELD_MASK = 63;
var EDGE_KINDS = [1, 2, 3, 4, 5];
var Edge = { Jump: 1, Grenade: 2, Interact: 3, VehicleSpecial: 4, FireOnset: 5 };
function directionalIntent(held, facing2, grounded) {
  const horizontal = Number(Boolean(held & Held.Right)) - Number(Boolean(held & Held.Left));
  const vertical = Number(Boolean(held & Held.Down)) - Number(Boolean(held & Held.Up));
  const nextFacing = horizontal === 0 ? facing2 : horizontal < 0 ? -1 : 1;
  return {
    horizontal,
    vertical,
    facing: nextFacing,
    crouch: grounded && vertical > 0,
    aim: vertical < 0 ? 1 : vertical > 0 && !grounded ? 2 : 0
  };
}

// src/game/combat/firearm.ts
function beginFirearm(current, tick2, nextActionId, catalog) {
  integer(tick2, 1, COUNTER_LIMIT - 1, "firearm tick");
  integer(
    nextActionId,
    current.weapon.lastActionInstanceId + 1,
    COUNTER_LIMIT - 2,
    "firearm allocation"
  );
  if (current.life !== "alive" || current.vehicleId !== null || current.action.kind !== "ready" || current.weapon.cooldownTicks !== 0)
    throw new Error("Firearm action is not ready");
  const actor = structuredClone(current);
  let profile = catalog.firearms.get(actor.weapon.id);
  if (!profile) throw new Error("Missing firearm profile");
  if (actor.weapon.ammo < profile.weapon.ammoPerAction) {
    profile = catalog.firearms.get("sidearm");
    if (profile?.weapon.ammoPerAction !== 0) throw new Error("Missing unlimited sidearm fallback");
    actor.weapon.id = "sidearm";
    actor.weapon.ammo = 0;
    actor.firearmAim = { pitch: actor.aim === 1 ? 4 : actor.aim === 2 ? -4 : 0, nextStepTick: 0 };
  }
  actor.action = {
    kind: "fire",
    actionInstanceId: nextActionId,
    stateStartTick: tick2,
    definitionId: firearmPoseTimeline(actor, catalog),
    nextMarkerIndex: 0
  };
  actor.weapon.ammo -= profile.weapon.ammoPerAction;
  actor.weapon.cooldownTicks = profile.weapon.cadenceTicks;
  actor.weapon.shotOrdinal = nextCounter(actor.weapon.shotOrdinal);
  actor.weapon.lastActionInstanceId = actor.action.actionInstanceId;
  const result = stepAction(actor.action, tick2, catalog);
  actor.action = result.action;
  return { actor, markers: result.markers, nextActionId: nextCounter(nextActionId) };
}
function stepFirearm(current, intent, tick2, nextActionId, catalog) {
  integer(tick2, 1, COUNTER_LIMIT - 1, "firearm tick");
  integer(nextActionId, 1, COUNTER_LIMIT - 2, "next action ID");
  integer(intent.held, 0, HELD_MASK, "firearm held mask");
  if (typeof intent.firePressed !== "boolean") throw new Error("Invalid fire edge");
  if (nextActionId <= current.weapon.lastActionInstanceId)
    throw new Error("Action allocator regressed");
  integer(current.weapon.cooldownTicks, 0, 3600, "weapon cooldown");
  integer(current.weapon.ammo, 0, 65535, "weapon ammunition");
  let actor = structuredClone(current);
  actor.firearmAim = advanceFirearmAim(actor, tick2, catalog);
  actor.weapon.cooldownTicks = Math.max(0, actor.weapon.cooldownTicks - 1);
  let outcome = "none";
  const markers = [];
  const requested = intent.firePressed || Boolean(intent.held & Held.Fire);
  const eligible = actor.life === "alive" && actor.vehicleId === null;
  if (!eligible && actor.action.kind === "fire") actor.action.kind = "ready";
  if (eligible && actor.action.kind === "fire") {
    const nextTimeline = firearmPoseTimeline(actor, catalog);
    if (nextTimeline !== actor.action.definitionId) {
      const prior = catalog.timelines.get(actor.action.definitionId);
      const next = catalog.timelines.get(nextTimeline);
      if (!prior || !next || prior.durationTicks !== next.durationTicks || canonical(prior.markers) !== canonical(next.markers))
        throw new Error("Firearm pose variants disagree on action markers");
      actor.action.definitionId = nextTimeline;
    }
    const result = stepAction(actor.action, tick2, catalog);
    actor.action = result.action;
    markers.push(...result.markers);
    if (result.finished) actor.action.kind = "ready";
  }
  if (requested) {
    if (!eligible || actor.action.kind !== "ready" && actor.action.kind !== "fire")
      outcome = "unavailable";
    else if (actor.weapon.cooldownTicks > 0 || actor.action.kind !== "ready") outcome = "cooldown";
    else {
      const result = beginFirearm(actor, tick2, nextActionId, catalog);
      actor = result.actor;
      nextActionId = result.nextActionId;
      markers.push(...result.markers);
      outcome = "applied";
    }
  }
  return { actor, markers, nextActionId, outcome };
}

// src/game/combat/foot-actions.ts
function stepFootCombatAction(current, intent, tick2, nextActionId, catalog, profiles2, closeTarget) {
  integer(intent.held, 0, HELD_MASK, "foot combat held mask");
  if (typeof intent.firePressed !== "boolean" || typeof intent.grenadePressed !== "boolean" || typeof closeTarget !== "boolean")
    throw new Error("Invalid action arbitration");
  const advanced = stepFirearm(
    current,
    { held: 0, firePressed: false },
    tick2,
    nextActionId,
    catalog
  );
  let actor = advanced.actor;
  const markers = advanced.markers;
  for (const field of ["grenadeCooldownTicks", "meleeCooldownTicks"])
    actor[field] = Math.max(0, integer(actor[field], 0, 3600, field) - 1);
  integer(actor.grenadeStock, 0, 65535, "grenade stock");
  const eligible = actor.life === "alive" && actor.vehicleId === null;
  if (actor.action.kind === "melee" || actor.action.kind === "grenade") {
    if (!eligible) actor.action.kind = "ready";
    else {
      const timeline = profiles2[actor.action.kind].timelineIds[actor.locomotion === "crouched" ? 1 : 0];
      const previous = catalog.timelines.get(actor.action.definitionId), next = catalog.timelines.get(timeline);
      if (!previous || !next || previous.durationTicks !== next.durationTicks || canonical(previous.markers) !== canonical(next.markers))
        throw new Error("Foot action pose markers disagree");
      actor.action.definitionId = timeline;
      const result = stepAction(actor.action, tick2, catalog);
      actor.action = result.action;
      markers.push(...result.markers);
      if (result.finished) actor.action.kind = "ready";
    }
  }
  let fire = "none", grenade = "none";
  const requested = intent.firePressed || Boolean(intent.held & Held.Fire);
  const begin2 = (kind) => {
    const profile = profiles2[kind];
    actor.action = {
      kind,
      actionInstanceId: nextActionId,
      definitionId: profile.timelineIds[actor.locomotion === "crouched" ? 1 : 0],
      stateStartTick: tick2,
      nextMarkerIndex: 0
    };
    nextActionId = nextCounter(nextActionId);
    if (kind === "grenade") {
      actor.grenadeStock--;
      actor.grenadeCooldownTicks = profile.cooldownTicks;
    } else actor.meleeCooldownTicks = profile.cooldownTicks;
    const result = stepAction(actor.action, tick2, catalog);
    actor.action = result.action;
    markers.push(...result.markers);
  };
  if (intent.grenadePressed) {
    if (!eligible || actor.grenadeStock === 0) grenade = "unavailable";
    else if (actor.action.kind !== "ready" || actor.grenadeCooldownTicks > 0) grenade = "cooldown";
    else {
      begin2("grenade");
      grenade = "applied";
    }
  }
  if (requested) {
    if (!eligible) fire = "unavailable";
    else if (actor.action.kind !== "ready" || actor.weapon.cooldownTicks > 0) fire = "cooldown";
    else if (closeTarget && actor.aim === 0 && actor.meleeCooldownTicks === 0) {
      begin2("melee");
      fire = "applied";
    } else {
      const result = beginFirearm(actor, tick2, nextActionId, catalog);
      actor = result.actor;
      nextActionId = result.nextActionId;
      markers.push(...result.markers);
      fire = "applied";
    }
  }
  return { actor, markers, nextActionId, fire, grenade };
}

// src/game/combat/grenade.ts
function grenadeVelocityBounds(profile) {
  return {
    x: Math.max(profile.standingVelocity.x, profile.crouchedVelocity.x) + profile.inheritedVelocityLimit.x,
    up: Math.max(-profile.standingVelocity.y, -profile.crouchedVelocity.y) + profile.inheritedVelocityLimit.y
  };
}
var clamp = (value, limit) => Math.max(-limit, Math.min(limit, value));
function grenadeLaunchVelocity(actor, profile, index, frame) {
  index.assertFrame(frame);
  const support2 = actor.body.supportId === null ? void 0 : index.get(actor.body.supportId);
  if (actor.body.grounded !== (actor.body.supportId !== null) || actor.body.grounded && !support2)
    throw new Error("Grenade launch requires accepted support");
  if (actor.facing !== 1 && actor.facing !== -1) throw new Error("Grenade launch facing");
  const impulse = actor.locomotion === "crouched" ? profile.crouchedVelocity : profile.standingVelocity;
  return {
    x: motion(
      impulse.x * actor.facing + clamp(motion(actor.body.vx) + (support2?.delta.x ?? 0), profile.inheritedVelocityLimit.x)
    ),
    y: motion(
      Math.min(
        profile.terminalVelocity,
        impulse.y + clamp(motion(actor.body.vy) + (support2?.delta.y ?? 0), profile.inheritedVelocityLimit.y)
      )
    )
  };
}
function stepGrenade(current, profile, shape, index, frame) {
  integer(current.spawnTick, 1, frame.tick, "grenade birth");
  integer(current.id, 1, COUNTER_LIMIT - 1, "grenade ID");
  integer(current.bounces, 0, profile.maximumBounces, "grenade bounce count");
  if (shape.id !== profile.bodyShapeId || current.body.id !== current.id)
    throw new Error("Grenade body identity");
  const grenade = structuredClone(current);
  index.assertFrame(frame);
  if (frame.tick === current.spawnTick) return { grenade, status: "active" };
  const vx = grenade.body.vx, vy = motion(Math.min(profile.terminalVelocity, grenade.body.vy + profile.gravity));
  grenade.body.vy = vy;
  const supportId = vy < 0 || !current.body.grounded ? null : startSupport(grenade.body, shape, 1, index, frame, null);
  const carry = supportId === null ? void 0 : index.get(supportId)?.delta;
  const result = stepBody(grenade.body, shape, 1, index, {
    frame,
    carrySupport: current.body.grounded
  });
  if (result.status !== "complete") {
    if (result.reason !== "crushed") throw new Error(`Grenade terrain: ${result.reason}`);
    return {
      status: "crushed",
      position: {
        x: position(result.movement.rect.x - shape.rect.x),
        y: position(result.movement.rect.y - shape.rect.y)
      },
      colliderIds: result.movement.diagnosticIds
    };
  }
  grenade.body = result.body;
  const horizontal = result.movement.contacts.find((contact) => contact.normal.x !== 0);
  const vertical = result.movement.contacts.find((contact) => contact.normal.y !== 0);
  if ((horizontal || vertical) && grenade.bounces < profile.maximumBounces) {
    grenade.bounces++;
    let reboundX = vx + (carry?.x ?? 0), reboundY = vy + (carry?.y ?? 0);
    if (horizontal) {
      const target = index.get(horizontal.otherId);
      if (!target) throw new Error("Missing grenade horizontal contact");
      reboundX = target.delta.x - divide(reboundX - target.delta.x, 2).quotient;
    }
    if (vertical) {
      const target = index.get(vertical.otherId);
      if (!target) throw new Error("Missing grenade vertical contact");
      reboundY = target.delta.y - divide(reboundY - target.delta.y, 2).quotient;
      reboundX = target.delta.x + divide((reboundX - target.delta.x) * 3, 4).quotient;
    }
    const bounds = grenadeVelocityBounds(profile);
    grenade.body.vx = motion(clamp(reboundX, bounds.x));
    grenade.body.vy = motion(Math.max(-bounds.up, Math.min(profile.terminalVelocity, reboundY)));
    grenade.body.grounded = false;
    grenade.body.supportId = null;
  } else if (vertical && grenade.body.grounded)
    grenade.body.vx = divide(grenade.body.vx * 3, 4).quotient;
  return frame.tick - current.spawnTick >= profile.fuseTicks ? { status: "detonated", position: { x: grenade.body.x, y: grenade.body.y } } : { grenade, status: "active" };
}

// src/game/combat/pickups.ts
var MAX_WEAPON_PICKUPS = 64;
function fields(value, expected) {
  if (Object.keys(value).sort().join(" ") !== expected.split(" ").sort().join(" "))
    throw new Error("Unexpected pickup fields");
}
function definitions(defs, catalog) {
  integer(defs.length, 0, MAX_WEAPON_PICKUPS, "pickup budget");
  const ids2 = /* @__PURE__ */ new Set(), claims = /* @__PURE__ */ new Set(), limits = /* @__PURE__ */ new Map();
  for (const def of defs) {
    fields(
      def,
      "id claimId sourceId kind weaponId ammo ammoLimit activationTick expiresTick supportId rect"
    );
    fields(def.rect, "x y w h");
    for (const value of [def.id, def.claimId, def.sourceId, def.supportId])
      integer(value, 1, COUNTER_LIMIT - 1, "pickup identity");
    if (ids2.has(def.id) || claims.has(def.claimId)) throw new Error("Duplicate pickup identity");
    ids2.add(def.id);
    claims.add(def.claimId);
    const weapon2 = catalog.firearms.get(def.weaponId)?.weapon;
    if (def.kind !== "weapon" || !weapon2) throw new Error("Unknown pickup content");
    const unlimited = weapon2.pickupAmmo === "unlimited";
    integer(def.ammoLimit, unlimited ? 0 : 1, unlimited ? 0 : 65535, "pickup inventory limit");
    integer(def.ammo, unlimited ? 0 : 1, def.ammoLimit, "pickup ammunition");
    if (limits.has(def.weaponId) && limits.get(def.weaponId) !== def.ammoLimit)
      throw new Error("Conflicting pickup inventory limits");
    limits.set(def.weaponId, def.ammoLimit);
    integer(def.activationTick, 1, COUNTER_LIMIT - 2, "pickup activation");
    integer(def.expiresTick, def.activationTick + 1, COUNTER_LIMIT - 1, "pickup expiry");
    integer(def.rect.w, 1, MAX_SHAPE, "pickup width");
    integer(def.rect.h, 1, MAX_SHAPE, "pickup height");
    for (const value of [def.rect.x, def.rect.y, def.rect.x + def.rect.w, def.rect.y + def.rect.h])
      position(value);
  }
}
function supported(def, terrain) {
  const support2 = terrain.find((surface) => surface.id === def.supportId);
  if (support2?.delta.x !== 0 || support2.delta.y !== 0 || def.rect.y + def.rect.h !== support2.rect.y || def.rect.x < support2.rect.x || def.rect.x + def.rect.w > support2.rect.x + support2.rect.w)
    return false;
  return !terrain.some(
    (surface) => surface.kind === "solid" && sweepAabb(def.rect, { x: 0, y: 0 }, surface.rect, surface.delta) !== null
  );
}
function createWeaponPickups(defs, catalog, terrain) {
  definitions(defs, catalog);
  for (const surface of terrain) validateSweepTarget(surface);
  if (defs.some((def) => !supported(def, terrain))) throw new Error("Unsafe pickup spawn");
  return {
    format: 1,
    tick: 0,
    contacts: [],
    items: [...defs].sort((a, b) => a.id - b.id).map((def) => ({
      id: def.id,
      status: "dormant",
      resolvedTick: null,
      claimedBy: null
    }))
  };
}
function validateWeaponPickups(state, defs, catalog, playerIds) {
  definitions(defs, catalog);
  fields(state, "format tick contacts items");
  if (state.format !== 1) throw new Error("Unsupported pickup format");
  integer(state.tick, 0, COUNTER_LIMIT - 1, "pickup tick");
  if (state.items.length !== defs.length) throw new Error("Pickup roster mismatch");
  const ordered3 = [...defs].sort((a, b) => a.id - b.id);
  for (const [index, item] of state.items.entries()) {
    fields(item, "id status resolvedTick claimedBy");
    const def = ordered3[index];
    if (!def || item.id !== def.id) throw new Error("Pickup identity mismatch");
    if (!["dormant", "available", "claimed", "expired", "unsupported"].includes(item.status))
      throw new Error("Unknown pickup status");
    if (item.status === "dormant" || item.status === "available") {
      if (item.resolvedTick !== null || item.claimedBy !== null || state.tick >= def.expiresTick || item.status === "dormant" !== state.tick < def.activationTick)
        throw new Error("Pickup availability mismatch");
    } else {
      integer(
        item.resolvedTick,
        def.activationTick,
        state.tick,
        "pickup resolution tick"
      );
      if (item.status === "expired" ? item.resolvedTick !== def.expiresTick : (item.resolvedTick ?? 0) >= def.expiresTick)
        throw new Error("Pickup lifetime mismatch");
      if (item.status === "claimed" ? !playerIds.has(item.claimedBy) : item.claimedBy !== null)
        throw new Error("Pickup claimant mismatch");
    }
  }
  integer(state.contacts.length, 0, MAX_WEAPON_PICKUPS * 4, "pickup contact budget");
  let previous = { id: 0, playerId: 0 };
  for (const contact of state.contacts) {
    fields(contact, "id playerId");
    if (!playerIds.has(contact.playerId) || !state.items.some((item) => item.id === contact.id && item.status === "available") || contact.id < previous.id || contact.id === previous.id && contact.playerId <= previous.playerId)
      throw new Error("Pickup contact roster/order mismatch");
    previous = contact;
  }
}
function compare2(a, b) {
  const difference2 = a.n * b.d - b.n * a.d;
  return difference2 < 0n ? -1 : difference2 > 0n ? 1 : 0;
}
function firstContact(movement, rect) {
  if (movement.status !== "complete") throw new Error("Unaccepted pickup movement");
  integer(movement.path.length, 1, 5, "pickup movement intervals");
  let elapsed = { n: 0n, d: 1n }, remaining = { n: 1n, d: 1n };
  for (const interval of movement.path) {
    const { numerator: n, denominator: d } = interval.until;
    integer(d, 1, 2 ** 17, "pickup residual denominator");
    integer(n, 0, d, "pickup residual numerator");
    const hit = sweepAabb(interval.rect, interval.motion, rect);
    const time2 = hit?.kind === "overlap" ? { numerator: 0, denominator: 1 } : hit?.time;
    if (time2 && compareContactTime(time2.numerator, time2.denominator, n, d) <= 0) {
      return {
        n: elapsed.n * remaining.d * BigInt(time2.denominator) + remaining.n * BigInt(time2.numerator) * elapsed.d,
        d: elapsed.d * remaining.d * BigInt(time2.denominator)
      };
    }
    elapsed = {
      n: elapsed.n * remaining.d * BigInt(d) + remaining.n * BigInt(n) * elapsed.d,
      d: elapsed.d * remaining.d * BigInt(d)
    };
    remaining = { n: remaining.n * BigInt(d - n), d: remaining.d * BigInt(d) };
  }
  return null;
}
function grant(actor, def, tick2) {
  const previous = { ...actor.weapon };
  const ammo = previous.id === def.weaponId ? Math.min(def.ammoLimit, previous.ammo + def.ammo) : def.ammo;
  if (previous.id === def.weaponId && ammo <= previous.ammo) return null;
  actor.weapon = { ...previous, id: def.weaponId, ammo };
  if (previous.id !== def.weaponId) {
    if (actor.action.kind === "fire")
      actor.action = {
        kind: "ready",
        actionInstanceId: 0,
        stateStartTick: tick2,
        definitionId: 0,
        nextMarkerIndex: 0
      };
    actor.firearmAim = {
      pitch: actor.locomotion === "crouched" ? 0 : actor.aim === 1 ? 4 : actor.aim === 2 ? -4 : 0,
      nextStepTick: 0
    };
  }
  return {
    id: def.id,
    claimId: def.claimId,
    sourceId: def.sourceId,
    playerId: actor.playerId,
    slot: actor.slot,
    tick: tick2,
    weaponId: def.weaponId,
    previousWeaponId: previous.id,
    previousAmmo: previous.ammo,
    ammo
  };
}
function stepWeaponPickups(current, defs, actors, movements, terrain, catalog) {
  integer(actors.length, 1, 4, "pickup players");
  const playerIds = /* @__PURE__ */ new Set(), slots = /* @__PURE__ */ new Set();
  for (const actor of actors) {
    integer(actor.playerId, 1, COUNTER_LIMIT - 1, "pickup player");
    integer(actor.slot, 0, 3, "pickup player slot");
    integer(actor.weapon.ammo, 0, 65535, "pickup player ammunition");
    if (playerIds.has(actor.playerId) || slots.has(actor.slot))
      throw new Error("Duplicate pickup player");
    playerIds.add(actor.playerId);
    slots.add(actor.slot);
  }
  validateWeaponPickups(current, defs, catalog, playerIds);
  for (const surface of terrain) validateSweepTarget(surface);
  const tick2 = integer(current.tick + 1, 1, COUNTER_LIMIT - 1, "next pickup tick");
  const state = structuredClone(current), players = structuredClone([...actors]);
  const byId = new Map(defs.map((def) => [def.id, def]));
  const candidates = [];
  const contacts = [];
  state.tick = tick2;
  for (const item of state.items) {
    if (item.status !== "available" && item.status !== "dormant") continue;
    const def = byId.get(item.id);
    if (!def) throw new Error("Missing pickup content");
    if (tick2 < def.activationTick) continue;
    if (tick2 >= def.expiresTick || !supported(def, terrain)) {
      item.status = tick2 >= def.expiresTick ? "expired" : "unsupported";
      item.resolvedTick = tick2;
      continue;
    }
    item.status = "available";
    for (const player2 of players) {
      if (player2.life !== "alive" || player2.bodyPresence !== "present" || player2.vehicleId !== null || ["enter", "exit", "hurt"].includes(player2.action.kind))
        continue;
      const movement = movements.get(player2.playerId);
      if (!movement) continue;
      const time2 = firstContact(movement, def.rect);
      const end = movement.rect;
      if (time2 && end.x <= def.rect.x + def.rect.w && end.x + end.w >= def.rect.x && end.y <= def.rect.y + def.rect.h && end.y + end.h >= def.rect.y)
        contacts.push({ id: def.id, playerId: player2.playerId });
      if (time2 && !current.contacts.some(
        (contact) => contact.id === def.id && contact.playerId === player2.playerId
      ))
        candidates.push({ item, def, player: player2, time: time2 });
    }
  }
  candidates.sort(
    (a, b) => compare2(a.time, b.time) || a.player.slot - b.player.slot || a.def.claimId - b.def.claimId
  );
  const claims = [];
  for (const { item, def, player: player2 } of candidates) {
    if (item.status !== "available") continue;
    const claim = grant(player2, def, tick2);
    if (!claim) continue;
    item.status = "claimed";
    item.resolvedTick = tick2;
    item.claimedBy = player2.playerId;
    claims.push(claim);
  }
  state.contacts = contacts.filter(
    (contact) => state.items.some((item) => item.id === contact.id && item.status === "available")
  ).sort((a, b) => a.id - b.id || a.playerId - b.playerId);
  validateWeaponPickups(state, defs, catalog, playerIds);
  return { state, players, claims };
}

// src/game/combat/rocket.ts
var QUADRANT = [
  [16384, 0],
  [16069, 3196],
  [15137, 6270],
  [13623, 9102],
  [11585, 11585],
  [9102, 13623],
  [6270, 15137],
  [3196, 16069]
];
var HEADINGS = [0, 1, 2, 3].flatMap(
  (quadrant) => QUADRANT.map(
    ([x, y]) => quadrant === 0 ? [x, y] : quadrant === 1 ? [-y, x] : quadrant === 2 ? [-x, -y] : [y, -x]
  )
);
var difference = (from, to) => (to - from + 48) % 32 - 16;
function velocity(heading, speed) {
  const vector = HEADINGS[integer(heading, 0, 31, "rocket heading")];
  if (!vector || vector[0] === void 0 || vector[1] === void 0)
    throw new Error("Missing rocket heading");
  return {
    x: divide(vector[0] * speed, 16384).quotient,
    y: divide(vector[1] * speed, 16384).quotient
  };
}
function headingTo(delta, fallback) {
  if (delta.x === 0 && delta.y === 0) return fallback;
  let best = 0, score = -Infinity;
  for (const [heading, vector] of HEADINGS.entries()) {
    const dot = (vector[0] ?? 0) * delta.x + (vector[1] ?? 0) * delta.y;
    if (dot > score) {
      best = heading;
      score = dot;
    }
  }
  return best;
}
function validateRocketProfile(profile) {
  integer(profile.bodyShapeId, 1, COUNTER_LIMIT - 1, "rocket shape");
  integer(profile.launchSpeed, 1, MAX_MOTION, "rocket launch speed");
  integer(profile.maximumSpeed, profile.launchSpeed, MAX_MOTION, "rocket maximum speed");
  integer(profile.acceleration, 1, MAX_MOTION, "rocket acceleration");
  integer(profile.lifetimeTicks, 1, 3600, "rocket lifetime");
  integer(profile.blastRadius, 1, 2 ** 16, "rocket blast radius");
  integer(profile.acquireRange, 1, MAX_MOTION, "rocket acquisition range");
  integer(profile.retainRange, profile.acquireRange, MAX_MOTION, "rocket retention range");
  integer(profile.acquireSteps, 0, 7, "rocket acquisition cone");
  integer(profile.retainSteps, profile.acquireSteps, 7, "rocket retention cone");
  integer(profile.launchLeashSteps, 0, 7, "rocket launch leash");
  integer(profile.acquireIntervalTicks, 1, 60, "rocket acquisition interval");
  integer(profile.turnIntervalTicks, 1, 60, "rocket turn interval");
}
function validateRocket(rocket2, profile) {
  for (const id2 of [rocket2.id, rocket2.ownerId, rocket2.actionInstanceId, rocket2.definitionId])
    integer(id2, 1, COUNTER_LIMIT - 1, "rocket identity");
  integer(rocket2.team, 1, 255, "rocket team");
  const tail = profile.lifetimeTicks + Math.max(profile.acquireIntervalTicks, profile.turnIntervalTicks);
  integer(rocket2.spawnTick, 1, COUNTER_LIMIT - 1 - tail, "rocket birth tick");
  integer(
    rocket2.tick,
    rocket2.spawnTick,
    rocket2.spawnTick + profile.lifetimeTicks - 1,
    "rocket tick"
  );
  integer(rocket2.launchHeading, 0, 31, "rocket launch heading");
  integer(rocket2.heading, 0, 31, "rocket heading");
  if (Math.abs(difference(rocket2.launchHeading, rocket2.heading)) > profile.launchLeashSteps)
    throw new Error("Rocket exceeded its launch leash");
  const speed = Math.min(
    profile.maximumSpeed,
    profile.launchSpeed + (rocket2.tick - rocket2.spawnTick) * profile.acceleration
  );
  if (rocket2.speed !== speed) throw new Error("Rocket speed disagrees with its age");
  const expected = velocity(rocket2.heading, speed);
  if (rocket2.velocity.x !== expected.x || rocket2.velocity.y !== expected.y)
    throw new Error("Rocket velocity disagrees with its heading");
  position(rocket2.position.x);
  position(rocket2.position.y);
  if (rocket2.targetId !== null) {
    integer(rocket2.targetId, 1, COUNTER_LIMIT - 1, "rocket target");
    if (rocket2.targetId === rocket2.ownerId) throw new Error("Rocket cannot lock its owner");
  }
  integer(
    rocket2.nextAcquireTick,
    rocket2.tick + 1,
    rocket2.tick + profile.acquireIntervalTicks,
    "rocket acquisition clock"
  );
  integer(
    rocket2.nextTurnTick,
    rocket2.tick + 1,
    rocket2.tick + profile.turnIntervalTicks,
    "rocket turn clock"
  );
  if ((rocket2.nextAcquireTick - rocket2.spawnTick - 1) % profile.acquireIntervalTicks !== 0 || (rocket2.nextTurnTick - rocket2.spawnTick) % profile.turnIntervalTicks !== 0)
    throw new Error("Rocket guidance clock phase disagrees with its birth");
}
function createRocket(source, origin, heading, tick2, profile) {
  validateRocketProfile(profile);
  const rocket2 = {
    ...source,
    position: { ...origin },
    velocity: velocity(heading, profile.launchSpeed),
    spawnTick: tick2,
    tick: tick2,
    launchHeading: heading,
    heading,
    speed: profile.launchSpeed,
    targetId: null,
    nextAcquireTick: tick2 + 1,
    nextTurnTick: tick2 + profile.turnIntervalTicks
  };
  validateRocket(rocket2, profile);
  return rocket2;
}
function validateCandidates(terrain, hurtboxes) {
  integer(terrain.length + hurtboxes.length, 0, 4096, "rocket candidates");
  const ids2 = /* @__PURE__ */ new Set();
  for (const target of terrain) validateSweepTarget(target);
  for (const target of hurtboxes) {
    integer(target.id, 1, COUNTER_LIMIT - 1, "rocket collision ID");
    integer(target.entityId, 1, COUNTER_LIMIT - 1, "rocket hurt entity");
    integer(target.team, 0, 255, "rocket hurt team");
    if (target.kind !== "body" && target.kind !== "shield")
      throw new Error("Invalid rocket hurt kind");
    if (target.solid !== void 0 && typeof target.solid !== "boolean")
      throw new Error("Invalid rocket solid flag");
    sweepBounds(target.rect, target.delta);
    integer(target.rect.w, 1, 2 ** 24, "rocket hurt width");
    integer(target.rect.h, 1, 2 ** 24, "rocket hurt height");
  }
  for (const target of [...terrain, ...hurtboxes]) {
    surfaceMaterialFor(target);
    if (ids2.has(target.id)) throw new Error("Duplicate rocket collision ID");
    ids2.add(target.id);
  }
}
function guidanceTargets(rocket2, profile, terrain, hurtboxes, retaining) {
  const range = retaining ? profile.retainRange : profile.acquireRange, steps = retaining ? profile.retainSteps : profile.acquireSteps;
  const candidates = hurtboxes.flatMap((target) => {
    if (target.kind !== "body" || target.solid || target.team === 0 || target.team === rocket2.team || target.entityId === rocket2.ownerId || retaining && target.entityId !== rocket2.targetId)
      return [];
    const center = {
      x: target.rect.x + divide(target.rect.w, 2).quotient,
      y: target.rect.y + divide(target.rect.h, 2).quotient
    }, delta = { x: center.x - rocket2.position.x, y: center.y - rocket2.position.y }, distance = delta.x * delta.x + delta.y * delta.y, heading = headingTo(delta, rocket2.heading);
    if (distance > range * range || Math.abs(difference(rocket2.heading, heading)) > steps || Math.abs(difference(rocket2.launchHeading, heading)) > profile.launchLeashSteps)
      return [];
    return [{ target, delta, distance, heading }];
  }).sort(
    (a, b) => a.distance - b.distance || a.target.entityId - b.target.entityId || a.target.id - b.target.id
  );
  const blockers = [
    ...terrain,
    ...hurtboxes.filter(
      (target) => target.solid || target.kind === "shield" && target.team !== rocket2.team && target.entityId !== rocket2.ownerId
    )
  ];
  for (const candidate of candidates) {
    if (!blockers.some(
      (target) => sweepAabb({ ...rocket2.position, w: 0, h: 0 }, candidate.delta, target.rect)
    ))
      return candidate;
  }
  return null;
}
function stepRocket(current, tick2, definition2, shape, profile, terrain, hurtboxes) {
  validateRocketProfile(profile);
  validateRocket(current, profile);
  if (tick2 !== current.tick + 1) throw new Error("Rocket requires consecutive ticks");
  if (definition2.id !== current.definitionId || definition2.kind !== "explosion" || definition2.material !== "explosive" || definition2.lifetimeTicks !== profile.lifetimeTicks || definition2.speed !== profile.launchSpeed || definition2.repeatDamageTicks !== 0 || shape.id !== profile.bodyShapeId)
    throw new Error("Invalid rocket attack policy");
  integer(definition2.damage, 1, 65535, "rocket damage");
  integer(definition2.maxTargets, 1, 64, "rocket blast targets");
  worldRect(current.position, shape.rect, 1);
  const extentX = Math.max(Math.abs(shape.rect.x), Math.abs(shape.rect.x + shape.rect.w)), extentY = Math.max(Math.abs(shape.rect.y), Math.abs(shape.rect.y + shape.rect.h));
  if (extentX * extentX + extentY * extentY > profile.blastRadius * profile.blastRadius)
    throw new Error("Rocket blast must enclose its flight body");
  validateCandidates(terrain, hurtboxes);
  const rocket2 = structuredClone(current);
  let lock = rocket2.targetId === null ? null : guidanceTargets(rocket2, profile, terrain, hurtboxes, true);
  if (!lock) rocket2.targetId = null;
  if (tick2 >= rocket2.nextAcquireTick) {
    if (!lock) lock = guidanceTargets(rocket2, profile, terrain, hurtboxes, false);
    rocket2.nextAcquireTick = tick2 + profile.acquireIntervalTicks;
  }
  rocket2.targetId = lock?.target.entityId ?? null;
  if (tick2 >= rocket2.nextTurnTick) {
    if (lock)
      rocket2.heading = (rocket2.heading + Math.sign(difference(rocket2.heading, lock.heading)) + 32) % 32;
    rocket2.nextTurnTick = tick2 + profile.turnIntervalTicks;
  }
  rocket2.speed = Math.min(profile.maximumSpeed, rocket2.speed + profile.acceleration);
  rocket2.velocity = velocity(rocket2.heading, rocket2.speed);
  const contact = projectileImpact(rocket2, shape, 0, terrain, hurtboxes);
  if (contact)
    return {
      status: "detonated",
      contact,
      // Contact selects the blast origin/time; it never grants a second direct-hit debit.
      impacts: explosionHits(
        rocket2,
        definition2,
        contact.position,
        profile.blastRadius,
        terrain,
        hurtboxes,
        { time: contact.time, primaryTarget: contact.entityId }
      )
    };
  rocket2.position = {
    x: position(rocket2.position.x + motion(rocket2.velocity.x)),
    y: position(rocket2.position.y + motion(rocket2.velocity.y))
  };
  rocket2.tick = tick2;
  return tick2 - rocket2.spawnTick >= profile.lifetimeTicks ? { status: "expired", position: rocket2.position } : { status: "active", rocket: rocket2 };
}

// src/game/content/scenarios/materials.ts
var MATERIAL_LAB_WEAPONS = [
  "sidearm",
  "heavy-machine-gun",
  "shotgun",
  "rocket-launcher",
  "flamethrower",
  "laser",
  "knife",
  "grenade"
];
var MATERIAL_TARGET_MOTIONS = ["stationary", "patrol"];
var MATERIAL_CASES = MATERIAL_LAB_WEAPONS.flatMap(
  (weapon2) => SURFACE_MATERIAL_IDS.flatMap(
    (materialId) => MATERIAL_TARGET_MOTIONS.map((targetMotion) => ({ weapon: weapon2, materialId, targetMotion }))
  )
);
function materialScenario(definition2) {
  if (!MATERIAL_LAB_WEAPONS.includes(definition2.weapon) || !MATERIAL_TARGET_MOTIONS.includes(definition2.targetMotion))
    throw new Error("Unknown material calibration case");
  surfaceMaterial(definition2.materialId);
  return `material:${definition2.weapon}:${definition2.materialId}:${definition2.targetMotion}`;
}
var MATERIAL_SCENARIOS = MATERIAL_CASES.map(materialScenario);
var cases = new Map(
  MATERIAL_SCENARIOS.map((scenario, index) => [scenario, MATERIAL_CASES[index]])
);
function materialCase(scenario) {
  return cases.get(scenario) ?? null;
}
var MATERIAL_CALIBRATION = {
  definitionId: 5,
  firstTargetX: pixels(112),
  targetSpacing: pixels(24),
  targetY: pixels(200),
  targetHealth: 32,
  patrolSpeed: 64,
  bounds: { x: 0, y: 0, w: pixels(384), h: pixels(232) },
  fallBoundary: pixels(248)
};
function materialPlayerX(weapon2) {
  return pixels(weapon2 === "knife" ? 70 : weapon2 === "grenade" ? 10 : 45);
}
function materialLabProp(definition2) {
  surfaceMaterial(definition2.materialId);
  return {
    id: 200,
    definitionId: 10 + SURFACE_MATERIAL_IDS.indexOf(definition2.materialId),
    materialId: definition2.materialId,
    rect: { x: pixels(92), y: pixels(80), w: pixels(2), h: pixels(120) },
    health: 8
  };
}

// src/game/content/weapons/laser.ts
var LASER_WEAPON = {
  id: "laser",
  attackId: 18,
  timelineId: 230,
  cadenceTicks: 6,
  ammoPerAction: 1,
  pickupAmmo: 120,
  aimPolicy: "cardinal",
  visualFamily: "fixture-laser",
  audioFamily: "fixture-laser"
};
var LASER_PROFILE = { range: pixels(512), width: pixels(4), pulseTicks: 6 };
var LASER_SHAPE = {
  id: 21,
  rect: { x: 0, y: -pixels(2), w: pixels(256), h: pixels(4) }
};
var LASER_ATTACK = {
  id: LASER_WEAPON.attackId,
  kind: "beam",
  shapeId: LASER_SHAPE.id,
  damage: 2,
  lifetimeTicks: 6,
  speed: 0,
  maxTargets: 8,
  repeatDamageTicks: 6,
  material: "energy"
};
validateBeamProfile(LASER_PROFILE);

// src/game/content/weapons/rocket-launcher.ts
var ROCKET_WEAPON = {
  id: "rocket-launcher",
  attackId: 17,
  timelineId: 220,
  cadenceTicks: 24,
  ammoPerAction: 1,
  pickupAmmo: 20,
  aimPolicy: "cardinal",
  visualFamily: "fixture-rocket",
  audioFamily: "fixture-rocket"
};
var ROCKET_SHAPE = {
  id: 19,
  rect: { x: -pixels(2), y: -pixels(2), w: pixels(4), h: pixels(4) }
};
var ROCKET_BLAST_SHAPE = {
  id: 20,
  rect: { x: -pixels(48), y: -pixels(48), w: pixels(96), h: pixels(96) }
};
var ROCKET_PROFILE = {
  bodyShapeId: ROCKET_SHAPE.id,
  launchSpeed: pixels(2),
  acceleration: 128,
  maximumSpeed: pixels(6),
  lifetimeTicks: 90,
  blastRadius: pixels(48),
  acquireRange: pixels(240),
  retainRange: pixels(256),
  acquireSteps: 2,
  retainSteps: 4,
  launchLeashSteps: 4,
  acquireIntervalTicks: 6,
  turnIntervalTicks: 3
};
var ROCKET_ATTACK = {
  id: ROCKET_WEAPON.attackId,
  kind: "explosion",
  shapeId: ROCKET_BLAST_SHAPE.id,
  damage: 4,
  lifetimeTicks: ROCKET_PROFILE.lifetimeTicks,
  speed: ROCKET_PROFILE.launchSpeed,
  maxTargets: 16,
  repeatDamageTicks: 0,
  material: "explosive"
};
validateRocketProfile(ROCKET_PROFILE);

// src/game/controller/foot.ts
function clone(actor) {
  return {
    ...actor,
    body: { ...actor.body, contacts: actor.body.contacts.map((contact) => ({ ...contact })) },
    action: { ...actor.action }
  };
}
function required(shapes2, id2) {
  const value = shapes2.get(id2);
  if (!value || value.id !== id2) throw new Error(`Missing controller shape ${id2}`);
  return value;
}
function stepFootController(current, intent, definition2, shapes2, index, frame, controlsLocked = false) {
  index.assertFrame(frame);
  integer(intent.held, 0, HELD_MASK, "controller held mask");
  if (typeof intent.jumpPressed !== "boolean") throw new Error("Invalid jump edge intent");
  if (current.geometryRevision !== index.frame.geometryRevision)
    throw new Error("Controller geometry revision mismatch");
  integer(current.jumpBufferTicks, 0, ARCADE.jumpBufferTicks, "jump buffer");
  integer(current.coyoteTicks, 0, ARCADE.coyoteTicks, "coyote timer");
  integer(current.ignoredSupportTicks, 0, ARCADE.dropThroughTicks, "drop timer");
  if (current.ignoredSupportId !== null)
    integer(current.ignoredSupportId, 1, COUNTER_LIMIT - 1, "ignored support ID");
  const actor = clone(current);
  if (actor.life !== "alive" || actor.vehicleId !== null || actor.locomotion === "seated" || actor.action.kind === "enter" || actor.action.kind === "exit")
    return { status: "inactive", actor };
  if (definition2.locomotion !== "grounded" || definition2.gravity <= 0 || definition2.jumpVelocity + definition2.gravity >= 0 || definition2.terminalVelocity <= 0 || definition2.runSpeed < 0)
    throw new Error("Invalid foot controller definition");
  for (const value of [
    definition2.gravity,
    definition2.jumpVelocity,
    definition2.terminalVelocity,
    definition2.runSpeed
  ])
    motion(value);
  const standing = required(shapes2, definition2.standingShapeId);
  const crouched2 = required(shapes2, definition2.crouchedShapeId);
  if (standing.rect.y + standing.rect.h !== 0 || crouched2.rect.y + crouched2.rect.h !== 0 || crouched2.rect.y < standing.rect.y || crouched2.rect.x < standing.rect.x || crouched2.rect.x + crouched2.rect.w > standing.rect.x + standing.rect.w)
    throw new Error("Controller stances must share feet and crouch within standing bounds");
  if (actor.body.shapeId !== standing.id && actor.body.shapeId !== crouched2.id)
    throw new Error("Unknown controller stance");
  if (actor.body.remainderX !== 0 || actor.body.remainderY !== 0)
    throw new Error("Unsupported controller motion remainder");
  let shape = required(shapes2, actor.body.shapeId);
  if (actor.ignoredSupportTicks === 0 || !index.get(actor.ignoredSupportId ?? 0)) {
    actor.ignoredSupportId = null;
    actor.ignoredSupportTicks = 0;
  }
  const touchingSupport = startSupport(
    actor.body,
    shape,
    actor.facing,
    index,
    frame,
    actor.ignoredSupportId
  );
  const support2 = actor.body.vy < 0 ? null : touchingSupport;
  const wasGrounded = current.body.grounded;
  actor.body.supportId = support2;
  actor.body.grounded = support2 !== null;
  const locked = controlsLocked || actor.action.kind === "hurt";
  const held = locked ? 0 : intent.held;
  const direction = directionalIntent(held, actor.facing, support2 !== null);
  if (locked) actor.jumpBufferTicks = 0;
  else if (intent.jumpPressed) actor.jumpBufferTicks = ARCADE.jumpBufferTicks;
  if (support2 !== null) actor.coyoteTicks = ARCADE.coyoteTicks;
  let jumpRequest = intent.jumpPressed ? locked ? "unavailable" : "buffered" : "none";
  const supportTarget = index.get(support2 ?? 0);
  const canJump = !locked && actor.jumpBufferTicks > 0 && (support2 !== null || actor.coyoteTicks > 0);
  let dropping = canJump && direction.vertical > 0 && supportTarget?.kind === "one-way";
  let dropQueuedAtEnd = false;
  let isCrouched = actor.locomotion === "crouched" || crouched2.id !== standing.id && shape.id === crouched2.id;
  const wantsCrouch = locked ? isCrouched : direction.crouch && (!canJump || dropping);
  const desired = wantsCrouch ? crouched2 : standing;
  const nextFacing = locked ? actor.facing : direction.facing;
  let changed2 = tryBodyShape(actor.body, shape, desired, actor.facing, nextFacing, index, frame);
  if (!changed2.accepted && desired.id === standing.id && isCrouched)
    changed2 = tryBodyShape(actor.body, shape, crouched2, actor.facing, nextFacing, index, frame);
  if (changed2.accepted) {
    actor.body = changed2.body;
    actor.facing = changed2.facing;
    shape = required(shapes2, actor.body.shapeId);
    isCrouched = shape.id === crouched2.id && (standing.id !== crouched2.id || wantsCrouch);
  }
  actor.body.vx = locked ? actor.action.kind === "hurt" ? actor.body.vx : 0 : isCrouched && support2 !== null ? 0 : direction.horizontal * definition2.runSpeed;
  actor.body.vy = Math.min(definition2.terminalVelocity, actor.body.vy + definition2.gravity);
  const events = [];
  let jumped = false;
  if (dropping) {
    actor.ignoredSupportId = support2;
    actor.ignoredSupportTicks = ARCADE.dropThroughTicks;
    actor.body.supportId = null;
    actor.body.grounded = false;
    actor.body.vy = Math.max(definition2.gravity, actor.body.vy);
    actor.jumpBufferTicks = 0;
    actor.coyoteTicks = 0;
    jumpRequest = "consumed";
    events.push({ kind: "drop", tick: frame.tick, supportId: support2 });
  } else if (canJump && !isCrouched) {
    actor.body.vy = definition2.jumpVelocity + definition2.gravity;
    actor.body.supportId = null;
    actor.body.grounded = false;
    actor.jumpBufferTicks = 0;
    actor.coyoteTicks = 0;
    jumped = true;
    jumpRequest = "consumed";
    events.push({ kind: "jump", tick: frame.tick, supportId: support2 });
  }
  const physics = stepBody(actor.body, shape, actor.facing, index, {
    frame,
    ...actor.ignoredSupportId === null ? {} : { ignoredOneWayId: actor.ignoredSupportId }
  });
  if (physics.status !== "complete") return { status: "failed", physics };
  actor.body = physics.body;
  const landed = support2 === null && actor.body.grounded;
  if (landed) events.push({ kind: "land", tick: frame.tick, supportId: actor.body.supportId });
  if ((support2 !== null || wasGrounded) && !actor.body.grounded && !jumped && !dropping)
    events.push({
      kind: "leave-support",
      tick: frame.tick,
      supportId: support2 ?? current.body.supportId
    });
  if (!locked && actor.body.grounded && direction.vertical > 0) {
    const crouchAtEnd = tryBodyShape(
      actor.body,
      shape,
      crouched2,
      actor.facing,
      actor.facing,
      index,
      frame,
      "end"
    );
    if (crouchAtEnd.accepted) {
      actor.body = crouchAtEnd.body;
      shape = crouched2;
      isCrouched = true;
    }
  }
  if (!locked && actor.body.grounded && actor.jumpBufferTicks > 0) {
    const landedOn = actor.body.supportId;
    const landedTarget = index.get(landedOn ?? 0);
    if (direction.vertical > 0 && landedTarget?.kind === "one-way") {
      actor.ignoredSupportId = landedOn;
      actor.ignoredSupportTicks = ARCADE.dropThroughTicks;
      actor.body = { ...actor.body, vy: 0, grounded: false, supportId: null };
      actor.jumpBufferTicks = 0;
      actor.coyoteTicks = 0;
      dropping = true;
      dropQueuedAtEnd = true;
      jumpRequest = "consumed";
      events.push({ kind: "drop", tick: frame.tick, supportId: landedOn });
    } else {
      const standingAtEnd = tryBodyShape(
        actor.body,
        shape,
        standing,
        actor.facing,
        actor.facing,
        index,
        frame,
        "end"
      );
      if (standingAtEnd.accepted) {
        actor.body = {
          ...standingAtEnd.body,
          vy: definition2.jumpVelocity,
          supportId: null,
          grounded: false
        };
        shape = standing;
        isCrouched = false;
        actor.jumpBufferTicks = 0;
        actor.coyoteTicks = 0;
        jumped = true;
        jumpRequest = "consumed";
        events.push({ kind: "jump", tick: frame.tick, supportId: landedOn });
      }
    }
  }
  if (!jumped && !dropping)
    actor.coyoteTicks = actor.body.grounded || support2 !== null ? ARCADE.coyoteTicks : Math.max(0, actor.coyoteTicks - 1);
  actor.jumpBufferTicks = Math.max(0, actor.jumpBufferTicks - 1);
  if (actor.ignoredSupportId !== null) {
    if (!dropQueuedAtEnd) actor.ignoredSupportTicks = Math.max(0, actor.ignoredSupportTicks - 1);
    const ignored = index.get(actor.ignoredSupportId);
    const feet = worldRect(actor.body, shape.rect, actor.facing);
    if (!ignored || actor.ignoredSupportTicks === 0 || feet.y + feet.h > ignored.rect.y + ignored.delta.y + ignored.rect.h) {
      actor.ignoredSupportId = null;
      actor.ignoredSupportTicks = 0;
    }
  }
  actor.locomotion = actor.body.grounded ? isCrouched ? "crouched" : "grounded" : "airborne";
  if (!locked) actor.aim = directionalIntent(held, actor.facing, actor.body.grounded).aim;
  return { status: "complete", actor, events, jumpRequest, physics };
}

// src/game/encounters/lifecycle.ts
var POSE_FAULTS = ["initial-overlap", "residual-overlap", "contact-limit", "unresolved-contact"];
function check2(ok, message) {
  if (!ok) throw new Error(`Encounter: ${message}`);
}
function id(value) {
  return integer(value, 1, COUNTER_LIMIT - 1, "encounter ID");
}
function tick(value) {
  return integer(value, 0, COUNTER_LIMIT - 2, "encounter tick");
}
function unique(values) {
  for (const value of values) id(value);
  check2(new Set(values).size === values.length, "duplicate ID");
}
function encounterCounts(state) {
  return {
    pending: state.members.filter((m) => m.status === "pending").length,
    alive: state.members.filter((m) => m.status === "alive").length,
    resolved: state.members.filter((m) => m.status === "resolved").length
  };
}
var EncounterLifecycle = class {
  #definition;
  #key;
  constructor(definition2) {
    id(definition2.id);
    integer(definition2.participants.length, 1, 4, "participant count");
    integer(definition2.members.length, 0, 256, "member count");
    integer(definition2.objectives.length, 0, 64, "objective count");
    unique(definition2.participants);
    unique(definition2.members.map((m) => m.id));
    unique(definition2.objectives);
    for (const member of definition2.members) {
      for (const flag of [member.required, member.critical, member.retreatAllowed])
        check2(typeof flag === "boolean", "member flag");
      integer(member.watchdogTicks, 1, 36e3, "watchdog duration");
      check2(
        !member.critical || member.required && !member.retreatAllowed,
        "critical actor policy"
      );
      if (member.ambientCleanupTicks !== null) {
        integer(
          member.ambientCleanupTicks,
          member.watchdogTicks,
          36e3,
          "ambient cleanup duration"
        );
        check2(!member.required && !member.critical, "required actor cannot use ambient cleanup");
      }
    }
    this.#definition = structuredClone(definition2);
    this.#definition.members.sort((a, b) => a.id - b.id);
    this.#definition.participants.sort((a, b) => a - b);
    this.#definition.objectives.sort((a, b) => a - b);
    this.#key = canonical(this.#definition);
    Object.freeze(this);
  }
  begin(startTick = 0) {
    tick(startTick);
    return {
      definitionKey: this.#key,
      tick: startTick,
      phase: "active",
      members: this.#definition.members.map((m) => ({
        id: m.id,
        status: "pending",
        activatedTick: null,
        resolvedTick: null,
        reason: null,
        killerId: null,
        progressKey: null,
        unchangedSince: null,
        unreachableSince: null,
        warnedUnchanged: false,
        warnedUnreachable: false
      })),
      objectives: this.#definition.objectives.map((id2) => ({ id: id2, completedTick: null })),
      kills: this.#definition.participants.map((playerId) => ({ playerId, count: 0 })),
      receipts: [],
      failure: null
    };
  }
  remaining(state) {
    if (state.phase === "retired") return 0;
    return state.members.filter(
      (m, i) => this.#definition.members[i]?.required && m.status !== "resolved"
    ).length + state.objectives.filter((o) => o.completedTick === null).length;
  }
  /** Check a saved continuation without advancing clocks, watchdogs or event receipts. */
  restore(state) {
    this.#validate(state);
    return structuredClone(state);
  }
  step(current, atTick, events, observations, failureMode = "record") {
    this.#validate(current);
    tick(atTick);
    check2(atTick === current.tick + 1, "nonconsecutive tick");
    check2(failureMode === "record" || failureMode === "throw", "failure mode");
    integer(events.length, 0, 1024, "event batch size");
    integer(observations.length, 0, 256, "observation count");
    const state = structuredClone(current);
    state.tick = atTick;
    const notices = [];
    const fail = (memberId, reason, cause) => {
      if (state.failure) return;
      state.failure = { id: memberId, tick: atTick, reason, cause };
      state.phase = "failed";
      notices.push({
        kind: "failed",
        encounterId: this.#definition.id,
        failure: { ...state.failure }
      });
    };
    for (const event of [...events].sort((a, b) => a.sequence - b.sequence)) {
      integer(event.sequence, 1, 1024, "event sequence");
      tick(event.tick);
      const signature = canonical(event);
      if (event.sequence <= state.receipts.length) {
        check2(state.receipts[event.sequence - 1] === signature, "conflicting duplicate event");
        continue;
      }
      check2(event.sequence === state.receipts.length + 1, "event sequence gap");
      check2(event.tick === atTick, "event effective tick mismatch");
      check2(
        state.phase !== "retired" && current.phase !== "failed",
        "event after terminal encounter"
      );
      if (event.kind === "retire") {
        check2(!state.failure, "cannot retire failed encounter");
        check2(Object.keys(event).length === 3, "retire event fields");
        for (const member of state.members)
          if (member.status !== "resolved") {
            member.status = "resolved";
            member.reason = "checkpoint-retired";
            member.resolvedTick = atTick;
          }
        state.phase = "retired";
        notices.push({ kind: "retired", tick: atTick, encounterId: this.#definition.id });
      } else if (event.kind === "objective") {
        check2(Object.keys(event).length === 4, "objective event fields");
        const objective = state.objectives.find((o) => o.id === event.id);
        check2(objective && objective.completedTick === null, "unknown/completed objective");
        objective.completedTick = atTick;
      } else {
        const index = state.members.findIndex((m) => m.id === event.id), member = state.members[index], policy = this.#definition.members[index];
        check2(member && policy, "unknown member");
        if (event.kind === "activate") {
          check2(Object.keys(event).length === 4, "activation fields");
          check2(member.status === "pending", "member already activated/resolved");
          member.status = "alive";
          member.activatedTick = atTick;
        } else if (event.kind === "fault") {
          check2(
            Object.keys(event).length === 5 && POSE_FAULTS.includes(event.reason),
            "pose fault fields"
          );
          check2(member.status === "alive", "fault of nonliving member");
          fail(event.id, policy.critical ? "critical-loss" : "invalid-pose", event.reason);
        } else {
          check2(event.kind === "resolve" && Object.keys(event).length === 6, "resolution fields");
          check2(member.status === "alive", "resolution of nonliving member");
          check2(
            ["killed", "retreated", "crushed", "out-of-bounds"].includes(event.reason),
            "resolution reason"
          );
          check2(
            event.killerId === null || event.reason === "killed" && this.#definition.participants.includes(event.killerId),
            "invalid kill attribution"
          );
          member.status = "resolved";
          member.resolvedTick = atTick;
          member.reason = event.reason;
          member.killerId = event.killerId;
          if (event.killerId !== null) {
            const credit = state.kills.find((k) => k.playerId === event.killerId);
            check2(credit, "unknown participant");
            credit.count++;
          }
          if (policy.critical && event.reason !== "killed")
            fail(event.id, "critical-loss", event.reason);
          else if (event.reason === "retreated" && !policy.retreatAllowed)
            fail(event.id, "forbidden-retreat", event.reason);
        }
      }
      state.receipts.push(signature);
    }
    const observed = /* @__PURE__ */ new Map();
    for (const observation of observations) {
      id(observation.id);
      check2(!observed.has(observation.id), "duplicate observation");
      check2(
        typeof observation.progressKey === "string" && observation.progressKey.length > 0 && observation.progressKey.length <= 256 && typeof observation.unreachable === "boolean",
        "invalid progress observation"
      );
      check2(
        state.members.some((m) => m.id === observation.id),
        "unknown observed member"
      );
      observed.set(observation.id, observation);
    }
    if (state.phase !== "failed" && state.phase !== "retired") {
      for (let i = 0; i < state.members.length; i++) {
        const member = state.members[i], policy = this.#definition.members[i];
        check2(member && policy, "missing member policy");
        if (member.status !== "alive") continue;
        const observation = observed.get(member.id);
        check2(observation, "missing living member observation");
        if (member.progressKey !== observation.progressKey) {
          member.progressKey = observation.progressKey;
          member.unchangedSince = atTick;
          member.warnedUnchanged = false;
        }
        if (!observation.unreachable) {
          member.unreachableSince = null;
          member.warnedUnreachable = false;
        } else if (member.unreachableSince === null) member.unreachableSince = atTick;
        for (const reason of ["unchanged", "unreachable"]) {
          const since = reason === "unchanged" ? member.unchangedSince : member.unreachableSince;
          const warned = reason === "unchanged" ? member.warnedUnchanged : member.warnedUnreachable;
          if (since !== null && atTick - since >= policy.watchdogTicks && !warned) {
            notices.push({
              kind: "watchdog",
              tick: atTick,
              encounterId: this.#definition.id,
              id: member.id,
              sinceTick: since,
              reason,
              progressKey: observation.progressKey
            });
            if (reason === "unchanged") member.warnedUnchanged = true;
            else member.warnedUnreachable = true;
          }
        }
        const stalledSince = member.unreachableSince ?? member.unchangedSince;
        if (policy.ambientCleanupTicks !== null && stalledSince !== null && atTick - stalledSince >= policy.ambientCleanupTicks) {
          member.status = "resolved";
          member.resolvedTick = atTick;
          member.reason = "ambient-timeout";
          notices.push({
            kind: "remove-ambient",
            tick: atTick,
            id: member.id,
            reason: "ambient-timeout"
          });
        }
      }
      if (state.phase === "active" && this.remaining(state) === 0) {
        state.phase = "complete";
        notices.push({ kind: "complete", tick: atTick, encounterId: this.#definition.id });
      }
    }
    if (failureMode === "throw" && state.failure)
      throw new Error(
        `Encounter ${this.#definition.id} ${state.failure.reason}: ${state.failure.id} at ${state.failure.tick}`
      );
    return { state, notices, remaining: this.remaining(state), counts: encounterCounts(state) };
  }
  #validate(state) {
    check2(state.definitionKey === this.#key, "definition mismatch");
    tick(state.tick);
    check2(["active", "complete", "retired", "failed"].includes(state.phase), "phase");
    check2(
      state.members.length === this.#definition.members.length && state.members.every((m, i) => m.id === this.#definition.members[i]?.id),
      "roster mismatch"
    );
    check2(
      state.objectives.length === this.#definition.objectives.length && state.objectives.every((o, i) => o.id === this.#definition.objectives[i]),
      "objective roster mismatch"
    );
    check2(
      state.kills.length === this.#definition.participants.length && state.kills.every((k, i) => k.playerId === this.#definition.participants[i]),
      "participant mismatch"
    );
    integer(state.receipts.length, 0, 1024, "receipt count");
    for (let i = 0; i < state.receipts.length; i++) {
      const receipt = state.receipts[i];
      check2(typeof receipt === "string" && receipt.length <= 512, "receipt length");
      const event = JSON.parse(receipt);
      tick(event.tick);
      check2(
        event.sequence === i + 1 && event.tick <= state.tick && canonical(event) === receipt,
        "receipt continuation"
      );
    }
    for (const member of state.members) {
      check2(["pending", "alive", "resolved"].includes(member.status), "member status");
      for (const value of [
        member.activatedTick,
        member.resolvedTick,
        member.unchangedSince,
        member.unreachableSince
      ])
        if (value !== null) {
          tick(value);
          check2(value <= state.tick, "future member tick");
        }
      check2(
        member.status === "resolved" === (member.reason !== null) && member.status === "resolved" === (member.resolvedTick !== null),
        "resolution state"
      );
      check2(
        member.reason === null || [
          "killed",
          "retreated",
          "crushed",
          "out-of-bounds",
          "ambient-timeout",
          "checkpoint-retired"
        ].includes(member.reason),
        "unknown saved resolution"
      );
      check2(
        member.killerId === null || member.reason === "killed" && this.#definition.participants.includes(member.killerId),
        "saved kill attribution"
      );
      check2(member.status !== "alive" || member.activatedTick !== null, "missing activation");
      check2(
        member.status !== "pending" || member.activatedTick === null && member.progressKey === null && member.unchangedSince === null && member.unreachableSince === null,
        "pending member continuation"
      );
      check2(
        member.progressKey === null || typeof member.progressKey === "string" && member.progressKey.length > 0 && member.progressKey.length <= 256,
        "saved progress key"
      );
      check2(
        typeof member.warnedUnchanged === "boolean" && typeof member.warnedUnreachable === "boolean",
        "saved watchdog flags"
      );
      check2(
        member.progressKey === null === (member.unchangedSince === null),
        "saved progress timer"
      );
    }
    for (const objective of state.objectives)
      if (objective.completedTick !== null) {
        tick(objective.completedTick);
        check2(objective.completedTick <= state.tick, "future objective tick");
      }
    for (const credit of state.kills) {
      integer(credit.count, 0, 256, "kill count");
      check2(
        credit.count === state.members.filter((m) => m.reason === "killed" && m.killerId === credit.playerId).length,
        "kill count mismatch"
      );
    }
    check2(state.phase === "failed" === (state.failure !== null), "failure state");
    if (state.failure) {
      tick(state.failure.tick);
      check2(
        state.failure.tick <= state.tick && state.members.some((m) => m.id === state.failure?.id) && ["critical-loss", "forbidden-retreat", "invalid-pose"].includes(state.failure.reason) && [...POSE_FAULTS, "retreated", "crushed", "out-of-bounds"].includes(state.failure.cause),
        "invalid failure continuation"
      );
    }
    check2(state.phase !== "complete" || this.remaining(state) === 0, "premature completion");
  }
};

// src/game/vehicles/tank.ts
var tankOwner = (tank) => tank.occupantId ?? tank.reservedBy;
var idleTankAction = (tick2) => ({
  kind: "ready",
  actionInstanceId: 0,
  stateStartTick: tick2,
  definitionId: 0,
  nextMarkerIndex: 0
});
var zero2 = { x: 0, y: 0 };
function createTank(id2, point2, supportId, profile) {
  return {
    body: {
      id: id2,
      ...point2,
      vx: 0,
      vy: 0,
      remainderX: 0,
      remainderY: 0,
      shapeId: profile.locomotion.standingShapeId,
      supportId,
      grounded: supportId !== null,
      contacts: []
    },
    definitionId: profile.definition.id,
    kind: "tank",
    lifecycle: "available",
    occupantId: null,
    reservedBy: null,
    controlEpoch: 1,
    ownerControlEpoch: null,
    facing: 1,
    heading: 0,
    invulnerableTicks: 0,
    armor: profile.definition.armor,
    action: idleTankAction(0),
    components: [],
    weapon: {
      id: profile.definition.weaponId,
      ammo: 0,
      cooldownTicks: 0,
      shotOrdinal: 0,
      lastActionInstanceId: 0
    },
    jumpBufferTicks: 0,
    coyoteTicks: 0,
    turnTicks: 0,
    disconnectedTicks: 0,
    lastGunOwnerId: null,
    lastGunControlEpoch: null
  };
}
function attachTankDriver(tank, actor, profile) {
  if (tankOwner(tank) !== actor.playerId) throw new Error("Tank attachment owner mismatch");
  const point2 = worldSocket(tank.body, profile.definition.seat.socket, tank.facing);
  actor.body = {
    ...actor.body,
    ...point2,
    vx: tank.body.vx,
    vy: tank.body.vy,
    remainderX: 0,
    remainderY: 0,
    grounded: false,
    supportId: null,
    contacts: []
  };
  actor.vehicleId = tank.body.id;
  actor.locomotion = "seated";
  actor.facing = tank.facing;
  actor.jumpBufferTicks = actor.coyoteTicks = actor.ignoredSupportTicks = 0;
  actor.ignoredSupportId = null;
}
function moveTank(current, intent, profile, shapes2, index, frame) {
  const tank = structuredClone(current);
  if (tank.lifecycle === "wreck" || tank.lifecycle === "destroying")
    return { tank, jumpAccepted: false, fault: null };
  tank.invulnerableTicks = Math.max(0, tank.invulnerableTicks - 1);
  tank.weapon.cooldownTicks = Math.max(0, tank.weapon.cooldownTicks - 1);
  tank.turnTicks = Math.max(0, tank.turnTicks - 1);
  const driving = tank.lifecycle === "occupied";
  const actor = {
    body: tank.body,
    life: "alive",
    locomotion: tank.body.grounded ? "grounded" : "airborne",
    action: idleTankAction(frame.tick),
    facing: tank.facing,
    aim: 0,
    jumpBufferTicks: tank.jumpBufferTicks,
    coyoteTicks: tank.coyoteTicks,
    ignoredSupportId: null,
    ignoredSupportTicks: 0,
    vehicleId: null,
    geometryRevision: frame.geometryRevision
  };
  const result = stepFootController(
    actor,
    {
      held: driving ? intent.held & (Held.Left | Held.Right) : 0,
      jumpPressed: driving && intent.jumpPressed
    },
    profile.locomotion,
    shapes2,
    index,
    frame
  );
  if (result.status === "failed") return { tank, jumpAccepted: false, fault: result.physics };
  tank.body = result.actor.body;
  tank.facing = result.actor.facing;
  tank.jumpBufferTicks = result.actor.jumpBufferTicks;
  tank.coyoteTicks = result.actor.coyoteTicks;
  if (driving && tank.turnTicks === 0) {
    const x = Number(Boolean(intent.held & Held.Right)) - Number(Boolean(intent.held & Held.Left));
    const y = Number(Boolean(intent.held & Held.Down)) - Number(Boolean(intent.held & Held.Up));
    const target = y < 0 ? x > 0 ? 1 : x < 0 ? 3 : 2 : y > 0 ? x > 0 ? 7 : x < 0 ? 5 : 6 : x < 0 ? 4 : x > 0 ? 0 : tank.heading;
    if (target !== tank.heading) {
      const clockwise = (target - tank.heading + 8) % 8;
      tank.heading = (tank.heading + (clockwise <= 4 ? 1 : 7)) % 8;
      tank.turnTicks = profile.turnTicks;
    }
  }
  return {
    tank,
    jumpAccepted: result.status === "complete" && ["consumed", "buffered"].includes(result.jumpRequest),
    fault: null
  };
}
function clearPath(actor, point2, shape, index, frame) {
  if (blockingShapes(point2, shape.rect, actor.facing, index, frame, "end").length) return false;
  const start = worldRect(actor.body, shape.rect, actor.facing), delta = { x: point2.x - actor.body.x, y: point2.y - actor.body.y };
  const terrain = index.query(sweepBounds(start, delta)).filter((target) => target.kind === "solid").map((target) => ({
    ...target,
    rect: {
      ...target.rect,
      x: target.rect.x + target.delta.x,
      y: target.rect.y + target.delta.y
    },
    delta: zero2
  }));
  const result = earliestSweep(start, delta, terrain);
  return result.overlaps.length === 0 && result.contacts.every((contact) => contact.time.numerator === contact.time.denominator);
}
function tankExitBody(tank, actor, profile, shape, index, frame) {
  const candidates = profile.definition.seat.ejectionCandidates;
  for (const [candidateIndex, offset] of candidates.entries()) {
    const point2 = worldSocket(tank.body, offset, tank.facing);
    if (point2.y > profile.fallBoundary || !clearPath(actor, point2, shape, index, frame)) continue;
    const body2 = {
      ...actor.body,
      ...point2,
      shapeId: shape.id,
      vx: 0,
      vy: 0,
      remainderX: 0,
      remainderY: 0,
      supportId: null,
      grounded: false,
      contacts: []
    };
    const bounds = sweepBounds(worldRect(body2, shape.rect, actor.facing));
    const endTerrain = index.query({
      minX: bounds.minX - 1,
      minY: bounds.minY - 1,
      maxX: bounds.maxX + 1,
      maxY: bounds.maxY + 1
    }).map((target) => ({
      ...target,
      rect: {
        ...target.rect,
        x: target.rect.x + target.delta.x,
        y: target.rect.y + target.delta.y
      },
      delta: zero2
    }));
    const endIndex = new CollisionIndex(new CollisionGrid(endTerrain), [], frame);
    const supportId = startSupport(body2, shape, actor.facing, endIndex, frame, null);
    if (candidateIndex < candidates.length - 1 && supportId === null) continue;
    body2.supportId = supportId;
    body2.grounded = supportId !== null;
    return body2;
  }
  return null;
}
function reserveTank(tank, actor, tick2, actionId, profile, shapes2, index, frame) {
  if (actor.life !== "alive" || actor.vehicleId !== null || actor.reboardCooldownTicks > 0 || !["ready", "fire"].includes(actor.action.kind) || !actor.body.grounded || tank.lifecycle !== "available" || tank.armor === 0 || !tank.body.grounded || Math.abs(tank.body.vx) > pixels(1))
    return false;
  const sensor = shapes2.get(profile.definition.seat.boardingSensorShapeId), shape = shapes2.get(actor.body.shapeId);
  if (!sensor || !shape) throw new Error("Missing tank boarding geometry");
  if (sweepAabb(
    worldRect(actor.body, shape.rect, actor.facing),
    zero2,
    worldRect(tank.body, sensor.rect, tank.facing)
  )?.kind !== "overlap")
    return false;
  const seat = worldSocket(tank.body, profile.definition.seat.socket, tank.facing);
  if (!clearPath(actor, seat, shape, index, frame)) return false;
  tank.lifecycle = "boarding";
  tank.reservedBy = actor.playerId;
  tank.controlEpoch = nextCounter(tank.controlEpoch);
  tank.ownerControlEpoch = actor.controlEpoch;
  tank.action = {
    kind: "enter",
    actionInstanceId: actionId,
    stateStartTick: tick2,
    definitionId: profile.definition.seat.boardingTimelineId,
    nextMarkerIndex: 0
  };
  actor.action = { ...tank.action };
  attachTankDriver(tank, actor, profile);
  return true;
}
function requestTankExit(tank, actor, tick2, actionId, profile, shape, index, frame) {
  if (tank.lifecycle !== "occupied" || tank.occupantId !== actor.playerId || !tankExitBody(tank, actor, profile, shape, index, frame))
    return false;
  tank.lifecycle = "exiting";
  tank.action = {
    kind: "exit",
    actionInstanceId: actionId,
    stateStartTick: tick2,
    definitionId: profile.exitTimelineId,
    nextMarkerIndex: 0
  };
  actor.action = { ...tank.action };
  return true;
}
function releaseTank(tank, actor, tick2, profile, shape, index, frame) {
  if (tankOwner(tank) !== actor.playerId) throw new Error("Tank release owner mismatch");
  const body2 = tankExitBody(tank, actor, profile, shape, index, frame);
  tank.occupantId = tank.reservedBy = null;
  tank.ownerControlEpoch = null;
  tank.controlEpoch = nextCounter(tank.controlEpoch);
  tank.lifecycle = tank.armor > 0 ? "available" : "wreck";
  tank.action = idleTankAction(tick2);
  tank.jumpBufferTicks = tank.coyoteTicks = tank.disconnectedTicks = 0;
  actor.vehicleId = null;
  actor.body = body2 ?? {
    ...actor.body,
    vx: 0,
    vy: 0,
    supportId: null,
    grounded: false,
    contacts: []
  };
  actor.locomotion = actor.body.grounded ? "grounded" : "airborne";
  actor.action = idleTankAction(tick2);
  actor.reboardCooldownTicks = profile.reboardTicks;
  actor.invulnerableTicks = Math.max(actor.invulnerableTicks, profile.exitProtectionTicks);
  return body2 !== null;
}
function stepTankTransfer(tank, actor, tick2, profile, catalog, shape, index, frame) {
  if (tank.lifecycle !== "boarding" && tank.lifecycle !== "exiting") return null;
  const step = stepAction(tank.action, tick2, catalog);
  tank.action = step.action;
  actor.action = { ...step.action };
  if (!step.markers.some(({ marker }) => marker.kind === "seat-transfer")) return null;
  if (tank.lifecycle === "boarding") {
    tank.occupantId = tank.reservedBy;
    tank.reservedBy = null;
    tank.lifecycle = "occupied";
    tank.action = actor.action = idleTankAction(tick2);
    return "board";
  }
  if (!tankExitBody(tank, actor, profile, shape, index, frame)) {
    tank.lifecycle = "occupied";
    tank.action = actor.action = idleTankAction(tick2);
    return "exit-blocked";
  }
  releaseTank(tank, actor, tick2, profile, shape, index, frame);
  return "exit";
}
function stepTankGun(tank, intent, tick2, nextActionId, profile, catalog) {
  const requested = intent.firePressed || Boolean(intent.held & Held.Fire);
  let outcome = "none";
  const markers = [];
  if (tank.lifecycle !== "occupied" || tank.occupantId === null)
    return { outcome: requested ? "unavailable" : outcome, nextActionId, markers };
  if (tank.action.kind === "fire") {
    const step = stepAction(tank.action, tick2, catalog);
    tank.action = step.finished ? idleTankAction(tick2) : step.action;
    markers.push(...step.markers);
  }
  if (requested) {
    if (tank.action.kind !== "ready" || tank.weapon.cooldownTicks > 0) outcome = "cooldown";
    else {
      integer(
        nextActionId,
        tank.weapon.lastActionInstanceId + 1,
        COUNTER_LIMIT - 2,
        "tank gun allocation"
      );
      const definitionId = profile.fireTimelineIds[tank.heading];
      if (definitionId === void 0) throw new Error("Missing tank gun heading");
      tank.action = {
        kind: "fire",
        actionInstanceId: nextActionId,
        stateStartTick: tick2,
        definitionId,
        nextMarkerIndex: 0
      };
      tank.weapon.cooldownTicks = profile.fireCadenceTicks;
      tank.weapon.shotOrdinal = nextCounter(tank.weapon.shotOrdinal);
      tank.weapon.lastActionInstanceId = nextActionId;
      tank.lastGunOwnerId = tank.occupantId;
      tank.lastGunControlEpoch = tank.ownerControlEpoch;
      nextActionId = nextCounter(nextActionId);
      const step = stepAction(tank.action, tick2, catalog);
      tank.action = step.action;
      markers.push(...step.markers);
      outcome = "applied";
    }
  }
  return { outcome, nextActionId, markers };
}
function publicTankState(tank) {
  return structuredClone({
    body: tank.body,
    definitionId: tank.definitionId,
    kind: tank.kind,
    lifecycle: tank.lifecycle,
    occupantId: tank.occupantId,
    reservedBy: tank.reservedBy,
    controlEpoch: tank.controlEpoch,
    ownerControlEpoch: tank.ownerControlEpoch,
    facing: tank.facing,
    heading: tank.heading,
    invulnerableTicks: tank.invulnerableTicks,
    armor: tank.armor,
    action: tank.action,
    components: tank.components,
    weapon: tank.weapon
  });
}
function validateTankState(tank, tick2, players, profile, catalog) {
  const check10 = (ok, message) => {
    if (!ok) throw new Error(`Tank state: ${message}`);
  };
  check10(
    tank.kind === "tank" && tank.definitionId === profile.definition.id && tank.body.shapeId === profile.locomotion.standingShapeId && tank.components.length === 0,
    "definition"
  );
  integer(tank.armor, 0, profile.definition.armor, "tank armor");
  check10(tank.armor === 0 === (tank.lifecycle === "wreck"), "wreck armor");
  integer(tank.heading, 0, 7, "tank heading");
  check10(tank.facing === -1 || tank.facing === 1, "facing");
  integer(tank.invulnerableTicks, 0, profile.damageProtectionTicks, "tank protection");
  integer(tank.turnTicks, 0, profile.turnTicks, "tank turn timer");
  integer(tank.jumpBufferTicks, 0, ARCADE.jumpBufferTicks, "tank jump buffer");
  integer(tank.coyoteTicks, 0, ARCADE.coyoteTicks, "tank coyote timer");
  integer(tank.disconnectedTicks, 0, profile.disconnectGraceTicks - 1, "tank disconnect grace");
  check10(tank.weapon.id === profile.definition.weaponId && tank.weapon.ammo === 0, "primary feed");
  integer(tank.weapon.cooldownTicks, 0, profile.fireCadenceTicks, "tank gun cadence");
  const gunOwner = players.find((player2) => player2.playerId === tank.lastGunOwnerId);
  check10(
    tank.weapon.shotOrdinal === 0 ? tank.weapon.lastActionInstanceId === 0 && tank.lastGunOwnerId === null && tank.lastGunControlEpoch === null : gunOwner && tank.lastGunControlEpoch !== null && tank.lastGunControlEpoch > 0 && tank.lastGunControlEpoch <= gunOwner.controlEpoch && tank.weapon.lastActionInstanceId > 0,
    "last gun owner"
  );
  const ownerId = tankOwner(tank), owner = players.find((player2) => player2.playerId === ownerId);
  check10(
    ownerId === null ? tank.ownerControlEpoch === null && tank.disconnectedTicks === 0 : owner?.life === "alive" && owner.vehicleId === tank.body.id && owner.controlEpoch === tank.ownerControlEpoch,
    "seat owner"
  );
  if (owner) {
    const seat = worldSocket(tank.body, profile.definition.seat.socket, tank.facing);
    check10(
      owner.body.x === seat.x && owner.body.y === seat.y && owner.body.vx === tank.body.vx && owner.body.vy === tank.body.vy && !owner.body.grounded && owner.body.supportId === null,
      "seat attachment"
    );
  }
  if (tank.action.kind === "ready") {
    check10(
      ["available", "occupied", "wreck"].includes(tank.lifecycle) && tank.action.actionInstanceId === 0 && tank.action.definitionId === 0 && tank.action.nextMarkerIndex === 0,
      "idle action"
    );
  } else {
    const timeline = catalog.timelines.get(tank.action.definitionId), age = tick2 - tank.action.stateStartTick;
    check10(
      timeline && age >= 0 && age < timeline.durationTicks && tank.action.nextMarkerIndex === timeline.markers.filter((marker) => marker.tickOffset <= age).length,
      "action cursor"
    );
    if (tank.lifecycle === "boarding" || tank.lifecycle === "exiting") {
      check10(
        tank.action.kind === (tank.lifecycle === "boarding" ? "enter" : "exit") && tank.action.definitionId === (tank.lifecycle === "boarding" ? profile.definition.seat.boardingTimelineId : profile.exitTimelineId) && owner && canonical(owner.action) === canonical(tank.action),
        "transfer action"
      );
    } else {
      check10(
        tank.lifecycle === "occupied" && tank.action.kind === "fire" && profile.fireTimelineIds.includes(tank.action.definitionId) && tank.action.actionInstanceId === tank.weapon.lastActionInstanceId && tank.lastGunOwnerId === ownerId,
        "gun action"
      );
    }
  }
}
function validateTankProfile(profile, shapes2, catalog) {
  if (profile.definition.kind !== "tank" || profile.definition.actorId !== profile.locomotion.id || profile.locomotion.standingShapeId !== profile.locomotion.crouchedShapeId)
    throw new Error("Invalid tank controller definition");
  integer(profile.headings.length, 8, 8, "tank headings");
  integer(profile.fireTimelineIds.length, 8, 8, "tank fire poses");
  for (const id2 of [
    profile.definition.seat.boardingSensorShapeId,
    profile.locomotion.standingShapeId
  ])
    if (!shapes2.has(id2)) throw new Error("Missing tank shape");
  for (const id2 of [
    profile.definition.seat.boardingTimelineId,
    profile.exitTimelineId,
    ...profile.fireTimelineIds
  ])
    if (!catalog.timelines.has(id2)) throw new Error("Missing tank timeline");
  for (const ticks of [
    profile.fireCadenceTicks,
    profile.turnTicks,
    profile.damageProtectionTicks,
    profile.reboardTicks,
    profile.exitProtectionTicks,
    profile.disconnectGraceTicks
  ])
    integer(ticks, 1, 120, "tank timing");
}

// src/game/content/contract-fixture.ts
var CONTRACT_FIXTURE = {
  format: 1,
  simulationHz: 60,
  shapes: [
    { id: 1, rect: { x: pixels(-7), y: pixels(-34), w: pixels(14), h: pixels(34) } },
    { id: 2, rect: { x: pixels(-7), y: pixels(-20), w: pixels(14), h: pixels(20) } },
    { id: 3, rect: { x: pixels(-5), y: pixels(-32), w: pixels(10), h: pixels(30) } },
    { id: 4, rect: { x: pixels(-1), y: pixels(-1), w: pixels(2), h: pixels(2) } },
    { id: 5, rect: { x: pixels(-40), y: pixels(-32), w: pixels(80), h: pixels(32) } },
    { id: 6, rect: { x: pixels(-24), y: pixels(-30), w: pixels(48), h: pixels(30) } }
  ],
  poses: [
    {
      id: 1,
      frame: "fixture-operative-idle",
      durationTicks: 6,
      sockets: [
        { name: "muzzle", point: { x: pixels(15), y: pixels(-23) } },
        { name: "hand", point: { x: pixels(10), y: pixels(-20) } }
      ],
      hurtShapeIds: [3]
    },
    {
      id: 2,
      frame: "fixture-tank-idle",
      durationTicks: 12,
      sockets: [
        { name: "seat", point: { x: 0, y: pixels(-20) } },
        { name: "ejection", point: { x: pixels(-40), y: 0 } }
      ],
      hurtShapeIds: [6]
    }
  ],
  timelines: [
    {
      id: 1,
      durationTicks: 6,
      poses: [1],
      markers: [{ tickOffset: 0, kind: "spawn-attack", payloadId: 1, socket: "muzzle" }]
    },
    {
      id: 2,
      durationTicks: 12,
      poses: [2],
      markers: [{ tickOffset: 11, kind: "seat-transfer", payloadId: 1, socket: "seat" }]
    }
  ],
  attacks: [
    {
      id: 1,
      kind: "swept-projectile",
      shapeId: 4,
      damage: 1,
      lifetimeTicks: 30,
      speed: pixels(12),
      maxTargets: 1,
      repeatDamageTicks: 0,
      material: "bullet"
    }
  ],
  weapons: [
    {
      id: "sidearm",
      attackId: 1,
      timelineId: 1,
      cadenceTicks: 10,
      ammoPerAction: 0,
      pickupAmmo: "unlimited",
      aimPolicy: "cardinal",
      visualFamily: "fixture-sidearm",
      audioFamily: "fixture-sidearm"
    }
  ],
  actors: [
    {
      id: 1,
      locomotion: "grounded",
      standingShapeId: 1,
      crouchedShapeId: 2,
      idlePoseId: 1,
      runSpeed: 768,
      jumpVelocity: -1430,
      gravity: 55,
      terminalVelocity: 2048
    },
    {
      id: 2,
      locomotion: "grounded",
      standingShapeId: 6,
      crouchedShapeId: 6,
      idlePoseId: 2,
      runSpeed: 640,
      jumpVelocity: -1200,
      gravity: 60,
      terminalVelocity: 2048
    }
  ],
  vehicles: [
    {
      id: 1,
      kind: "tank",
      actorId: 2,
      armor: 3,
      weaponId: "sidearm",
      seat: {
        socket: { x: 0, y: pixels(-20) },
        ejectionCandidates: [
          { x: pixels(-40), y: 0 },
          { x: pixels(40), y: 0 }
        ],
        boardingSensorShapeId: 5,
        boardingTimelineId: 2
      }
    }
  ],
  terrain: [
    {
      id: 100,
      kind: "solid",
      rect: { x: 0, y: pixels(200), w: pixels(384), h: pixels(16) },
      visibleSurfaceId: "fixture-floor"
    },
    {
      id: 101,
      kind: "one-way",
      rect: { x: pixels(100), y: pixels(145), w: pixels(80), h: pixels(8) },
      visibleSurfaceId: "fixture-platform"
    }
  ],
  encounters: [
    {
      id: 1,
      camera: { x: 0, y: 0, w: pixels(384), h: pixels(216) },
      killBounds: { x: pixels(-64), y: pixels(-64), w: pixels(512), h: pixels(320) },
      checkpoint: { x: pixels(32), y: pixels(200) },
      spawns: [
        {
          id: 102,
          actorId: 1,
          point: { x: pixels(50), y: pixels(200) },
          required: true,
          retreatAllowed: false
        }
      ],
      vehicleSpawns: [{ id: 103, definitionId: 1, point: { x: pixels(250), y: pixels(200) } }]
    }
  ]
};

// src/game/content/validate.ts
function check3(condition, message) {
  if (!condition) throw new Error(`Invalid content: ${message}`);
}
function unique2(values, label) {
  check3(values.length <= 4096, `${label} count`);
  const table = /* @__PURE__ */ new Map();
  for (const value of values) {
    if (typeof value.id === "number") integer(value.id, 1, COUNTER_LIMIT - 1, label);
    check3(!table.has(value.id), `duplicate ${label} ID ${value.id}`);
    table.set(value.id, value);
  }
  return table;
}
function point(value, local = false) {
  const maximum = local ? MAX_SHAPE : 2 ** 24;
  integer(value.x, -maximum, maximum, "point x");
  integer(value.y, -maximum, maximum, "point y");
}
function rectangle(rect, local = false) {
  if (local) validateLocalRect(rect);
  point(rect, local);
  integer(rect.w, 1, local ? MAX_SHAPE : 2 ** 24, "rectangle width");
  integer(rect.h, 1, local ? MAX_SHAPE : 2 ** 24, "rectangle height");
  position(rect.x + rect.w);
  position(rect.y + rect.h);
}
function validateContent(content) {
  canonical(content);
  check3(content.format === 1 && content.simulationHz === 60, "format/tick rate");
  const shapes2 = unique2(content.shapes, "shape");
  const poses = unique2(content.poses, "pose");
  const timelines = unique2(content.timelines, "timeline");
  const attacks = unique2(content.attacks, "attack");
  const weapons = unique2(content.weapons, "weapon");
  const actors = unique2(content.actors, "actor");
  const vehicles = unique2(content.vehicles, "vehicle");
  const entities = new Set(unique2(content.terrain, "terrain").keys());
  unique2(content.encounters, "encounter");
  for (const shape of content.shapes) rectangle(shape.rect, true);
  for (const pose of content.poses) {
    integer(pose.durationTicks, 1, 3600, "pose duration");
    check3(pose.frame.length > 0, "missing frame identity");
    check3(
      pose.sockets.length <= 8 && new Set(pose.sockets.map((socket) => socket.name)).size === pose.sockets.length,
      "duplicate/excess sockets"
    );
    for (const socket of pose.sockets) point(socket.point, true);
    check3(
      pose.hurtShapeIds.length <= 16 && pose.hurtShapeIds.every((id2) => shapes2.has(id2)),
      "unknown/excess hurt shapes"
    );
  }
  for (const timeline of content.timelines) {
    integer(timeline.durationTicks, 1, 3600, "timeline duration");
    check3(
      timeline.poses.length > 0 && timeline.poses.length <= 256 && timeline.poses.every((id2) => poses.has(id2)),
      "missing/excess timeline poses"
    );
    const duration = timeline.poses.reduce(
      (sum, id2) => sum + (poses.get(id2)?.durationTicks ?? 0),
      0
    );
    check3(duration === timeline.durationTicks, "timeline exposure duration mismatch");
    check3(timeline.markers.length <= 128, "excess markers");
    let previous = -1;
    for (const marker of timeline.markers) {
      integer(marker.tickOffset, 0, timeline.durationTicks - 1, "marker tick");
      check3(marker.tickOffset >= previous, "unordered markers");
      previous = marker.tickOffset;
      let age = marker.tickOffset;
      const pose = timeline.poses.map((id2) => poses.get(id2)).find((candidate) => {
        if (!candidate) return false;
        if (age < candidate.durationTicks) return true;
        age -= candidate.durationTicks;
        return false;
      });
      check3(
        Boolean(pose?.sockets.some((socket) => socket.name === marker.socket)),
        "missing active pose socket"
      );
      if (marker.kind === "spawn-attack" || marker.kind === "activate-hitbox")
        check3(attacks.has(marker.payloadId), "unknown marker attack");
      if (marker.kind === "seat-transfer")
        check3(vehicles.has(marker.payloadId), "unknown marker vehicle");
    }
  }
  for (const attack2 of content.attacks) {
    check3(ATTACK_MATERIALS.includes(attack2.material), "unknown attack material");
    check3(shapes2.has(attack2.shapeId), "unknown attack shape");
    motion(attack2.speed);
    integer(attack2.damage, 1, 65535, "damage");
    integer(attack2.lifetimeTicks, 1, 3600, "attack lifetime");
    integer(attack2.maxTargets, 1, 256, "attack target limit");
    integer(attack2.repeatDamageTicks, 0, 3600, "damage interval");
  }
  for (const weapon2 of content.weapons) {
    check3(
      attacks.has(weapon2.attackId) && timelines.has(weapon2.timelineId),
      "unknown weapon action"
    );
    integer(weapon2.cadenceTicks, 1, 3600, "weapon cadence");
    integer(weapon2.ammoPerAction, 0, 65535, "ammo cost");
    if (weapon2.pickupAmmo !== "unlimited")
      integer(weapon2.pickupAmmo, 1, 65535, "pickup ammunition");
    check3(
      weapon2.pickupAmmo === "unlimited" ? weapon2.ammoPerAction === 0 : weapon2.ammoPerAction > 0,
      "inconsistent ammo policy"
    );
    check3(
      weapon2.visualFamily.length > 0 && weapon2.audioFamily.length > 0,
      "missing weapon media family"
    );
  }
  for (const actor of content.actors) {
    check3(
      shapes2.has(actor.standingShapeId) && shapes2.has(actor.crouchedShapeId) && poses.has(actor.idlePoseId),
      "unknown actor shape/pose"
    );
    for (const value of [actor.runSpeed, actor.jumpVelocity, actor.gravity, actor.terminalVelocity])
      motion(value);
    check3(
      actor.runSpeed >= 0 && actor.gravity >= 0 && actor.terminalVelocity > 0 && actor.jumpVelocity <= 0,
      "actor movement signs"
    );
  }
  for (const vehicle of content.vehicles) {
    check3(
      actors.has(vehicle.actorId) && weapons.has(vehicle.weaponId) && shapes2.has(vehicle.seat.boardingSensorShapeId) && timelines.has(vehicle.seat.boardingTimelineId),
      "unknown vehicle reference"
    );
    integer(vehicle.armor, 1, 65535, "vehicle armor");
    point(vehicle.seat.socket, true);
    check3(
      vehicle.seat.ejectionCandidates.length > 0 && vehicle.seat.ejectionCandidates.length <= 8,
      "ejection candidates"
    );
    for (const candidate of vehicle.seat.ejectionCandidates) point(candidate, true);
  }
  for (const terrain of content.terrain) {
    rectangle(terrain.rect);
    check3(terrain.visibleSurfaceId.length > 0, "invisible terrain");
  }
  for (const encounter of content.encounters) {
    rectangle(encounter.camera);
    rectangle(encounter.killBounds);
    point(encounter.checkpoint);
    check3(
      encounter.spawns.length <= 256 && encounter.vehicleSpawns.length <= 16,
      "encounter entity budget"
    );
    for (const spawn of [...encounter.spawns, ...encounter.vehicleSpawns]) {
      integer(spawn.id, 1, COUNTER_LIMIT - 1, "spawn ID");
      check3(!entities.has(spawn.id), "reused world entity ID");
      entities.add(spawn.id);
      point(spawn.point);
      if ("actorId" in spawn) check3(actors.has(spawn.actorId), "unknown spawn actor");
      else check3(vehicles.has(spawn.definitionId), "unknown spawn vehicle");
    }
  }
}

// src/game/labs/foot-fixture.ts
var FOOT_SHAPES = new Map(CONTRACT_FIXTURE.shapes.map((shape) => [shape.id, shape]));
var FOOT_DEFINITION = CONTRACT_FIXTURE.actors[0];
if (!FOOT_DEFINITION) throw new Error("Missing foot fixture definition");
function footState(x = 0, y = 0) {
  return {
    body: {
      id: 1,
      x: pixels(x),
      y: pixels(y),
      vx: 0,
      vy: 0,
      remainderX: 0,
      remainderY: 0,
      shapeId: 1,
      supportId: 100,
      grounded: true,
      contacts: []
    },
    life: "alive",
    locomotion: "grounded",
    action: {
      kind: "ready",
      actionInstanceId: 0,
      stateStartTick: 0,
      definitionId: 0,
      nextMarkerIndex: 0
    },
    facing: 1,
    aim: 0,
    jumpBufferTicks: 0,
    coyoteTicks: 4,
    ignoredSupportId: null,
    ignoredSupportTicks: 0,
    vehicleId: null,
    geometryRevision: 1
  };
}
function footActor(x = 0, y = 0) {
  return {
    ...footState(x, y),
    playerId: 1,
    slot: 0,
    controlEpoch: 1,
    lifeStartTick: 0,
    bodyPresence: "present",
    invulnerableTicks: 0,
    reboardCooldownTicks: 0,
    vehicleSpecialTicks: 0,
    weapon: { id: "sidearm", ammo: 0, cooldownTicks: 0, shotOrdinal: 0, lastActionInstanceId: 0 },
    firearmAim: { pitch: 0, nextStepTick: 0 },
    grenadeStock: 10,
    grenadeCooldownTicks: 0,
    meleeCooldownTicks: 0,
    health: 1,
    lives: 3,
    lastRallyMission: 0,
    processedEdgeIds: [0, 0, 0, 0, 0]
  };
}
function footTerrain(id2, x, y, w, h, kind = "solid") {
  return {
    id: id2,
    rect: { x: pixels(x), y: pixels(y), w: pixels(w), h: pixels(h) },
    kind,
    delta: { x: 0, y: 0 }
  };
}
var FOOT_FLOOR = footTerrain(100, -200, 0, 400, 16);

// src/game/labs/combat-terrain.ts
var COMBAT_SUPPORT = [
  {
    id: 104,
    definitionId: 1,
    rect: { x: pixels(176), y: pixels(160), w: pixels(152), h: pixels(56) },
    health: 8,
    materialId: "timber"
  }
];
function combatGeometryRevision(props) {
  return 1 + props.filter((prop) => prop.health === 0).length;
}
function combatDestructibles(scenario) {
  const definition2 = materialCase(scenario);
  return definition2 ? [materialLabProp(definition2)] : scenario === "support" ? COMBAT_SUPPORT : [];
}
function materialCombatStage(world) {
  const definition2 = materialCase(world.scenario);
  if (!definition2) return;
  return {
    terrain: combatTerrain(world.scenario, world.tick + 1, world.props),
    destructibles: combatDestructibles(world.scenario),
    enemyBounds: { ...MATERIAL_CALIBRATION.bounds },
    fallBoundary: MATERIAL_CALIBRATION.fallBoundary,
    entry: { x: materialPlayerX(definition2.weapon), y: MATERIAL_CALIBRATION.targetY },
    activeEnemyIds: new Set(world.targets.map((target) => target.enemy.body.id)),
    patrolSpeed: definition2.targetMotion === "stationary" ? 0 : MATERIAL_CALIBRATION.patrolSpeed,
    extraHurtboxes: []
  };
}
var COMBAT_ORDNANCE = [
  {
    id: 102,
    shapeId: 17,
    x: pixels(24),
    y: pixels(160),
    w: pixels(240),
    h: pixels(8),
    start: 0,
    end: 50,
    dx: pixels(1),
    dy: 0
  },
  {
    id: 103,
    shapeId: 18,
    x: pixels(190),
    y: pixels(90),
    w: pixels(132),
    h: pixels(10),
    start: 55,
    end: 85,
    dx: 0,
    dy: pixels(2)
  }
];
function ordnancePlatforms(tick2) {
  integer(tick2, 0, 3601, "ordnance trajectory tick");
  return COMBAT_ORDNANCE.map((platform, i) => {
    const age = Math.max(0, Math.min(platform.end, tick2) - platform.start);
    const previous = Math.max(0, Math.min(platform.end, Math.max(0, tick2 - 1)) - platform.start);
    return {
      id: platform.id,
      x: platform.x + age * platform.dx,
      y: platform.y + age * platform.dy,
      vx: (age - previous) * platform.dx,
      vy: (age - previous) * platform.dy,
      shapeId: platform.shapeId,
      trajectoryId: i + 1,
      trajectoryTick: tick2
    };
  });
}
function combatTerrain(scenario, tick2 = 0, props = []) {
  const material = materialCase(scenario);
  if (material) {
    const definition2 = materialLabProp(material);
    if (props.length !== 1 || props[0]?.id !== definition2.id || props[0].definitionId !== definition2.definitionId)
      throw new Error("Missing material geometry state");
    return [
      footTerrain(100, 0, 200, 384, 16),
      ...props.filter((prop) => prop.health > 0).map((prop) => ({
        id: prop.id,
        kind: "solid",
        materialId: definition2.materialId,
        rect: { ...definition2.rect },
        delta: { x: 0, y: 0 }
      }))
    ];
  }
  if (scenario === "support") {
    if (props.length !== COMBAT_SUPPORT.length) throw new Error("Missing support state");
    return [
      footTerrain(100, 0, 200, 152, 16),
      ...props.filter((prop) => prop.health > 0).map((prop) => {
        const definition2 = COMBAT_SUPPORT.find((definition3) => definition3.id === prop.id);
        if (!definition2) throw new Error("Unknown support geometry");
        return {
          id: prop.id,
          kind: "solid",
          materialId: definition2.materialId,
          rect: { ...definition2.rect },
          delta: { x: 0, y: 0 }
        };
      }),
      footTerrain(105, 352, 200, 32, 16)
    ];
  }
  const terrain = [
    footTerrain(100, 0, 200, 384, 16),
    ...scenario === "wall" ? [footTerrain(101, 140, 130, 3, 70)] : []
  ];
  if (scenario === "ordnance")
    for (const [i, platform] of ordnancePlatforms(tick2).entries()) {
      const definition2 = COMBAT_ORDNANCE[i];
      if (!definition2) throw new Error("Missing ordnance platform");
      terrain.push({
        id: platform.id,
        kind: "solid",
        rect: {
          x: platform.x - platform.vx,
          y: platform.y - platform.vy,
          w: definition2.w,
          h: definition2.h
        },
        delta: { x: platform.vx, y: platform.vy }
      });
    }
  return terrain;
}
function combatEndTerrain(scenario, tick2, props = []) {
  return combatTerrain(scenario, tick2, props).map((target) => ({
    ...target,
    rect: { ...target.rect, x: target.rect.x + target.delta.x, y: target.rect.y + target.delta.y },
    delta: { x: 0, y: 0 }
  }));
}
function combatCollisionIndex(scenario, frame, props = [], terrainOverride) {
  const terrain = terrainOverride ?? combatTerrain(scenario, frame.tick, props);
  const moving = (target) => target.delta.x !== 0 || target.delta.y !== 0;
  return new CollisionIndex(
    new CollisionGrid(terrain.filter((target) => !moving(target))),
    terrain.filter(moving),
    frame
  );
}

// src/game/labs/combat-content.ts
var COMBAT_CONTENT = structuredClone(CONTRACT_FIXTURE);
COMBAT_CONTENT.shapes.push(
  { id: 7, rect: { x: pixels(-5), y: pixels(-18), w: pixels(10), h: pixels(16) } },
  { id: 8, rect: { x: pixels(5), y: pixels(-30), w: pixels(4), h: pixels(28) } },
  { id: 9, rect: { x: pixels(-10), y: pixels(-8), w: pixels(34), h: pixels(16) } },
  { id: 10, rect: { x: pixels(-3), y: pixels(-3), w: pixels(6), h: pixels(6) } },
  { id: 11, rect: { x: pixels(-48), y: pixels(-48), w: pixels(96), h: pixels(96) } },
  { id: 12, rect: { x: 0, y: pixels(-10), w: pixels(30), h: pixels(24) } },
  { id: 13, rect: { x: 0, y: pixels(-3), w: pixels(20), h: pixels(6) } },
  { id: 14, rect: { x: 0, y: pixels(-8), w: pixels(14), h: pixels(8) } },
  structuredClone(ROCKET_SHAPE),
  structuredClone(ROCKET_BLAST_SHAPE),
  structuredClone(LASER_SHAPE)
);
var sidearm = COMBAT_CONTENT.weapons[0];
var attack = COMBAT_CONTENT.attacks[0];
if (!sidearm || !attack) throw new Error("Missing baseline firearm content");
sidearm.cadenceTicks = 8;
var hmg = {
  ...sidearm,
  id: "heavy-machine-gun",
  attackId: 2,
  cadenceTicks: 5,
  ammoPerAction: 1,
  pickupAmmo: 150,
  timelineId: 14,
  visualFamily: "fixture-hmg",
  audioFamily: "fixture-hmg"
};
COMBAT_CONTENT.weapons.push(hmg);
COMBAT_CONTENT.attacks.push({ ...attack, id: 2, speed: pixels(18) });
var HMG_SWEEP = {
  stepTicks: 2,
  headings: [
    [-4, 16, 2, 0, 0, 4608],
    [-3, 200, 6, -7, 1763, 4257],
    [-2, 201, 11, -12, 3258, 3258],
    [-1, 202, 14, -17, 4257, 1763],
    [0, 14, 15, -23, 4608, 0],
    [1, 203, 14, -29, 4257, -1763],
    [2, 204, 11, -34, 3258, -3258],
    [3, 205, 6, -37, 1763, -4257],
    [4, 15, 2, -38, 0, -4608]
  ].map(([pitch = 0, timelineId = 0, x = 0, y = 0, vx = 0, vy = 0]) => ({
    pitch,
    timelineId,
    muzzle: { x: pixels(x), y: pixels(y) },
    velocity: { x: vx, y: vy }
  }))
};
var shotgun = {
  ...sidearm,
  id: "shotgun",
  attackId: 10,
  cadenceTicks: 28,
  ammoPerAction: 1,
  pickupAmmo: 24,
  visualFamily: "fixture-shotgun",
  audioFamily: "fixture-shotgun"
};
var flame = {
  ...sidearm,
  id: "flamethrower",
  attackId: 11,
  cadenceTicks: 30,
  ammoPerAction: 1,
  pickupAmmo: 30,
  visualFamily: "fixture-flame",
  audioFamily: "fixture-flame"
};
var rocket = structuredClone(ROCKET_WEAPON);
var laser = structuredClone(LASER_WEAPON);
COMBAT_CONTENT.weapons.push(shotgun, flame, rocket, laser);
COMBAT_CONTENT.attacks.push(
  structuredClone(ROCKET_ATTACK),
  structuredClone(LASER_ATTACK),
  {
    id: 10,
    kind: "shot-volume",
    shapeId: 13,
    damage: 4,
    lifetimeTicks: 6,
    speed: 0,
    maxTargets: 16,
    repeatDamageTicks: 0,
    material: "bullet"
  },
  {
    id: 11,
    kind: "flame-volumes",
    shapeId: 14,
    damage: 1,
    lifetimeTicks: 30,
    speed: 0,
    maxTargets: 16,
    repeatDamageTicks: 6,
    material: "heat"
  }
);
var AREA_PROFILES = /* @__PURE__ */ new Map([
  [
    10,
    {
      kind: "shot-volume",
      emissionOffsets: [0],
      attachedTicks: 0,
      maximumReach: pixels(110),
      frames: [20, 40, 60, 80, 100, 110].map((length2, age) => ({
        x: 0,
        y: -pixels(3 + age * 2),
        w: pixels(length2),
        h: pixels(6 + age * 4)
      }))
    }
  ],
  [
    11,
    {
      kind: "flame-volumes",
      emissionOffsets: [0, 6, 12],
      attachedTicks: 6,
      maximumReach: pixels(90),
      frames: Array.from({ length: 18 }, (_, age) => {
        const width = age < 6 ? [14, 18, 24, 28, 32, 36][age] ?? 0 : 36;
        const height = age < 6 ? 8 + Math.min(age, 3) * 2 : age < 14 ? 14 : 10;
        return {
          x: age < 6 ? 0 : (age - 5) * (pixels(4) + 128),
          y: pixels((age < 6 ? [-4, -2, 0, 2, 4, 2][age] ?? 0 : 2) - height / 2),
          w: pixels(width),
          h: pixels(height)
        };
      })
    }
  ]
]);
var FOOT_ACTION_PROFILES = {
  melee: { timelineIds: [40, 41], cooldownTicks: 18 },
  grenade: { timelineIds: [50, 51], cooldownTicks: 20 }
};
var GRENADE_PROFILE = {
  bodyShapeId: 10,
  fuseTicks: 90,
  gravity: 55,
  terminalVelocity: 2048,
  maximumBounces: 3,
  radius: pixels(48),
  standingVelocity: { x: pixels(2) + 128, y: -pixels(4) - 128 },
  crouchedVelocity: { x: pixels(4), y: -pixels(1) - 128 },
  inheritedVelocityLimit: { x: pixels(8), y: pixels(8) }
};
COMBAT_CONTENT.attacks.push(
  {
    id: 4,
    kind: "melee",
    shapeId: 9,
    damage: 1,
    lifetimeTicks: 4,
    speed: 0,
    maxTargets: 4,
    repeatDamageTicks: 0,
    material: "blade"
  },
  {
    id: 5,
    kind: "explosion",
    shapeId: 11,
    damage: 1,
    lifetimeTicks: GRENADE_PROFILE.fuseTicks,
    speed: GRENADE_PROFILE.standingVelocity.x,
    maxTargets: 16,
    repeatDamageTicks: 0,
    material: "explosive"
  }
);
for (const kind of ["melee", "grenade"]) {
  const profile = FOOT_ACTION_PROFILES[kind];
  for (const [stance, id2] of profile.timelineIds.entries()) {
    const durations = kind === "melee" ? [5, 4, 9] : [4, 1, 15];
    const poseIds = [id2, id2 + 2, id2 + 4];
    for (const [phase, poseId] of poseIds.entries())
      COMBAT_CONTENT.poses.push({
        id: poseId,
        frame: `engineering-${kind}-${stance}-${phase}`,
        durationTicks: durations[phase] ?? 0,
        sockets: [
          {
            name: "hand",
            point: { x: pixels(10), y: pixels(stance === 1 ? -12 : kind === "melee" ? -20 : -24) }
          }
        ],
        hurtShapeIds: [stance === 1 ? 7 : 3]
      });
    COMBAT_CONTENT.timelines.push({
      id: id2,
      durationTicks: profile.cooldownTicks,
      poses: poseIds,
      markers: [
        {
          tickOffset: durations[0] ?? 0,
          kind: kind === "melee" ? "activate-hitbox" : "spawn-attack",
          payloadId: kind === "melee" ? 4 : 5,
          socket: "hand"
        },
        {
          tickOffset: durations[0] ?? 0,
          kind: "sound",
          payloadId: kind === "melee" ? 4 : 5,
          socket: "hand"
        }
      ]
    });
  }
}
var RIFLE_PROFILE = {
  timelineIds: [30, 31],
  raiseTicks: 24,
  lastReleaseTick: 36,
  range: pixels(240),
  upAlignment: pixels(24),
  upHeight: pixels(48),
  aimHeight: pixels(16)
};
COMBAT_CONTENT.attacks.push({ ...attack, id: 3, speed: pixels(3), lifetimeTicks: 150 });
for (const [aim, id2] of RIFLE_PROFILE.timelineIds.entries()) {
  const muzzle = aim === 0 ? { x: pixels(15), y: pixels(-23) } : { x: pixels(2), y: pixels(-36) };
  const poseIds = [id2, id2 + 2, id2 + 4];
  for (const [phase, poseId] of poseIds.entries())
    COMBAT_CONTENT.poses.push({
      id: poseId,
      frame: `engineering-rifle-${aim}-${phase}`,
      durationTicks: [24, 13, 35][phase] ?? 0,
      sockets: [
        { name: "muzzle", point: muzzle },
        { name: "hand", point: { x: 0, y: pixels(-23) } }
      ],
      hurtShapeIds: [3]
    });
  COMBAT_CONTENT.timelines.push({
    id: id2,
    durationTicks: 72,
    poses: poseIds,
    markers: [24, 30, 36].flatMap((tickOffset) => [
      { tickOffset, kind: "spawn-attack", payloadId: 3, socket: "muzzle" },
      { tickOffset, kind: "sound", payloadId: 3, socket: "muzzle" }
    ])
  });
}
var SHIELD_PROFILE = {
  timelineIds: { brace: 100, advance: 101, turn: 102, bash: 103, stunned: 104 },
  integrity: 2,
  speed: pixels(1),
  sightRange: pixels(384),
  bashRange: pixels(29),
  bashHeight: pixels(24),
  bashActiveTick: 12,
  bashActiveTicks: 4,
  damageByMaterial: { bullet: 0, explosive: 2, heat: 1, energy: 1, blade: 0, blunt: 1 }
};
COMBAT_CONTENT.attacks.push({
  id: 6,
  kind: "melee",
  shapeId: 12,
  damage: 1,
  lifetimeTicks: 4,
  speed: 0,
  maxTargets: 4,
  repeatDamageTicks: 0,
  material: "blunt"
});
for (const [index, durationTicks] of [24, 36, 9, 9, 12, 4, 14, 36].entries())
  COMBAT_CONTENT.poses.push({
    id: 100 + index,
    frame: `engineering-shield-${index}`,
    durationTicks,
    sockets: [{ name: "hand", point: { x: 0, y: pixels(-18) } }],
    hurtShapeIds: [3]
  });
COMBAT_CONTENT.timelines.push(
  { id: 100, durationTicks: 24, poses: [100], markers: [] },
  { id: 101, durationTicks: 36, poses: [101], markers: [] },
  {
    id: 102,
    durationTicks: 18,
    poses: [102, 103],
    markers: [
      { tickOffset: 9, kind: "face", payloadId: 1, socket: "hand" },
      { tickOffset: 9, kind: "sound", payloadId: 8, socket: "hand" }
    ]
  },
  {
    id: 103,
    durationTicks: 30,
    poses: [104, 105, 106],
    markers: [
      { tickOffset: 12, kind: "activate-hitbox", payloadId: 6, socket: "hand" },
      { tickOffset: 12, kind: "sound", payloadId: 6, socket: "hand" }
    ]
  },
  {
    id: 104,
    durationTicks: 36,
    poses: [107],
    markers: [{ tickOffset: 0, kind: "sound", payloadId: 7, socket: "hand" }]
  }
);
var profiles = [];
for (const [index, weapon2] of [sidearm, hmg, shotgun, flame, rocket, laser].entries()) {
  const base = weapon2.id === "laser" ? LASER_WEAPON.timelineId : weapon2.id === "rocket-launcher" ? ROCKET_WEAPON.timelineId : 10 + index * 4;
  const timelineIds = [base, base + 1, base + 2, base + 3];
  weapon2.timelineId = base;
  const duration = weapon2.id === "laser" ? LASER_WEAPON.cadenceTicks : weapon2.id === "flamethrower" ? 30 : weapon2.id === "shotgun" || weapon2.id === "rocket-launcher" ? 12 : 4;
  const emissions = AREA_PROFILES.get(weapon2.attackId)?.emissionOffsets ?? [0];
  for (const [poseIndex, id2] of timelineIds.entries()) {
    const muzzle = (weapon2.id === "heavy-machine-gun" && poseIndex !== 3 ? HMG_SWEEP.headings.find((heading) => heading.timelineId === id2)?.muzzle : void 0) ?? [
      { x: pixels(15), y: pixels(-23) },
      { x: pixels(2), y: pixels(-36) },
      { x: pixels(2), y: 0 },
      { x: pixels(15), y: pixels(-12) }
    ][poseIndex];
    if (!muzzle) throw new Error("Missing firearm socket");
    COMBAT_CONTENT.poses.push({
      id: id2,
      frame: `engineering-${weapon2.id}-${poseIndex}`,
      durationTicks: duration,
      sockets: [
        { name: "muzzle", point: muzzle },
        { name: "hand", point: { x: 0, y: poseIndex === 3 ? pixels(-12) : pixels(-23) } }
      ],
      hurtShapeIds: [poseIndex === 3 ? 7 : 3]
    });
    COMBAT_CONTENT.timelines.push({
      id: id2,
      durationTicks: duration,
      poses: [id2],
      markers: [
        ...emissions.flatMap((tickOffset) => [
          {
            tickOffset,
            kind: "spawn-attack",
            payloadId: weapon2.attackId,
            socket: "muzzle"
          },
          {
            tickOffset,
            kind: "sound",
            payloadId: weapon2.attackId,
            socket: "muzzle"
          }
        ]),
        ...["flamethrower", "laser"].includes(weapon2.id) ? [] : [
          {
            tickOffset: 2,
            kind: "sound",
            payloadId: weapon2.attackId,
            socket: "hand"
          }
        ]
      ]
    });
  }
  profiles.push({
    weapon: weapon2,
    timelineIds,
    ...weapon2.id === "heavy-machine-gun" ? { sweep: HMG_SWEEP } : {}
  });
}
for (const heading of HMG_SWEEP.headings.filter((heading2) => heading2.timelineId >= 200)) {
  const reference = COMBAT_CONTENT.timelines.find((timeline) => timeline.id === 14);
  if (!reference) throw new Error("Missing HMG timing");
  COMBAT_CONTENT.poses.push({
    id: heading.timelineId,
    frame: `engineering-heavy-machine-gun-pitch-${heading.pitch}`,
    durationTicks: reference.durationTicks,
    sockets: [
      { name: "muzzle", point: heading.muzzle },
      { name: "hand", point: { x: 0, y: pixels(-23) } }
    ],
    hurtShapeIds: [3]
  });
  COMBAT_CONTENT.timelines.push({
    ...structuredClone(reference),
    id: heading.timelineId,
    poses: [heading.timelineId]
  });
}
var tankActor = {
  id: 2,
  locomotion: "grounded",
  standingShapeId: 15,
  crouchedShapeId: 15,
  idlePoseId: 130,
  runSpeed: pixels(3),
  jumpVelocity: -pixels(5),
  gravity: 64,
  terminalVelocity: pixels(8)
};
var tankDefinition = {
  id: 1,
  kind: "tank",
  actorId: 2,
  armor: 3,
  weaponId: "heavy-machine-gun",
  seat: {
    socket: { x: 0, y: -pixels(6) },
    ejectionCandidates: [
      { x: pixels(30), y: 0 },
      { x: -pixels(30), y: 0 },
      { x: 0, y: -pixels(38) }
    ],
    boardingSensorShapeId: 16,
    boardingTimelineId: 130
  }
};
var TANK_PROFILE = {
  definition: tankDefinition,
  locomotion: tankActor,
  exitTimelineId: 131,
  fireTimelineIds: Array.from({ length: 8 }, (_, i) => 140 + i),
  attackId: 16,
  fireCadenceTicks: 5,
  turnTicks: 3,
  damageProtectionTicks: 30,
  reboardTicks: 30,
  exitProtectionTicks: 12,
  disconnectGraceTicks: 15,
  fallBoundary: pixels(248),
  hardpoint: { x: 0, y: -pixels(24) },
  headings: [
    [26, -24, 20, 0],
    [20, -44, 14, -14],
    [0, -50, 0, -20],
    [-20, -44, -14, -14],
    [-26, -24, -20, 0],
    [-20, -4, -14, 14],
    [0, 2, 0, 20],
    [20, -4, 14, 14]
  ].map(([x = 0, y = 0, vx = 0, vy = 0]) => ({
    muzzle: { x: pixels(x), y: pixels(y) },
    velocity: { x: pixels(vx), y: pixels(vy) }
  }))
};
COMBAT_CONTENT.actors = COMBAT_CONTENT.actors.map((actor) => actor.id === 2 ? tankActor : actor);
COMBAT_CONTENT.vehicles = [tankDefinition];
COMBAT_CONTENT.shapes.push(
  { id: 15, rect: { x: -pixels(20), y: -pixels(24), w: pixels(40), h: pixels(24) } },
  { id: 16, rect: { x: -pixels(40), y: -pixels(40), w: pixels(80), h: pixels(40) } }
);
COMBAT_CONTENT.attacks.push({
  id: 16,
  kind: "swept-projectile",
  shapeId: 4,
  damage: 1,
  lifetimeTicks: 40,
  speed: pixels(20),
  maxTargets: 1,
  repeatDamageTicks: 0,
  material: "bullet"
});
for (const [id2, duration] of [
  [130, 12],
  [131, 8]
]) {
  COMBAT_CONTENT.poses.push({
    id: id2,
    frame: `engineering-tank-${id2 === 130 ? "board" : "exit"}`,
    durationTicks: duration,
    sockets: [
      { name: "seat", point: tankDefinition.seat.socket },
      { name: "ejection", point: { x: pixels(30), y: 0 } }
    ],
    hurtShapeIds: [15]
  });
  COMBAT_CONTENT.timelines.push({
    id: id2,
    durationTicks: duration,
    poses: [id2],
    markers: [
      {
        tickOffset: duration - 1,
        kind: "seat-transfer",
        payloadId: 1,
        socket: id2 === 130 ? "seat" : "ejection"
      }
    ]
  });
}
for (const [heading, exposure] of TANK_PROFILE.headings.entries()) {
  const id2 = 140 + heading;
  COMBAT_CONTENT.poses.push({
    id: id2,
    frame: `engineering-tank-fire-${heading}`,
    durationTicks: 3,
    sockets: [{ name: "muzzle", point: exposure.muzzle }],
    hurtShapeIds: [15]
  });
  COMBAT_CONTENT.timelines.push({
    id: id2,
    durationTicks: 3,
    poses: [id2],
    markers: [
      { tickOffset: 0, kind: "spawn-attack", payloadId: 16, socket: "muzzle" },
      { tickOffset: 0, kind: "sound", payloadId: 16, socket: "muzzle" }
    ]
  });
}
for (const platform of COMBAT_ORDNANCE)
  COMBAT_CONTENT.shapes.push({
    id: platform.shapeId,
    rect: { x: 0, y: 0, w: platform.w, h: platform.h }
  });
validateContent(COMBAT_CONTENT);
for (const [id2, profile] of AREA_PROFILES) {
  const definition2 = COMBAT_CONTENT.attacks.find((attack2) => attack2.id === id2);
  if (!definition2) throw new Error("Missing area attack definition");
  validateAreaProfile(profile, definition2);
}
var COMBAT_CATALOG = {
  firearms: new Map(profiles.map((profile) => [profile.weapon.id, profile])),
  timelines: new Map(COMBAT_CONTENT.timelines.map((timeline) => [timeline.id, timeline])),
  poses: new Map(COMBAT_CONTENT.poses.map((pose) => [pose.id, pose]))
};
var COMBAT_SHAPES = new Map(COMBAT_CONTENT.shapes.map((shape) => [shape.id, shape]));
for (const profile of profiles) validateFirearmSweep(profile, COMBAT_CATALOG);
validateTankProfile(TANK_PROFILE, COMBAT_SHAPES, COMBAT_CATALOG);
var COMBAT_ATTACKS = new Map(
  COMBAT_CONTENT.attacks.map((definition2) => [definition2.id, definition2])
);

// src/game/labs/combat-pickups.ts
var SUPPLIES = [
  { weaponId: "heavy-machine-gun", ammo: 150, x: 90 },
  { weaponId: "shotgun", ammo: 24, x: 145 },
  { weaponId: "flamethrower", ammo: 30, x: 200 },
  { weaponId: "rocket-launcher", ammo: 20, x: 255 },
  { weaponId: "laser", ammo: 120, x: 310 }
];
function combatPickupDefinitions(scenario, players) {
  integer(players, 1, 4, "combat supply party size");
  if (scenario !== "pickups" && scenario !== "support") return [];
  const definition2 = (id2, sourceId, weaponId, ammo, x, y, supportId, expiresTick = 3600) => ({
    id: id2,
    claimId: id2,
    sourceId,
    kind: "weapon",
    weaponId,
    ammo,
    ammoLimit: ammo,
    activationTick: 1,
    expiresTick,
    supportId,
    rect: { x: pixels(x - 12), y: pixels(y - 23), w: pixels(24), h: pixels(23) }
  });
  if (scenario === "support") return [definition2(620, 505, "shotgun", 24, 250, 160, 104)];
  return [
    ...SUPPLIES.flatMap(
      (supply, station) => Array.from(
        { length: players },
        (_, slot) => definition2(
          600 + station * 4 + slot,
          500 + station,
          supply.weaponId,
          supply.ammo,
          supply.x,
          200,
          100
        )
      )
    ),
    // The rear item expires while the group travels forward, independently of any claim.
    definition2(621, 506, "shotgun", 24, 12, 200, 100, 24)
  ];
}

// src/game/labs/combat-scenarios.ts
var COMBAT_SCENARIOS = [
  "range",
  "wall",
  "shield",
  "rifle",
  "guard",
  "shotgun",
  "flame",
  "tank",
  "ordnance",
  "hmg",
  "support",
  "rocket",
  "laser",
  "pickups",
  ...MATERIAL_SCENARIOS
];
function isCombatScenario(value) {
  return typeof value === "string" && COMBAT_SCENARIOS.some((scenario) => scenario === value);
}
function combatScenarioId(scenario) {
  const id2 = COMBAT_SCENARIOS.indexOf(scenario) + 1;
  if (id2 === 0) throw new Error("Unknown combat scenario");
  return id2;
}
function combatScenarioFromId(id2) {
  integer(id2, 1, COMBAT_SCENARIOS.length, "registered combat scenario");
  const scenario = COMBAT_SCENARIOS[id2 - 1];
  if (!scenario) throw new Error("Missing combat scenario content");
  return scenario;
}

// src/game/labs/combat-tanks.ts
var neutral = { held: 0, jumpPressed: false, firePressed: false };
function exitShape() {
  const shape = FOOT_DEFINITION && COMBAT_SHAPES.get(FOOT_DEFINITION.standingShapeId);
  if (!shape) throw new Error("Missing tank ejection shape");
  return shape;
}
function releaseCombatTank(world, tank, reason, changes, lifeNotices, index, frame) {
  const id2 = tankOwner(tank);
  if (reason === "destroyed") tank.armor = 0;
  if (id2 === null) {
    if (reason === "destroyed") tank.controlEpoch = nextCounter(tank.controlEpoch);
    tank.lifecycle = tank.armor === 0 ? "wreck" : "available";
    tank.action = idleTankAction(frame.tick);
    if (tank.armor === 0) tank.body.vx = tank.body.vy = tank.invulnerableTicks = 0;
    return;
  }
  const slot = world.players.findIndex((player2) => player2.playerId === id2);
  const actor = world.players[slot];
  if (!actor) throw new Error("Missing tank release owner");
  const safe = releaseTank(tank, actor, frame.tick, TANK_PROFILE, exitShape(), index, frame);
  if (tank.armor === 0) tank.body.vx = tank.body.vy = tank.invulnerableTicks = 0;
  changes.set(id2, reason);
  if (!safe || tank.body.y > TANK_PROFILE.fallBoundary) {
    const death = damagePlayer(actor, frame.tick, 1, "classic", "fall");
    world.players[slot] = death.actor;
    if (death.notice) lifeNotices.push(death.notice);
  }
}
function advanceCombatTanks(world, commands, connections, changes, lifeNotices, index, frame) {
  const outcomes = /* @__PURE__ */ new Map();
  for (const player2 of world.players) {
    if (player2.vehicleId !== null && !world.tanks.some(
      (tank) => tank.body.id === player2.vehicleId && tankOwner(tank) === player2.playerId
    ))
      throw new Error("Combat vehicle owner mismatch");
    outcomes.set(player2.playerId, { jumpAccepted: false, interact: "none" });
  }
  for (const [tankIndex, before] of world.tanks.entries()) {
    if (before.lifecycle === "wreck") continue;
    const id2 = tankOwner(before), actor = world.players.find((player2) => player2.playerId === id2), slot = actor?.slot;
    const connected = id2 !== null && connections.connectedPlayerIds.includes(id2);
    const forced = id2 !== null && connections.releasePlayerIds.includes(id2);
    const intent = connected && !forced && slot !== void 0 ? commands[slot] ?? neutral : neutral;
    const moved = moveTank(before, intent, TANK_PROFILE, COMBAT_SHAPES, index, frame);
    const tank = moved.tank;
    world.tanks[tankIndex] = tank;
    if (actor) attachTankDriver(tank, actor, TANK_PROFILE);
    if (moved.fault && moved.fault.reason !== "crushed")
      throw new Error(`Combat tank: ${moved.fault.reason}`);
    if (moved.fault || tank.body.y > TANK_PROFILE.fallBoundary) {
      releaseCombatTank(world, tank, "destroyed", changes, lifeNotices, index, frame);
      continue;
    }
    if (id2 === null || !actor) continue;
    tank.disconnectedTicks = connected ? 0 : tank.disconnectedTicks + 1;
    if (forced || tank.disconnectedTicks >= TANK_PROFILE.disconnectGraceTicks) {
      releaseCombatTank(world, tank, "disconnect", changes, lifeNotices, index, frame);
      continue;
    }
    const outcome = outcomes.get(id2);
    if (outcome) outcome.jumpAccepted = moved.jumpAccepted;
    const transfer = stepTankTransfer(
      tank,
      actor,
      frame.tick,
      TANK_PROFILE,
      COMBAT_CATALOG,
      exitShape(),
      index,
      frame
    );
    if (transfer) changes.set(id2, transfer === "board" ? "board" : "exit");
  }
  for (const actor of [...world.players].sort((a, b) => a.slot - b.slot)) {
    const command2 = commands[actor.slot], outcome = outcomes.get(actor.playerId);
    if (!command2?.interactPressed || !outcome) continue;
    outcome.interact = "unavailable";
    if (changes.has(actor.playerId) || !connections.connectedPlayerIds.includes(actor.playerId))
      continue;
    const owned = world.tanks.find((tank) => tankOwner(tank) === actor.playerId);
    if (owned) {
      if (requestTankExit(
        owned,
        actor,
        frame.tick,
        world.nextActionId,
        TANK_PROFILE,
        exitShape(),
        index,
        frame
      )) {
        changes.set(actor.playerId, "exit");
        world.nextActionId = nextCounter(world.nextActionId);
        outcome.interact = "applied";
      }
    } else {
      const candidates = [...world.tanks].sort(
        (a, b) => Math.abs(a.body.x - actor.body.x) + Math.abs(a.body.y - actor.body.y) - Math.abs(b.body.x - actor.body.x) - Math.abs(b.body.y - actor.body.y) || a.body.id - b.body.id
      );
      for (const tank of candidates) {
        if (!reserveTank(
          tank,
          actor,
          frame.tick,
          world.nextActionId,
          TANK_PROFILE,
          COMBAT_SHAPES,
          index,
          frame
        ))
          continue;
        changes.set(actor.playerId, "board");
        world.nextActionId = nextCounter(world.nextActionId);
        outcome.interact = "applied";
        break;
      }
    }
  }
  return outcomes;
}
function fireCombatTanks(world, commands, changes, terrain) {
  const outcomes = /* @__PURE__ */ new Map();
  for (const tank of world.tanks) {
    const ownerId = tank.occupantId;
    if (ownerId === null) continue;
    const actor = world.players.find((player2) => player2.playerId === ownerId), command2 = actor && commands[actor.slot];
    if (!actor || !command2) throw new Error("Missing tank fire owner");
    const changed2 = changes.has(ownerId);
    const result = stepTankGun(
      tank,
      changed2 ? neutral : command2,
      world.tick,
      world.nextActionId,
      TANK_PROFILE,
      COMBAT_CATALOG
    );
    world.nextActionId = result.nextActionId;
    outcomes.set(
      ownerId,
      changed2 && (command2.firePressed || command2.held & Held.Fire) ? "unavailable" : result.outcome
    );
    for (const item of result.markers) {
      const socket = item.pose.sockets.find((socket2) => socket2.name === "muzzle"), definition2 = COMBAT_ATTACKS.get(item.marker.payloadId), heading = TANK_PROFILE.headings[TANK_PROFILE.fireTimelineIds.indexOf(tank.action.definitionId)], shape = definition2 && COMBAT_SHAPES.get(definition2.shapeId);
      if (!socket || !definition2 || !shape || !heading)
        throw new Error("Missing tank release content");
      const point2 = worldSocket(tank.body, socket.point, 1);
      const notice2 = {
        kind: "sound",
        ownerId,
        actionInstanceId: item.actionInstanceId,
        markerIndex: item.markerIndex,
        source: {
          definitionId: definition2.id,
          controlEpoch: actor.controlEpoch,
          shotOrdinal: tank.weapon.shotOrdinal,
          vehicleId: tank.body.id
        },
        position: point2,
        impact: null,
        targetId: null,
        beam: null
      };
      if (item.marker.kind === "spawn-attack") {
        notice2.kind = "shot";
        if (muzzleBlocked(worldSocket(tank.body, TANK_PROFILE.hardpoint, 1), point2, shape, terrain))
          notice2.kind = "muzzle-blocked";
        else {
          if (world.projectiles.length >= 256)
            throw new Error("Tank projectile cap requires recovery");
          world.projectiles.push({
            id: world.nextEntityId,
            ownerId,
            team: 1,
            actionInstanceId: item.actionInstanceId,
            definitionId: definition2.id,
            position: point2,
            velocity: { ...heading.velocity },
            spawnTick: world.tick
          });
          world.nextEntityId = nextCounter(world.nextEntityId);
        }
      } else if (item.marker.kind !== "sound") throw new Error("Unsupported tank gun marker");
      world.events.push(notice2);
    }
  }
  return outcomes;
}
function tankCombatHurtboxes(tanks, previous = tanks) {
  return tanks.flatMap((tank, i) => {
    if (tank.armor === 0) return [];
    const before = previous[i], shape = COMBAT_SHAPES.get(tank.body.shapeId);
    if (!before || before.body.id !== tank.body.id || !shape)
      throw new Error("Tank hurtbox identity");
    return [
      {
        id: tank.body.id * 2,
        entityId: tank.body.id,
        team: 1,
        kind: "body",
        rect: worldRect(before.body, shape.rect, tank.facing),
        delta: { x: tank.body.x - before.body.x, y: tank.body.y - before.body.y }
      }
    ];
  });
}
function commitCombatSeats(current, world, changes) {
  return [...changes].sort(([a], [b]) => a - b).map(([playerId, reason]) => {
    const before = current.players.find((actor2) => actor2.playerId === playerId), actor = world.players.find((actor2) => actor2.playerId === playerId);
    if (!before || !actor) throw new Error("Missing seat transfer generation");
    actor.controlEpoch = nextCounter(before.controlEpoch);
    const tank = world.tanks.find((tank2) => tankOwner(tank2) === playerId);
    if (tank) tank.ownerControlEpoch = actor.controlEpoch;
    return {
      kind: "seat",
      playerId,
      vehicleId: actor.vehicleId,
      controlEpoch: actor.controlEpoch,
      reason
    };
  });
}

// src/game/labs/combat.ts
var COMBAT_LAB_LIMIT = 3600;
var COMBAT_ENTRY = {
  firstX: pixels(45),
  slotSpacing: pixels(4),
  y: pixels(200),
  fallBoundary: pixels(248)
};
var COMBAT_TANK_DEPOT = {
  firstPlayerX: pixels(36),
  slotSpacing: pixels(56),
  vehicleOffsetX: pixels(24),
  y: pixels(200)
};
function combatEntryContext(actor, index, frame, scenario = "range") {
  if (!FOOT_DEFINITION) throw new Error("Missing life physics definition");
  const shape = COMBAT_SHAPES.get(FOOT_DEFINITION.standingShapeId);
  if (!shape) throw new Error("Missing life entry shape");
  const lift = scenario === "ordnance" ? index.get(COMBAT_ORDNANCE[0].id)?.rect : void 0;
  const material = materialCase(scenario);
  return {
    shape,
    definition: FOOT_DEFINITION,
    shapes: COMBAT_SHAPES,
    fallBoundary: COMBAT_ENTRY.fallBoundary,
    anchors: [
      {
        x: material ? materialPlayerX(material.weapon) + actor.slot * COMBAT_ENTRY.slotSpacing : scenario === "tank" ? COMBAT_TANK_DEPOT.firstPlayerX + actor.slot * COMBAT_TANK_DEPOT.slotSpacing : COMBAT_ENTRY.firstX + actor.slot * COMBAT_ENTRY.slotSpacing + (lift ? lift.x - pixels(24) : 0),
        y: lift?.y ?? COMBAT_ENTRY.y
      }
    ],
    index,
    frame
  };
}
function combatEncounterDefinition(world) {
  return {
    id: 1,
    participants: world.players.map((player2) => player2.playerId),
    members: world.targets.map(({ enemy }) => ({
      id: enemy.body.id,
      required: true,
      critical: false,
      retreatAllowed: false,
      watchdogTicks: 600,
      ambientCleanupTicks: null
    })),
    objectives: []
  };
}
function lifecycle(world) {
  return new EncounterLifecycle(combatEncounterDefinition(world));
}
function createCombatLab(scenario, count = 1) {
  if (!isCombatScenario(scenario)) throw new Error("Unknown combat scenario");
  const material = materialCase(scenario);
  integer(count, 1, 4, "combat players");
  const players = Array.from({ length: count }, (_, slot) => {
    const actor = footActor(
      material ? materialPlayerX(material.weapon) / 256 : scenario === "tank" ? (COMBAT_TANK_DEPOT.firstPlayerX + slot * COMBAT_TANK_DEPOT.slotSpacing) / 256 : 45 + slot * 4,
      scenario === "ordnance" ? 160 : 200
    );
    actor.playerId = actor.body.id = slot + 1;
    actor.slot = slot;
    if (scenario === "ordnance") actor.body.supportId = 102;
    if (slot === 1 && scenario !== "pickups")
      actor.weapon = { ...actor.weapon, id: "heavy-machine-gun", ammo: 150 };
    if (scenario === "hmg") actor.weapon = { ...actor.weapon, id: "heavy-machine-gun", ammo: 150 };
    if (scenario === "shotgun") actor.weapon = { ...actor.weapon, id: "shotgun", ammo: 24 };
    if (scenario === "flame") actor.weapon = { ...actor.weapon, id: "flamethrower", ammo: 30 };
    if (scenario === "rocket") actor.weapon = { ...actor.weapon, id: "rocket-launcher", ammo: 20 };
    if (scenario === "laser") actor.weapon = { ...actor.weapon, id: "laser", ammo: 120 };
    if (material) {
      const weapon2 = COMBAT_CONTENT.weapons.find(
        (weapon3) => weapon3.id === (material.weapon === "knife" || material.weapon === "grenade" ? "sidearm" : material.weapon)
      );
      if (!weapon2) throw new Error("Missing material weapon content");
      actor.weapon = {
        ...actor.weapon,
        id: weapon2.id,
        ammo: weapon2.pickupAmmo === "unlimited" ? 0 : weapon2.pickupAmmo
      };
    }
    return actor;
  });
  const props = combatDestructibles(scenario).map(createDestructible);
  const targets2 = Array.from({ length: 2 }, (_, index) => ({
    enemy: {
      body: {
        ...footActor(
          material ? (MATERIAL_CALIBRATION.firstTargetX + index * MATERIAL_CALIBRATION.targetSpacing) / 256 : scenario === "support" ? 220 + index * 60 : scenario === "ordnance" ? 340 + index * 26 : scenario === "tank" ? 300 + index * 40 : scenario === "shotgun" ? 140 + index * 30 : (scenario === "guard" || scenario === "flame") && index === 0 ? 140 : scenario === "flame" ? 220 : 220 + index * 60,
          scenario === "support" ? 160 : 200
        ).body,
        ...scenario === "support" ? { supportId: 104 } : {},
        id: 20 + index
      },
      facing: -1,
      geometryRevision: 1,
      life: "alive",
      removalReason: null,
      turns: 0
    },
    health: material ? MATERIAL_CALIBRATION.targetHealth : 1,
    shield: scenario === "shield" && index === 0,
    rifle: scenario === "tank" || scenario === "rifle" || (scenario === "guard" || scenario === "flame" || scenario === "support") && index === 1 ? createRifleState() : null,
    guard: (scenario === "guard" || scenario === "flame" || scenario === "support") && index === 0 ? createShieldState(SHIELD_PROFILE) : null
  }));
  return {
    format: 14,
    scenario,
    tick: 0,
    nextActionId: 1,
    nextEntityId: 1e3,
    eventSequence: 0,
    players,
    tanks: scenario === "tank" ? players.map(
      (actor) => createTank(
        30 + actor.slot,
        {
          x: COMBAT_TANK_DEPOT.firstPlayerX + actor.slot * COMBAT_TANK_DEPOT.slotSpacing + COMBAT_TANK_DEPOT.vehicleOffsetX,
          y: COMBAT_TANK_DEPOT.y
        },
        100,
        TANK_PROFILE
      )
    ) : [],
    targets: targets2,
    props,
    pickups: createWeaponPickups(
      combatPickupDefinitions(scenario, count),
      COMBAT_CATALOG,
      combatTerrain(scenario, 0, props)
    ),
    pickupClaims: [],
    projectiles: [],
    rockets: [],
    beams: [],
    strikes: [],
    grenades: [],
    areas: [],
    encounter: lifecycle({ players, targets: targets2 }).begin(),
    events: []
  };
}
function combatAreaAnchor(world, area) {
  const actor = world.players.find((actor2) => actor2.playerId === area.ownerId);
  if (actor?.life !== "alive" || actor.vehicleId !== null || actor.action.kind !== "fire" || actor.action.actionInstanceId !== area.actionInstanceId)
    return null;
  const pose = actionPose(
    COMBAT_CATALOG,
    actor.action.definitionId,
    world.tick - actor.action.stateStartTick
  );
  const socket = pose?.sockets.find((socket2) => socket2.name === "muzzle");
  if (!socket) throw new Error("Missing attached volume socket");
  return {
    origin: worldSocket(actor.body, socket.point, actor.facing),
    heading: actor.aim === 1 ? 1 : actor.aim === 2 ? 2 : actor.facing === 1 ? 0 : 3
  };
}
function actionHand(actor, tick2) {
  const pose = actionPose(
    COMBAT_CATALOG,
    actor.action.definitionId,
    tick2 - actor.action.stateStartTick
  );
  const socket = pose?.sockets.find((socket2) => socket2.name === "hand");
  if (!socket) throw new Error("Missing combat hand socket");
  return socket.point;
}
function appendShieldMarkers(world, target, markers) {
  const guard = target.guard;
  if (!guard || target.health === 0) return;
  for (const item of markers) {
    if (item.marker.kind === "face") continue;
    if (item.marker.kind !== "sound" && item.marker.kind !== "activate-hitbox")
      throw new Error("Unsupported shield marker");
    const socket = item.pose.sockets.find((socket2) => socket2.name === item.marker.socket);
    if (!socket) throw new Error("Missing shield marker socket");
    world.events.push({
      kind: item.marker.kind === "sound" ? "action-sound" : "melee",
      ownerId: target.enemy.body.id,
      actionInstanceId: item.actionInstanceId,
      markerIndex: item.markerIndex,
      source: {
        definitionId: item.marker.payloadId,
        timelineId: guard.action.definitionId,
        stateStartTick: guard.action.stateStartTick
      },
      position: worldSocket(target.enemy.body, socket.point, target.enemy.facing),
      impact: null,
      targetId: null,
      beam: null
    });
  }
}
function combatMeleeEligible(actor, terrain, hurtboxes) {
  const definition2 = COMBAT_ATTACKS.get(4), shape = COMBAT_SHAPES.get(9);
  if (!definition2 || !shape) throw new Error("Missing contextual melee content");
  const pose = COMBAT_CATALOG.poses.get(
    FOOT_ACTION_PROFILES.melee.timelineIds[actor.locomotion === "crouched" ? 1 : 0]
  );
  const socket = pose?.sockets.find((socket2) => socket2.name === "hand");
  if (!socket) throw new Error("Missing melee ready socket");
  const hand = worldSocket(actor.body, socket.point, actor.facing);
  return actor.aim === 0 && meleeHits(
    { id: actor.body.id, ownerId: actor.playerId, team: 1, actionInstanceId: 1, definitionId: 4 },
    definition2,
    shape,
    hand,
    { x: 0, y: 0 },
    actor.facing,
    { x: actor.body.x, y: hand.y },
    terrain,
    hurtboxes
  ).some((hit) => hit.damage > 0);
}
function combatHurtboxes(targets2, tick2, previous = targets2) {
  return targets2.flatMap((target, index) => {
    if (target.health === 0 || target.enemy.life !== "alive") return [];
    const body2 = target.enemy.body, before = previous[index]?.enemy.body;
    if (!before || before.id !== body2.id) throw new Error("Target motion identity mismatch");
    const protectedBody = target.shield || target.guard !== null && shieldProtected(target.guard, tick2, SHIELD_PROFILE);
    const kinds = protectedBody ? ["body", "shield"] : ["body"];
    return kinds.map((kind) => {
      const shape = COMBAT_SHAPES.get(kind === "body" ? 3 : 8);
      if (!shape) throw new Error("Missing target hurt shape");
      return {
        id: body2.id * 2 + (kind === "shield" ? 1 : 0),
        entityId: body2.id,
        team: 2,
        kind,
        rect: worldRect(before, shape.rect, target.enemy.facing),
        delta: { x: body2.x - before.x, y: body2.y - before.y }
      };
    });
  });
}
function playerCombatHurtboxes(players, previous = players) {
  return players.flatMap((player2, slot) => {
    if (player2.life !== "alive" || player2.invulnerableTicks > 0 || player2.vehicleId !== null)
      return [];
    const before = previous[slot];
    const shape = COMBAT_SHAPES.get(
      player2.body.shapeId === FOOT_DEFINITION?.crouchedShapeId ? 7 : 3
    );
    if (!before || before.body.id !== player2.body.id || !shape)
      throw new Error("Player hurtbox identity");
    return [
      {
        id: player2.body.id * 2,
        entityId: player2.body.id,
        team: 1,
        kind: "body",
        rect: worldRect(before.body, shape.rect, player2.facing),
        delta: { x: player2.body.x - before.body.x, y: player2.body.y - before.body.y }
      }
    ];
  });
}
function advanceCombatLab(current, commands, connections = {
  connectedPlayerIds: current.players.map((p) => p.playerId),
  releasePlayerIds: []
}, stage) {
  integer(current.tick, 0, COMBAT_LAB_LIMIT - 1, "combat tick");
  if (current.format !== 14 || current.pickups.tick !== current.tick)
    throw new Error("Combat supply format/boundary mismatch");
  stage ??= materialCombatStage(current);
  if (commands.length !== current.players.length) throw new Error("Missing combat input owner");
  for (const command2 of commands) {
    integer(command2.held, 0, HELD_MASK, "combat held mask");
    if (typeof command2.firePressed !== "boolean" || typeof command2.jumpPressed !== "boolean" || typeof command2.grenadePressed !== "boolean" || typeof command2.interactPressed !== "boolean")
      throw new Error("Invalid combat edges");
  }
  const world = structuredClone(current);
  const tick2 = ++world.tick;
  world.events = [];
  const physicalTerrain = stage?.terrain ?? combatTerrain(world.scenario, tick2, world.props);
  const active = (target) => !stage || stage.activeEnemyIds.has(target.enemy.body.id);
  const destructibles = stage?.destructibles ?? combatDestructibles(world.scenario);
  const terrain = physicalTerrain.filter(
    (target) => !world.props.some((prop) => prop.id === target.id)
  );
  const frame = { tick: tick2, geometryRevision: combatGeometryRevision(world.props) };
  const index = combatCollisionIndex(world.scenario, frame, world.props, physicalTerrain);
  const encounterEvents = [];
  const activatedIds = /* @__PURE__ */ new Set();
  const activateTarget = (id2) => {
    if (!activatedIds.has(id2) && world.encounter.members.some((member) => member.id === id2 && member.status === "pending")) {
      activatedIds.add(id2);
      encounterEvents.push({ kind: "activate", id: id2, sequence: ++world.eventSequence, tick: tick2 });
    }
  };
  const lifeNotices = [];
  const seatChanges = /* @__PURE__ */ new Map();
  const playerMovement = /* @__PURE__ */ new Map();
  const outcomes = [];
  for (const [slot, actor] of world.players.entries()) {
    const command2 = commands[slot];
    if (!command2 || !FOOT_DEFINITION) throw new Error("Missing combat controller");
    const life = stepPlayerLife(actor, tick2, "classic", {
      ...combatEntryContext(actor, index, frame, world.scenario),
      ...stage ? {
        fallBoundary: stage.fallBoundary,
        anchors: [{ x: stage.entry.x + actor.slot * pixels(24), y: stage.entry.y }]
      } : {}
    });
    if (life.notice) lifeNotices.push(life.notice);
    const result = stepFootController(
      life.actor,
      command2,
      FOOT_DEFINITION,
      COMBAT_SHAPES,
      index,
      frame
    );
    if (result.status === "failed") {
      if (result.physics.reason !== "crushed")
        throw new Error(`Combat body: ${result.physics.reason}`);
      const killed = damagePlayer(life.actor, tick2, 1, "classic", "crush");
      world.players[slot] = killed.actor;
      if (killed.notice) lifeNotices.push(killed.notice);
    } else {
      world.players[slot] = result.actor;
      if (result.status === "complete" && actor.life === "alive" && actor.controlEpoch === life.actor.controlEpoch)
        playerMovement.set(actor.playerId, result.physics.movement);
    }
    outcomes.push({
      playerId: actor.playerId,
      jumpAccepted: result.status === "complete" && (result.jumpRequest === "consumed" || result.jumpRequest === "buffered"),
      fire: "none",
      grenade: "none",
      interact: "none"
    });
  }
  const tankOutcomes = advanceCombatTanks(
    world,
    commands,
    connections,
    seatChanges,
    lifeNotices,
    index,
    frame
  );
  for (const outcome of outcomes) {
    const tank = tankOutcomes.get(outcome.playerId);
    if (!tank) throw new Error("Missing tank input outcome");
    outcome.jumpAccepted ||= tank.jumpAccepted;
    outcome.interact = tank.interact;
  }
  for (const target of world.targets) {
    if (!active(target)) continue;
    activateTarget(target.enemy.body.id);
    if (target.health === 0) continue;
    const shieldStep = target.guard && stepShield(
      target.guard,
      target.enemy,
      world.players,
      tick2,
      world.nextActionId,
      COMBAT_CATALOG,
      SHIELD_PROFILE
    );
    if (shieldStep) {
      target.guard = shieldStep.state;
      target.enemy.facing = shieldStep.state.facing;
      world.nextActionId = shieldStep.nextActionId;
    }
    const shape = COMBAT_SHAPES.get(target.enemy.body.shapeId);
    if (!shape) throw new Error("Missing enemy body");
    const result = stepGroundedEnemy(
      target.enemy,
      {
        speed: shieldStep ? shieldStep.speed : target.rifle?.action.kind === "fire" ? 0 : stage?.patrolSpeed ?? 64,
        turnAtBoundary: !target.guard && target.rifle?.action.kind !== "fire",
        gravity: 55,
        terminalVelocity: 2048,
        bounds: stage?.enemyBounds ?? { x: 0, y: 0, w: pixels(384), h: pixels(220) }
      },
      shape,
      index,
      frame
    );
    if (result.status === "failed") throw new Error(`Combat enemy: ${result.physics.reason}`);
    target.enemy = result.enemy;
    if (target.enemy.removalReason) {
      target.health = 0;
      if (target.rifle) cancelRifle(target.rifle);
      if (target.guard) cancelShield(target.guard);
      encounterEvents.push({
        kind: "resolve",
        id: target.enemy.body.id,
        reason: target.enemy.removalReason,
        killerId: null,
        sequence: ++world.eventSequence,
        tick: tick2
      });
    }
    if (shieldStep) appendShieldMarkers(world, target, shieldStep.markers);
  }
  for (const [slot, actor] of world.players.entries()) {
    const command2 = commands[slot];
    if (!command2) throw new Error("Missing firearm input");
    const result = stepFootCombatAction(
      actor,
      seatChanges.has(actor.playerId) ? { held: 0, firePressed: false, grenadePressed: false } : command2,
      tick2,
      world.nextActionId,
      COMBAT_CATALOG,
      FOOT_ACTION_PROFILES,
      combatMeleeEligible(actor, terrain, [
        ...combatHurtboxes(world.targets, tick2),
        ...destructibleHurtboxes(world.props, destructibles),
        ...stage?.extraHurtboxes ?? []
      ])
    );
    world.players[slot] = result.actor;
    world.nextActionId = result.nextActionId;
    const outcome = outcomes.find((item) => item.playerId === actor.playerId);
    if (!outcome) throw new Error("Missing combat action owner");
    outcome.fire = result.fire;
    outcome.grenade = result.grenade;
    for (const item of result.markers) {
      const local = item.pose.sockets.find((socket) => socket.name === item.marker.socket)?.point;
      if (!local) throw new Error("Missing marker socket");
      const position2 = worldSocket(actor.body, local, actor.facing);
      if (item.marker.payloadId === 4 || item.marker.payloadId === 5) {
        const notice3 = {
          kind: "action-sound",
          ownerId: actor.playerId,
          actionInstanceId: item.actionInstanceId,
          markerIndex: item.markerIndex,
          source: {
            definitionId: item.marker.payloadId,
            timelineId: result.actor.action.definitionId,
            stateStartTick: result.actor.action.stateStartTick
          },
          position: position2,
          impact: null,
          targetId: null,
          beam: null
        };
        if (item.marker.kind === "activate-hitbox") {
          notice3.kind = "melee";
          world.strikes.push({
            id: world.nextEntityId,
            ownerId: actor.playerId,
            team: 1,
            actionInstanceId: item.actionInstanceId,
            definitionId: 4,
            spawnTick: tick2,
            endTick: tick2 + (COMBAT_ATTACKS.get(4)?.lifetimeTicks ?? 0),
            hitIds: []
          });
          world.nextEntityId = nextCounter(world.nextEntityId);
        } else if (item.marker.kind === "spawn-attack") {
          notice3.kind = "throw";
          const shape = COMBAT_SHAPES.get(GRENADE_PROFILE.bodyShapeId);
          if (!shape) throw new Error("Missing grenade body");
          const handRoot = { x: actor.body.x, y: position2.y };
          const delta = { x: position2.x - handRoot.x, y: 0 };
          const blocking = earliestSweep(
            worldRect(handRoot, shape.rect, 1),
            delta,
            physicalTerrain.map((target) => ({
              ...target,
              rect: {
                ...target.rect,
                x: target.rect.x + target.delta.x,
                y: target.rect.y + target.delta.y
              },
              delta: { x: 0, y: 0 }
            }))
          );
          if (blocking.overlaps.length) throw new Error("Grenade hand starts inside terrain");
          const contact = blocking.contacts[0];
          const releaseDelta = contact ? displacementAtContact(delta, contact.time) : delta;
          const release = { x: handRoot.x + releaseDelta.x, y: handRoot.y + releaseDelta.y };
          notice3.position = release;
          const velocity2 = grenadeLaunchVelocity(actor, GRENADE_PROFILE, index, frame);
          world.grenades.push({
            id: world.nextEntityId,
            ownerId: actor.playerId,
            team: 1,
            actionInstanceId: item.actionInstanceId,
            definitionId: 5,
            spawnTick: tick2,
            bounces: 0,
            body: {
              id: world.nextEntityId,
              x: release.x,
              y: release.y,
              vx: velocity2.x,
              vy: velocity2.y,
              remainderX: 0,
              remainderY: 0,
              shapeId: shape.id,
              grounded: false,
              supportId: null,
              contacts: []
            }
          });
          world.nextEntityId = nextCounter(world.nextEntityId);
        } else if (item.marker.kind !== "sound") throw new Error("Unsupported foot action marker");
        world.events.push(notice3);
        continue;
      }
      const notice2 = {
        kind: "sound",
        ownerId: actor.playerId,
        actionInstanceId: item.actionInstanceId,
        markerIndex: item.markerIndex,
        source: {
          definitionId: item.marker.payloadId,
          controlEpoch: result.actor.controlEpoch,
          shotOrdinal: result.actor.weapon.shotOrdinal
        },
        position: position2,
        impact: null,
        targetId: null,
        beam: null
      };
      if (item.marker.kind === "spawn-attack") {
        const definition2 = COMBAT_ATTACKS.get(item.marker.payloadId);
        const shape = definition2 && COMBAT_SHAPES.get(definition2.shapeId);
        const hand = item.pose.sockets.find((socket) => socket.name === "hand")?.point;
        if (!definition2 || !shape || !hand) throw new Error("Missing release definition");
        notice2.kind = "shot";
        const areaProfile = AREA_PROFILES.get(definition2.id);
        const rocket2 = definition2.id === ROCKET_ATTACK.id;
        const laser2 = definition2.id === LASER_ATTACK.id;
        const clearance = rocket2 ? ROCKET_SHAPE : areaProfile || laser2 ? COMBAT_SHAPES.get(4) : shape;
        if (!clearance) throw new Error("Missing muzzle clearance shape");
        const blocked = muzzleBlocked(
          worldSocket(actor.body, hand, actor.facing),
          position2,
          clearance,
          physicalTerrain,
          rocket2 ? "bullet" : definition2.material
        );
        if (areaProfile) {
          let area = world.areas.find((area2) => area2.actionInstanceId === item.actionInstanceId);
          if (!area) {
            if (world.areas.length >= 16) throw new Error("Area attack cap requires recovery");
            area = {
              id: world.nextEntityId,
              ownerId: actor.playerId,
              team: 1,
              actionInstanceId: item.actionInstanceId,
              definitionId: definition2.id,
              startTick: result.actor.action.stateStartTick,
              emitted: 0,
              cancelledTick: null,
              lobes: [],
              hits: []
            };
            world.areas.push(area);
            world.nextEntityId = nextCounter(world.nextEntityId);
          }
          emitArea(
            area,
            tick2,
            areaProfile,
            {
              origin: position2,
              heading: actor.aim === 1 ? 1 : actor.aim === 2 ? 2 : actor.facing === 1 ? 0 : 3
            },
            blocked
          );
          if (blocked) notice2.kind = "muzzle-blocked";
        } else if (blocked) notice2.kind = "muzzle-blocked";
        else if (laser2) {
          if (world.beams.length >= 8) throw new Error("Beam cap requires recovery");
          world.beams.push({
            id: world.nextEntityId,
            ownerId: actor.playerId,
            team: 1,
            actionInstanceId: item.actionInstanceId,
            definitionId: definition2.id,
            spawnTick: tick2,
            tick: tick2,
            origin: { ...position2 },
            heading: actor.aim === 1 ? 1 : actor.aim === 2 ? 2 : actor.facing === 1 ? 0 : 3,
            length: LASER_PROFILE.range
          });
          world.nextEntityId = nextCounter(world.nextEntityId);
        } else if (rocket2) {
          if (world.rockets.length >= 32) throw new Error("Rocket cap requires recovery");
          world.rockets.push(
            createRocket(
              {
                id: world.nextEntityId,
                ownerId: actor.playerId,
                team: 1,
                actionInstanceId: item.actionInstanceId,
                definitionId: definition2.id
              },
              position2,
              actor.aim === 1 ? 24 : actor.aim === 2 ? 8 : actor.facing === 1 ? 0 : 16,
              tick2,
              ROCKET_PROFILE
            )
          );
          world.nextEntityId = nextCounter(world.nextEntityId);
        } else {
          if (world.projectiles.length >= 256) throw new Error("Projectile cap requires recovery");
          world.projectiles.push({
            id: world.nextEntityId,
            ownerId: actor.playerId,
            team: 1,
            actionInstanceId: item.actionInstanceId,
            definitionId: definition2.id,
            position: position2,
            velocity: firearmVelocity(result.actor, definition2.speed, COMBAT_CATALOG),
            spawnTick: tick2
          });
          world.nextEntityId = nextCounter(world.nextEntityId);
        }
      } else if (item.marker.kind !== "sound") throw new Error("Unsupported firearm marker");
      world.events.push(notice2);
    }
  }
  const tankFire = fireCombatTanks(world, commands, seatChanges, physicalTerrain);
  for (const outcome of outcomes) {
    const fire = tankFire.get(outcome.playerId);
    if (fire !== void 0) outcome.fire = fire;
  }
  for (const target of world.targets) {
    if (!active(target) || !target.rifle || target.health === 0) continue;
    const shape = COMBAT_SHAPES.get(4);
    if (!shape) throw new Error("Missing rifle projectile shape");
    const result = stepRifleAttack(
      target.rifle,
      target.enemy,
      world.players,
      tick2,
      world.nextActionId,
      COMBAT_CATALOG,
      RIFLE_PROFILE,
      shape,
      physicalTerrain
    );
    target.rifle = result.state;
    target.enemy.facing = result.facing;
    world.nextActionId = result.nextActionId;
    for (const item of result.markers) {
      const muzzle = item.pose.sockets.find((socket) => socket.name === "muzzle")?.point;
      const hand = item.pose.sockets.find((socket) => socket.name === "hand")?.point;
      const definition2 = COMBAT_ATTACKS.get(item.marker.payloadId);
      if (!muzzle || !hand || !definition2) throw new Error("Missing rifle release content");
      const position2 = worldSocket(target.enemy.body, muzzle, target.enemy.facing);
      const notice2 = {
        kind: "sound",
        ownerId: target.enemy.body.id,
        actionInstanceId: item.actionInstanceId,
        markerIndex: item.markerIndex,
        source: {
          definitionId: definition2.id,
          timelineId: target.rifle.action.definitionId,
          stateStartTick: target.rifle.action.stateStartTick
        },
        position: position2,
        impact: null,
        targetId: null,
        beam: null
      };
      if (item.marker.kind === "spawn-attack") {
        notice2.kind = "shot";
        if (muzzleBlocked(
          worldSocket(target.enemy.body, hand, target.enemy.facing),
          position2,
          shape,
          physicalTerrain
        ))
          notice2.kind = "muzzle-blocked";
        else {
          if (world.projectiles.length >= 256) throw new Error("Projectile cap requires recovery");
          world.projectiles.push({
            id: world.nextEntityId,
            ownerId: target.enemy.body.id,
            team: 2,
            actionInstanceId: item.actionInstanceId,
            definitionId: definition2.id,
            position: position2,
            velocity: {
              x: target.rifle.aim === 0 ? definition2.speed * target.enemy.facing : 0,
              y: target.rifle.aim === 1 ? -definition2.speed : 0
            },
            spawnTick: tick2
          });
          world.nextEntityId = nextCounter(world.nextEntityId);
        }
      } else if (item.marker.kind !== "sound") throw new Error("Unsupported rifle marker");
      world.events.push(notice2);
    }
  }
  const hurtboxes = [
    // Authored actors remain material before AI activation. A long-range round must
    // meet an intact shield before it can enter the body behind it.
    ...combatHurtboxes(world.targets, tick2, current.targets),
    ...playerCombatHurtboxes(world.players, current.players),
    ...tankCombatHurtboxes(world.tanks, current.tanks),
    ...destructibleHurtboxes(world.props, destructibles),
    ...stage?.extraHurtboxes ?? []
  ];
  const impacts = [];
  world.beams = world.beams.flatMap((beam) => {
    const index2 = world.players.findIndex((player2) => player2.playerId === beam.ownerId);
    let anchor = index2 >= 0 && ((commands[index2]?.held ?? 0) & Held.Fire) !== 0 ? combatAreaAnchor(world, beam) : null;
    if (anchor) {
      const actor = world.players[index2], clearance = COMBAT_SHAPES.get(4);
      if (!actor || !clearance) throw new Error("Missing beam muzzle clearance");
      if (muzzleBlocked(
        worldSocket(actor.body, actionHand(actor, tick2), actor.facing),
        anchor.origin,
        clearance,
        physicalTerrain,
        "energy"
      ))
        anchor = null;
    }
    const result = beam.spawnTick === tick2 ? emitBeam(
      beam,
      tick2,
      LASER_ATTACK,
      LASER_PROFILE,
      { origin: beam.origin, heading: beam.heading },
      terrain,
      hurtboxes
    ) : stepBeam(beam, tick2, LASER_ATTACK, LASER_PROFILE, anchor, terrain, hurtboxes);
    if (result.cast) {
      impacts.push(...result.cast.impacts);
      if (beam.spawnTick === tick2) {
        const notice2 = world.events.find(
          (event) => event.kind === "shot" && event.actionInstanceId === beam.actionInstanceId
        );
        if (!notice2) throw new Error("Missing laser birth event");
        notice2.beam = {
          heading: result.cast.heading,
          length: result.cast.length,
          width: result.cast.width
        };
      }
    }
    return result.beam ? [result.beam] : [];
  });
  world.rockets = world.rockets.flatMap((rocket2) => {
    if (rocket2.spawnTick === tick2) return [rocket2];
    const result = stepRocket(
      rocket2,
      tick2,
      ROCKET_ATTACK,
      ROCKET_SHAPE,
      ROCKET_PROFILE,
      terrain,
      hurtboxes
    );
    if (result.status === "active") return [result.rocket];
    if (result.status === "detonated") {
      world.events.push({
        kind: "explosion",
        ownerId: rocket2.ownerId,
        actionInstanceId: rocket2.actionInstanceId,
        markerIndex: 0,
        source: {
          definitionId: rocket2.definitionId,
          spawnTick: rocket2.spawnTick,
          sourceId: rocket2.id
        },
        position: result.contact.position,
        impact: null,
        targetId: null,
        beam: null
      });
      impacts.push(...result.impacts);
    }
    return [];
  });
  world.areas = world.areas.flatMap((area) => {
    const definition2 = COMBAT_ATTACKS.get(area.definitionId), profile = AREA_PROFILES.get(area.definitionId);
    if (!definition2 || !profile) throw new Error("Missing area policy");
    const result = stepArea(
      area,
      tick2,
      definition2,
      profile,
      combatAreaAnchor(world, area),
      terrain,
      hurtboxes
    );
    impacts.push(...result.impacts);
    return result.attack ? [result.attack] : [];
  });
  for (const target of world.targets) {
    const guard = target.guard;
    if (!active(target) || !guard || target.health === 0 || guard.phase !== "bash") continue;
    const age = tick2 - guard.action.stateStartTick;
    if (age < SHIELD_PROFILE.bashActiveTick || age >= SHIELD_PROFILE.bashActiveTick + SHIELD_PROFILE.bashActiveTicks)
      continue;
    const pose = actionPose(COMBAT_CATALOG, guard.action.definitionId, age);
    const socket = pose?.sockets.find((socket2) => socket2.name === "hand");
    const definition2 = COMBAT_ATTACKS.get(6), shape = COMBAT_SHAPES.get(12);
    const previous = current.targets.find(
      (candidate) => candidate.enemy.body.id === target.enemy.body.id
    );
    if (!socket || !definition2 || !shape || !previous) throw new Error("Missing bash volume");
    const moving = age > SHIELD_PROFILE.bashActiveTick;
    const body2 = moving ? previous.enemy.body : target.enemy.body;
    const hand = worldSocket(body2, socket.point, guard.facing);
    const delta = moving ? { x: target.enemy.body.x - body2.x, y: target.enemy.body.y - body2.y } : { x: 0, y: 0 };
    const candidates = moving ? hurtboxes : hurtboxes.map((hurt) => ({
      ...hurt,
      rect: { ...hurt.rect, x: hurt.rect.x + hurt.delta.x, y: hurt.rect.y + hurt.delta.y },
      delta: { x: 0, y: 0 }
    }));
    const hits = meleeHits(
      {
        id: target.enemy.body.id,
        ownerId: target.enemy.body.id,
        team: 2,
        actionInstanceId: guard.action.actionInstanceId,
        definitionId: 6
      },
      definition2,
      shape,
      hand,
      delta,
      guard.facing,
      { x: body2.x, y: hand.y },
      terrain,
      candidates,
      guard.hitIds
    );
    for (const hit of hits) if (hit.entityId !== null) guard.hitIds.push(hit.entityId);
    guard.hitIds.sort((a, b) => a - b);
    impacts.push(...hits);
  }
  world.strikes = world.strikes.filter((strike) => {
    const owner = world.players.find((player2) => player2.playerId === strike.ownerId);
    const before = current.players.find((player2) => player2.playerId === strike.ownerId);
    if (!owner || !before) throw new Error("Missing melee owner");
    if (tick2 >= strike.endTick || owner.life !== "alive" || owner.action.actionInstanceId !== strike.actionInstanceId || owner.action.kind !== "melee")
      return false;
    const definition2 = COMBAT_ATTACKS.get(strike.definitionId), shape = definition2 && COMBAT_SHAPES.get(definition2.shapeId);
    if (!definition2 || !shape) throw new Error("Missing melee volume");
    const hand = actionHand(owner, tick2);
    const sameFacing = owner.facing === before.facing && strike.spawnTick !== tick2;
    const start = worldSocket(sameFacing ? before.body : owner.body, hand, owner.facing);
    const delta = sameFacing ? { x: owner.body.x - before.body.x, y: owner.body.y - before.body.y } : { x: 0, y: 0 };
    const candidates = sameFacing ? hurtboxes : hurtboxes.map((target) => ({
      ...target,
      rect: {
        ...target.rect,
        x: target.rect.x + target.delta.x,
        y: target.rect.y + target.delta.y
      },
      delta: { x: 0, y: 0 }
    }));
    const hits = meleeHits(
      strike,
      definition2,
      shape,
      start,
      delta,
      owner.facing,
      { x: sameFacing ? before.body.x : owner.body.x, y: start.y },
      terrain,
      candidates,
      strike.hitIds
    );
    for (const hit of hits) if (hit.entityId !== null) strike.hitIds.push(hit.entityId);
    strike.hitIds.sort((a, b) => a - b);
    impacts.push(...hits);
    return true;
  });
  world.grenades = world.grenades.filter((grenade) => {
    const shape = COMBAT_SHAPES.get(GRENADE_PROFILE.bodyShapeId), definition2 = COMBAT_ATTACKS.get(grenade.definitionId);
    if (!shape || !definition2) throw new Error("Missing grenade policy");
    const result = stepGrenade(grenade, GRENADE_PROFILE, shape, index, frame);
    if (result.status === "active") {
      Object.assign(grenade, result.grenade);
      return true;
    }
    const position2 = result.position;
    if (result.status === "crushed") {
      const colliderId = result.colliderIds[0];
      if (colliderId === void 0) throw new Error("Grenade crush lacks a terrain witness");
      world.events.push({
        kind: "impact",
        ownerId: grenade.ownerId,
        actionInstanceId: grenade.actionInstanceId,
        markerIndex: 0,
        source: null,
        position: position2,
        targetId: null,
        beam: null,
        impact: {
          sourceId: grenade.id,
          definitionId: grenade.definitionId,
          actionInstanceId: grenade.actionInstanceId,
          ownerId: grenade.ownerId,
          colliderId,
          entityId: null,
          kind: "terrain",
          damage: 0,
          position: position2,
          time: { numerator: 1, denominator: 1 }
        }
      });
      return false;
    }
    world.events.push({
      kind: "explosion",
      ownerId: grenade.ownerId,
      actionInstanceId: grenade.actionInstanceId,
      markerIndex: 0,
      source: {
        definitionId: grenade.definitionId,
        spawnTick: grenade.spawnTick,
        sourceId: grenade.id
      },
      position: position2,
      impact: null,
      targetId: null,
      beam: null
    });
    impacts.push(
      ...explosionHits(grenade, definition2, position2, GRENADE_PROFILE.radius, terrain, hurtboxes)
    );
    return false;
  });
  if (world.projectiles.length + world.rockets.length + world.beams.length + world.areas.length + world.grenades.length + world.strikes.length > 256)
    throw new Error("Attack entity budget requires recovery");
  world.projectiles = world.projectiles.filter((projectile) => {
    const definition2 = COMBAT_ATTACKS.get(projectile.definitionId);
    const shape = definition2 && COMBAT_SHAPES.get(definition2.shapeId);
    if (!definition2 || !shape) throw new Error("Missing projectile definition");
    if (tick2 - projectile.spawnTick > definition2.lifetimeTicks) return false;
    if (projectile.spawnTick === tick2) return true;
    const impact2 = sweepProjectile(projectile, definition2, shape, terrain, hurtboxes);
    if (impact2) {
      impacts.push(impact2);
      return false;
    }
    projectile.position = {
      x: position(projectile.position.x + projectile.velocity.x),
      y: position(projectile.position.y + projectile.velocity.y)
    };
    return tick2 - projectile.spawnTick < definition2.lifetimeTicks;
  });
  impacts.sort(
    (a, b) => compareContactTime(
      a.time.numerator,
      a.time.denominator,
      b.time.numerator,
      b.time.denominator
    ) || a.actionInstanceId - b.actionInstanceId || a.sourceId - b.sourceId || a.colliderId - b.colliderId
  );
  for (const impact2 of impacts) {
    const notice2 = {
      kind: "impact",
      ownerId: impact2.ownerId,
      actionInstanceId: impact2.actionInstanceId,
      markerIndex: 0,
      source: null,
      position: impact2.position,
      impact: impact2,
      targetId: impact2.entityId,
      beam: null
    };
    world.events.push(notice2);
    const prop = world.props.find((prop2) => prop2.id === impact2.entityId);
    if (prop) {
      const attack2 = COMBAT_ATTACKS.get(impact2.definitionId);
      const definition2 = destructibles.find((definition3) => definition3.id === prop.id);
      if (!attack2 || !definition2) throw new Error("Missing prop attack/material definition");
      if (damageDestructible(prop, definition2, impact2, attack2, tick2))
        world.events.push({ ...notice2, kind: "prop-destroyed" });
      continue;
    }
    const tank = world.tanks.find((tank2) => tank2.body.id === impact2.entityId);
    if (tank) {
      if (impact2.damage > 0 && tank.armor > 0 && tank.invulnerableTicks === 0) {
        tank.armor--;
        tank.invulnerableTicks = TANK_PROFILE.damageProtectionTicks;
        if (tank.armor === 0) {
          releaseCombatTank(world, tank, "destroyed", seatChanges, lifeNotices, index, frame);
          world.events.push({ ...notice2, kind: "killed" });
        }
      }
      continue;
    }
    const slot = world.players.findIndex((player3) => player3.body.id === impact2.entityId);
    const player2 = world.players[slot];
    if (player2 && impact2.damage > 0) {
      const damage = damagePlayer(player2, tick2, impact2.damage, "classic");
      world.players[slot] = damage.actor;
      if (damage.notice) {
        lifeNotices.push(damage.notice);
        world.events.push({ ...notice2, kind: "killed" });
      }
      continue;
    }
    const target = world.targets.find((candidate) => candidate.enemy.body.id === impact2.entityId);
    if (target && target.health > 0) activateTarget(target.enemy.body.id);
    if (target?.guard && target.health > 0 && impact2.kind === "shield") {
      const definition2 = COMBAT_ATTACKS.get(impact2.definitionId);
      if (!definition2) throw new Error("Unknown shield damage definition");
      const damage = damageShield(
        target.guard,
        definition2,
        tick2,
        world.nextActionId,
        COMBAT_CATALOG,
        SHIELD_PROFILE
      );
      target.guard = damage.state;
      world.nextActionId = damage.nextActionId;
      if (damage.broken) world.events.push({ ...notice2, kind: "shield-break" });
      appendShieldMarkers(world, target, damage.markers);
    }
    if (!target || target.health === 0 || impact2.damage === 0) continue;
    target.health = Math.max(0, target.health - impact2.damage);
    if (target.health === 0) {
      target.enemy.life = "removed";
      if (target.rifle) cancelRifle(target.rifle);
      if (target.guard) cancelShield(target.guard);
      world.events.push({ ...notice2, kind: "killed" });
      encounterEvents.push({
        kind: "resolve",
        id: target.enemy.body.id,
        reason: "killed",
        killerId: impact2.ownerId,
        sequence: ++world.eventSequence,
        tick: tick2
      });
    }
  }
  const geometryRevision = combatGeometryRevision(world.props);
  if (geometryRevision !== frame.geometryRevision) {
    const removed = new Set(world.props.filter((prop) => prop.health === 0).map((prop) => prop.id));
    for (const actor of world.players) {
      const detached = detachDestroyedSupport(actor.body, removed);
      actor.geometryRevision = geometryRevision;
      if (detached && actor.locomotion !== "seated") actor.locomotion = "airborne";
      if (actor.ignoredSupportId !== null && removed.has(actor.ignoredSupportId)) {
        actor.ignoredSupportId = null;
        actor.ignoredSupportTicks = 0;
      }
    }
    for (const { enemy } of world.targets) {
      detachDestroyedSupport(enemy.body, removed);
      enemy.geometryRevision = geometryRevision;
    }
    for (const tank of world.tanks) detachDestroyedSupport(tank.body, removed);
    for (const grenade of world.grenades) detachDestroyedSupport(grenade.body, removed);
  }
  for (const [slot, actor] of world.players.entries()) {
    if (actor.life !== "alive" || actor.body.y <= (stage?.fallBoundary ?? COMBAT_ENTRY.fallBoundary))
      continue;
    const death = damagePlayer(actor, tick2, 1, "classic", "fall");
    world.players[slot] = death.actor;
    if (death.notice) lifeNotices.push(death.notice);
  }
  const supplies = stepWeaponPickups(
    current.pickups,
    combatPickupDefinitions(world.scenario, world.players.length),
    world.players,
    playerMovement,
    physicalTerrain.filter(
      (surface) => !world.props.some((prop) => prop.id === surface.id && prop.health === 0)
    ),
    COMBAT_CATALOG
  );
  world.pickups = supplies.state;
  world.players = supplies.players;
  world.pickupClaims = supplies.claims;
  world.strikes = world.strikes.filter(
    (strike) => world.players.some(
      (player2) => player2.playerId === strike.ownerId && player2.life === "alive" && player2.action.actionInstanceId === strike.actionInstanceId
    )
  );
  for (const area of world.areas) {
    const profile = AREA_PROFILES.get(area.definitionId);
    if (!profile) throw new Error("Missing area cancellation policy");
    if (!combatAreaAnchor(world, area)) cancelArea(area, tick2, profile);
  }
  world.beams = world.beams.filter((beam) => combatAreaAnchor(world, beam) !== null);
  world.encounter = lifecycle(world).step(
    world.encounter,
    tick2,
    encounterEvents,
    world.targets.filter(
      (target) => target.health > 0 && (active(target) || activatedIds.has(target.enemy.body.id))
    ).map((target) => ({
      id: target.enemy.body.id,
      progressKey: canonical([
        target.enemy.body.x,
        target.enemy.body.y,
        target.enemy.body.vx,
        target.enemy.body.vy,
        target.enemy.body.supportId,
        target.enemy.facing
      ]),
      unreachable: false
    })),
    "throw"
  ).state;
  const seatEvents = commitCombatSeats(current, world, seatChanges);
  return { state: world, outcomes, lifeNotices, seatEvents, impacts, playerMovement };
}

// src/shared/diagnostics/combat-events.ts
function combatEventContext(identity3) {
  return {
    ...identity3,
    attackIds: new Set(COMBAT_CONTENT.attacks.map((value) => value.id)),
    beamProfiles: /* @__PURE__ */ new Map([[LASER_ATTACK.id, LASER_PROFILE]]),
    pickupDefinitions: new Map(
      [...combatPickupDefinitions("pickups", 4), ...combatPickupDefinitions("support", 4)].map(
        (def) => [def.id, def]
      )
    ),
    soundIds: new Set(
      COMBAT_CONTENT.timelines.flatMap(
        (timeline) => timeline.markers.filter((marker) => marker.kind === "sound").map((marker) => marker.payloadId)
      )
    )
  };
}
function combatGameplayEvents(previous, next) {
  if (next.tick !== previous.tick + 1) throw new Error("Combat event boundary mismatch");
  const events = next.events.map((notice2) => {
    const event = {
      kind: notice2.kind,
      origin: previous.players.some((player2) => player2.playerId === notice2.ownerId) ? "player" : "enemy",
      ownerId: notice2.ownerId,
      actionInstanceId: notice2.actionInstanceId,
      markerIndex: notice2.markerIndex,
      definitionId: 0,
      x: notice2.position.x,
      y: notice2.position.y,
      targetId: notice2.targetId,
      material: notice2.impact?.kind ?? (notice2.kind === "muzzle-blocked" ? "terrain" : "none"),
      confirmation: null,
      beam: notice2.beam,
      pickup: null
    };
    if (notice2.impact) {
      if (notice2.impact.actionInstanceId !== notice2.actionInstanceId)
        throw new Error("Missing impact attack identity");
      event.definitionId = notice2.impact.definitionId;
    } else {
      const source = notice2.source;
      if (!source) throw new Error("Missing firearm confirmation source");
      event.definitionId = source.definitionId;
      if ("controlEpoch" in source)
        event.confirmation = {
          playerId: notice2.ownerId,
          controlEpoch: source.controlEpoch,
          shotOrdinal: source.shotOrdinal
        };
    }
    return event;
  });
  const definitions2 = combatPickupDefinitions(next.scenario, next.players.length);
  for (const claim of next.pickupClaims) {
    const def = definitions2.find((def2) => def2.id === claim.id);
    if (!def || claim.tick !== next.tick) throw new Error("Missing pickup event content/boundary");
    events.push({
      kind: "pickup",
      origin: "player",
      ownerId: claim.playerId,
      actionInstanceId: 0,
      markerIndex: 0,
      definitionId: claim.sourceId,
      targetId: claim.id,
      x: def.rect.x,
      y: def.rect.y,
      material: "none",
      confirmation: null,
      beam: null,
      pickup: {
        claimId: claim.claimId,
        weaponId: claim.weaponId,
        previousWeaponId: claim.previousWeaponId,
        previousAmmo: claim.previousAmmo,
        ammo: claim.ammo
      }
    });
  }
  return events;
}

// src/game/campaign/lifecycle.ts
function check4(ok, reason) {
  if (!ok) throw new Error(`Campaign: ${reason}`);
}
function ids(values, label) {
  integer(values.length, 0, 320, `${label} count`);
  let previous = 0;
  for (const id2 of values) {
    integer(id2, previous + 1, COUNTER_LIMIT - 1, label);
    previous = id2;
  }
}
function validate2(state) {
  const rules = RULE_PRESETS[state.ruleset];
  check4(rules, "unknown ruleset");
  integer(state.mission, 1, 255, "mission number");
  integer(state.checkpointId, 1, COUNTER_LIMIT - 1, "checkpoint ID");
  integer(state.encounterId, 1, COUNTER_LIMIT - 1, "encounter ID");
  integer(state.continuesRemaining, 0, rules.sharedContinues, "remaining continues");
  integer(state.continuesUsed, 0, rules.sharedContinues, "used continues");
  check4(
    state.continuesRemaining + state.continuesUsed === rules.sharedContinues,
    "continue accounting"
  );
  check4(
    ["playing", "wipe", "intermission", "victory", "defeat"].includes(state.phase),
    "unknown phase"
  );
  ids(state.requiredEntities, "required entities");
  ids(
    state.resolvedEntities.map((entity) => entity.id),
    "resolved entities"
  );
  for (const entity of state.resolvedEntities)
    check4(["killed", "retreated", "out-of-bounds"].includes(entity.reason), "resolution reason");
}
function party(state, players, tick2) {
  validate2(state);
  integer(players.length, 1, ARCADE.maxPlayers, "party size");
  ids(
    players.map((player2) => player2.playerId),
    "player IDs"
  );
  check4(new Set(players.map((player2) => player2.slot)).size === players.length, "duplicate slot");
  for (const player2 of players) {
    integer(player2.slot, 0, ARCADE.maxPlayers - 1, "party slot");
    integer(player2.lastRallyMission, 0, 255, "rally mission");
    validatePlayerLife(player2, tick2, state.ruleset);
  }
}
function createCampaign(ruleset, checkpointId, encounterId) {
  check4(RULE_PRESETS[ruleset], "unknown ruleset");
  const state = {
    ruleset,
    mission: 1,
    checkpointId,
    encounterId,
    continuesRemaining: RULE_PRESETS[ruleset].sharedContinues,
    continuesUsed: 0,
    phase: "playing",
    requiredEntities: [],
    resolvedEntities: []
  };
  validate2(state);
  return state;
}
function evaluatePartyWipe(current, players, connected, tick2) {
  party(current, players, tick2);
  ids(connected, "connected players");
  check4(
    connected.every((id2) => players.some((player2) => player2.playerId === id2)),
    "unknown connected player"
  );
  const state = structuredClone(current);
  if (state.phase !== "playing" || connected.length === 0) return state;
  if (players.some((player2) => connected.includes(player2.playerId) && player2.lives > 0))
    return state;
  state.phase = state.continuesRemaining > 0 ? "wipe" : "defeat";
  return state;
}
function checkpoint(current, entry, mission) {
  check4(entry.mission === mission, "checkpoint mission mismatch");
  integer(entry.id, 1, COUNTER_LIMIT - 1, "checkpoint ID");
  integer(entry.encounterId, 1, COUNTER_LIMIT - 1, "checkpoint encounter ID");
  ids(entry.requiredEntities, "checkpoint entities");
  return {
    ...structuredClone(current),
    mission,
    checkpointId: entry.id,
    encounterId: entry.encounterId,
    requiredEntities: [...entry.requiredEntities],
    resolvedEntities: [],
    phase: "playing"
  };
}
function enter(player2, state, tick2, entry) {
  const context = entry.entries.get(player2.playerId);
  check4(context, "missing checkpoint player anchor");
  const next = enterPlayer(player2, tick2, state.ruleset, context);
  check4(next, "checkpoint player anchor is blocked");
  return next;
}
function stageContinue(current, players, tick2, entry) {
  party(current, players, tick2);
  check4(current.phase === "wipe" && current.continuesRemaining > 0, "continue unavailable");
  check4(entry.id === current.checkpointId, "continue checkpoint mismatch");
  const state = checkpoint(current, entry, current.mission);
  const reset = players.map(
    (player2) => enter({ ...player2, lives: ARCADE.initialLives }, state, tick2, entry)
  );
  state.continuesRemaining--;
  state.continuesUsed++;
  return {
    state,
    players: reset,
    boundary: {
      kind: "continue",
      tick: tick2,
      mission: state.mission,
      checkpointId: state.checkpointId,
      continueOrdinal: state.continuesUsed
    }
  };
}

// src/game/labs/combat-campaign.ts
var check5 = (ok, reason) => {
  if (!ok) throw new Error(`Combat campaign: ${reason}`);
};
var resolvedEntities = (combat) => combat.encounter.members.flatMap(
  (member) => member.reason === "killed" || member.reason === "retreated" || member.reason === "out-of-bounds" ? [{ id: member.id, reason: member.reason }] : []
);
function createCombatCampaign(combat) {
  const state = createCampaign("classic", 1, combatEncounterDefinition(combat).id);
  state.requiredEntities = combat.targets.map((target) => target.enemy.body.id);
  return { state, continues: [] };
}
function validateCombatCampaign(campaign, combat, runEpoch) {
  integer(runEpoch, 1, COUNTER_LIMIT - 1, "campaign epoch");
  const state = campaign.state;
  check5(
    state.ruleset === "classic" && state.mission === 1 && state.checkpointId === 1 && state.encounterId === 1,
    "diagnostic checkpoint identity"
  );
  evaluatePartyWipe(state, combat.players, [], combat.tick);
  check5(["playing", "wipe", "defeat"].includes(state.phase), "unsupported diagnostic phase");
  check5(state.phase !== "wipe" || state.continuesRemaining > 0, "wipe credit budget");
  check5(state.phase !== "defeat" || state.continuesRemaining === 0, "defeat credit budget");
  check5(
    canonical(state.resolvedEntities) === canonical(resolvedEntities(combat)),
    "campaign resolution ledger"
  );
  const initial = createCombatLab(combat.scenario, combat.players.length);
  const initialVehicles = initial.tanks.map((tank) => tank.body.id);
  const initialIds = initial.targets.map((target) => target.enemy.body.id);
  check5(campaign.continues.length === state.continuesUsed, "continue decision count");
  integer(
    campaign.continues.length,
    0,
    RULE_PRESETS[state.ruleset].sharedContinues,
    "continue history length"
  );
  let lastTick = -1, lastEpoch = 0;
  const allocated = /* @__PURE__ */ new Set();
  for (const [index, decision] of campaign.continues.entries()) {
    check5(
      decision.ordinal === index + 1 && decision.checkpointId === state.checkpointId,
      "continue decision identity"
    );
    integer(decision.tick, lastTick + 1, combat.tick, "continue tick");
    integer(decision.fromRunEpoch, lastEpoch || 1, runEpoch - 1, "continue source epoch");
    check5(decision.runEpoch === decision.fromRunEpoch + 1, "continue generation");
    integer(
      decision.nextEntityIdBefore,
      Math.max(
        ...campaign.continues[index - 1]?.spawnedEntityIds ?? initialIds,
        ...campaign.continues[index - 1]?.spawnedVehicleIds ?? initialVehicles
      ) + 1,
      combat.nextEntityId - 1,
      "continue allocation boundary"
    );
    check5(
      [...decision.spawnedEntityIds, ...decision.spawnedVehicleIds].every(
        (id2, i) => id2 === decision.nextEntityIdBefore + i
      ),
      "checkpoint allocation sequence"
    );
    for (const ids2 of [decision.retiredVehicleIds, decision.spawnedVehicleIds]) {
      check5(ids2.length === initialVehicles.length, "checkpoint vehicle count");
      for (const [i, id2] of ids2.entries())
        integer(
          id2,
          i ? (ids2[i - 1] ?? 0) + 1 : 1,
          combat.nextEntityId - 1,
          "checkpoint vehicle ID"
        );
    }
    check5(
      canonical(decision.retiredVehicleIds) === canonical(campaign.continues[index - 1]?.spawnedVehicleIds ?? initialVehicles),
      "checkpoint vehicle retirement prefix"
    );
    for (const ids2 of [decision.retiredEntityIds, decision.spawnedEntityIds]) {
      check5(ids2.length === combat.targets.length, "checkpoint entity count");
      for (const [i, id2] of ids2.entries())
        integer(id2, i ? (ids2[i - 1] ?? 0) + 1 : 1, combat.nextEntityId - 1, "checkpoint entity ID");
    }
    check5(
      canonical(decision.retiredEntityIds) === canonical(campaign.continues[index - 1]?.spawnedEntityIds ?? initialIds),
      "checkpoint retirement prefix"
    );
    if (index === 0)
      for (const id2 of [...decision.retiredEntityIds, ...decision.retiredVehicleIds])
        allocated.add(id2);
    for (const id2 of [...decision.spawnedEntityIds, ...decision.spawnedVehicleIds]) {
      check5(!allocated.has(id2), "reused checkpoint entity");
      allocated.add(id2);
    }
    check5(decision.kills.length === combat.players.length, "checkpoint kill roster");
    for (const [i, credit] of decision.kills.entries()) {
      check5(credit.playerId === combat.players[i]?.playerId, "checkpoint kill owner");
      integer(credit.count, 0, combat.targets.length, "checkpoint kills");
    }
    check5(
      decision.kills.reduce((sum, credit) => sum + credit.count, 0) <= combat.targets.length,
      "checkpoint kill total"
    );
    lastTick = decision.tick;
    lastEpoch = decision.runEpoch;
  }
  const expectedIds = campaign.continues.at(-1)?.spawnedEntityIds ?? initialIds;
  check5(
    canonical(combat.tanks.map((tank) => tank.body.id)) === canonical(campaign.continues.at(-1)?.spawnedVehicleIds ?? initialVehicles),
    "current checkpoint vehicle roster"
  );
  check5(
    canonical(combat.targets.map((target) => target.enemy.body.id)) === canonical(expectedIds),
    "current checkpoint entity roster"
  );
  check5(
    canonical(state.requiredEntities) === canonical(expectedIds),
    "campaign requirement roster"
  );
}
function advanceCombatCampaign(current, combat, connected) {
  const campaign = structuredClone(current);
  campaign.state.resolvedEntities = resolvedEntities(combat);
  if (connected.length && connected.every(
    (id2) => combat.players.some((player2) => player2.playerId === id2 && player2.life === "spectating")
  ))
    campaign.state = evaluatePartyWipe(campaign.state, combat.players, connected, combat.tick);
  return campaign;
}
function continueCombatCheckpoint(current, campaign, runEpoch) {
  validateCombatCampaign(campaign, current, runEpoch);
  const world = structuredClone(current);
  const template = createCombatLab(current.scenario, current.players.length);
  world.targets = template.targets.map((target) => {
    const id2 = world.nextEntityId;
    world.nextEntityId = nextCounter(world.nextEntityId);
    return { ...target, enemy: { ...target.enemy, body: { ...target.enemy.body, id: id2 } } };
  });
  world.tanks = template.tanks.map((tank) => {
    const id2 = world.nextEntityId;
    world.nextEntityId = nextCounter(world.nextEntityId);
    tank.body.id = id2;
    tank.action.stateStartTick = world.tick;
    return tank;
  });
  world.props = structuredClone(template.props);
  const pickupDefinitions = combatPickupDefinitions(world.scenario, world.players.length);
  world.pickups = structuredClone(template.pickups);
  world.pickups.tick = world.tick;
  for (const item of world.pickups.items) {
    const def = pickupDefinitions.find((def2) => def2.id === item.id);
    if (!def) throw new Error("Missing checkpoint supply definition");
    item.status = world.tick >= def.expiresTick ? "expired" : world.tick >= def.activationTick ? "available" : "dormant";
    item.resolvedTick = item.status === "expired" ? def.expiresTick : null;
  }
  world.pickupClaims = [];
  for (const player2 of world.players) player2.geometryRevision = 1;
  world.projectiles = [];
  world.rockets = [];
  world.beams = [];
  world.strikes = [];
  world.grenades = [];
  world.areas = [];
  world.events = [];
  world.eventSequence = 0;
  world.encounter = new EncounterLifecycle(combatEncounterDefinition(world)).begin(world.tick);
  const frame = { tick: world.tick, geometryRevision: 1 };
  const index = new CollisionIndex(
    new CollisionGrid(combatEndTerrain(world.scenario, world.tick, world.props)),
    [],
    frame
  );
  const entry = stageContinue(campaign.state, world.players, world.tick, {
    mission: 1,
    id: 1,
    encounterId: 1,
    requiredEntities: world.targets.map((target) => target.enemy.body.id),
    entries: new Map(
      world.players.map((player2) => [
        player2.playerId,
        combatEntryContext(player2, index, frame, world.scenario)
      ])
    )
  });
  world.players = entry.players;
  const decision = {
    ordinal: entry.boundary.continueOrdinal,
    tick: world.tick,
    checkpointId: 1,
    fromRunEpoch: runEpoch,
    runEpoch: nextCounter(runEpoch),
    nextEntityIdBefore: current.nextEntityId,
    retiredEntityIds: current.targets.map((target) => target.enemy.body.id),
    spawnedEntityIds: world.targets.map((target) => target.enemy.body.id),
    retiredVehicleIds: current.tanks.map((tank) => tank.body.id),
    spawnedVehicleIds: world.tanks.map((tank) => tank.body.id),
    kills: structuredClone(current.encounter.kills)
  };
  return {
    combat: world,
    campaign: { state: entry.state, continues: [...structuredClone(campaign.continues), decision] }
  };
}

// src/shared/protocol/schema.ts
var ProtocolError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "ProtocolError";
  }
  code;
};

// src/shared/protocol/binary.ts
function bounded(value, minimum, maximum) {
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum)
    throw new ProtocolError("malformed", `Wire integer outside [${minimum}, ${maximum}]`);
  return value;
}
var Writer = class {
  offset = 0;
  bytes;
  view;
  constructor(length2) {
    this.bytes = new Uint8Array(length2);
    this.view = new DataView(this.bytes.buffer);
  }
  u8(value) {
    this.reserve(1);
    this.view.setUint8(this.offset++, bounded(value, 0, 255));
  }
  u16(value) {
    this.reserve(2);
    this.view.setUint16(this.offset, bounded(value, 0, 65535), true);
    this.offset += 2;
  }
  u32(value, minimum = 0, maximum = COUNTER_LIMIT - 1) {
    this.reserve(4);
    this.view.setUint32(this.offset, bounded(value, minimum, maximum), true);
    this.offset += 4;
  }
  i32(value, maximum) {
    this.reserve(4);
    this.view.setInt32(this.offset, bounded(value, -maximum, maximum), true);
    this.offset += 4;
  }
  bool(value) {
    if (typeof value !== "boolean") throw new ProtocolError("malformed", "Wire boolean required");
    this.u32(value ? 1 : 0);
  }
  optionalId(value) {
    this.u32(value === null ? 0 : value, value === null ? 0 : 1);
  }
  choice(values, value) {
    this.u32(values.indexOf(value), 0, values.length - 1);
  }
  zero(length2) {
    this.reserve(length2);
    this.offset += length2;
  }
  reserve(length2) {
    if (this.offset + length2 > this.bytes.byteLength)
      throw new ProtocolError("malformed", "Wire writer overrun");
  }
};
var Reader = class {
  constructor(bytes) {
    this.bytes = bytes;
    this.view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  }
  bytes;
  offset = 0;
  view;
  u8() {
    this.reserve(1);
    return this.view.getUint8(this.offset++);
  }
  u16() {
    this.reserve(2);
    const result = this.view.getUint16(this.offset, true);
    this.offset += 2;
    return result;
  }
  u32(minimum = 0, maximum = COUNTER_LIMIT - 1) {
    this.reserve(4);
    const result = this.view.getUint32(this.offset, true);
    this.offset += 4;
    return bounded(result, minimum, maximum);
  }
  i32(maximum) {
    this.reserve(4);
    const result = this.view.getInt32(this.offset, true);
    this.offset += 4;
    return bounded(result, -maximum, maximum);
  }
  bool() {
    return this.u32(0, 1) === 1;
  }
  choice(values) {
    const result = values[this.u32(0, values.length - 1)];
    if (result === void 0) throw new ProtocolError("malformed", "Invalid wire enum");
    return result;
  }
  zero(length2) {
    this.reserve(length2);
    for (let index = 0; index < length2; index++)
      if (this.view.getUint8(this.offset + index) !== 0)
        throw new ProtocolError("malformed", "Nonzero reserved/padding bytes");
    this.offset += length2;
  }
  reserve(length2) {
    if (this.offset + length2 > this.bytes.byteLength)
      throw new ProtocolError("malformed", "Truncated wire record");
  }
};

// src/shared/protocol/controller-record.ts
var CONTACTS = ["solid", "one-way", "platform"];
var ACTIONS = ["ready", "fire", "melee", "grenade", "enter", "exit", "hurt"];
var WEAPONS = [
  "sidearm",
  "heavy-machine-gun",
  "shotgun",
  "rocket-launcher",
  "flamethrower",
  "laser"
];
var LIFE = ["alive", "death", "respawning", "spectating"];
var BODY_PRESENCE = ["present", "removed"];
var LOCOMOTION = ["grounded", "airborne", "crouched", "seated"];
var VEHICLES = ["tank", "walker", "aircraft"];
var LIFECYCLE = ["available", "boarding", "occupied", "exiting", "destroying", "wreck"];
function writeBody(writer, body2) {
  writer.u32(body2.id, 1);
  writer.i32(body2.x, MAX_POSITION);
  writer.i32(body2.y, MAX_POSITION);
  writer.i32(body2.vx, MAX_MOTION);
  writer.i32(body2.vy, MAX_MOTION);
  writer.i32(body2.remainderX, MAX_MOTION * 2 - 1);
  writer.i32(body2.remainderY, MAX_MOTION * 2 - 1);
  writer.u32(body2.shapeId, 1, 65535);
  writer.optionalId(body2.supportId);
  writer.bool(body2.grounded);
  writer.u32(body2.contacts.length, 0, 4);
  for (const contact of body2.contacts) {
    writer.u32(contact.otherId, 1);
    writer.i32(contact.normalX, 1);
    writer.i32(contact.normalY, 1);
    writer.u32(contact.toiNumerator, 0, 2 ** 26);
    writer.u32(contact.toiDenominator, 1, 2 ** 17);
    writer.choice(CONTACTS, contact.kind);
  }
  writer.zero((4 - body2.contacts.length) * 24);
}
function readBody(reader) {
  const body2 = {
    id: reader.u32(1),
    x: reader.i32(MAX_POSITION),
    y: reader.i32(MAX_POSITION),
    vx: reader.i32(MAX_MOTION),
    vy: reader.i32(MAX_MOTION),
    remainderX: reader.i32(MAX_MOTION * 2 - 1),
    remainderY: reader.i32(MAX_MOTION * 2 - 1),
    shapeId: reader.u32(1, 65535),
    supportId: reader.u32() || null,
    grounded: reader.bool(),
    contacts: []
  };
  const count = reader.u32(0, 4);
  for (let index = 0; index < count; index++)
    body2.contacts.push({
      otherId: reader.u32(1),
      normalX: reader.i32(1),
      normalY: reader.i32(1),
      toiNumerator: reader.u32(0, 2 ** 26),
      toiDenominator: reader.u32(1, 2 ** 17),
      kind: reader.choice(CONTACTS)
    });
  reader.zero((4 - count) * 24);
  return body2;
}
function writeAction(writer, action2) {
  writer.choice(ACTIONS, action2.kind);
  writer.u32(action2.actionInstanceId);
  writer.u32(action2.stateStartTick);
  writer.u32(action2.definitionId, 0, 65535);
  writer.u32(action2.nextMarkerIndex, 0, 128);
}
function readAction(reader) {
  return {
    kind: reader.choice(ACTIONS),
    actionInstanceId: reader.u32(),
    stateStartTick: reader.u32(),
    definitionId: reader.u32(0, 65535),
    nextMarkerIndex: reader.u32(0, 128)
  };
}
function writeWeapon(writer, weapon2) {
  writer.choice(WEAPONS, weapon2.id);
  writer.u32(weapon2.ammo, 0, 65535);
  writer.u32(weapon2.cooldownTicks, 0, 65535);
  writer.u32(weapon2.shotOrdinal);
  writer.u32(weapon2.lastActionInstanceId);
}
function readWeapon(reader) {
  return {
    id: reader.choice(WEAPONS),
    ammo: reader.u32(0, 65535),
    cooldownTicks: reader.u32(0, 65535),
    shotOrdinal: reader.u32(),
    lastActionInstanceId: reader.u32()
  };
}
function writePlayer(writer, player2) {
  writeBody(writer, player2.body);
  writer.u32(player2.playerId, 1);
  writer.u32(player2.slot, 0, 3);
  writer.u32(player2.controlEpoch, 1);
  writer.choice(LIFE, player2.life);
  writer.u32(player2.lifeStartTick);
  writer.choice(BODY_PRESENCE, player2.bodyPresence);
  writer.choice(LOCOMOTION, player2.locomotion);
  writeAction(writer, player2.action);
  writer.i32(player2.facing, 1);
  writer.u32(player2.aim, 0, 2);
  writer.i32(player2.firearmAim.pitch, 4);
  writer.u32(player2.firearmAim.nextStepTick);
  writer.u32(player2.jumpBufferTicks, 0, 65535);
  writer.u32(player2.coyoteTicks, 0, 65535);
  writer.optionalId(player2.ignoredSupportId);
  writer.u32(player2.ignoredSupportTicks, 0, 65535);
  writer.u32(player2.invulnerableTicks, 0, 65535);
  writer.u32(player2.reboardCooldownTicks, 0, 65535);
  writer.u32(player2.vehicleSpecialTicks, 0, 65535);
  writer.optionalId(player2.vehicleId);
  writeWeapon(writer, player2.weapon);
  writer.u32(player2.grenadeStock, 0, 65535);
  writer.u32(player2.grenadeCooldownTicks, 0, 65535);
  writer.u32(player2.meleeCooldownTicks, 0, 65535);
  writer.u32(player2.geometryRevision, 1);
  writer.u32(player2.health, 0, 65535);
  writer.u32(player2.lives, 0, 65535);
  writer.u32(player2.lastRallyMission, 0, 65535);
  if (player2.processedEdgeIds.length !== 5)
    throw new ProtocolError("malformed", "Five controller edge cursors required");
  for (const edge of player2.processedEdgeIds) writer.u32(edge);
}
function readPlayer(reader) {
  return {
    body: readBody(reader),
    playerId: reader.u32(1),
    slot: reader.u32(0, 3),
    controlEpoch: reader.u32(1),
    life: reader.choice(LIFE),
    lifeStartTick: reader.u32(),
    bodyPresence: reader.choice(BODY_PRESENCE),
    locomotion: reader.choice(LOCOMOTION),
    action: readAction(reader),
    facing: reader.i32(1),
    aim: reader.u32(0, 2),
    firearmAim: { pitch: reader.i32(4), nextStepTick: reader.u32() },
    jumpBufferTicks: reader.u32(0, 65535),
    coyoteTicks: reader.u32(0, 65535),
    ignoredSupportId: reader.u32() || null,
    ignoredSupportTicks: reader.u32(0, 65535),
    invulnerableTicks: reader.u32(0, 65535),
    reboardCooldownTicks: reader.u32(0, 65535),
    vehicleSpecialTicks: reader.u32(0, 65535),
    vehicleId: reader.u32() || null,
    weapon: readWeapon(reader),
    grenadeStock: reader.u32(0, 65535),
    grenadeCooldownTicks: reader.u32(0, 65535),
    meleeCooldownTicks: reader.u32(0, 65535),
    geometryRevision: reader.u32(1),
    health: reader.u32(0, 65535),
    lives: reader.u32(0, 65535),
    lastRallyMission: reader.u32(0, 65535),
    processedEdgeIds: [reader.u32(), reader.u32(), reader.u32(), reader.u32(), reader.u32()]
  };
}
function writeVehicle(writer, vehicle) {
  writeBody(writer, vehicle.body);
  writer.u32(vehicle.definitionId, 1, 65535);
  writer.choice(VEHICLES, vehicle.kind);
  writer.choice(LIFECYCLE, vehicle.lifecycle);
  writer.optionalId(vehicle.occupantId);
  writer.optionalId(vehicle.reservedBy);
  writer.u32(vehicle.controlEpoch, 1);
  writer.u32(vehicle.armor, 0, 65535);
  writeAction(writer, vehicle.action);
  writeWeapon(writer, vehicle.weapon);
  writer.u32(vehicle.components.length, 0, 8);
  for (const component of vehicle.components) {
    writer.u32(component.id, 1);
    writer.u32(component.health, 0, 65535);
    writer.bool(component.broken);
  }
  writer.zero((8 - vehicle.components.length) * 12);
  writer.optionalId(vehicle.ownerControlEpoch);
  writer.i32(vehicle.facing, 1);
  writer.u32(vehicle.heading, 0, 7);
  writer.u32(vehicle.invulnerableTicks, 0, 65535);
}
function readVehicle(reader) {
  const vehicle = {
    body: readBody(reader),
    definitionId: reader.u32(1, 65535),
    kind: reader.choice(VEHICLES),
    lifecycle: reader.choice(LIFECYCLE),
    occupantId: reader.u32() || null,
    reservedBy: reader.u32() || null,
    controlEpoch: reader.u32(1),
    ownerControlEpoch: null,
    facing: 1,
    heading: 0,
    invulnerableTicks: 0,
    armor: reader.u32(0, 65535),
    action: readAction(reader),
    weapon: readWeapon(reader),
    components: []
  };
  const count = reader.u32(0, 8);
  for (let index = 0; index < count; index++)
    vehicle.components.push({
      id: reader.u32(1),
      health: reader.u32(0, 65535),
      broken: reader.bool()
    });
  reader.zero((8 - count) * 12);
  vehicle.ownerControlEpoch = reader.u32() || null;
  vehicle.facing = reader.i32(1);
  vehicle.heading = reader.u32(0, 7);
  vehicle.invulnerableTicks = reader.u32(0, 65535);
  return vehicle;
}

// src/shared/protocol/limits.ts
var PROTOCOL_MAJOR = 3;
var PROTOCOL_MINOR = 14;
var MAGIC = 17989;
var INPUT_TYPE = 1;
var INPUT_HEADER_BYTES = 32;
var COMMAND_BYTES = 20;
var EDGE_BYTES = 8;
var MAX_COMMANDS = 3;
var MAX_EDGES_PER_COMMAND = 8;
var MAX_INPUT_BYTES = 284;
var ACK_BYTES = 40;
var MAX_QUEUED_COMMANDS = 120;
var MAX_PREDICTION_TICKS = 180;
var MAX_EDGE_ADVANCE = 256;
var MAX_CLIENT_LEAD_TICKS = 6;
var INPUT_STALE_TICKS = 15;
var INPUT_STALE_MS = 250;

// src/shared/protocol/events.ts
var EVENT_CAPABILITY = 2;
var EVENT_TYPE = 3;
var EVENT_HEADER_BYTES = 32;
var EVENT_RECORD_BYTES = 96;
var MAX_EVENT_BATCH = 64;
var MAX_EVENT_HISTORY = 512;
var EVENT_HISTORY_TICKS = 120;
var EVENT_KINDS = [
  "shot",
  "sound",
  "muzzle-blocked",
  "impact",
  "killed",
  "melee",
  "throw",
  "action-sound",
  "explosion",
  "shield-break",
  "prop-destroyed",
  "pickup"
];
var EVENT_MATERIALS = ["none", "terrain", "shield", "body"];
var EVENT_ORIGINS = ["player", "enemy"];
function eventCounter(value, zero3 = false) {
  return integer(value, zero3 ? 0 : 1, COUNTER_LIMIT - 1, "event counter");
}
function eventRequire(condition, message) {
  if (!condition) throw new ProtocolError("malformed", message);
}
function identity(value, expected) {
  eventCounter(value.runEpoch);
  eventCounter(value.connectionEpoch);
  if (value.runEpoch !== expected.runEpoch || value.connectionEpoch !== expected.connectionEpoch)
    throw new ProtocolError("identity-mismatch", "Event session mismatch");
}
function validateGameplayEvent(event, context) {
  eventRequire(
    Object.keys(event).sort().join() === "actionInstanceId,beam,confirmation,definitionId,kind,markerIndex,material,origin,ownerId,pickup,targetId,x,y",
    "Unexpected gameplay event fields"
  );
  eventRequire(EVENT_KINDS.includes(event.kind), "Unknown gameplay event kind");
  eventRequire(EVENT_ORIGINS.includes(event.origin), "Unknown event origin");
  eventRequire(EVENT_MATERIALS.includes(event.material), "Unknown impact material");
  eventCounter(event.ownerId);
  eventCounter(event.actionInstanceId, event.kind === "pickup");
  integer(event.markerIndex, 0, MAX_EVENT_HISTORY - 1, "event marker");
  eventCounter(event.definitionId);
  integer(event.x, -MAX_POSITION, MAX_POSITION, "event x");
  integer(event.y, -MAX_POSITION, MAX_POSITION, "event y");
  if (event.kind === "pickup") {
    const def = event.targetId === null ? void 0 : context.pickupDefinitions.get(event.targetId);
    const grant2 = event.pickup;
    eventRequire(def !== void 0 && grant2 !== null, "Unknown or missing pickup grant");
    eventRequire(
      Object.keys(grant2).sort().join() === "ammo,claimId,previousAmmo,previousWeaponId,weaponId",
      "Unexpected pickup grant fields"
    );
    integer(grant2.previousAmmo, 0, 65535, "previous pickup ammunition");
    eventRequire(
      grant2.previousWeaponId !== "sidearm" || grant2.previousAmmo === 0,
      "Sidearm pickup ammunition"
    );
    integer(grant2.ammo, 0, def.ammoLimit, "granted ammunition");
    eventRequire(
      WEAPONS.includes(grant2.previousWeaponId) && grant2.weaponId === def.weaponId && grant2.claimId === def.claimId,
      "Pickup content identity"
    );
    eventRequire(
      event.origin === "player" && event.actionInstanceId === 0 && event.markerIndex === 0 && event.definitionId === def.sourceId && event.confirmation === null && event.beam === null && event.material === "none",
      "Pickup event attribution"
    );
    eventRequire(event.x === def.rect.x && event.y === def.rect.y, "Pickup event location");
    eventRequire(
      grant2.previousWeaponId === grant2.weaponId ? grant2.ammo === Math.min(def.ammoLimit, grant2.previousAmmo + def.ammo) && grant2.ammo > grant2.previousAmmo : grant2.ammo === def.ammo,
      "Pickup inventory grant"
    );
    return;
  }
  eventRequire(event.pickup === null, "Unexpected pickup grant");
  eventRequire(
    (["sound", "action-sound"].includes(event.kind) ? context.soundIds : context.attackIds).has(
      event.definitionId
    ),
    "Unknown event content definition"
  );
  integer(event.x, -MAX_POSITION, MAX_POSITION, "event x");
  integer(event.y, -MAX_POSITION, MAX_POSITION, "event y");
  const beamProfile = context.beamProfiles.get(event.definitionId);
  eventRequire(
    event.beam !== null === (event.kind === "shot" && beamProfile !== void 0),
    "Invalid beam event geometry presence"
  );
  if (event.beam !== null) {
    eventRequire(
      event.beam.width === beamProfile?.width && event.beam.length <= beamProfile.range,
      "Beam event disagrees with content profile"
    );
    eventRequire(
      Object.keys(event.beam).sort().join() === "heading,length,width",
      "Unexpected beam geometry fields"
    );
    beamSegments(
      { x: event.x, y: event.y },
      event.beam.heading,
      event.beam.length,
      event.beam.width
    );
  }
  if (event.targetId !== null) eventCounter(event.targetId);
  const firearm = ["shot", "sound", "muzzle-blocked"].includes(event.kind);
  if (firearm) {
    if (event.origin === "player") {
      eventRequire(event.confirmation !== null, "Missing firearm confirmation identity");
      eventRequire(
        Object.keys(event.confirmation).sort().join() === "controlEpoch,playerId,shotOrdinal",
        "Unexpected confirmation fields"
      );
      eventCounter(event.confirmation.playerId);
      eventCounter(event.confirmation.controlEpoch);
      eventCounter(event.confirmation.shotOrdinal);
      eventRequire(event.confirmation.playerId === event.ownerId, "Confirmation owner mismatch");
    } else eventRequire(event.confirmation === null, "Enemy event has player confirmation");
    eventRequire(event.targetId === null, "Unexpected firearm target");
    eventRequire(
      event.material === (event.kind === "muzzle-blocked" ? "terrain" : "none"),
      "Invalid firearm material"
    );
  } else if (["melee", "throw", "action-sound", "explosion"].includes(event.kind)) {
    eventRequire(
      event.confirmation === null && event.targetId === null && event.material === "none",
      "Invalid foot action event"
    );
  } else {
    eventRequire(
      event.confirmation === null && event.material !== "none",
      "Invalid impact confirmation/material"
    );
    eventRequire(
      event.material === "terrain" ? event.targetId === null : event.targetId !== null,
      "Invalid impact target"
    );
    if (event.kind === "killed") eventRequire(event.material === "body", "Invalid kill material");
    if (event.kind === "prop-destroyed")
      eventRequire(event.material === "body", "Invalid prop destruction material");
    if (event.kind === "shield-break")
      eventRequire(event.material === "shield", "Invalid shield break material");
  }
}
function followsEvent(previous, next) {
  return next.cursor === previous.cursor + 1 && (next.tick === previous.tick && next.counter === previous.counter + 1 || next.tick > previous.tick && next.counter === 0);
}
function validateEventBatch(batch, context) {
  identity(batch, context);
  eventCounter(batch.throughTick, true);
  eventRequire(
    Array.isArray(batch.events) && batch.events.length > 0 && batch.events.length <= MAX_EVENT_BATCH,
    "Invalid event batch count"
  );
  let previous;
  for (const envelope of batch.events) {
    eventCounter(envelope.cursor);
    eventCounter(envelope.tick, true);
    integer(envelope.counter, 0, MAX_EVENT_HISTORY - 1, "event identity counter");
    eventRequire(envelope.tick <= batch.throughTick, "Event beyond committed boundary");
    if (previous)
      eventRequire(followsEvent(previous, envelope), "Noncontiguous event identities/cursors");
    validateGameplayEvent(envelope.event, context);
    if (envelope.event.kind === "pickup") {
      const def = context.pickupDefinitions.get(envelope.event.targetId ?? 0);
      eventRequire(
        def !== void 0 && envelope.tick >= def.activationTick && envelope.tick < def.expiresTick,
        "Pickup event lifetime"
      );
    }
    previous = envelope;
  }
}
function encodeEventBatch(batch, context) {
  validateEventBatch(batch, context);
  const length2 = EVENT_HEADER_BYTES + batch.events.length * EVENT_RECORD_BYTES;
  const w = new Writer(length2);
  w.u16(MAGIC);
  w.u8(PROTOCOL_MAJOR);
  w.u8(PROTOCOL_MINOR);
  w.u8(EVENT_TYPE);
  w.zero(1);
  w.u16(length2);
  w.u32(batch.runEpoch);
  w.u32(batch.connectionEpoch);
  w.u32(batch.throughTick);
  w.u32(batch.events[0]?.cursor ?? 0);
  w.u16(batch.events.length);
  w.u16(EVENT_RECORD_BYTES);
  w.zero(4);
  for (const { cursor, tick: tick2, counter: counter4, event } of batch.events) {
    w.u32(cursor);
    w.u32(tick2);
    w.u32(counter4);
    w.choice(EVENT_KINDS, event.kind);
    w.choice(EVENT_ORIGINS, event.origin);
    w.u32(event.ownerId);
    w.u32(event.actionInstanceId);
    w.u32(event.markerIndex);
    w.u32(event.definitionId);
    w.i32(event.x, MAX_POSITION);
    w.i32(event.y, MAX_POSITION);
    w.optionalId(event.targetId);
    w.choice(EVENT_MATERIALS, event.material);
    w.u32(event.confirmation?.playerId ?? 0);
    w.u32(event.confirmation?.controlEpoch ?? 0);
    w.u32(event.confirmation?.shotOrdinal ?? 0);
    w.u32(event.beam?.length ?? 0);
    w.u32(event.beam?.width ?? 0);
    w.u32(event.beam?.heading ?? 0);
    w.u32(event.pickup?.claimId ?? 0);
    w.u32(event.pickup ? WEAPONS.indexOf(event.pickup.weaponId) + 1 : 0, 0, WEAPONS.length);
    w.u32(event.pickup ? WEAPONS.indexOf(event.pickup.previousWeaponId) + 1 : 0, 0, WEAPONS.length);
    w.u32(event.pickup?.previousAmmo ?? 0, 0, 65535);
    w.u32(event.pickup?.ammo ?? 0, 0, 65535);
  }
  eventRequire(w.offset === length2, "Event writer size mismatch");
  return w.bytes;
}
function controlObject(raw, fields6) {
  eventRequire(new TextEncoder().encode(raw).byteLength <= 512, "Event control too large");
  const data = JSON.parse(raw);
  eventRequire(
    Boolean(data) && typeof data === "object" && !Array.isArray(data),
    "Invalid event control"
  );
  eventRequire(
    Object.keys(data).sort().join() === fields6.sort().join(),
    "Unexpected event control fields"
  );
  return data;
}
function decodeEventResyncRequest(raw, context) {
  const data = controlObject(raw, [
    "type",
    "runEpoch",
    "connectionEpoch",
    "lastEventCursor"
  ]);
  identity(data, context);
  eventCounter(data.lastEventCursor, true);
  eventRequire(data.type === "event-resync-request", "Invalid event resync request");
  return data;
}

// src/shared/protocol/event-stream.ts
function createEventHistory(runEpoch) {
  eventCounter(runEpoch);
  return { runEpoch, tick: 0, cursor: 0, entries: [], capEvictions: 0, ageEvictions: 0 };
}
function stageEventTick(current, tick2, events, context) {
  eventCounter(tick2);
  eventRequire(
    tick2 === current.tick + 1 && current.runEpoch === context.runEpoch,
    "Event history boundary mismatch"
  );
  eventRequire(
    events.length <= MAX_EVENT_HISTORY,
    "Event tick exceeds the retained stream capacity"
  );
  for (const event of events) validateGameplayEvent(event, context);
  const entries = current.entries.filter((item) => item.tick > tick2 - EVENT_HISTORY_TICKS);
  const ageEvictions = current.ageEvictions + current.entries.length - entries.length;
  let cursor = current.cursor;
  for (const [counter4, event] of events.entries()) {
    cursor = nextCounter(cursor);
    entries.push({ cursor, tick: tick2, counter: counter4, event: structuredClone(event) });
  }
  const overflow = Math.max(0, entries.length - MAX_EVENT_HISTORY);
  return {
    runEpoch: current.runEpoch,
    tick: tick2,
    cursor,
    entries: entries.slice(overflow),
    ageEvictions,
    capEvictions: current.capEvictions + overflow
  };
}
function eventBatches(history, acknowledged, connectionEpoch) {
  eventCounter(acknowledged, true);
  eventCounter(connectionEpoch);
  eventRequire(acknowledged <= history.cursor, "Event acknowledgment beyond world cursor");
  const oldest = history.entries[0]?.cursor ?? history.cursor + 1;
  if (acknowledged < oldest - 1) return null;
  const entries = history.entries.filter((item) => item.cursor > acknowledged);
  const batches = [];
  for (let offset = 0; offset < entries.length; offset += MAX_EVENT_BATCH)
    batches.push({
      runEpoch: history.runEpoch,
      connectionEpoch,
      throughTick: history.tick,
      events: structuredClone(entries.slice(offset, offset + MAX_EVENT_BATCH))
    });
  return batches;
}
function acceptsEventBaseline(pending, snapshotAck, eventAck, previouslySentCursor) {
  if (!pending) return false;
  eventCounter(snapshotAck, true);
  eventCounter(eventAck, true);
  if (snapshotAck < pending.snapshotId && eventAck <= previouslySentCursor) return false;
  eventRequire(
    snapshotAck === pending.snapshotId && eventAck === pending.baselineEventCursor,
    "Event baseline acknowledgment must accept its exact snapshot and cursor together"
  );
  return true;
}

// src/shared/diagnostics/room-workload.ts
var PROBE_IDENTITY = {
  simulationVersion: 1,
  simulationBuild: "1".repeat(64),
  contentFormat: 1,
  contentHash: "2".repeat(64),
  presentationBuild: "3".repeat(64)
};
var PROBE_SHAPES = /* @__PURE__ */ new Set([1, 2, 3, 4]);
function probeContext(slot) {
  return {
    runEpoch: 1,
    connectionEpoch: slot + 1,
    playerId: slot + 1,
    geometryRevision: 1,
    shapeIds: PROBE_SHAPES
  };
}
function body(id2, shapeId) {
  return {
    id: id2,
    x: id2 % 300 * 256,
    y: 180 * 256,
    vx: 0,
    vy: 0,
    remainderX: 0,
    remainderY: 0,
    shapeId,
    supportId: 1e4,
    grounded: true,
    contacts: [
      {
        otherId: 1e4,
        normalX: 0,
        normalY: -1,
        toiNumerator: 0,
        toiDenominator: 1,
        kind: "solid"
      }
    ]
  };
}
function action() {
  return {
    kind: "ready",
    actionInstanceId: 0,
    stateStartTick: 0,
    definitionId: 0,
    nextMarkerIndex: 0
  };
}
function weapon() {
  return {
    id: "sidearm",
    ammo: 0,
    cooldownTicks: 0,
    shotOrdinal: 0,
    lastActionInstanceId: 0
  };
}
function probeAck(slot) {
  return {
    playerId: slot + 1,
    connectionEpoch: slot + 1,
    controlEpoch: 1,
    lastProcessedSequence: 0,
    appliedAtServerTick: 0,
    processedEdgeIds: [0, 0, 0, 0, 0]
  };
}
function player(slot) {
  return {
    body: body(slot + 1, 1),
    playerId: slot + 1,
    slot,
    controlEpoch: 1,
    life: "alive",
    locomotion: "grounded",
    action: action(),
    facing: 1,
    aim: 0,
    jumpBufferTicks: 0,
    coyoteTicks: 0,
    ignoredSupportId: null,
    ignoredSupportTicks: 0,
    invulnerableTicks: 0,
    reboardCooldownTicks: 0,
    vehicleSpecialTicks: 0,
    vehicleId: null,
    weapon: weapon(),
    firearmAim: { pitch: 0, nextStepTick: 0 },
    grenadeStock: 5,
    grenadeCooldownTicks: 0,
    meleeCooldownTicks: 0,
    geometryRevision: 1,
    health: 1,
    lives: 3,
    lastRallyMission: 1,
    lifeStartTick: 0,
    bodyPresence: "present",
    processedEdgeIds: [0, 0, 0, 0, 0]
  };
}
function createRoomWorkload(multiplier) {
  if (multiplier !== 1 && multiplier !== 2) throw new RangeError("Unknown diagnostic workload");
  return {
    runEpoch: 1,
    connectionEpoch: 1,
    snapshotId: 1,
    tick: 0,
    baselineEventCursor: 0,
    geometryRevision: 1,
    stateHash: 0,
    roomMode: "loading",
    combat: null,
    camera: { x: 0, y: 0 },
    campaign: {
      ruleset: "classic",
      mission: 1,
      checkpointId: 1,
      continuesRemaining: 3,
      continuesUsed: 0,
      phase: "playing",
      encounterId: 1,
      remainingEnemies: 32 * multiplier
    },
    players: Array.from({ length: 4 }, (_, slot) => player(slot)),
    acknowledgments: Array.from({ length: 4 }, (_, slot) => probeAck(slot)),
    vehicles: Array.from({ length: 4 * multiplier }, (_, index) => ({
      body: body(100 + index, 2),
      definitionId: 1,
      kind: "tank",
      lifecycle: "available",
      occupantId: null,
      reservedBy: null,
      controlEpoch: 1,
      ownerControlEpoch: null,
      facing: 1,
      heading: 0,
      invulnerableTicks: 0,
      armor: 100,
      action: action(),
      components: [{ id: 1, health: 100, broken: false }],
      weapon: weapon()
    })),
    enemies: Array.from({ length: 32 * multiplier }, (_, index) => ({
      id: 200 + index,
      definitionId: 1,
      x: index * 256,
      y: 180 * 256,
      vx: index % 2 ? 128 : -128,
      vy: 0,
      shapeId: 1,
      facing: 1,
      health: 3,
      mode: 0,
      stateStartTick: 0,
      actionInstanceId: 0,
      actionDefinitionId: 0,
      modeTicks: 0,
      supportId: 1e4,
      geometryRevision: 1
    })),
    projectiles: Array.from({ length: 96 * multiplier }, (_, index) => ({
      id: 400 + index,
      ownerId: 1,
      actionInstanceId: index + 1,
      definitionId: 1,
      x: index * 256,
      y: 100 * 256,
      vx: 1024,
      vy: 0,
      spawnTick: 0,
      lifetimeTicks: 65535,
      heading: 0,
      shapeId: 3
    })),
    platforms: Array.from({ length: 16 * multiplier }, (_, index) => ({
      id: 800 + index,
      x: index * 256,
      y: 100 * 256,
      vx: 64,
      vy: 0,
      shapeId: 4,
      trajectoryId: 1,
      trajectoryTick: 0
    })),
    threats: Array.from({ length: 24 * multiplier }, (_, index) => ({
      actionInstanceId: 1e3 + index,
      sourceId: 200 + index,
      definitionId: 1,
      telegraphTick: 0,
      activeTick: 30,
      endTick: 65535,
      x: index * 256,
      y: 100 * 256,
      vx: 0,
      vy: 0,
      heading: 0,
      targetId: index % 4 + 1,
      motion: "linear",
      cancelled: false,
      stateVersion: 1,
      shapeId: 3
    })),
    removedIds: []
  };
}
function stepRoomWorkload(world, tick2, inputs) {
  if (tick2 !== world.tick + 1) throw new Error("Nonconsecutive diagnostic world tick");
  for (const input of inputs) {
    const actor = world.players.find((value) => value.playerId === input.playerId);
    if (!actor) throw new Error("Unknown diagnostic player");
    actor.body.vx = ((input.command.held & Held.Right ? 1 : 0) - (input.command.held & Held.Left ? 1 : 0)) * 256;
    actor.body.x = (actor.body.x + actor.body.vx + 384 * 256) % (384 * 256);
    actor.aim = input.command.aim;
  }
  for (const entity of [...world.enemies, ...world.projectiles, ...world.platforms]) {
    entity.x = (entity.x + entity.vx + 384 * 256) % (384 * 256);
  }
  world.tick = tick2;
}
function roomWorkloadHash(world) {
  const { connectionEpoch: _connection, snapshotId: _snapshot, stateHash: _hash, ...state } = world;
  return Number.parseInt(stateHash(state), 16);
}

// src/shared/diagnostics/controller-recovery.ts
function recoverControllerWorld(current) {
  if (current.vehicles.length || current.players.some((actor) => actor.vehicleId !== null))
    throw new Error("Controller recovery does not own vehicle handoff");
  return renewControllerGenerations(current);
}
function renewControllerGenerations(current) {
  if (current.players.some((actor) => actor.vehicleId !== null) || current.vehicles.some(
    (vehicle) => vehicle.occupantId !== null || vehicle.reservedBy !== null || vehicle.ownerControlEpoch !== null
  ))
    throw new Error("Controller generations require settled vehicle ownership");
  const next = structuredClone(current);
  next.runEpoch = nextCounter(current.runEpoch);
  next.roomMode = "loading";
  for (const actor of next.players) {
    const ack = next.acknowledgments.find((value) => value.playerId === actor.playerId);
    if (!ack) throw new Error("Missing recovery acknowledgment");
    actor.controlEpoch = nextCounter(actor.controlEpoch);
    actor.jumpBufferTicks = 0;
    actor.processedEdgeIds = [0, 0, 0, 0, 0];
    ack.connectionEpoch = nextCounter(ack.connectionEpoch);
    ack.controlEpoch = actor.controlEpoch;
    ack.lastProcessedSequence = 0;
    ack.appliedAtServerTick = 0;
    ack.processedEdgeIds = [0, 0, 0, 0, 0];
  }
  next.stateHash = roomWorkloadHash(next);
  return next;
}
function controllerPeerContext(world, slot) {
  const actor = world.players.find((value) => value.slot === slot);
  const ack = world.acknowledgments.find((value) => value.playerId === actor?.playerId);
  if (!actor || !ack) throw new Error("Missing controller session");
  return {
    ...probeContext(slot),
    runEpoch: world.runEpoch,
    connectionEpoch: ack.connectionEpoch,
    playerId: actor.playerId,
    geometryRevision: world.geometryRevision
  };
}

// src/shared/diagnostics/combat-workload.ts
var COMBAT_TERRAIN = combatTerrain("range");
var COMBAT_SHAPE_IDS = new Set(COMBAT_SHAPES.keys());
function combatPeerContext(world, slot) {
  return {
    ...controllerPeerContext(world, slot),
    shapeIds: COMBAT_SHAPE_IDS,
    ...combatGeometryContext(world.combat?.scenarioId)
  };
}
function combatGeometryContext(expectedScenarioId) {
  return {
    geometryRevisions: /* @__PURE__ */ new Set([1, 2]),
    validateGeometry: (snapshot) => {
      const combat = snapshot.combat;
      if (!combat) throw new Error("Missing combat geometry baseline");
      if (expectedScenarioId !== void 0 && combat.scenarioId !== expectedScenarioId)
        throw new Error("Combat scenario changed within loaded content");
      const scenario = combatSnapshotScenario(snapshot);
      const material = materialCase(scenario);
      for (const enemy of snapshot.enemies)
        if (material && (enemy.definitionId !== MATERIAL_CALIBRATION.definitionId || enemy.health > MATERIAL_CALIBRATION.targetHealth))
          throw new Error("Material calibration target content mismatch");
      validateWeaponPickups(
        { format: 1, tick: snapshot.tick, items: combat.pickups, contacts: [] },
        combatPickupDefinitions(scenario, snapshot.players.length),
        COMBAT_CATALOG,
        new Set(snapshot.players.map((p) => p.playerId))
      );
      validateDestructibles(
        combat.props,
        combatDestructibles(scenario),
        snapshot.tick,
        [...snapshot.players.map((p) => p.playerId), ...combat.members.map((m) => m.id)],
        combat.nextActionId
      );
      if (snapshot.geometryRevision !== combatGeometryRevision(combat.props))
        throw new Error("Destructible geometry revision mismatch");
    }
  };
}
function combatSnapshotScenario(snapshot) {
  if (!snapshot.combat) throw new Error("Missing combat scenario identity");
  return combatScenarioFromId(snapshot.combat.scenarioId);
}
async function combatIdentity() {
  const bytes = new TextEncoder().encode(
    canonical({
      content: COMBAT_CONTENT,
      surfaceMaterials: SURFACE_MATERIALS,
      scenarios: COMBAT_SCENARIOS,
      materials: {
        cases: MATERIAL_CASES,
        calibration: MATERIAL_CALIBRATION,
        destructibles: COMBAT_SCENARIOS.map(combatDestructibles)
      },
      campaignFormat: 2,
      combatFormat: 14,
      pickups: [1, 2, 3, 4].map((players) => [
        combatPickupDefinitions("pickups", players),
        combatPickupDefinitions("support", players)
      ]),
      rifle: RIFLE_PROFILE,
      shield: SHIELD_PROFILE,
      areas: [...AREA_PROFILES],
      footActions: FOOT_ACTION_PROFILES,
      grenade: GRENADE_PROFILE,
      rocket: ROCKET_PROFILE,
      tank: TANK_PROFILE,
      tankDepot: COMBAT_TANK_DEPOT,
      ordnance: COMBAT_ORDNANCE,
      laser: LASER_PROFILE,
      support: COMBAT_SUPPORT,
      life: {
        rules: RULE_PRESETS,
        deathTicks: ARCADE.deathTicks,
        entryTicks: ARCADE.respawnEntryTicks,
        protectionTicks: ARCADE.respawnProtectionTicks,
        checkpoint: COMBAT_ENTRY
      },
      profiles: [...COMBAT_CATALOG.firearms].map(([id2, profile]) => ({
        id: id2,
        timelineIds: profile.timelineIds,
        sweep: profile.sweep ?? null
      }))
    })
  );
  const digest2 = await crypto.subtle.digest("SHA-256", bytes);
  return {
    ...PROBE_IDENTITY,
    contentHash: Array.from(
      new Uint8Array(digest2),
      (byte) => byte.toString(16).padStart(2, "0")
    ).join("")
  };
}
function projectCombatCampaign(snapshot, campaign) {
  const { ruleset, mission, checkpointId, continuesRemaining, continuesUsed, phase, encounterId } = campaign.state;
  Object.assign(snapshot.campaign, {
    ruleset,
    mission,
    checkpointId,
    continuesRemaining,
    continuesUsed,
    phase,
    encounterId
  });
}
function combatSnapshot(combat, previous = createRoomWorkload(1), campaign) {
  const snapshot = structuredClone(previous);
  snapshot.tick = combat.tick;
  snapshot.geometryRevision = combatGeometryRevision(combat.props);
  snapshot.players = structuredClone(combat.players);
  snapshot.vehicles = combat.tanks.map(publicTankState);
  snapshot.platforms = combat.scenario === "ordnance" ? ordnancePlatforms(combat.tick) : [];
  snapshot.threats = combat.targets.flatMap(({ enemy, health, rifle }) => {
    if (!rifle || health === 0 || rifle.action.kind !== "fire" || combat.tick - rifle.action.stateStartTick > RIFLE_PROFILE.lastReleaseTick)
      return [];
    const pose = actionPose(
      COMBAT_CATALOG,
      rifle.action.definitionId,
      combat.tick - rifle.action.stateStartTick
    );
    const socket = pose?.sockets.find((socket2) => socket2.name === "muzzle");
    const attack2 = COMBAT_CONTENT.attacks.find((attack3) => attack3.id === 3);
    if (!socket || !attack2) throw new Error("Missing rifle threat content");
    const point2 = worldSocket(enemy.body, socket.point, enemy.facing);
    return [
      {
        actionInstanceId: rifle.action.actionInstanceId,
        sourceId: enemy.body.id,
        definitionId: attack2.id,
        telegraphTick: rifle.action.stateStartTick,
        activeTick: rifle.action.stateStartTick + RIFLE_PROFILE.raiseTicks,
        endTick: rifle.action.stateStartTick + RIFLE_PROFILE.lastReleaseTick,
        x: point2.x,
        y: point2.y,
        vx: rifle.aim === 0 ? attack2.speed * enemy.facing : 0,
        vy: rifle.aim === 1 ? -attack2.speed : 0,
        heading: rifle.aim === 1 ? 1 : enemy.facing === -1 ? 3 : 0,
        targetId: rifle.targetId,
        motion: "locked",
        cancelled: false,
        stateVersion: 1,
        shapeId: attack2.shapeId
      }
    ];
  });
  for (const player2 of combat.players) {
    if (player2.life !== "alive" || player2.action.kind !== "melee") continue;
    const marker = COMBAT_CATALOG.timelines.get(player2.action.definitionId)?.markers.find((marker2) => marker2.kind === "activate-hitbox");
    const definition3 = marker && COMBAT_CONTENT.attacks.find((attack2) => attack2.id === marker.payloadId);
    if (!marker || !definition3) throw new Error("Missing melee threat window");
    const activeTick = player2.action.stateStartTick + marker.tickOffset;
    const endTick = activeTick + definition3.lifetimeTicks;
    if (combat.tick >= endTick) continue;
    const pose = actionPose(
      COMBAT_CATALOG,
      player2.action.definitionId,
      combat.tick - player2.action.stateStartTick
    );
    const socket = pose?.sockets.find((socket2) => socket2.name === "hand");
    if (!socket) throw new Error("Missing melee threat socket");
    const hand = worldSocket(player2.body, socket.point, player2.facing);
    snapshot.threats.push({
      actionInstanceId: player2.action.actionInstanceId,
      sourceId: player2.playerId,
      definitionId: 4,
      telegraphTick: player2.action.stateStartTick,
      activeTick,
      endTick,
      x: hand.x,
      y: hand.y,
      vx: 0,
      vy: 0,
      heading: player2.facing === 1 ? 0 : 3,
      targetId: null,
      motion: "authored",
      cancelled: false,
      stateVersion: 1,
      shapeId: 9
    });
  }
  for (const target of combat.targets) {
    const guard = target.guard;
    if (!guard || target.health === 0 || guard.phase !== "bash" || combat.tick - guard.action.stateStartTick >= SHIELD_PROFILE.bashActiveTick + SHIELD_PROFILE.bashActiveTicks)
      continue;
    const pose = actionPose(
      COMBAT_CATALOG,
      guard.action.definitionId,
      combat.tick - guard.action.stateStartTick
    );
    const socket = pose?.sockets.find((socket2) => socket2.name === "hand");
    if (!socket) throw new Error("Missing bash telegraph socket");
    const point2 = worldSocket(target.enemy.body, socket.point, guard.facing);
    snapshot.threats.push({
      actionInstanceId: guard.action.actionInstanceId,
      sourceId: target.enemy.body.id,
      definitionId: 6,
      telegraphTick: guard.action.stateStartTick,
      activeTick: guard.action.stateStartTick + SHIELD_PROFILE.bashActiveTick,
      endTick: guard.action.stateStartTick + SHIELD_PROFILE.bashActiveTick + SHIELD_PROFILE.bashActiveTicks,
      ...point2,
      vx: 0,
      vy: 0,
      heading: guard.facing === 1 ? 0 : 3,
      targetId: guard.targetId,
      motion: "authored",
      cancelled: false,
      stateVersion: 1,
      shapeId: 12
    });
  }
  snapshot.threats.sort((a, b) => a.actionInstanceId - b.actionInstanceId);
  snapshot.enemies = combat.targets.filter((target) => target.health > 0).map(({ enemy, health, shield, rifle, guard }) => ({
    id: enemy.body.id,
    definitionId: materialCase(combat.scenario) ? MATERIAL_CALIBRATION.definitionId : guard ? 4 : rifle ? 3 : shield ? 2 : 1,
    x: enemy.body.x,
    y: enemy.body.y,
    vx: enemy.body.vx,
    vy: enemy.body.vy,
    shapeId: enemy.body.shapeId,
    facing: enemy.facing,
    health,
    mode: guard ? shieldMode(guard) : rifle ? rifleMode(rifle, combat.tick, RIFLE_PROFILE) : 0,
    stateStartTick: guard?.action.stateStartTick ?? rifle?.action.stateStartTick ?? 0,
    actionInstanceId: guard?.action.actionInstanceId ?? (rifle?.action.kind === "fire" ? rifle.action.actionInstanceId : 0),
    actionDefinitionId: guard?.action.definitionId ?? (rifle?.action.kind === "fire" ? rifle.action.definitionId : 0),
    modeTicks: guard?.action.actionInstanceId ? combat.tick - guard.action.stateStartTick : rifle?.action.kind === "fire" ? combat.tick - rifle.action.stateStartTick : 0,
    supportId: enemy.body.supportId,
    geometryRevision: snapshot.geometryRevision
  }));
  snapshot.projectiles = combat.projectiles.map((projectile) => ({
    id: projectile.id,
    ownerId: projectile.ownerId,
    actionInstanceId: projectile.actionInstanceId,
    definitionId: projectile.definitionId,
    x: projectile.position.x,
    y: projectile.position.y,
    vx: projectile.velocity.x,
    vy: projectile.velocity.y,
    spawnTick: projectile.spawnTick,
    lifetimeTicks: COMBAT_CONTENT.attacks.find((attack2) => attack2.id === projectile.definitionId)?.lifetimeTicks ?? 0,
    heading: projectile.definitionId === TANK_PROFILE.attackId ? TANK_PROFILE.headings.findIndex(
      ({ velocity: velocity2 }) => velocity2.x === projectile.velocity.x && velocity2.y === projectile.velocity.y
    ) : projectile.velocity.y < 0 ? 1 : projectile.velocity.y > 0 ? 2 : projectile.velocity.x < 0 ? 3 : 0,
    shapeId: 4
  }));
  for (const grenade of combat.grenades)
    snapshot.projectiles.push({
      id: grenade.id,
      ownerId: grenade.ownerId,
      actionInstanceId: grenade.actionInstanceId,
      definitionId: grenade.definitionId,
      x: grenade.body.x,
      y: grenade.body.y,
      vx: grenade.body.vx,
      vy: grenade.body.vy,
      spawnTick: grenade.spawnTick,
      lifetimeTicks: GRENADE_PROFILE.fuseTicks,
      heading: grenade.body.vy < 0 ? 1 : grenade.body.vy > 0 ? 2 : grenade.body.vx < 0 ? 3 : 0,
      shapeId: grenade.body.shapeId
    });
  for (const rocket2 of combat.rockets)
    snapshot.projectiles.push({
      id: rocket2.id,
      ownerId: rocket2.ownerId,
      actionInstanceId: rocket2.actionInstanceId,
      definitionId: rocket2.definitionId,
      x: rocket2.position.x,
      y: rocket2.position.y,
      vx: rocket2.velocity.x,
      vy: rocket2.velocity.y,
      spawnTick: rocket2.spawnTick,
      lifetimeTicks: ROCKET_PROFILE.lifetimeTicks,
      heading: rocket2.heading,
      shapeId: ROCKET_PROFILE.bodyShapeId
    });
  snapshot.projectiles.sort((a, b) => a.id - b.id);
  snapshot.removedIds = combat.targets.filter((target) => target.health === 0).map((target) => target.enemy.body.id).concat(combat.props.filter((prop) => prop.health === 0).map((prop) => prop.id)).concat(
    combat.pickups.items.filter((item) => !["dormant", "available"].includes(item.status)).map((item) => item.id)
  ).sort((a, b) => a - b);
  snapshot.campaign.remainingEnemies = combat.targets.filter((target) => target.health > 0).length;
  snapshot.campaign.encounterId = 1;
  const definition2 = combatEncounterDefinition(combat);
  snapshot.combat = {
    scenarioId: combatScenarioId(combat.scenario),
    props: structuredClone(combat.props),
    pickups: structuredClone(combat.pickups.items),
    volumes: combat.areas.flatMap((area) => {
      const profile = AREA_PROFILES.get(area.definitionId);
      if (!profile) throw new Error("Missing area snapshot profile");
      return areaExposures(
        area,
        combat.tick,
        profile,
        combatTerrain(combat.scenario, combat.tick, combat.props)
      );
    }).concat(combat.beams.flatMap((beam) => beamExposures(beam, LASER_PROFILE))).sort((a, b) => a.id - b.id || a.lobe - b.lobe),
    nextEntityId: combat.nextEntityId,
    nextActionId: combat.nextActionId,
    encounterEventCursor: combat.eventSequence,
    encounterId: definition2.id,
    phase: combat.encounter.phase,
    members: combat.encounter.members.map((member, index) => {
      const policy = definition2.members[index];
      if (!policy || policy.id !== member.id) throw new Error("Combat roster mismatch");
      return {
        id: member.id,
        required: policy.required,
        critical: policy.critical,
        retreatAllowed: policy.retreatAllowed,
        status: member.status,
        activatedTick: member.activatedTick,
        resolvedTick: member.resolvedTick,
        reason: member.reason,
        killerId: member.killerId
      };
    }),
    objectives: structuredClone(combat.encounter.objectives),
    kills: structuredClone(combat.encounter.kills),
    failure: structuredClone(combat.encounter.failure)
  };
  if (campaign) projectCombatCampaign(snapshot, campaign);
  snapshot.stateHash = roomWorkloadHash(snapshot);
  return snapshot;
}
function createCombatWorkload(scenario = "range", players = 4) {
  const combat = createCombatLab(scenario, players), baseline = createRoomWorkload(1);
  baseline.acknowledgments = baseline.acknowledgments.filter(
    (ack) => combat.players.some((player2) => player2.playerId === ack.playerId)
  );
  return { combat, snapshot: combatSnapshot(combat, baseline) };
}
function evaluateCombatTick(current, previous, prepared, releasePlayerIds = []) {
  if (current.tick !== previous.tick) throw new Error("Combat/snapshot boundary mismatch");
  const commands = current.players.map((actor) => {
    const item = prepared.find(({ input }) => input.playerId === actor.playerId);
    if (item && item.input.serverTick !== current.tick + 1)
      throw new Error("Combat input tick mismatch");
    return {
      held: item?.input.command.held ?? 0,
      jumpPressed: item?.input.command.edges.some((edge) => edge.kind === Edge.Jump) ?? false,
      firePressed: item?.input.command.edges.some((edge) => edge.kind === Edge.FireOnset) ?? false,
      grenadePressed: item?.input.command.edges.some((edge) => edge.kind === Edge.Grenade) ?? false,
      interactPressed: item?.input.command.edges.some((edge) => edge.kind === Edge.Interact) ?? false
    };
  });
  const result = advanceCombatLab(current, commands, {
    connectedPlayerIds: prepared.map((item) => item.input.playerId),
    releasePlayerIds
  });
  const outcomes = prepared.map((item) => {
    const actor = result.state.players.find((player2) => player2.playerId === item.input.playerId);
    const outcome = result.outcomes.find((value) => value.playerId === item.input.playerId);
    if (!actor || !outcome) throw new Error("Unknown combat input owner");
    actor.processedEdgeIds = [...item.acknowledgment.processedEdgeIds];
    let jump = false, grenade = false, fire = false, interact = false;
    return {
      playerId: actor.playerId,
      ...actor.controlEpoch !== item.acknowledgment.controlEpoch ? { controlEpoch: actor.controlEpoch } : {},
      edgeResults: item.input.command.edges.map((edge) => {
        let accepted = "unavailable";
        if (edge.kind === Edge.Jump && !jump) {
          accepted = outcome.jumpAccepted ? "applied" : "unavailable";
          jump = true;
        }
        if (edge.kind === Edge.Grenade && !grenade) {
          accepted = outcome.grenade === "none" ? "unavailable" : outcome.grenade;
          grenade = true;
        } else if (edge.kind === Edge.Grenade) accepted = "cooldown";
        if (edge.kind === Edge.FireOnset && !fire) {
          accepted = outcome.fire === "none" ? "unavailable" : outcome.fire;
          fire = true;
        } else if (edge.kind === Edge.FireOnset) accepted = "cooldown";
        if (edge.kind === Edge.Interact && !interact) {
          accepted = outcome.interact === "none" ? "unavailable" : outcome.interact;
          interact = true;
        } else if (edge.kind === Edge.Interact) accepted = "cooldown";
        return { ...edge, outcome: accepted };
      })
    };
  });
  const snapshot = combatSnapshot(result.state, previous);
  for (const item of prepared) {
    const index = snapshot.acknowledgments.findIndex((ack) => ack.playerId === item.input.playerId);
    if (index < 0) throw new Error("Missing combat acknowledgment");
    snapshot.acknowledgments[index] = structuredClone(item.acknowledgment);
  }
  for (const ack of snapshot.acknowledgments) {
    const actor = result.state.players.find((player2) => player2.playerId === ack.playerId);
    if (!actor) throw new Error("Missing combat ownership acknowledgment");
    ack.controlEpoch = actor.controlEpoch;
  }
  snapshot.stateHash = roomWorkloadHash(snapshot);
  return { state: { combat: result.state, snapshot }, outcomes, seatEvents: result.seatEvents };
}

// src/shared/diagnostics/combat-runtime.ts
function createCombatRuntime(scenario = "range", players = 4) {
  const state = createCombatWorkload(scenario, players);
  const campaign = createCombatCampaign(state.combat);
  projectCombatCampaign(state.snapshot, campaign);
  state.snapshot.roomMode = "playing";
  state.snapshot.stateHash = roomWorkloadHash(state.snapshot);
  return {
    ...state,
    history: createEventHistory(state.snapshot.runEpoch),
    connectedPlayerIds: state.combat.players.map((p) => p.playerId),
    pausedFrom: null,
    campaign
  };
}
function combatRuntimeHash(state) {
  const {
    connectionEpoch: _connection,
    snapshotId: _snapshot,
    stateHash: _hash,
    ...snapshot
  } = state.snapshot;
  return stateHash({
    combat: state.combat,
    snapshot,
    history: state.history,
    connectedPlayerIds: state.connectedPlayerIds,
    pausedFrom: state.pausedFrom,
    campaign: state.campaign
  });
}
function check6(ok, message) {
  if (!ok) throw new Error(`Combat journal: ${message}`);
}
function command(value, allowZero) {
  integer(value.sequence, allowZero ? 0 : 1, COUNTER_LIMIT - 1, "journal command sequence");
  integer(value.clientTick, 0, COUNTER_LIMIT - 1, "journal client tick");
  integer(value.controlEpoch, 1, COUNTER_LIMIT - 1, "journal control epoch");
  integer(value.held, 0, HELD_MASK, "journal held mask");
  integer(value.aim, 0, 2, "journal aim");
  integer(value.edges.length, 0, 8, "journal edge count");
  const highWater = /* @__PURE__ */ new Map();
  for (const edge of value.edges) {
    check6(
      EDGE_KINDS.includes(edge.kind) && edge.id > (highWater.get(edge.kind) ?? 0),
      "edge order"
    );
    integer(edge.id, 1, COUNTER_LIMIT - 1, "journal edge ID");
    highWater.set(edge.kind, edge.id);
  }
}
function validatePrepared(current, prepared) {
  integer(prepared.length, 0, 4, "journal owner count");
  let previousId = 0;
  for (const item of prepared) {
    const { input, acknowledgment } = item;
    const previous = current.snapshot.acknowledgments.find((a) => a.playerId === input.playerId);
    check6(previous && input.playerId > previousId, "unknown/duplicate/unordered input owner");
    previousId = input.playerId;
    check6(input.serverTick === current.combat.tick + 1, "nonconsecutive applied input");
    check6(["applied", "stale", "old-control"].includes(input.outcome), "input admission outcome");
    check6(
      typeof item.neutralized === "boolean" && (!item.neutralized || input.outcome === "stale"),
      "neutralization decision"
    );
    check6(input.repeatedHeld === (input.submittedCommand === null), "held-repeat decision");
    command(input.command, input.submittedCommand === null);
    check6(!input.repeatedHeld || input.command.edges.length === 0, "repeated action edge");
    check6(
      input.outcome === "applied" || input.command.held === 0 && input.command.aim === 0 && input.command.edges.length === 0,
      "rejected input not neutral"
    );
    if (input.outcome === "applied")
      check6(input.command.controlEpoch === previous.controlEpoch, "applied old control");
    const expected = structuredClone(previous);
    if (input.submittedCommand !== null) {
      const submitted = input.submittedCommand;
      command(submitted, false);
      check6(submitted.sequence > previous.lastProcessedSequence, "sequence reuse");
      check6(
        input.outcome === "old-control" ? submitted.controlEpoch !== previous.controlEpoch : submitted.controlEpoch === previous.controlEpoch,
        "control rejection mismatch"
      );
      const normalized = structuredClone(submitted);
      if (input.outcome !== "applied") {
        normalized.held = 0;
        normalized.aim = 0;
        normalized.edges = [];
      }
      check6(canonical(input.command) === canonical(normalized), "submitted/applied mismatch");
      expected.lastProcessedSequence = submitted.sequence;
      expected.appliedAtServerTick = input.serverTick;
      for (const edge of submitted.edges) {
        check6(edge.id > (expected.processedEdgeIds[edge.kind - 1] ?? 0), "edge cursor reuse");
        expected.processedEdgeIds[edge.kind - 1] = edge.id;
      }
    }
    check6(canonical(expected) === canonical(acknowledgment), "acknowledgment continuation");
  }
}
function stageCombatRuntime(current, prepared, connections = []) {
  check6(
    current.snapshot.roomMode === "playing" && current.pausedFrom === null,
    "combat requires playing phase"
  );
  integer(connections.length, 0, 4, "combat connection changes");
  const baseline = connections.length ? structuredClone(current) : current;
  let previousConnectionPlayer = 0;
  for (const connection of connections) {
    const actor = baseline.combat.players.find((p) => p.playerId === connection.playerId);
    const ack = baseline.snapshot.acknowledgments.find((a) => a.playerId === connection.playerId);
    const input = prepared.find((p) => p.input.playerId === connection.playerId);
    check6(
      actor && ack && input && connection.playerId > previousConnectionPlayer,
      "connection owner/order"
    );
    integer(connection.connectionEpoch, 1, COUNTER_LIMIT - 1, "connection epoch");
    check6(
      connection.connectionEpoch === ack.connectionEpoch + 1,
      "connection generation must advance once"
    );
    check6(input.input.submittedCommand === null, "new connection must begin with a fresh baseline");
    const fresh = input.input.command;
    check6(
      fresh.sequence === 0 && fresh.clientTick === 0 && fresh.held === 0 && fresh.aim === 0 && fresh.edges.length === 0,
      "new connection must discard prior intent"
    );
    previousConnectionPlayer = connection.playerId;
    actor.jumpBufferTicks = 0;
    actor.processedEdgeIds = [0, 0, 0, 0, 0];
    ack.connectionEpoch = connection.connectionEpoch;
    ack.lastProcessedSequence = 0;
    ack.appliedAtServerTick = 0;
    ack.processedEdgeIds = [0, 0, 0, 0, 0];
  }
  if (connections.length) baseline.snapshot.players = structuredClone(baseline.combat.players);
  validatePrepared(baseline, prepared);
  const result = evaluateCombatTick(
    baseline.combat,
    baseline.snapshot,
    prepared,
    connections.map((value) => value.playerId)
  );
  if (!result.state.snapshot.acknowledgments.some(
    (a) => a.connectionEpoch === result.state.snapshot.connectionEpoch
  )) {
    const recipient = result.state.snapshot.acknowledgments[0];
    if (!recipient) throw new Error("Missing snapshot recipient");
    result.state.snapshot.connectionEpoch = recipient.connectionEpoch;
  }
  const history = stageEventTick(
    current.history,
    result.state.combat.tick,
    combatGameplayEvents(current.combat, result.state.combat),
    combatEventContext(current.snapshot)
  );
  result.state.snapshot.baselineEventCursor = history.cursor;
  result.state.snapshot.stateHash = roomWorkloadHash(result.state.snapshot);
  const connectedPlayerIds = prepared.map((p) => p.input.playerId);
  const campaign = advanceCombatCampaign(current.campaign, result.state.combat, connectedPlayerIds);
  projectCombatCampaign(result.state.snapshot, campaign);
  if (campaign.state.phase === "wipe" || campaign.state.phase === "defeat")
    result.state.snapshot.roomMode = "intermission";
  result.state.snapshot.stateHash = roomWorkloadHash(result.state.snapshot);
  const state = {
    ...result.state,
    history,
    connectedPlayerIds,
    pausedFrom: null,
    campaign
  };
  const boundary = [];
  for (const player2 of current.combat.players) {
    const was = current.connectedPlayerIds.includes(player2.playerId), connected = connectedPlayerIds.includes(player2.playerId);
    const replacement = connections.find((value) => value.playerId === player2.playerId);
    if (replacement) {
      boundary.push({ kind: "neutralize", playerId: player2.playerId, reason: "disconnect" });
      boundary.push({
        kind: "connection",
        playerId: player2.playerId,
        connectionEpoch: replacement.connectionEpoch,
        connected: true
      });
    } else if (was !== connected) {
      const ack = state.snapshot.acknowledgments.find((a) => a.playerId === player2.playerId);
      if (!ack) throw new Error("Missing combat connection owner");
      boundary.push({
        kind: "connection",
        playerId: player2.playerId,
        connectionEpoch: ack.connectionEpoch,
        connected
      });
      if (!connected)
        boundary.push({ kind: "neutralize", playerId: player2.playerId, reason: "disconnect" });
    }
  }
  for (const item of prepared)
    if (item.neutralized)
      boundary.push({ kind: "neutralize", playerId: item.input.playerId, reason: "stale" });
  boundary.push(...result.seatEvents);
  const journal = {
    tick: state.combat.tick,
    runEpoch: state.snapshot.runEpoch,
    inputs: prepared.map((item, index) => ({
      input: structuredClone(item.input),
      edgeResults: item.input.outcome === "applied" ? structuredClone([...result.outcomes[index]?.edgeResults ?? []]) : (item.input.submittedCommand?.edges ?? []).map((edge) => ({
        ...edge,
        outcome: item.input.outcome
      }))
    })),
    acknowledgments: prepared.map((p) => structuredClone(p.acknowledgment)),
    boundaryEvents: boundary.map((event, order) => ({ order, event })),
    beforeHash: combatRuntimeHash(current),
    assertions: [{ kind: "state-hash", value: combatRuntimeHash(state) }]
  };
  return { state, outcomes: result.outcomes, journal };
}
function replayCombatTick(current, journal) {
  check6(
    journal.runEpoch === current.snapshot.runEpoch && journal.tick === current.combat.tick + 1 && journal.beforeHash === combatRuntimeHash(current),
    "missing/changed journal prefix"
  );
  integer(journal.inputs.length, 0, 4, "journal input count");
  integer(journal.boundaryEvents.length, 0, 16, "journal boundary count");
  check6(journal.acknowledgments.length === journal.inputs.length, "journal acknowledgment count");
  const prepared = journal.inputs.map(({ input }, index) => {
    const acknowledgment = journal.acknowledgments[index];
    if (!acknowledgment) throw new Error("Missing journal acknowledgment");
    return {
      input,
      acknowledgment,
      neutralized: journal.boundaryEvents.some(
        ({ event }) => event.kind === "neutralize" && event.playerId === input.playerId && event.reason === "stale"
      )
    };
  });
  const connections = journal.boundaryEvents.flatMap(({ event }) => {
    if (event.kind !== "connection" || !event.connected) return [];
    const before = current.snapshot.acknowledgments.find((a) => a.playerId === event.playerId);
    return before && event.connectionEpoch !== before.connectionEpoch ? [{ playerId: event.playerId, connectionEpoch: event.connectionEpoch }] : [];
  });
  const result = stageCombatRuntime(current, prepared, connections);
  check6(canonical(result.journal) === canonical(journal), "journal outcome/boundary/hash mismatch");
  return result.state;
}

// src/shared/protocol/combat-record.ts
var COMBAT_HEADER_BYTES = 56;
var COMBAT_MEMBER_BYTES = 32;
var AREA_EXPOSURE_BYTES = 48;
var MAX_AREA_EXPOSURES = 64;
var DESTRUCTIBLE_BYTES = 24;
var MAX_DESTRUCTIBLES = 32;
var PICKUP_BYTES = 16;
var MAX_PICKUPS = 64;
var MAX_COMBAT_BYTES = 8792 + AREA_EXPOSURE_BYTES * MAX_AREA_EXPOSURES + DESTRUCTIBLE_BYTES * MAX_DESTRUCTIBLES + PICKUP_BYTES * MAX_PICKUPS;
var PICKUP_STATUSES = ["dormant", "available", "claimed", "expired", "unsupported"];
var PHASES = ["active", "complete", "retired", "failed"];
var STATUSES = ["pending", "alive", "resolved"];
var RESOLUTIONS = [
  "killed",
  "retreated",
  "crushed",
  "out-of-bounds",
  "ambient-timeout",
  "checkpoint-retired"
];
var FAILURES = ["critical-loss", "forbidden-retreat", "invalid-pose"];
var CAUSES = [
  "initial-overlap",
  "residual-overlap",
  "contact-limit",
  "unresolved-contact",
  "retreated",
  "crushed",
  "out-of-bounds"
];
function check7(ok, message) {
  if (!ok) throw new ProtocolError("malformed", `Combat baseline: ${message}`);
}
function length(members, objectives, kills, volumes, props, pickups) {
  check7(Number.isInteger(members) && members >= 0 && members <= 256, "member count");
  check7(Number.isInteger(objectives) && objectives >= 0 && objectives <= 64, "objective count");
  check7(Number.isInteger(kills) && kills >= 1 && kills <= 4, "participant count");
  check7(
    Number.isInteger(volumes) && volumes >= 0 && volumes <= MAX_AREA_EXPOSURES,
    "area volume count"
  );
  check7(Number.isInteger(props) && props >= 0 && props <= MAX_DESTRUCTIBLES, "destructible count");
  check7(Number.isInteger(pickups) && pickups >= 0 && pickups <= MAX_PICKUPS, "pickup count");
  return pickups * PICKUP_BYTES + props * DESTRUCTIBLE_BYTES + COMBAT_HEADER_BYTES + members * COMBAT_MEMBER_BYTES + (objectives + kills) * 8 + volumes * AREA_EXPOSURE_BYTES;
}
function combatRecordBytes(combat) {
  return combat === null ? 0 : length(
    combat.members.length,
    combat.objectives.length,
    combat.kills.length,
    combat.volumes.length,
    combat.props.length,
    combat.pickups.length
  );
}
function writeTick(w, tick2) {
  w.u32(tick2 === null ? 0 : tick2 + 1, tick2 === null ? 0 : 1);
}
function readTick(r) {
  const value = r.u32();
  return value === 0 ? null : value - 1;
}
function writeOptional(w, values, value) {
  if (value !== null) check7(values.includes(value), "unknown enum");
  w.u32(value === null ? 0 : values.indexOf(value) + 1, 0, values.length);
}
function readOptional(r, values) {
  const index = r.u32(0, values.length);
  return index === 0 ? null : values[index - 1] ?? null;
}
function writeCombat(w, combat) {
  w.u16(5);
  w.u16(COMBAT_HEADER_BYTES);
  w.u32(combat.scenarioId, 1);
  w.u32(combat.nextEntityId, 1);
  w.u32(combat.nextActionId, 1);
  w.u32(combat.encounterEventCursor, 0, 1024);
  w.u32(combat.encounterId, 1);
  w.choice(PHASES, combat.phase);
  w.u16(combat.members.length);
  w.u16(combat.objectives.length);
  w.u16(combat.kills.length);
  w.u16(combat.volumes.length);
  w.u16(combat.props.length);
  w.u16(combat.pickups.length);
  w.optionalId(combat.failure?.id ?? null);
  writeTick(w, combat.failure?.tick ?? null);
  writeOptional(w, FAILURES, combat.failure?.reason ?? null);
  writeOptional(w, CAUSES, combat.failure?.cause ?? null);
  for (const pickup of combat.pickups) {
    w.u32(pickup.id, 1);
    w.choice(PICKUP_STATUSES, pickup.status);
    writeTick(w, pickup.resolvedTick);
    w.optionalId(pickup.claimedBy);
  }
  for (const prop of combat.props) {
    w.u32(prop.id, 1);
    w.u32(prop.definitionId, 1);
    w.u32(prop.health, 0, 65535);
    writeTick(w, prop.destroyedTick);
    w.optionalId(prop.destroyerId);
    w.optionalId(prop.destroyActionId);
  }
  for (const member of combat.members) {
    w.u32(member.id, 1);
    for (const flag of [member.required, member.critical, member.retreatAllowed])
      check7(typeof flag === "boolean", "policy flag");
    w.u32(
      Number(member.required) | Number(member.critical) << 1 | Number(member.retreatAllowed) << 2,
      0,
      7
    );
    w.choice(STATUSES, member.status);
    writeTick(w, member.activatedTick);
    writeTick(w, member.resolvedTick);
    writeOptional(w, RESOLUTIONS, member.reason);
    w.optionalId(member.killerId);
    w.zero(4);
  }
  for (const objective of combat.objectives) {
    w.u32(objective.id, 1);
    writeTick(w, objective.completedTick);
  }
  for (const credit of combat.kills) {
    w.u32(credit.playerId, 1);
    w.u32(credit.count, 0, 256);
  }
  for (const volume of combat.volumes) {
    for (const value of [
      volume.id,
      volume.ownerId,
      volume.actionInstanceId,
      volume.definitionId,
      volume.spawnTick,
      volume.endTick
    ])
      w.u32(value, 1);
    w.i32(volume.rect.x, MAX_POSITION);
    w.i32(volume.rect.y, MAX_POSITION);
    w.u32(volume.rect.w, 1, MAX_SHAPE);
    w.u32(volume.rect.h, 1, MAX_SHAPE);
    w.u32(volume.heading, 0, 3);
    w.u16(volume.lobe);
    check7(typeof volume.attached === "boolean", "area attachment flag");
    w.u16(Number(volume.attached));
  }
}
function readCombat(r) {
  const start = r.offset;
  check7(r.u16() === 5 && r.u16() === COMBAT_HEADER_BYTES, "section version/header");
  const cursors = {
    scenarioId: r.u32(1),
    nextEntityId: r.u32(1),
    nextActionId: r.u32(1),
    encounterEventCursor: r.u32(0, 1024),
    encounterId: r.u32(1),
    phase: r.choice(PHASES)
  };
  const members = r.u16(), objectives = r.u16(), kills = r.u16(), volumes = r.u16(), props = r.u16(), pickups = r.u16();
  check7(
    start + length(members, objectives, kills, volumes, props, pickups) === r.bytes.byteLength,
    "section length"
  );
  const id2 = r.u32() || null, tick2 = readTick(r), reason = readOptional(r, FAILURES), cause = readOptional(r, CAUSES);
  check7(
    id2 === null ? tick2 === null && reason === null && cause === null : tick2 !== null && reason !== null && cause !== null,
    "partial failure"
  );
  const combat = {
    ...cursors,
    failure: id2 !== null && tick2 !== null && reason !== null && cause !== null ? { id: id2, tick: tick2, reason, cause } : null,
    props: [],
    pickups: [],
    members: [],
    objectives: [],
    kills: [],
    volumes: []
  };
  for (let i = 0; i < pickups; i++)
    combat.pickups.push({
      id: r.u32(1),
      status: r.choice(PICKUP_STATUSES),
      resolvedTick: readTick(r),
      claimedBy: r.u32() || null
    });
  for (let i = 0; i < props; i++)
    combat.props.push({
      id: r.u32(1),
      definitionId: r.u32(1),
      health: r.u32(0, 65535),
      destroyedTick: readTick(r),
      destroyerId: r.u32() || null,
      destroyActionId: r.u32() || null
    });
  for (let i = 0; i < members; i++) {
    const id3 = r.u32(1), flags = r.u32(0, 7);
    combat.members.push({
      id: id3,
      required: Boolean(flags & 1),
      critical: Boolean(flags & 2),
      retreatAllowed: Boolean(flags & 4),
      status: r.choice(STATUSES),
      activatedTick: readTick(r),
      resolvedTick: readTick(r),
      reason: readOptional(r, RESOLUTIONS),
      killerId: r.u32() || null
    });
    r.zero(4);
  }
  for (let i = 0; i < objectives; i++)
    combat.objectives.push({ id: r.u32(1), completedTick: readTick(r) });
  for (let i = 0; i < kills; i++) combat.kills.push({ playerId: r.u32(1), count: r.u32(0, 256) });
  for (let i = 0; i < volumes; i++) {
    const volume = {
      id: r.u32(1),
      ownerId: r.u32(1),
      actionInstanceId: r.u32(1),
      definitionId: r.u32(1),
      spawnTick: r.u32(1),
      endTick: r.u32(1),
      rect: {
        x: r.i32(MAX_POSITION),
        y: r.i32(MAX_POSITION),
        w: r.u32(1, MAX_SHAPE),
        h: r.u32(1, MAX_SHAPE)
      },
      heading: r.u32(0, 3),
      lobe: r.u16(),
      attached: false
    };
    const flag = r.u16();
    check7(flag <= 1, "area attachment flag");
    volume.attached = flag === 1;
    combat.volumes.push(volume);
  }
  return combat;
}
function validateCombat(snapshot) {
  const combat = snapshot.combat;
  if (combat === null) return;
  check7(
    Number.isSafeInteger(combat.scenarioId) && combat.scenarioId > 0 && combat.scenarioId < COUNTER_LIMIT,
    "scenario identity"
  );
  combatRecordBytes(combat);
  check7(combat.encounterId === snapshot.campaign.encounterId, "encounter identity");
  function ordered3(ids2) {
    check7(
      ids2.every(
        (id2, i) => Number.isSafeInteger(id2) && id2 > 0 && id2 < COUNTER_LIMIT && (i === 0 || id2 > (ids2[i - 1] ?? 0))
      ),
      "unordered/duplicate IDs"
    );
  }
  ordered3(combat.props.map((p) => p.id));
  ordered3(combat.pickups.map((p) => p.id));
  ordered3(combat.members.map((m) => m.id));
  ordered3(combat.objectives.map((o) => o.id));
  ordered3(combat.kills.map((k) => k.playerId));
  const participants = new Set(snapshot.players.map((p) => p.playerId));
  const areaOwners = /* @__PURE__ */ new Map();
  const areaActions = /* @__PURE__ */ new Map();
  for (const [index, volume] of combat.volumes.entries()) {
    const previous = combat.volumes[index - 1];
    check7(
      !previous || volume.id > previous.id || volume.id === previous.id && volume.lobe > previous.lobe,
      "unordered/duplicate area exposures"
    );
    check7(
      participants.has(volume.ownerId) && volume.lobe >= 0 && volume.lobe < 4,
      "area owner/lobe"
    );
    check7(
      volume.spawnTick <= snapshot.tick && snapshot.tick < volume.endTick && volume.endTick - volume.spawnTick <= 120,
      "area lifetime"
    );
    check7(
      Math.abs(volume.rect.x + volume.rect.w) <= MAX_POSITION && Math.abs(volume.rect.y + volume.rect.h) <= MAX_POSITION,
      "area endpoint bounds"
    );
    check7(
      ![
        ...snapshot.players.map((p) => p.body.id),
        ...combat.members.map((m) => m.id),
        ...snapshot.removedIds,
        ...snapshot.enemies.map((e) => e.id),
        ...snapshot.projectiles.map((p) => p.id),
        ...snapshot.vehicles.map((v) => v.body.id),
        ...snapshot.platforms.map((p) => p.id)
      ].includes(volume.id),
      "area entity collision"
    );
    const owner = `${volume.ownerId}/${volume.actionInstanceId}/${volume.definitionId}`;
    check7(
      !areaOwners.has(volume.id) || areaOwners.get(volume.id) === owner,
      "area source ownership"
    );
    areaOwners.set(volume.id, owner);
    check7(
      !areaActions.has(volume.actionInstanceId) || areaActions.get(volume.actionInstanceId) === volume.id,
      "duplicate area action"
    );
    areaActions.set(volume.actionInstanceId, volume.id);
  }
  check7(
    combat.kills.length === participants.size && combat.kills.every((k) => participants.has(k.playerId)),
    "participant roster"
  );
  function time2(value) {
    check7(
      value === null || Number.isSafeInteger(value) && value >= 0 && value <= snapshot.tick && value < COUNTER_LIMIT - 1,
      "future/invalid tick"
    );
  }
  const propOwners = /* @__PURE__ */ new Set([...participants, ...combat.members.map((m) => m.id)]);
  for (const pickup of combat.pickups) {
    check7(
      Object.keys(pickup).sort().join() === "claimedBy,id,resolvedTick,status",
      "pickup fields"
    );
    check7(PICKUP_STATUSES.includes(pickup.status), "pickup status");
    time2(pickup.resolvedTick);
    const resolved = !["dormant", "available"].includes(pickup.status);
    check7(
      resolved === (pickup.resolvedTick !== null) && (!resolved || (pickup.resolvedTick ?? 0) > 0),
      "pickup resolution"
    );
    check7(
      pickup.status === "claimed" ? pickup.claimedBy !== null && participants.has(pickup.claimedBy) : pickup.claimedBy === null,
      "pickup claimant"
    );
    check7(resolved === snapshot.removedIds.includes(pickup.id), "pickup removal mismatch");
    check7(
      ![
        ...participants,
        ...combat.members.map((m) => m.id),
        ...combat.props.map((p) => p.id),
        ...snapshot.vehicles.map((v) => v.body.id),
        ...snapshot.projectiles.map((p) => p.id),
        ...snapshot.platforms.map((p) => p.id),
        ...combat.volumes.map((v) => v.id)
      ].includes(pickup.id),
      "pickup identity reused"
    );
  }
  for (const prop of combat.props) {
    time2(prop.destroyedTick);
    check7(prop.id < combat.nextEntityId, "unallocated prop identity");
    check7(
      Number.isSafeInteger(prop.health) && prop.health >= 0 && prop.health <= 65535,
      "prop health"
    );
    check7(
      Number.isSafeInteger(prop.definitionId) && prop.definitionId > 0 && prop.definitionId < COUNTER_LIMIT,
      "prop definition"
    );
    check7(prop.health === 0 === snapshot.removedIds.includes(prop.id), "prop removal mismatch");
    check7(
      ![
        ...combat.members.map((m) => m.id),
        ...participants,
        ...snapshot.vehicles.map((v) => v.body.id),
        ...snapshot.projectiles.map((p) => p.id),
        ...snapshot.platforms.map((p) => p.id),
        ...combat.volumes.map((v) => v.id)
      ].includes(prop.id),
      "prop identity reused"
    );
    check7(
      prop.health > 0 ? prop.destroyedTick === null && prop.destroyerId === null && prop.destroyActionId === null : prop.destroyedTick !== null && prop.destroyedTick > 0 && prop.destroyerId !== null && propOwners.has(prop.destroyerId) && Number.isSafeInteger(prop.destroyActionId) && (prop.destroyActionId ?? 0) > 0 && (prop.destroyActionId ?? COUNTER_LIMIT) < combat.nextActionId,
      "prop destruction attribution"
    );
  }
  for (const m of combat.members) {
    time2(m.activatedTick);
    time2(m.resolvedTick);
    check7(!m.critical || m.required && !m.retreatAllowed, "critical policy");
    check7(
      m.status === "resolved" === (m.reason !== null) && m.status === "resolved" === (m.resolvedTick !== null),
      "resolution state"
    );
    check7(m.status !== "pending" || m.activatedTick === null, "pending activation");
    check7(m.status !== "alive" || m.activatedTick !== null, "missing activation");
    check7(
      m.status !== "resolved" || m.reason === "checkpoint-retired" || m.activatedTick !== null,
      "unactivated resolution"
    );
    check7(
      m.activatedTick === null || m.resolvedTick === null || m.activatedTick <= m.resolvedTick,
      "resolution before activation"
    );
    check7(
      m.killerId === null || m.reason === "killed" && participants.has(m.killerId),
      "kill attribution"
    );
    check7(
      m.reason !== "ambient-timeout" || !m.required && !m.critical,
      "required ambient cleanup"
    );
    check7(m.reason !== "checkpoint-retired" || combat.phase === "retired", "retirement phase");
    check7(
      m.status !== "resolved" || !snapshot.enemies.some((e) => e.id === m.id && e.health > 0),
      "resolved enemy still alive"
    );
  }
  for (const o of combat.objectives) time2(o.completedTick);
  for (const k of combat.kills)
    check7(
      k.count === combat.members.filter((m) => m.reason === "killed" && m.killerId === k.playerId).length,
      "kill count mismatch"
    );
  const remaining = combat.phase === "retired" ? 0 : combat.members.filter((m) => m.required && m.status !== "resolved").length + combat.objectives.filter((o) => o.completedTick === null).length;
  check7(remaining === snapshot.campaign.remainingEnemies, "remaining count mismatch");
  check7(combat.phase !== "complete" || remaining === 0, "premature completion");
  check7(
    combat.phase !== "retired" || combat.members.every((m) => m.status === "resolved"),
    "incomplete retirement"
  );
  check7(combat.phase === "failed" === (combat.failure !== null), "failure state");
  if (combat.failure !== null) {
    time2(combat.failure.tick);
    check7(
      combat.members.some((m) => m.id === combat.failure?.id),
      "unknown failure owner"
    );
  }
  const entityIds = [
    ...snapshot.players.map((p) => p.body.id),
    ...snapshot.vehicles.map((v) => v.body.id),
    ...snapshot.enemies.map((e) => e.id),
    ...snapshot.projectiles.flatMap((p) => [p.id, p.ownerId]),
    ...snapshot.platforms.map((p) => p.id),
    ...snapshot.threats.map((t) => t.sourceId),
    ...snapshot.removedIds,
    ...combat.members.map((m) => m.id),
    ...combat.pickups.map((p) => p.id),
    ...combat.volumes.map((volume) => volume.id)
  ];
  const actionIds = [
    ...snapshot.players.flatMap((p) => [p.action.actionInstanceId, p.weapon.lastActionInstanceId]),
    ...snapshot.vehicles.flatMap((v) => [v.action.actionInstanceId, v.weapon.lastActionInstanceId]),
    ...snapshot.enemies.map((e) => e.actionInstanceId),
    ...snapshot.projectiles.map((p) => p.actionInstanceId),
    ...snapshot.threats.map((t) => t.actionInstanceId),
    ...combat.volumes.map((volume) => volume.actionInstanceId)
  ];
  check7(combat.nextEntityId > Math.max(0, ...entityIds), "entity allocator reused ID");
  check7(combat.nextActionId > Math.max(0, ...actionIds), "action allocator reused ID");
}

// src/shared/protocol/snapshot-schema.ts
var ROOM_MODES = [
  "lobby",
  "loading",
  "playing",
  "intermission",
  "paused-empty",
  "recovering",
  "completed",
  "expired"
];
var SNAPSHOT_TYPE = 2;
var SNAPSHOT_HEADER_BYTES = 64;
var CAMPAIGN_BYTES = 40;
var BODY_BYTES = 140;
var PLAYER_BYTES = 304;
var VEHICLE_BYTES = 324;
var ENEMY_BYTES = 64;
var PROJECTILE_BYTES = 48;
var PLATFORM_BYTES = 32;
var THREAT_BYTES = 64;
var SNAPSHOT_CAPS = {
  players: 4,
  vehicles: 16,
  enemies: 128,
  projectiles: 256,
  platforms: 64,
  threats: 128,
  removedIds: 512
};
var MIN_SNAPSHOT_BYTES = 448;
var MAX_BASE_SNAPSHOT_BYTES = 39432;
var MAX_SNAPSHOT_BYTES = MAX_BASE_SNAPSHOT_BYTES + MAX_COMBAT_BYTES;

// src/shared/protocol/snapshot.ts
var RULESETS = ["classic", "accessible"];
var PHASES2 = ["playing", "wipe", "intermission", "victory", "defeat"];
var THREAT_MOTION = ["linear", "locked", "authored"];
function check8(condition, message) {
  if (!condition) throw new ProtocolError("malformed", message);
}
function frameLength(counts) {
  for (const key2 of Object.keys(SNAPSHOT_CAPS))
    check8(
      Number.isInteger(counts[key2]) && counts[key2] >= (key2 === "players" ? 1 : 0) && counts[key2] <= SNAPSHOT_CAPS[key2],
      `Invalid ${key2} snapshot count`
    );
  return SNAPSHOT_HEADER_BYTES + CAMPAIGN_BYTES + counts.players * (PLAYER_BYTES + ACK_BYTES) + counts.vehicles * VEHICLE_BYTES + counts.enemies * ENEMY_BYTES + counts.projectiles * PROJECTILE_BYTES + counts.platforms * PLATFORM_BYTES + counts.threats * THREAT_BYTES + counts.removedIds * 4;
}
function ordered2(ids2, label) {
  for (let index = 1; index < ids2.length; index++)
    check8((ids2[index] ?? 0) > (ids2[index - 1] ?? 0), `Unordered/duplicate ${label}`);
}
function validate3(snapshot, context) {
  validateCombat(snapshot);
  context.validateGeometry?.(snapshot);
  if (snapshot.runEpoch !== context.runEpoch || snapshot.connectionEpoch !== context.connectionEpoch)
    throw new ProtocolError("identity-mismatch", "Snapshot belongs to another run/socket");
  if (snapshot.geometryRevision !== context.geometryRevision && !context.geometryRevisions?.has(snapshot.geometryRevision))
    throw new ProtocolError("resync-required", "Snapshot geometry is not loaded");
  check8(
    snapshot.acknowledgments.length === snapshot.players.length,
    "Missing player acknowledgments"
  );
  const shape = (id2) => {
    if (!context.shapeIds.has(id2))
      throw new ProtocolError("resync-required", "Snapshot shape is not loaded");
  };
  const ids2 = [];
  const groups = [
    snapshot.players.map((p) => p.body.id),
    snapshot.vehicles.map((v) => v.body.id),
    snapshot.enemies.map((e) => e.id),
    snapshot.projectiles.map((p) => p.id),
    snapshot.platforms.map((p) => p.id),
    snapshot.combat?.props.filter((p) => p.health > 0).map((p) => p.id) ?? []
  ];
  for (const group of groups) {
    ordered2(group, "entity IDs");
    ids2.push(...group);
  }
  const liveIds = new Set(ids2);
  check8(liveIds.size === ids2.length, "Entity ID reused across snapshot sections");
  ordered2(snapshot.removedIds, "removal IDs");
  check8(
    snapshot.removedIds.every((id2) => !liveIds.has(id2)),
    "Live entity also removed"
  );
  ordered2(
    snapshot.threats.map((threat) => threat.actionInstanceId),
    "threat action IDs"
  );
  check8(
    new Set(snapshot.players.map((p) => p.playerId)).size === snapshot.players.length && new Set(snapshot.players.map((p) => p.slot)).size === snapshot.players.length,
    "Duplicate player/slot"
  );
  check8(
    snapshot.players.some((p) => p.playerId === context.playerId),
    "Local player missing from baseline"
  );
  const removed = new Set(snapshot.removedIds);
  function body2(value) {
    check8(value.contacts.length <= 4, "Contact count limit");
    shape(value.shapeId);
    check8(value.grounded === (value.supportId !== null), "Ground/support mismatch");
    if (value.supportId !== null)
      check8(!removed.has(value.supportId), "Body stands on removed support");
    const keys = /* @__PURE__ */ new Set();
    for (const contact of value.contacts) {
      check8(
        Math.abs(contact.normalX) + Math.abs(contact.normalY) === 1,
        "Noncardinal contact normal"
      );
      check8(contact.toiNumerator <= contact.toiDenominator, "Contact outside tick interval");
      check8(!removed.has(contact.otherId), "Contact with removed geometry");
      const key2 = `${contact.otherId}:${contact.normalX}:${contact.normalY}`;
      check8(!keys.has(key2), "Duplicate contact");
      keys.add(key2);
    }
  }
  function action2(value) {
    check8(value.stateStartTick <= snapshot.tick, "Future action state");
    if (value.kind !== "ready")
      check8(value.actionInstanceId > 0 && value.definitionId > 0, "Active action has no identity");
  }
  for (const [index, player2] of snapshot.players.entries()) {
    body2(player2.body);
    action2(player2.action);
    check8(player2.lifeStartTick <= snapshot.tick, "Future life phase");
    check8(validBodyPresence(player2), "Inconsistent body presence");
    check8(
      player2.firearmAim.nextStepTick <= snapshot.tick + 60,
      "Future firearm turn exceeds content bound"
    );
    check8(player2.facing === -1 || player2.facing === 1, "Invalid facing");
    check8(player2.geometryRevision === snapshot.geometryRevision, "Controller geometry mismatch");
    check8(
      player2.locomotion === "seated" === (player2.vehicleId !== null),
      "Controller seat mismatch"
    );
    if (player2.ignoredSupportId !== null)
      check8(!removed.has(player2.ignoredSupportId), "Ignored support has been removed");
    const ack = snapshot.acknowledgments[index];
    check8(
      Boolean(ack && ack.playerId === player2.playerId && ack.controlEpoch === player2.controlEpoch),
      "Controller/acknowledgment identity mismatch"
    );
    if (!ack) throw new ProtocolError("malformed", "Missing acknowledgment");
    if (player2.playerId === context.playerId && ack.connectionEpoch !== context.connectionEpoch)
      throw new ProtocolError("identity-mismatch", "Local acknowledgment socket mismatch");
    check8(ack.appliedAtServerTick <= snapshot.tick, "Acknowledgment is in the future");
    check8(
      ack.lastProcessedSequence !== 0 || ack.appliedAtServerTick === 0 && ack.processedEdgeIds.every((value) => value === 0),
      "Unprocessed command has processing cursors"
    );
    check8(
      ack.processedEdgeIds.length === 5 && ack.processedEdgeIds.every((value, edge) => value === player2.processedEdgeIds[edge]),
      "Controller/acknowledgment edge mismatch"
    );
    if (player2.vehicleId !== null) {
      const vehicle = snapshot.vehicles.find((v) => v.body.id === player2.vehicleId);
      check8(
        Boolean(
          vehicle && (vehicle.occupantId ?? vehicle.reservedBy) === player2.body.id && vehicle.ownerControlEpoch === player2.controlEpoch
        ),
        "Unowned controller vehicle"
      );
    }
  }
  const seatClaims = /* @__PURE__ */ new Set();
  for (const vehicle of snapshot.vehicles) {
    check8(vehicle.facing === -1 || vehicle.facing === 1, "Invalid vehicle facing");
    check8(
      vehicle.ownerControlEpoch !== null === (vehicle.occupantId !== null || vehicle.reservedBy !== null),
      "Vehicle owner input generation mismatch"
    );
    check8(vehicle.components.length <= 8, "Vehicle component count limit");
    body2(vehicle.body);
    action2(vehicle.action);
    ordered2(
      vehicle.components.map((component) => component.id),
      "vehicle components"
    );
    check8(
      vehicle.occupantId === null || vehicle.reservedBy === null,
      "Occupied seat is also reserved"
    );
    check8(
      vehicle.occupantId === null ? !["occupied", "exiting"].includes(vehicle.lifecycle) : ["occupied", "exiting", "destroying"].includes(vehicle.lifecycle),
      "Vehicle occupancy lifecycle mismatch"
    );
    check8(
      vehicle.lifecycle === "boarding" === (vehicle.reservedBy !== null),
      "Vehicle reservation lifecycle mismatch"
    );
    for (const id2 of [vehicle.occupantId, vehicle.reservedBy]) {
      if (id2 !== null) {
        check8(!seatClaims.has(id2), "Member claims multiple vehicle seats");
        check8(
          snapshot.players.some(
            (p) => p.body.id === id2 && p.life === "alive" && p.vehicleId === vehicle.body.id && p.controlEpoch === vehicle.ownerControlEpoch
          ),
          "Unknown vehicle member"
        );
        seatClaims.add(id2);
      }
    }
    if (vehicle.occupantId !== null)
      check8(
        snapshot.players.some(
          (p) => p.body.id === vehicle.occupantId && p.vehicleId === vehicle.body.id
        ),
        "Vehicle occupant is elsewhere"
      );
  }
  for (const enemy of snapshot.enemies) {
    shape(enemy.shapeId);
    check8(enemy.facing === -1 || enemy.facing === 1, "Invalid enemy facing");
    check8(
      enemy.stateStartTick <= snapshot.tick && enemy.geometryRevision === snapshot.geometryRevision,
      "Enemy state/geometry mismatch"
    );
    if (enemy.supportId !== null)
      check8(!removed.has(enemy.supportId), "Enemy stands on removed geometry");
  }
  for (const projectile of snapshot.projectiles) {
    shape(projectile.shapeId);
    check8(projectile.spawnTick <= snapshot.tick, "Future projectile spawn");
  }
  for (const platform of snapshot.platforms) shape(platform.shapeId);
  for (const threat of snapshot.threats) {
    shape(threat.shapeId);
    check8(
      threat.telegraphTick <= threat.activeTick && threat.activeTick < threat.endTick,
      "Invalid threat activation interval"
    );
  }
}
function writeAck(w, ack) {
  w.u32(ack.playerId, 1);
  w.u32(ack.connectionEpoch, 1);
  w.u32(ack.controlEpoch, 1);
  w.u32(ack.lastProcessedSequence);
  w.u32(ack.appliedAtServerTick);
  check8(ack.processedEdgeIds.length === 5, "Five acknowledgment edge cursors required");
  for (const value of ack.processedEdgeIds) w.u32(value);
}
function readAck(r) {
  return {
    playerId: r.u32(1),
    connectionEpoch: r.u32(1),
    controlEpoch: r.u32(1),
    lastProcessedSequence: r.u32(),
    appliedAtServerTick: r.u32(),
    processedEdgeIds: [r.u32(), r.u32(), r.u32(), r.u32(), r.u32()]
  };
}
function writeEnemy(w, e) {
  w.u32(e.id, 1);
  w.u32(e.definitionId, 1, 65535);
  w.i32(e.x, MAX_POSITION);
  w.i32(e.y, MAX_POSITION);
  w.i32(e.vx, MAX_MOTION);
  w.i32(e.vy, MAX_MOTION);
  w.u32(e.shapeId, 1, 65535);
  w.i32(e.facing, 1);
  w.u32(e.health, 0, 65535);
  w.u32(e.mode, 0, 31);
  w.u32(e.stateStartTick);
  w.u32(e.actionInstanceId);
  w.u32(e.actionDefinitionId, 0, 65535);
  w.u32(e.modeTicks, 0, 65535);
  w.optionalId(e.supportId);
  w.u32(e.geometryRevision, 1);
}
function readEnemy(r) {
  return {
    id: r.u32(1),
    definitionId: r.u32(1, 65535),
    x: r.i32(MAX_POSITION),
    y: r.i32(MAX_POSITION),
    vx: r.i32(MAX_MOTION),
    vy: r.i32(MAX_MOTION),
    shapeId: r.u32(1, 65535),
    facing: r.i32(1),
    health: r.u32(0, 65535),
    mode: r.u32(0, 31),
    stateStartTick: r.u32(),
    actionInstanceId: r.u32(),
    actionDefinitionId: r.u32(0, 65535),
    modeTicks: r.u32(0, 65535),
    supportId: r.u32() || null,
    geometryRevision: r.u32(1)
  };
}
function writeProjectile(w, p) {
  w.u32(p.id, 1);
  w.u32(p.ownerId, 1);
  w.u32(p.actionInstanceId, 1);
  w.u32(p.definitionId, 1, 65535);
  w.i32(p.x, MAX_POSITION);
  w.i32(p.y, MAX_POSITION);
  w.i32(p.vx, MAX_MOTION);
  w.i32(p.vy, MAX_MOTION);
  w.u32(p.spawnTick);
  w.u32(p.lifetimeTicks, 1, 65535);
  w.u32(p.heading, 0, 255);
  w.u32(p.shapeId, 1, 65535);
}
function readProjectile(r) {
  return {
    id: r.u32(1),
    ownerId: r.u32(1),
    actionInstanceId: r.u32(1),
    definitionId: r.u32(1, 65535),
    x: r.i32(MAX_POSITION),
    y: r.i32(MAX_POSITION),
    vx: r.i32(MAX_MOTION),
    vy: r.i32(MAX_MOTION),
    spawnTick: r.u32(),
    lifetimeTicks: r.u32(1, 65535),
    heading: r.u32(0, 255),
    shapeId: r.u32(1, 65535)
  };
}
function writePlatform(w, p) {
  w.u32(p.id, 1);
  w.i32(p.x, MAX_POSITION);
  w.i32(p.y, MAX_POSITION);
  w.i32(p.vx, MAX_MOTION);
  w.i32(p.vy, MAX_MOTION);
  w.u32(p.shapeId, 1, 65535);
  w.u32(p.trajectoryId, 0, 65535);
  w.u32(p.trajectoryTick);
}
function readPlatform(r) {
  return {
    id: r.u32(1),
    x: r.i32(MAX_POSITION),
    y: r.i32(MAX_POSITION),
    vx: r.i32(MAX_MOTION),
    vy: r.i32(MAX_MOTION),
    shapeId: r.u32(1, 65535),
    trajectoryId: r.u32(0, 65535),
    trajectoryTick: r.u32()
  };
}
function writeThreat(w, t) {
  w.u32(t.actionInstanceId, 1);
  w.u32(t.sourceId, 1);
  w.u32(t.definitionId, 1, 65535);
  w.u32(t.telegraphTick);
  w.u32(t.activeTick);
  w.u32(t.endTick);
  w.i32(t.x, MAX_POSITION);
  w.i32(t.y, MAX_POSITION);
  w.i32(t.vx, MAX_MOTION);
  w.i32(t.vy, MAX_MOTION);
  w.u32(t.heading, 0, 255);
  w.optionalId(t.targetId);
  w.choice(THREAT_MOTION, t.motion);
  w.bool(t.cancelled);
  w.u32(t.stateVersion, 1);
  w.u32(t.shapeId, 1, 65535);
}
function readThreat(r) {
  return {
    actionInstanceId: r.u32(1),
    sourceId: r.u32(1),
    definitionId: r.u32(1, 65535),
    telegraphTick: r.u32(),
    activeTick: r.u32(),
    endTick: r.u32(),
    x: r.i32(MAX_POSITION),
    y: r.i32(MAX_POSITION),
    vx: r.i32(MAX_MOTION),
    vy: r.i32(MAX_MOTION),
    heading: r.u32(0, 255),
    targetId: r.u32() || null,
    motion: r.choice(THREAT_MOTION),
    cancelled: r.bool(),
    stateVersion: r.u32(1),
    shapeId: r.u32(1, 65535)
  };
}
function encodeSnapshot(snapshot, context) {
  const counts = {
    players: snapshot.players.length,
    vehicles: snapshot.vehicles.length,
    enemies: snapshot.enemies.length,
    projectiles: snapshot.projectiles.length,
    platforms: snapshot.platforms.length,
    threats: snapshot.threats.length,
    removedIds: snapshot.removedIds.length
  };
  const length2 = frameLength(counts) + combatRecordBytes(snapshot.combat);
  validate3(snapshot, context);
  const w = new Writer(length2);
  w.u16(MAGIC);
  w.u8(PROTOCOL_MAJOR);
  w.u8(PROTOCOL_MINOR);
  w.u8(SNAPSHOT_TYPE);
  w.u8(snapshot.combat === null ? 0 : 1);
  w.u16(length2);
  w.u32(snapshot.runEpoch, 1);
  w.u32(snapshot.connectionEpoch, 1);
  w.u32(snapshot.snapshotId, 1);
  w.u32(snapshot.tick);
  w.u32(snapshot.baselineEventCursor);
  w.u32(snapshot.geometryRevision, 1);
  w.u32(snapshot.stateHash, 0, 4294967295);
  w.u8(counts.players);
  w.u8(counts.vehicles);
  w.u16(counts.enemies);
  w.u16(counts.projectiles);
  w.u16(counts.platforms);
  w.u16(counts.threats);
  w.u16(counts.removedIds);
  w.u8(ROOM_MODES.indexOf(snapshot.roomMode));
  w.zero(15);
  w.i32(snapshot.camera.x, MAX_POSITION);
  w.i32(snapshot.camera.y, MAX_POSITION);
  w.choice(RULESETS, snapshot.campaign.ruleset);
  w.u32(snapshot.campaign.mission, 1, 255);
  w.u32(snapshot.campaign.checkpointId, 1);
  w.u32(snapshot.campaign.continuesRemaining, 0, 65535);
  w.u32(snapshot.campaign.continuesUsed, 0, 65535);
  w.choice(PHASES2, snapshot.campaign.phase);
  w.u32(snapshot.campaign.encounterId, 1);
  w.u32(snapshot.campaign.remainingEnemies, 0, 320);
  for (const ack of snapshot.acknowledgments) writeAck(w, ack);
  for (const player2 of snapshot.players) writePlayer(w, player2);
  for (const vehicle of snapshot.vehicles) writeVehicle(w, vehicle);
  for (const enemy of snapshot.enemies) writeEnemy(w, enemy);
  for (const projectile of snapshot.projectiles) writeProjectile(w, projectile);
  for (const platform of snapshot.platforms) writePlatform(w, platform);
  for (const threat of snapshot.threats) writeThreat(w, threat);
  for (const id2 of snapshot.removedIds) w.u32(id2, 1);
  if (snapshot.combat !== null) writeCombat(w, snapshot.combat);
  check8(w.offset === length2, "Snapshot encoder record size mismatch");
  return w.bytes;
}
function decodeSnapshot(bytes, context) {
  check8(
    bytes.byteLength >= MIN_SNAPSHOT_BYTES && bytes.byteLength <= MAX_SNAPSHOT_BYTES,
    "Snapshot size limit"
  );
  const r = new Reader(bytes);
  check8(
    r.u16() === MAGIC && r.u8() === PROTOCOL_MAJOR && r.u8() === PROTOCOL_MINOR && r.u8() === SNAPSHOT_TYPE,
    "Snapshot frame header"
  );
  const flags = r.u8();
  check8(flags <= 1 && r.u16() === bytes.byteLength, "Snapshot frame header");
  const header = {
    runEpoch: r.u32(1),
    connectionEpoch: r.u32(1),
    snapshotId: r.u32(1),
    tick: r.u32(),
    baselineEventCursor: r.u32(),
    geometryRevision: r.u32(1),
    stateHash: r.u32(0, 4294967295)
  };
  if (header.runEpoch !== context.runEpoch || header.connectionEpoch !== context.connectionEpoch)
    throw new ProtocolError("identity-mismatch", "Snapshot belongs to another run/socket");
  if (header.geometryRevision !== context.geometryRevision && !context.geometryRevisions?.has(header.geometryRevision))
    throw new ProtocolError("resync-required", "Snapshot geometry is not loaded");
  const counts = {
    players: r.u8(),
    vehicles: r.u8(),
    enemies: r.u16(),
    projectiles: r.u16(),
    platforms: r.u16(),
    threats: r.u16(),
    removedIds: r.u16()
  };
  const baseLength = frameLength(counts);
  check8(
    flags === 0 ? baseLength === bytes.byteLength : baseLength + COMBAT_HEADER_BYTES <= bytes.byteLength,
    "Snapshot section lengths do not match frame"
  );
  const roomMode = ROOM_MODES[r.u8()];
  check8(roomMode !== void 0, "Unknown room mode");
  r.zero(15);
  const snapshot = {
    ...header,
    roomMode,
    camera: { x: r.i32(MAX_POSITION), y: r.i32(MAX_POSITION) },
    campaign: {
      ruleset: r.choice(RULESETS),
      mission: r.u32(1, 255),
      checkpointId: r.u32(1),
      continuesRemaining: r.u32(0, 65535),
      continuesUsed: r.u32(0, 65535),
      phase: r.choice(PHASES2),
      encounterId: r.u32(1),
      remainingEnemies: r.u32(0, 320)
    },
    combat: null,
    acknowledgments: [],
    players: [],
    vehicles: [],
    enemies: [],
    projectiles: [],
    platforms: [],
    threats: [],
    removedIds: []
  };
  for (let index = 0; index < counts.players; index++) snapshot.acknowledgments.push(readAck(r));
  for (let index = 0; index < counts.players; index++) snapshot.players.push(readPlayer(r));
  for (let index = 0; index < counts.vehicles; index++) snapshot.vehicles.push(readVehicle(r));
  for (let index = 0; index < counts.enemies; index++) snapshot.enemies.push(readEnemy(r));
  for (let index = 0; index < counts.projectiles; index++)
    snapshot.projectiles.push(readProjectile(r));
  for (let index = 0; index < counts.platforms; index++) snapshot.platforms.push(readPlatform(r));
  for (let index = 0; index < counts.threats; index++) snapshot.threats.push(readThreat(r));
  for (let index = 0; index < counts.removedIds; index++) snapshot.removedIds.push(r.u32(1));
  if (flags === 1) snapshot.combat = readCombat(r);
  check8(r.offset === bytes.byteLength, "Trailing snapshot bytes");
  validate3(snapshot, context);
  return snapshot;
}

// src/shared/session/room-phase.ts
function isPausableRoom(mode) {
  return ["lobby", "loading", "playing", "intermission"].includes(mode);
}
function isWaitingRoom(mode) {
  return ["lobby", "loading", "intermission", "completed"].includes(mode);
}
function requireAdmissionPhase(mode, existing) {
  if (!ROOM_MODES.includes(mode)) throw new Error("protocol-error");
  if (mode === "recovering") throw new Error("outage");
  if (mode === "expired" || mode === "completed" && !existing) throw new Error("room-ended");
  if (!existing && mode !== "lobby" && mode !== "intermission") throw new Error("in-progress");
}

// src/shared/diagnostics/combat-checkpoint.ts
var COMBAT_ARCHIVE_MAX_BYTES = 1024 * 1024;
var COMBAT_SEGMENT_TICKS = 15;
var COMBAT_CHECKPOINT_TICKS = 60;
function check9(ok, message) {
  if (!ok) throw new Error(`Combat checkpoint: ${message}`);
}
function fields2(value, names) {
  check9(
    value !== null && !Array.isArray(value) && Object.keys(value).sort().join(",") === names.split(" ").sort().join(","),
    "unexpected/missing fields"
  );
}
function identity2(value) {
  fields2(value, "simulationVersion simulationBuild contentFormat contentHash runId");
  integer(value.simulationVersion, 1, COUNTER_LIMIT - 1, "simulation version");
  integer(value.contentFormat, 1, COUNTER_LIMIT - 1, "content format");
  for (const digest2 of [value.simulationBuild, value.contentHash])
    check9(typeof digest2 === "string" && /^[a-f0-9]{64}$/u.test(digest2), "identity digest");
  check9(typeof value.runId === "string" && /^[a-z0-9-]{8,80}$/u.test(value.runId), "run identity");
}
function validateCombatCheckpoint(state) {
  fields2(state, "combat snapshot history connectedPlayerIds pausedFrom campaign");
  const { combat, snapshot, history } = state;
  fields2(state.campaign, "state continues");
  fields2(
    state.campaign.state,
    "ruleset mission checkpointId encounterId continuesRemaining continuesUsed phase requiredEntities resolvedEntities"
  );
  for (const decision of state.campaign.continues) {
    fields2(
      decision,
      "ordinal tick checkpointId fromRunEpoch runEpoch nextEntityIdBefore retiredEntityIds spawnedEntityIds retiredVehicleIds spawnedVehicleIds kills"
    );
    for (const kill of decision.kills) fields2(kill, "playerId count");
  }
  validateCombatCampaign(state.campaign, combat, snapshot.runEpoch);
  check9(
    snapshot.roomMode === "paused-empty" ? state.pausedFrom !== null && isPausableRoom(state.pausedFrom) : state.pausedFrom === null,
    "paused room origin"
  );
  fields2(
    combat,
    "format scenario tick nextActionId nextEntityId eventSequence players tanks targets props pickups pickupClaims projectiles rockets beams strikes grenades areas encounter events"
  );
  check9(combat.format === 14, "simulation format");
  integer(combat.tick, 0, COMBAT_LAB_LIMIT, "combat checkpoint tick");
  integer(combat.players.length, 1, 4, "combat checkpoint players");
  integer(combat.projectiles.length, 0, 256, "combat checkpoint projectiles");
  integer(combat.rockets.length, 0, 32, "combat checkpoint rockets");
  integer(combat.beams.length, 0, 4, "combat checkpoint beams");
  integer(combat.strikes.length, 0, 4, "combat checkpoint strikes");
  integer(combat.grenades.length, 0, 32, "combat checkpoint grenades");
  integer(combat.areas.length, 0, 16, "combat area budget");
  integer(
    combat.projectiles.length + combat.rockets.length + combat.beams.length + combat.strikes.length + combat.grenades.length + combat.areas.length,
    0,
    256,
    "attack entity budget"
  );
  integer(combat.events.length, 0, MAX_EVENT_HISTORY, "combat checkpoint notices");
  const initial = createCombatLab(combat.scenario, combat.players.length);
  validateWeaponPickups(
    combat.pickups,
    combatPickupDefinitions(combat.scenario, combat.players.length),
    COMBAT_CATALOG,
    new Set(combat.players.map((p) => p.playerId))
  );
  check9(combat.pickups.tick === combat.tick, "pickup boundary");
  integer(combat.pickupClaims.length, 0, 64, "pickup claim budget");
  const claims = /* @__PURE__ */ new Set();
  const finalGrants = /* @__PURE__ */ new Map();
  for (const claim of combat.pickupClaims) {
    fields2(
      claim,
      "id claimId sourceId playerId slot tick weaponId previousWeaponId previousAmmo ammo"
    );
    const item = combat.pickups.items.find((item2) => item2.id === claim.id);
    const actor = combat.players.find((actor2) => actor2.playerId === claim.playerId);
    check9(
      !claims.has(claim.id) && claim.tick === combat.tick && item?.status === "claimed" && item.resolvedTick === claim.tick && item.claimedBy === claim.playerId && actor?.slot === claim.slot,
      "pickup claim attribution"
    );
    claims.add(claim.id);
    const previous = finalGrants.get(claim.playerId);
    check9(
      !previous || claim.previousWeaponId === previous.weaponId && claim.previousAmmo === previous.ammo,
      "pickup grant chain"
    );
    finalGrants.set(claim.playerId, claim);
  }
  for (const claim of finalGrants.values()) {
    const actor = combat.players.find((actor2) => actor2.playerId === claim.playerId);
    check9(
      actor?.weapon.id === claim.weaponId && actor.weapon.ammo === claim.ammo,
      "pickup terminal inventory"
    );
  }
  for (const contact of combat.pickups.contacts) {
    const actor = combat.players.find((actor2) => actor2.playerId === contact.playerId);
    const def = combatPickupDefinitions(combat.scenario, combat.players.length).find(
      (def2) => def2.id === contact.id
    );
    const shape = actor && COMBAT_SHAPES.get(actor.body.shapeId);
    check9(actor && def && shape, "pickup contact content");
    const rect = worldRect(actor.body, shape.rect, actor.facing);
    check9(
      rect.x <= def.rect.x + def.rect.w && rect.x + rect.w >= def.rect.x && rect.y <= def.rect.y + def.rect.h && rect.y + rect.h >= def.rect.y,
      "pickup contact geometry"
    );
  }
  check9(
    combat.pickups.items.filter((item) => item.status === "claimed" && item.resolvedTick === combat.tick).every((item) => claims.has(item.id)),
    "missing committed pickup claim"
  );
  if (combat.tick > 0)
    for (const event of combatGameplayEvents({ ...combat, tick: combat.tick - 1 }, combat).filter(
      (event2) => event2.kind === "pickup"
    ))
      validateGameplayEvent(event, combatEventContext(snapshot));
  validateDestructibles(
    combat.props,
    combatDestructibles(combat.scenario),
    combat.tick,
    [...combat.players.map((p) => p.playerId), ...combat.targets.map((t) => t.enemy.body.id)],
    combat.nextActionId
  );
  check9(
    snapshot.geometryRevision === combatGeometryRevision(combat.props),
    "committed geometry revision"
  );
  for (const prop of combat.props)
    fields2(prop, "id definitionId health destroyedTick destroyerId destroyActionId");
  const actionOwners = /* @__PURE__ */ new Map();
  const ownAction = (actionId, ownerId) => {
    integer(actionId, 0, combat.nextActionId - 1, "action allocation");
    if (actionId === 0) return;
    const owner = actionOwners.get(actionId);
    check9(owner === void 0 || owner === ownerId, "action owner collision");
    actionOwners.set(actionId, ownerId);
  };
  for (const prop of combat.props)
    if (prop.destroyActionId !== null && prop.destroyerId !== null)
      ownAction(prop.destroyActionId, prop.destroyerId);
  check9(combat.targets.length === initial.targets.length, "target roster");
  const lifecycle2 = new EncounterLifecycle(combatEncounterDefinition(combat));
  lifecycle2.restore(combat.encounter);
  check9(
    combat.encounter.tick === combat.tick && combat.eventSequence === combat.encounter.receipts.length,
    "ledger boundary"
  );
  for (const [index, actor] of combat.players.entries()) {
    ownAction(actor.action.actionInstanceId, actor.playerId);
    ownAction(actor.weapon.lastActionInstanceId, actor.playerId);
    const original = initial.players[index];
    check9(
      original && actor.playerId === original.playerId && actor.body.id === original.body.id && actor.slot === original.slot,
      "player roster"
    );
    check9(COMBAT_CATALOG.firearms.has(actor.weapon.id), "unsupported weapon");
    fields2(actor.firearmAim, "pitch nextStepTick");
    validateFirearmAim(actor, combat.tick, COMBAT_CATALOG);
    validatePlayerLife(actor, combat.tick, snapshot.campaign.ruleset);
    if (actor.action.kind !== "ready") {
      const timeline = COMBAT_CATALOG.timelines.get(actor.action.definitionId);
      const age = combat.tick - actor.action.stateStartTick;
      check9(
        ["fire", "melee", "grenade", "enter", "exit"].includes(actor.action.kind) && timeline && age >= 0 && age < timeline.durationTicks && actor.action.nextMarkerIndex === timeline.markers.filter((marker) => marker.tickOffset <= age).length,
        "action marker cursor"
      );
      if (actor.action.kind === "melee" || actor.action.kind === "grenade")
        check9(
          FOOT_ACTION_PROFILES[actor.action.kind].timelineIds.includes(actor.action.definitionId),
          "foot action timeline"
        );
      if (actor.action.kind === "enter" || actor.action.kind === "exit")
        check9(actor.vehicleId !== null, "transfer requires seat owner");
    }
  }
  check9(combat.tanks.length === initial.tanks.length, "tank roster");
  for (const tank of combat.tanks) {
    fields2(
      tank,
      "body definitionId kind lifecycle occupantId reservedBy controlEpoch ownerControlEpoch facing heading invulnerableTicks armor action components weapon jumpBufferTicks coyoteTicks turnTicks disconnectedTicks lastGunOwnerId lastGunControlEpoch"
    );
    fields2(tank.action, "kind actionInstanceId stateStartTick definitionId nextMarkerIndex");
    fields2(tank.weapon, "id ammo cooldownTicks shotOrdinal lastActionInstanceId");
    validateTankState(tank, combat.tick, combat.players, TANK_PROFILE, COMBAT_CATALOG);
    ownAction(tank.action.actionInstanceId, tankOwner(tank) ?? tank.lastGunOwnerId ?? 0);
    ownAction(tank.weapon.lastActionInstanceId, tank.lastGunOwnerId ?? 0);
  }
  for (const [index, target] of combat.targets.entries()) {
    fields2(target, "enemy health shield rifle guard");
    fields2(target.enemy, "body facing geometryRevision life removalReason turns");
    const original = initial.targets[index], member = combat.encounter.members[index], body2 = target.enemy.body;
    check9(
      original && member && body2.id === member.id && target.shield === original.shield,
      "target identity"
    );
    integer(target.health, 0, original.health, "target health");
    check9(
      target.rifle !== null === (original.rifle !== null) && target.guard !== null === (original.guard !== null),
      "enemy attack policy"
    );
    if (target.guard) {
      const guard = target.guard;
      fields2(guard, "phase integrity facing turnFacing targetId action hitIds");
      fields2(guard.action, "actionInstanceId stateStartTick definitionId nextMarkerIndex");
      check9(
        guard.action.actionInstanceId !== 0 || member.status === "pending",
        "unstarted shield action"
      );
      ownAction(guard.action.actionInstanceId, body2.id);
      validateShield(
        guard,
        target.enemy,
        combat.tick,
        combat.nextActionId,
        combat.players,
        COMBAT_CATALOG,
        SHIELD_PROFILE,
        [...combat.props.map((prop) => prop.id), ...combat.tanks.map((tank) => tank.body.id)]
      );
    }
    if (target.rifle) {
      ownAction(target.rifle.action.actionInstanceId, target.enemy.body.id);
      fields2(target.rifle, "action targetId aim facing");
      fields2(
        target.rifle.action,
        "kind actionInstanceId stateStartTick definitionId nextMarkerIndex"
      );
      validateRifleState(
        target.rifle,
        target.enemy,
        combat.tick,
        combat.nextActionId,
        combat.players,
        COMBAT_CATALOG,
        RIFLE_PROFILE
      );
    }
    integer(target.enemy.turns, 0, combat.tick, "enemy turn cursor");
    check9(
      target.health === 0 === (target.enemy.life === "removed") && ["alive", "removed"].includes(target.enemy.life),
      "enemy life"
    );
    check9(target.health === 0 === (member.status === "resolved"), "enemy ledger resolution");
    check9(
      target.enemy.removalReason === null || target.health === 0 && ["crushed", "out-of-bounds"].includes(target.enemy.removalReason) && member.reason === target.enemy.removalReason,
      "enemy removal cause"
    );
    check9(
      target.enemy.geometryRevision === snapshot.geometryRevision && [-1, 1].includes(target.enemy.facing),
      "enemy geometry/facing"
    );
    const writer = new Writer(BODY_BYTES);
    writeBody(writer, body2);
    check9(canonical(readBody(new Reader(writer.bytes))) === canonical(body2), "body schema");
    check9(
      COMBAT_SHAPES.has(body2.shapeId) && body2.grounded === (body2.supportId !== null),
      "enemy support/shape"
    );
    const contacts = /* @__PURE__ */ new Set();
    for (const contact of body2.contacts) {
      const key2 = `${contact.otherId}:${contact.normalX}:${contact.normalY}`;
      check9(
        Math.abs(contact.normalX) + Math.abs(contact.normalY) === 1 && contact.toiNumerator <= contact.toiDenominator && !contacts.has(key2),
        "enemy contacts"
      );
      contacts.add(key2);
    }
  }
  for (const projectile of combat.projectiles) {
    ownAction(projectile.actionInstanceId, projectile.ownerId);
    fields2(projectile, "id ownerId team actionInstanceId definitionId position velocity spawnTick");
    fields2(projectile.position, "x y");
    fields2(projectile.velocity, "x y");
    const attack2 = COMBAT_ATTACKS.get(projectile.definitionId);
    check9(
      attack2 && attack2.kind === "swept-projectile" && attack2.material === "bullet" && (projectile.team === 1 && combat.players.some((p) => p.playerId === projectile.ownerId) && projectile.definitionId !== 3 || projectile.team === 2 && projectile.definitionId === 3 && combat.targets.some((t) => t.rifle && t.enemy.body.id === projectile.ownerId)),
      "projectile owner/definition"
    );
    check9(
      projectile.spawnTick > 0 && projectile.spawnTick <= combat.tick && combat.tick - projectile.spawnTick < attack2.lifetimeTicks,
      "projectile lifetime"
    );
    check9(
      attack2.id === TANK_PROFILE.attackId ? TANK_PROFILE.headings.some(
        ({ velocity: velocity2 }) => velocity2.x === projectile.velocity.x && velocity2.y === projectile.velocity.y
      ) : attack2.id === 2 ? COMBAT_CATALOG.firearms.get("heavy-machine-gun")?.sweep?.headings.some(
        ({ velocity: velocity2 }) => Math.abs(projectile.velocity.x) === velocity2.x && projectile.velocity.y === velocity2.y
      ) : Math.abs(projectile.velocity.x) + Math.abs(projectile.velocity.y) === attack2.speed,
      "projectile motion"
    );
  }
  const attackIds = new Set(combat.projectiles.map((projectile) => projectile.id));
  const ownAttack = (source) => {
    integer(source.id, 1, combat.nextEntityId - 1, "attack entity allocation");
    check9(
      !attackIds.has(source.id) && !combat.targets.some((target) => target.enemy.body.id === source.id) && !combat.tanks.some((tank) => tank.body.id === source.id) && !combat.players.some((player2) => player2.body.id === source.id),
      "attack entity collision"
    );
    attackIds.add(source.id);
    check9(
      source.team === 1 && combat.players.some((player2) => player2.playerId === source.ownerId),
      "foot attack ownership"
    );
    ownAction(source.actionInstanceId, source.ownerId);
  };
  const rocketActions = /* @__PURE__ */ new Set();
  const beamOwners = /* @__PURE__ */ new Set();
  for (const beam of combat.beams) {
    fields2(
      beam,
      "id ownerId team actionInstanceId definitionId spawnTick tick origin heading length"
    );
    fields2(beam.origin, "x y");
    ownAttack(beam);
    check9(!beamOwners.has(beam.ownerId), "duplicate beam owner");
    beamOwners.add(beam.ownerId);
    validateBeamPulse(beam, LASER_ATTACK, LASER_PROFILE);
    const actor = combat.players.find((player2) => player2.playerId === beam.ownerId);
    const anchor = combatAreaAnchor(combat, beam);
    check9(
      beam.tick === combat.tick && actor?.weapon.id === "laser" && actor.action.stateStartTick === beam.spawnTick && anchor !== null && canonical(anchor.origin) === canonical(beam.origin) && anchor.heading === beam.heading,
      "beam owner/clock/muzzle"
    );
  }
  for (const rocket2 of combat.rockets) {
    fields2(
      rocket2,
      "id ownerId team actionInstanceId definitionId position velocity spawnTick tick launchHeading heading speed targetId nextAcquireTick nextTurnTick"
    );
    fields2(rocket2.position, "x y");
    fields2(rocket2.velocity, "x y");
    ownAttack(rocket2);
    check9(!rocketActions.has(rocket2.actionInstanceId), "duplicate rocket action");
    rocketActions.add(rocket2.actionInstanceId);
    check9(
      rocket2.definitionId === ROCKET_ATTACK.id && rocket2.tick === combat.tick,
      "rocket definition/tick"
    );
    check9(
      rocket2.targetId === null || combat.targets.some((target) => target.enemy.body.id === rocket2.targetId),
      "rocket target roster"
    );
    validateRocket(rocket2, ROCKET_PROFILE);
    sweepBounds(worldRect(rocket2.position, ROCKET_SHAPE.rect, 1), { x: 0, y: 0 });
  }
  for (const strike of combat.strikes) {
    fields2(strike, "id ownerId team actionInstanceId definitionId spawnTick endTick hitIds");
    ownAttack(strike);
    const owner = combat.players.find((player2) => player2.playerId === strike.ownerId);
    check9(
      owner?.life === "alive" && owner.action.kind === "melee" && owner.action.actionInstanceId === strike.actionInstanceId && strike.definitionId === 4 && strike.spawnTick === owner.action.stateStartTick + (COMBAT_CATALOG.timelines.get(owner.action.definitionId)?.markers.find((marker) => marker.kind === "activate-hitbox")?.tickOffset ?? -1) && strike.spawnTick <= combat.tick && strike.endTick === strike.spawnTick + (COMBAT_ATTACKS.get(4)?.lifetimeTicks ?? 0) && combat.tick < strike.endTick,
      "active melee continuation"
    );
    integer(strike.hitIds.length, 0, COMBAT_ATTACKS.get(4)?.maxTargets ?? 0, "melee hit budget");
    for (const [index, id2] of strike.hitIds.entries())
      check9(
        (index === 0 || id2 > (strike.hitIds[index - 1] ?? 0)) && (combat.targets.some((target) => target.enemy.body.id === id2) || combat.props.some((prop) => prop.id === id2)),
        "melee hit ledger"
      );
  }
  const areaActions = /* @__PURE__ */ new Set();
  for (const area of combat.areas) {
    fields2(
      area,
      "id ownerId team actionInstanceId definitionId startTick emitted cancelledTick lobes hits"
    );
    ownAttack(area);
    check9(!areaActions.has(area.actionInstanceId), "duplicate area action");
    areaActions.add(area.actionInstanceId);
    const definition2 = COMBAT_ATTACKS.get(area.definitionId), profile = AREA_PROFILES.get(area.definitionId);
    check9(definition2 && profile, "area attack definition");
    for (const lobe of area.lobes) {
      fields2(lobe, "index origin heading reach");
      fields2(lobe.origin, "x y");
    }
    for (const hit of area.hits) fields2(hit, "entityId nextTick");
    validateArea(area, combat.tick, definition2, profile, [
      ...combat.targets.map((target) => target.enemy.body.id),
      ...combat.props.map((prop) => prop.id)
    ]);
    const anchor = combatAreaAnchor(combat, area);
    if (anchor) {
      const owner = combat.players.find((player2) => player2.playerId === area.ownerId);
      check9(owner?.action.stateStartTick === area.startTick, "area action start");
      check9(
        COMBAT_CATALOG.timelines.get(owner.action.definitionId)?.markers.some(
          (marker) => marker.kind === "spawn-attack" && marker.payloadId === area.definitionId
        ),
        "area action definition"
      );
    }
    if (profile.kind === "flame-volumes") {
      check9(anchor === null === (area.cancelledTick !== null), "flame action cancellation");
      for (const lobe of area.lobes) {
        const age = combat.tick - area.startTick - (profile.emissionOffsets[lobe.index] ?? 0);
        if (age < profile.attachedTicks)
          check9(
            anchor && canonical(lobe.origin) === canonical(anchor.origin) && lobe.heading === anchor.heading,
            "attached flame anchor"
          );
      }
    } else check9(area.cancelledTick === null, "released shotgun cancellation");
  }
  for (const grenade of combat.grenades) {
    const bounds = grenadeVelocityBounds(GRENADE_PROFILE);
    fields2(grenade, "id ownerId team actionInstanceId definitionId body spawnTick bounces");
    ownAttack(grenade);
    check9(
      grenade.definitionId === 5 && grenade.body.id === grenade.id && grenade.body.shapeId === GRENADE_PROFILE.bodyShapeId,
      "grenade body/definition"
    );
    integer(
      grenade.spawnTick,
      Math.max(1, combat.tick - GRENADE_PROFILE.fuseTicks + 1),
      combat.tick,
      "grenade fuse continuation"
    );
    integer(grenade.bounces, 0, GRENADE_PROFILE.maximumBounces, "grenade bounce count");
    const writer = new Writer(BODY_BYTES);
    writeBody(writer, grenade.body);
    check9(
      canonical(readBody(new Reader(writer.bytes))) === canonical(grenade.body),
      "grenade body schema"
    );
    integer(grenade.body.vx, -bounds.x, bounds.x, "grenade horizontal motion");
    integer(
      grenade.body.vy,
      -bounds.up,
      GRENADE_PROFILE.terminalVelocity,
      "grenade vertical motion"
    );
  }
  for (const notice2 of combat.events) {
    ownAction(notice2.actionInstanceId, notice2.ownerId);
    fields2(
      notice2,
      "kind ownerId actionInstanceId markerIndex source position impact targetId beam"
    );
    fields2(notice2.position, "x y");
    check9(
      notice2.beam !== null === (notice2.kind === "shot" && notice2.source?.definitionId === LASER_ATTACK.id),
      "beam notice presence"
    );
    if (notice2.beam !== null) {
      fields2(notice2.beam, "heading length width");
      check9(
        notice2.beam.width === LASER_PROFILE.width && notice2.beam.length <= LASER_PROFILE.range,
        "beam notice profile"
      );
      beamSegments(notice2.position, notice2.beam.heading, notice2.beam.length, notice2.beam.width);
    }
    check9(
      [
        "shot",
        "sound",
        "muzzle-blocked",
        "impact",
        "killed",
        "melee",
        "throw",
        "action-sound",
        "explosion",
        "shield-break",
        "prop-destroyed"
      ].includes(notice2.kind),
      "notice kind"
    );
    check9(
      combat.players.some((p) => p.playerId === notice2.ownerId) || combat.targets.some((t) => (t.rifle || t.guard) && t.enemy.body.id === notice2.ownerId),
      "notice owner"
    );
    integer(notice2.actionInstanceId, 1, combat.nextActionId - 1, "notice action");
    integer(notice2.markerIndex, 0, 127, "notice marker");
    integer(notice2.position.x, -MAX_POSITION, MAX_POSITION, "notice x");
    integer(notice2.position.y, -MAX_POSITION, MAX_POSITION, "notice y");
    check9(
      notice2.targetId === null || combat.props.some((prop) => prop.id === notice2.targetId) || combat.tanks.some((tank) => tank.body.id === notice2.targetId) || combat.targets.some((t) => t.enemy.body.id === notice2.targetId) || combat.players.some((p) => p.body.id === notice2.targetId),
      "notice target"
    );
    check9(
      ["impact", "killed", "shield-break", "prop-destroyed"].includes(notice2.kind) === (notice2.impact !== null),
      "notice impact"
    );
    check9(notice2.impact === null === (notice2.source !== null), "notice source kind");
    if (notice2.source !== null) {
      if ("controlEpoch" in notice2.source) {
        const source = notice2.source;
        fields2(
          source,
          "vehicleId" in source ? "definitionId controlEpoch shotOrdinal vehicleId" : "definitionId controlEpoch shotOrdinal"
        );
        const owner = combat.players.find((player2) => player2.playerId === notice2.ownerId);
        const tank = "vehicleId" in source ? combat.tanks.find((tank2) => tank2.body.id === source.vehicleId) : null;
        const weapon2 = "vehicleId" in source ? tank?.weapon : owner?.weapon;
        check9(
          owner && weapon2?.lastActionInstanceId === notice2.actionInstanceId && weapon2.shotOrdinal === source.shotOrdinal && ("vehicleId" in source ? tank?.lastGunOwnerId === owner.playerId && tank.lastGunControlEpoch === source.controlEpoch && source.definitionId === TANK_PROFILE.attackId : owner.controlEpoch === source.controlEpoch && source.definitionId !== TANK_PROFILE.attackId),
          "notice confirmation identity"
        );
        integer(notice2.source.shotOrdinal, 1, COUNTER_LIMIT - 1, "notice shot ordinal");
      } else if ("timelineId" in notice2.source) {
        fields2(notice2.source, "definitionId timelineId stateStartTick");
        const enemy = combat.targets.find((target) => target.enemy.body.id === notice2.ownerId);
        const player2 = combat.players.find((player3) => player3.playerId === notice2.ownerId);
        check9(
          enemy?.rifle ? enemy.rifle.action.actionInstanceId === notice2.actionInstanceId && enemy.rifle.action.definitionId === notice2.source.timelineId && notice2.source.definitionId === 3 : enemy?.guard ? enemy.guard.action.actionInstanceId === notice2.actionInstanceId && enemy.guard.action.definitionId === notice2.source.timelineId && enemy.guard.action.stateStartTick === notice2.source.stateStartTick : player2 && [4, 5].includes(notice2.source.definitionId) && (player2.life === "death" || player2.action.actionInstanceId === notice2.actionInstanceId),
          "timeline notice owner"
        );
        const marker = COMBAT_CATALOG.timelines.get(notice2.source.timelineId)?.markers[notice2.markerIndex];
        check9(
          marker && marker.tickOffset === combat.tick - notice2.source.stateStartTick && marker.payloadId === notice2.source.definitionId && marker.kind === (["sound", "action-sound"].includes(notice2.kind) ? "sound" : notice2.kind === "melee" ? "activate-hitbox" : "spawn-attack"),
          "timeline notice marker"
        );
      } else {
        fields2(notice2.source, "definitionId spawnTick sourceId");
        check9(
          notice2.kind === "explosion" && (notice2.source.definitionId === 5 && notice2.source.spawnTick === combat.tick - GRENADE_PROFILE.fuseTicks || notice2.source.definitionId === ROCKET_ATTACK.id && notice2.source.spawnTick < combat.tick && combat.tick - notice2.source.spawnTick <= ROCKET_PROFILE.lifetimeTicks),
          "detonation lifetime boundary"
        );
        integer(notice2.source.spawnTick, 1, combat.tick - 1, "detonation birth tick");
        integer(notice2.source.sourceId, 1, combat.nextEntityId - 1, "detonation source");
      }
      if (!("spawnTick" in notice2.source))
        check9(
          [...COMBAT_CATALOG.timelines.values()].some((timeline) => {
            const marker = timeline.markers[notice2.markerIndex];
            return marker?.payloadId === notice2.source?.definitionId && marker?.kind === (["sound", "action-sound"].includes(notice2.kind) ? "sound" : notice2.kind === "melee" ? "activate-hitbox" : "spawn-attack");
          }),
          "notice marker payload"
        );
    }
    if (notice2.impact !== null) {
      const impact2 = notice2.impact;
      fields2(
        impact2,
        "sourceId definitionId actionInstanceId ownerId colliderId entityId kind damage position time"
      );
      fields2(impact2.time, "numerator denominator");
      fields2(impact2.position, "x y");
      integer(impact2.sourceId, 1, combat.nextEntityId - 1, "impact projectile");
      check9(COMBAT_ATTACKS.has(impact2.definitionId), "impact definition");
      integer(impact2.colliderId, 1, COUNTER_LIMIT - 1, "impact collider");
      integer(impact2.damage, 0, 65535, "impact damage");
      integer(impact2.time.denominator, 1, 2 ** 17, "impact denominator");
      integer(impact2.time.numerator, 0, impact2.time.denominator, "impact numerator");
      check9(
        impact2.actionInstanceId === notice2.actionInstanceId && impact2.ownerId === notice2.ownerId && impact2.entityId === notice2.targetId && canonical(impact2.position) === canonical(notice2.position),
        "impact attribution"
      );
      check9(
        ["terrain", "shield", "body"].includes(impact2.kind) && impact2.kind === "terrain" === (impact2.entityId === null),
        "impact material"
      );
      check9(notice2.kind !== "killed" || impact2.kind === "body", "kill material");
      if (notice2.kind === "prop-destroyed") {
        const prop = combat.props.find((prop2) => prop2.id === notice2.targetId);
        check9(
          impact2.kind === "body" && prop?.health === 0 && prop.destroyedTick === combat.tick && prop.destroyerId === notice2.ownerId && prop.destroyActionId === notice2.actionInstanceId,
          "prop destruction attribution"
        );
      }
      if (notice2.kind === "shield-break") {
        const broken = combat.targets.find(
          (target) => target.enemy.body.id === notice2.targetId
        )?.guard;
        check9(
          impact2.kind === "shield" && broken?.integrity === 0 && broken.action.stateStartTick === combat.tick,
          "shield break attribution"
        );
      }
    }
  }
  const local = snapshot.acknowledgments.find(
    (a) => a.connectionEpoch === snapshot.connectionEpoch
  );
  check9(local, "checkpoint snapshot recipient");
  const context = {
    runEpoch: snapshot.runEpoch,
    connectionEpoch: snapshot.connectionEpoch,
    playerId: local.playerId,
    geometryRevision: snapshot.geometryRevision,
    shapeIds: new Set(COMBAT_SHAPES.keys())
  };
  const restored = decodeSnapshot(encodeSnapshot(snapshot, context), context);
  check9(
    canonical(restored) === canonical(snapshot) && snapshot.stateHash === roomWorkloadHash(snapshot),
    "snapshot schema/hash"
  );
  check9(
    canonical(combatSnapshot(combat, snapshot, state.campaign)) === canonical(snapshot),
    "combat/snapshot mismatch"
  );
  integer(state.connectedPlayerIds.length, 0, combat.players.length, "connected roster size");
  check9(
    state.connectedPlayerIds.every(
      (id2, i) => combat.players.some((p) => p.playerId === id2) && (i === 0 || id2 > (state.connectedPlayerIds[i - 1] ?? 0))
    ),
    "connected roster"
  );
  fields2(history, "runEpoch tick cursor entries capEvictions ageEvictions");
  check9(
    history.runEpoch === snapshot.runEpoch && history.tick === combat.tick && history.cursor === snapshot.baselineEventCursor,
    "event history boundary"
  );
  eventCounter(history.cursor, true);
  integer(history.entries.length, 0, MAX_EVENT_HISTORY, "retained event count");
  integer(history.capEvictions, 0, history.cursor, "event cap evictions");
  integer(history.ageEvictions, 0, history.cursor, "event age evictions");
  check9(
    history.capEvictions + history.ageEvictions + history.entries.length === history.cursor,
    "event retention accounting"
  );
  const retainedPickupClaims = /* @__PURE__ */ new Set();
  for (const [index, envelope] of history.entries.entries()) {
    fields2(envelope, "cursor tick counter event");
    eventCounter(envelope.cursor);
    integer(
      envelope.tick,
      Math.max(1, combat.tick - EVENT_HISTORY_TICKS + 1),
      combat.tick,
      "retained event tick"
    );
    integer(envelope.counter, 0, MAX_EVENT_HISTORY - 1, "retained event counter");
    check9(
      envelope.cursor === history.cursor - history.entries.length + index + 1,
      "retained cursor gap"
    );
    const previous = history.entries[index - 1];
    check9(!previous || followsEvent(previous, envelope), "event identity gap");
    validateGameplayEvent(envelope.event, combatEventContext(snapshot));
    const event = envelope.event;
    check9(
      event.origin === "player" ? combat.players.some((player2) => player2.playerId === event.ownerId) : combat.targets.some(
        (target) => (target.rifle || target.guard) && target.enemy.body.id === event.ownerId
      ),
      "retained event owner/origin"
    );
    ownAction(event.actionInstanceId, event.ownerId);
    if (event.kind === "pickup") {
      check9(
        event.pickup && !retainedPickupClaims.has(event.pickup.claimId),
        "duplicate retained pickup claim"
      );
      retainedPickupClaims.add(event.pickup.claimId);
      const item = combat.pickups.items.find((item2) => item2.id === event.targetId);
      check9(
        item?.status === "claimed" && item.claimedBy === event.ownerId && item.resolvedTick === envelope.tick,
        "retained pickup attribution"
      );
    }
    check9(envelope.event.actionInstanceId < combat.nextActionId, "future retained action");
  }
}
async function digest(payload) {
  const hash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(payload));
  return Array.from(new Uint8Array(hash), (b) => b.toString(16).padStart(2, "0")).join("");
}
async function seal(kind, value, expected) {
  identity2(expected);
  const payload = canonical(value);
  check9(
    new TextEncoder().encode(payload).byteLength < COMBAT_ARCHIVE_MAX_BYTES / 2,
    "payload size limit"
  );
  return canonical({
    format: 17,
    protocolMajor: PROTOCOL_MAJOR,
    protocolMinor: PROTOCOL_MINOR,
    kind,
    identity: expected,
    payload,
    sha256: await digest(payload)
  });
}
async function unseal(raw, kind, expected) {
  identity2(expected);
  check9(
    typeof raw === "string" && raw.length <= COMBAT_ARCHIVE_MAX_BYTES && new TextEncoder().encode(raw).byteLength <= COMBAT_ARCHIVE_MAX_BYTES,
    "archive size limit"
  );
  const envelope = JSON.parse(raw);
  fields2(envelope, "format protocolMajor protocolMinor kind identity payload sha256");
  check9(
    envelope.format === 17 && envelope.kind === kind && envelope.protocolMajor === PROTOCOL_MAJOR && envelope.protocolMinor === PROTOCOL_MINOR,
    "archive version/kind"
  );
  check9(canonical(envelope.identity) === canonical(expected), "archive identity mismatch");
  check9(
    typeof envelope.payload === "string" && envelope.payload.length < COMBAT_ARCHIVE_MAX_BYTES / 2 && await digest(envelope.payload) === envelope.sha256,
    "archive checksum mismatch"
  );
  const value = JSON.parse(envelope.payload);
  check9(canonical(value) === envelope.payload, "noncanonical payload");
  return value;
}
async function encodeCombatCheckpoint(current, expected) {
  const state = structuredClone(current);
  validateCombatCheckpoint(state);
  return seal("checkpoint", state, { ...expected });
}
async function decodeCombatCheckpoint(raw, expected) {
  const state = await unseal(raw, "checkpoint", expected);
  validateCombatCheckpoint(state);
  return state;
}
async function encodeAcceptedCombatJournalSegment(start, entries, accepted, expected) {
  const saved = structuredClone([...entries]);
  integer(saved.length, 1, COMBAT_SEGMENT_TICKS, "journal segment ticks");
  let hash = combatRuntimeHash(start);
  for (const [index, entry] of saved.entries()) {
    check9(
      entry.runEpoch === start.snapshot.runEpoch && entry.tick === start.combat.tick + index + 1 && entry.beforeHash === hash && entry.assertions.length === 1 && entry.assertions[0]?.kind === "state-hash" && /^[a-f0-9]{8}$/u.test(entry.assertions[0].value),
      "accepted journal prefix"
    );
    hash = entry.assertions[0].value;
  }
  validateCombatCheckpoint(accepted);
  check9(
    accepted.snapshot.runEpoch === start.snapshot.runEpoch && accepted.combat.tick === start.combat.tick + saved.length && combatRuntimeHash(accepted) === hash,
    "accepted journal boundary"
  );
  const segment = {
    runEpoch: start.snapshot.runEpoch,
    fromTick: start.combat.tick + 1,
    throughTick: accepted.combat.tick,
    entries: saved
  };
  return seal("journal", segment, { ...expected });
}
async function restoreCombatJournalSegment(start, raw, expected) {
  const segment = await unseal(raw, "journal", expected);
  fields2(segment, "runEpoch fromTick throughTick entries");
  integer(segment.entries.length, 1, COMBAT_SEGMENT_TICKS, "journal segment ticks");
  check9(
    segment.runEpoch === start.snapshot.runEpoch && segment.fromTick === start.combat.tick + 1 && segment.throughTick === start.combat.tick + segment.entries.length,
    "journal segment gap/epoch"
  );
  let state = start;
  for (const entry of segment.entries) state = replayCombatTick(state, entry);
  validateCombatCheckpoint(state);
  return state;
}

// src/shared/diagnostics/combat-writer.ts
var COMBAT_BACKLOG_LIMIT = 30;
var CombatJournalWriter = class {
  constructor(port, initial, onPause, keepAlive) {
    this.port = port;
    this.onPause = onPause;
    this.keepAlive = keepAlive;
    this.durable = structuredClone(initial);
    this.acceptedTick = initial.combat.tick;
    this.acceptedHash = combatRuntimeHash(initial);
    this.durableHash = this.acceptedHash;
  }
  port;
  onPause;
  keepAlive;
  durable;
  durableHash;
  acceptedTick;
  acceptedHash;
  queued = [];
  queuedEnd = null;
  pending = null;
  sealed = null;
  failure = null;
  accepting = true;
  get status() {
    return {
      runEpoch: this.durable.snapshot.runEpoch,
      committedTick: this.durable.combat.tick,
      committedHash: this.durableHash,
      acceptedTick: this.acceptedTick,
      backlogTicks: this.acceptedTick - this.durable.combat.tick,
      queuedTicks: this.queued.length,
      writing: this.pending !== null,
      failure: this.failure,
      accepting: this.accepting,
      limitTicks: COMBAT_BACKLOG_LIMIT
    };
  }
  record(entry, accepted) {
    if (!this.accepting || this.failure) throw new Error("Combat journal writer requires recovery");
    if (entry.tick !== this.acceptedTick + 1 || entry.runEpoch !== this.durable.snapshot.runEpoch || entry.beforeHash !== this.acceptedHash || accepted.combat.tick !== entry.tick || accepted.snapshot.runEpoch !== entry.runEpoch || entry.assertions.length !== 1 || entry.assertions[0]?.kind !== "state-hash")
      throw new Error("Combat writer input prefix changed");
    this.queued.push(structuredClone(entry));
    this.acceptedTick = entry.tick;
    this.acceptedHash = entry.assertions[0].value;
    if (this.queued.length === COMBAT_SEGMENT_TICKS) this.queuedEnd = structuredClone(accepted);
    this.pump();
    if (this.acceptedTick - this.durable.combat.tick >= COMBAT_BACKLOG_LIMIT)
      this.fail("journal-backlog-limit");
  }
  fail(reason) {
    if (this.failure !== null) return;
    this.failure = reason.slice(0, 256);
    this.accepting = false;
    this.onPause(this.failure);
  }
  pump() {
    if (this.pending || !this.accepting || this.queued.length < COMBAT_SEGMENT_TICKS) return;
    const accepted = this.queuedEnd;
    if (!accepted) throw new Error("Missing accepted combat boundary");
    this.queuedEnd = null;
    const entries = this.queued.splice(0, COMBAT_SEGMENT_TICKS);
    this.write(entries, accepted);
  }
  write(entries, accepted) {
    this.pending = Promise.resolve().then(() => this.port.commit(this.durable, entries, accepted)).then((state) => {
      const last = entries.at(-1);
      const hash = combatRuntimeHash(state);
      if (!last || state.combat.tick !== last.tick || state.snapshot.runEpoch !== last.runEpoch || hash !== last.assertions[0]?.value)
        throw new Error("Combat durable acknowledgment mismatch");
      this.durable = structuredClone(state);
      this.durableHash = hash;
    }).catch((error) => {
      this.fail(String(error));
    }).finally(() => {
      this.pending = null;
      this.pump();
    });
    this.keepAlive(this.pending);
  }
  /** Stop at the accepted boundary and confirm its final, possibly short segment without new ticks. */
  seal(current) {
    if (this.sealed) return this.sealed;
    if (!this.accepting || this.failure)
      return Promise.reject(new Error("Combat journal writer requires recovery"));
    if (current.combat.tick !== this.acceptedTick || combatRuntimeHash(current) !== this.acceptedHash)
      return Promise.reject(new Error("Combat seal boundary changed"));
    const accepted = structuredClone(current);
    this.accepting = false;
    this.sealed = (async () => {
      await this.pending;
      if (this.failure) throw new Error(this.failure);
      if (this.queued.length) {
        this.write(this.queued.splice(0), accepted);
        this.queuedEnd = null;
        await this.pending;
      }
      if (this.failure) throw new Error(this.failure);
      if (this.durable.combat.tick !== this.acceptedTick || this.durableHash !== this.acceptedHash)
        throw new Error("Unconfirmed combat pause tail");
      return structuredClone(this.durable);
    })();
    return this.sealed;
  }
  /** Stop scheduling new work, wait for the in-flight write, then recover only the durable head. */
  async retire() {
    this.accepting = false;
    if (this.sealed) await this.sealed.catch(() => {
    });
    else await this.pending;
    this.queued = [];
    this.queuedEnd = null;
  }
};

// src/game/content/compiled/navigation.json
var navigation_default = {
  format: 1,
  compiler: "edgefall-ldtk-1",
  editorSchema: "1.5.3",
  contentHash: "a6434f8f6468122005419e4c88336a3e6dbf29547ca01ed1057b818514c2dbb6",
  graphicsHash: "8523df73611d93e17ef71e49e31839cfac6fb97ba022b330e87793f6b447b47a",
  gameplay: {
    format: 1,
    simulationHz: 60,
    dimensions: {
      w: 128e3,
      h: 102400
    },
    definitions: {
      format: 1,
      simulationHz: 60,
      shapes: [
        {
          id: 1,
          rect: {
            x: -1792,
            y: -8704,
            w: 3584,
            h: 8704
          }
        },
        {
          id: 2,
          rect: {
            x: -1792,
            y: -5120,
            w: 3584,
            h: 5120
          }
        },
        {
          id: 3,
          rect: {
            x: -1280,
            y: -8192,
            w: 2560,
            h: 7680
          }
        },
        {
          id: 4,
          rect: {
            x: -256,
            y: -256,
            w: 512,
            h: 512
          }
        },
        {
          id: 5,
          rect: {
            x: -10240,
            y: -8192,
            w: 20480,
            h: 8192
          }
        },
        {
          id: 6,
          rect: {
            x: -6144,
            y: -7680,
            w: 12288,
            h: 7680
          }
        }
      ],
      poses: [
        {
          id: 1,
          frame: "fixture-operative-idle",
          durationTicks: 6,
          sockets: [
            {
              name: "muzzle",
              point: {
                x: 3840,
                y: -5888
              }
            },
            {
              name: "hand",
              point: {
                x: 2560,
                y: -5120
              }
            }
          ],
          hurtShapeIds: [
            3
          ]
        },
        {
          id: 2,
          frame: "fixture-tank-idle",
          durationTicks: 12,
          sockets: [
            {
              name: "seat",
              point: {
                x: 0,
                y: -5120
              }
            },
            {
              name: "ejection",
              point: {
                x: -10240,
                y: 0
              }
            }
          ],
          hurtShapeIds: [
            6
          ]
        }
      ],
      timelines: [
        {
          id: 1,
          durationTicks: 6,
          poses: [
            1
          ],
          markers: [
            {
              tickOffset: 0,
              kind: "spawn-attack",
              payloadId: 1,
              socket: "muzzle"
            }
          ]
        },
        {
          id: 2,
          durationTicks: 12,
          poses: [
            2
          ],
          markers: [
            {
              tickOffset: 11,
              kind: "seat-transfer",
              payloadId: 1,
              socket: "seat"
            }
          ]
        }
      ],
      attacks: [
        {
          id: 1,
          kind: "swept-projectile",
          shapeId: 4,
          damage: 1,
          lifetimeTicks: 30,
          speed: 3072,
          maxTargets: 1,
          repeatDamageTicks: 0,
          material: "bullet"
        }
      ],
      weapons: [
        {
          id: "sidearm",
          attackId: 1,
          timelineId: 1,
          cadenceTicks: 10,
          ammoPerAction: 0,
          pickupAmmo: "unlimited",
          aimPolicy: "cardinal",
          visualFamily: "fixture-sidearm",
          audioFamily: "fixture-sidearm"
        }
      ],
      actors: [
        {
          id: 1,
          locomotion: "grounded",
          standingShapeId: 1,
          crouchedShapeId: 2,
          idlePoseId: 1,
          runSpeed: 768,
          jumpVelocity: -1430,
          gravity: 55,
          terminalVelocity: 2048
        },
        {
          id: 2,
          locomotion: "grounded",
          standingShapeId: 6,
          crouchedShapeId: 6,
          idlePoseId: 2,
          runSpeed: 640,
          jumpVelocity: -1200,
          gravity: 60,
          terminalVelocity: 2048
        }
      ],
      vehicles: [
        {
          id: 1,
          kind: "tank",
          actorId: 2,
          armor: 3,
          weaponId: "sidearm",
          seat: {
            socket: {
              x: 0,
              y: -5120
            },
            ejectionCandidates: [
              {
                x: -10240,
                y: 0
              },
              {
                x: 10240,
                y: 0
              }
            ],
            boardingSensorShapeId: 5,
            boardingTimelineId: 2
          }
        }
      ]
    },
    terrain: [
      {
        id: 1501,
        kind: "solid",
        rect: {
          x: 0,
          y: 76800,
          w: 25600,
          h: 10240
        },
        delta: {
          x: 0,
          y: 0
        }
      },
      {
        id: 1514,
        kind: "solid",
        rect: {
          x: 33280,
          y: 76800,
          w: 30720,
          h: 10240
        },
        delta: {
          x: 0,
          y: 0
        }
      },
      {
        id: 1529,
        kind: "solid",
        rect: {
          x: 71680,
          y: 76800,
          w: 56320,
          h: 10240
        },
        delta: {
          x: 0,
          y: 0
        }
      }
    ],
    camera: {
      x: 0,
      y: 0,
      w: 128e3,
      h: 92160
    },
    killBounds: {
      x: 0,
      y: 0,
      w: 128e3,
      h: 102400
    },
    exit: {
      x: 94720,
      y: 66560,
      w: 5120,
      h: 10240
    },
    entry: {
      actorId: 1,
      actor: {
        body: {
          id: 1e6,
          x: 12800,
          y: 76800,
          vx: 0,
          vy: 0,
          remainderX: 0,
          remainderY: 0,
          shapeId: 1,
          supportId: 1501,
          grounded: true,
          contacts: []
        },
        life: "alive",
        locomotion: "grounded",
        action: {
          kind: "ready",
          actionInstanceId: 0,
          stateStartTick: 0,
          definitionId: 0,
          nextMarkerIndex: 0
        },
        facing: 1,
        aim: 0,
        jumpBufferTicks: 0,
        coyoteTicks: 4,
        ignoredSupportId: null,
        ignoredSupportTicks: 0,
        vehicleId: null,
        geometryRevision: 1
      }
    },
    checkpoint: {
      x: 97280,
      y: 76800,
      facing: 1
    },
    spawns: [
      {
        actorId: 1,
        actor: {
          body: {
            id: 1000007,
            x: 20480,
            y: 76800,
            vx: 0,
            vy: 0,
            remainderX: 0,
            remainderY: 0,
            shapeId: 1,
            supportId: 1501,
            grounded: true,
            contacts: []
          },
          life: "alive",
          locomotion: "grounded",
          action: {
            kind: "ready",
            actionInstanceId: 0,
            stateStartTick: 0,
            definitionId: 0,
            nextMarkerIndex: 0
          },
          facing: 1,
          aim: 0,
          jumpBufferTicks: 0,
          coyoteTicks: 4,
          ignoredSupportId: null,
          ignoredSupportTicks: 0,
          vehicleId: null,
          geometryRevision: 1
        }
      }
    ],
    links: [
      {
        actorId: 1,
        actor: {
          body: {
            id: 1000005,
            x: 12800,
            y: 76800,
            vx: 0,
            vy: 0,
            remainderX: 0,
            remainderY: 0,
            shapeId: 1,
            supportId: 1501,
            grounded: true,
            contacts: []
          },
          life: "alive",
          locomotion: "grounded",
          action: {
            kind: "ready",
            actionInstanceId: 0,
            stateStartTick: 0,
            definitionId: 0,
            nextMarkerIndex: 0
          },
          facing: 1,
          aim: 0,
          jumpBufferTicks: 0,
          coyoteTicks: 4,
          ignoredSupportId: null,
          ignoredSupportTicks: 0,
          vehicleId: null,
          geometryRevision: 1
        },
        definition: {
          id: 1000005,
          kind: "jump",
          sourceSpanId: 4,
          sourceX: 12800,
          destinationSpanId: 5,
          destinationMinX: 51968,
          destinationMaxX: 51968,
          direction: 1,
          maxTicks: 90
        }
      },
      {
        actorId: 1,
        actor: {
          body: {
            id: 1000006,
            x: 51200,
            y: 76800,
            vx: 0,
            vy: 0,
            remainderX: 0,
            remainderY: 0,
            shapeId: 1,
            supportId: 1514,
            grounded: true,
            contacts: []
          },
          life: "alive",
          locomotion: "grounded",
          action: {
            kind: "ready",
            actionInstanceId: 0,
            stateStartTick: 0,
            definitionId: 0,
            nextMarkerIndex: 0
          },
          facing: 1,
          aim: 0,
          jumpBufferTicks: 0,
          coyoteTicks: 4,
          ignoredSupportId: null,
          ignoredSupportTicks: 0,
          vehicleId: null,
          geometryRevision: 1
        },
        definition: {
          id: 1000006,
          kind: "jump",
          sourceSpanId: 5,
          sourceX: 51200,
          destinationSpanId: 6,
          destinationMinX: 90368,
          destinationMaxX: 90368,
          direction: 1,
          maxTicks: 90
        }
      }
    ],
    route: {
      status: "route",
      geometryRevision: 1,
      from: {
        x: 12800,
        y: 76800,
        facing: 1
      },
      destination: {
        x: 97280,
        y: 76800,
        facing: 1
      },
      shapeId: 1,
      costTicks: 117,
      linkIds: [
        1000005,
        1000006
      ],
      legs: [
        {
          kind: "settle",
          ticks: 1
        },
        {
          kind: "traverse",
          linkId: 1000005,
          ticks: 51
        },
        {
          kind: "walk",
          direction: -1,
          ticks: 1
        },
        {
          kind: "walk",
          direction: -1,
          ticks: 1
        },
        {
          kind: "walk",
          direction: 1,
          ticks: 1
        },
        {
          kind: "settle",
          ticks: 1
        },
        {
          kind: "traverse",
          linkId: 1000006,
          ticks: 51
        },
        {
          kind: "walk",
          direction: 1,
          ticks: 9
        },
        {
          kind: "settle",
          ticks: 1
        }
      ]
    }
  },
  presentation: {
    format: 1,
    tileset: {
      id: 20,
      path: "terrain.png",
      width: 10,
      height: 10,
      cell: 10
    },
    tiles: [
      {
        x: 0,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 10,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 20,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 30,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 40,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 50,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 60,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 70,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 80,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 90,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 130,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 140,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 150,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 160,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 170,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 180,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 190,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 200,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 210,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 220,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 230,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 240,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 280,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 290,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 300,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 310,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 320,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 330,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 340,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 350,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 360,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 370,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 380,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 390,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 400,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 410,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 420,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 430,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 440,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 450,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 460,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 470,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 480,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 490,
        y: 300,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 0,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 10,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 20,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 30,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 40,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 50,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 60,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 70,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 80,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 90,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 130,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 140,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 150,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 160,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 170,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 180,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 190,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 200,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 210,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 220,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 230,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 240,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 280,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 290,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 300,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 310,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 320,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 330,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 340,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 350,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 360,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 370,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 380,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 390,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 400,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 410,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 420,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 430,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 440,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 450,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 460,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 470,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 480,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 490,
        y: 310,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 0,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 10,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 20,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 30,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 40,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 50,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 60,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 70,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 80,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 90,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 130,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 140,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 150,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 160,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 170,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 180,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 190,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 200,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 210,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 220,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 230,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 240,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 280,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 290,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 300,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 310,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 320,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 330,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 340,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 350,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 360,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 370,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 380,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 390,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 400,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 410,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 420,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 430,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 440,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 450,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 460,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 470,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 480,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 490,
        y: 320,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 0,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 10,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 20,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 30,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 40,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 50,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 60,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 70,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 80,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 90,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 130,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 140,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 150,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 160,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 170,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 180,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 190,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 200,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 210,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 220,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 230,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 240,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 280,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 290,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 300,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 310,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 320,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 330,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 340,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 350,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 360,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 370,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 380,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 390,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 400,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 410,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 420,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 430,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 440,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 450,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 460,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 470,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 480,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      },
      {
        x: 490,
        y: 330,
        sx: 0,
        sy: 0,
        flip: 0,
        tile: 0
      }
    ],
    assetSha256: "db04ec948db7f056562d9e8bef0c029dd98bf630f9d1a60708cebcdea764e627"
  },
  buildHash: "e7042cbe2114695b232b5958580c5e3bd881da7f5adbe528f7e38ff3f7ae9688"
};

// src/shared/diagnostics/controller-workload.ts
var CONTROLLER_IDENTITY = {
  ...PROBE_IDENTITY,
  contentHash: navigation_default.contentHash,
  presentationBuild: navigation_default.graphicsHash
};
var CONTROLLER_TERRAIN = navigation_default.gameplay.terrain;
var CONTROLLER_INPUT_PREFILL_TICKS = 5;
var shapes = new Map(
  navigation_default.gameplay.definitions.shapes.map((s) => [s.id, s])
);
var definition = navigation_default.gameplay.definitions.actors.find(
  (a) => a.id === navigation_default.gameplay.entry.actorId
);
if (!definition) throw new Error("Missing compiled controller definition");
var grid = new CollisionGrid(CONTROLLER_TERRAIN);
function createControllerWorkload() {
  const world = createRoomWorkload(1);
  world.players = Array.from(
    { length: 4 },
    (_, slot) => ({
      ...footActor(),
      ...structuredClone(navigation_default.gameplay.entry.actor),
      playerId: slot + 1,
      slot,
      controlEpoch: 1,
      body: {
        ...structuredClone(navigation_default.gameplay.entry.actor.body),
        id: slot + 1,
        x: navigation_default.gameplay.entry.actor.body.x + slot * 3 * 256
      }
    })
  );
  world.enemies = [];
  world.projectiles = [];
  world.platforms = [];
  world.vehicles = [];
  world.threats = [];
  world.campaign.remainingEnemies = 0;
  return world;
}
function stepNetworkController(actor, command2, tick2) {
  if (!definition || command2.controlEpoch !== actor.controlEpoch)
    throw new Error("Controller epoch/policy mismatch");
  const frame = { tick: tick2, geometryRevision: 1 };
  const result = stepFootController(
    actor,
    { held: command2.held, jumpPressed: command2.edges.some((e) => e.kind === Edge.Jump) },
    definition,
    shapes,
    new CollisionIndex(grid, [], frame),
    frame
  );
  if (result.status === "failed") throw new Error(`Controller physics: ${result.physics.reason}`);
  let next = result.actor;
  next.processedEdgeIds = [...actor.processedEdgeIds];
  for (const edge of command2.edges) next.processedEdgeIds[edge.kind - 1] = edge.id;
  if (next.life === "alive" && next.body.y > 390 * 256)
    next = damagePlayer(next, tick2, 1, "classic", "fall").actor;
  let jumpHandled = false;
  const edges = command2.edges.map((edge) => {
    const applied = edge.kind === Edge.Jump && !jumpHandled && result.status === "complete" && (result.jumpRequest === "consumed" || result.jumpRequest === "buffered");
    if (edge.kind === Edge.Jump) jumpHandled = true;
    return { ...edge, outcome: applied ? "applied" : "unavailable" };
  });
  return { actor: next, edges };
}

// src/shared/protocol/codec.ts
function requireValid(condition, message) {
  if (!condition) throw new ProtocolError("malformed", message);
}
function bounded2(value, min, max, field) {
  requireValid(Number.isSafeInteger(value) && value >= min && value <= max, `Invalid ${field}`);
}
function counter(value, field, allowZero = false) {
  bounded2(value, allowZero ? 0 : 1, COUNTER_LIMIT - 1, field);
}
function validateInputBatch(batch) {
  counter(batch.runEpoch, "runEpoch");
  counter(batch.connectionEpoch, "connectionEpoch");
  counter(batch.packetSequence, "packetSequence");
  counter(batch.snapshotAck, "snapshotAck", true);
  counter(batch.eventAck, "eventAck", true);
  requireValid(
    Array.isArray(batch.commands) && batch.commands.length <= MAX_COMMANDS,
    "Invalid command count"
  );
  let previous;
  const edgeHighWater = /* @__PURE__ */ new Map();
  for (const command2 of batch.commands) {
    counter(command2.sequence, "sequence");
    counter(command2.clientTick, "clientTick", true);
    counter(command2.controlEpoch, "controlEpoch");
    bounded2(command2.held, 0, HELD_MASK, "held bits");
    bounded2(command2.aim, 0, 2, "aim");
    requireValid(
      Array.isArray(command2.edges) && command2.edges.length <= MAX_EDGES_PER_COMMAND,
      "Invalid edge count"
    );
    if (previous) {
      requireValid(command2.sequence === previous.sequence + 1, "Noncontiguous command sequence");
      requireValid(command2.clientTick === previous.clientTick + 1, "Noncontiguous client tick");
    }
    previous = command2;
    for (const edge of command2.edges) {
      bounded2(edge.kind, 1, 5, "edge kind");
      counter(edge.id, "edge ID");
      const before = edgeHighWater.get(edge.kind);
      if (before !== void 0)
        requireValid(
          edge.id > before && edge.id - before <= MAX_EDGE_ADVANCE,
          "Nonmonotonic edge ID"
        );
      edgeHighWater.set(edge.kind, edge.id);
    }
  }
}
function decodeInputBatch(bytes, expected) {
  requireValid(
    bytes.byteLength >= INPUT_HEADER_BYTES && bytes.byteLength <= MAX_INPUT_BYTES,
    "Input frame size"
  );
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  requireValid(
    view.getUint16(0, true) === MAGIC && view.getUint8(2) === PROTOCOL_MAJOR && view.getUint8(3) === PROTOCOL_MINOR && view.getUint8(4) === INPUT_TYPE,
    "Unsupported frame header"
  );
  requireValid(
    view.getUint8(5) === 0 && view.getUint16(6, true) === bytes.byteLength,
    "Invalid flags/length"
  );
  requireValid(view.getUint8(29) === 0 && view.getUint16(30, true) === 0, "Reserved header bits");
  const count = view.getUint8(28);
  requireValid(count <= MAX_COMMANDS, "Command count");
  const batch = {
    runEpoch: view.getUint32(8, true),
    connectionEpoch: view.getUint32(12, true),
    packetSequence: view.getUint32(16, true),
    snapshotAck: view.getUint32(20, true),
    eventAck: view.getUint32(24, true),
    commands: []
  };
  if (batch.runEpoch !== expected.runEpoch || batch.connectionEpoch !== expected.connectionEpoch)
    throw new ProtocolError("identity-mismatch", "Input belongs to another run/socket epoch");
  let offset = INPUT_HEADER_BYTES;
  for (let index = 0; index < count; index++) {
    requireValid(offset + COMMAND_BYTES <= bytes.byteLength, "Truncated command");
    const edgeCount = view.getUint8(offset + 15);
    requireValid(
      edgeCount <= MAX_EDGES_PER_COMMAND && view.getUint32(offset + 16, true) === 0,
      "Edge count/reserved command bits"
    );
    const command2 = {
      sequence: view.getUint32(offset, true),
      clientTick: view.getUint32(offset + 4, true),
      controlEpoch: view.getUint32(offset + 8, true),
      held: view.getUint16(offset + 12, true),
      aim: view.getUint8(offset + 14),
      edges: []
    };
    offset += COMMAND_BYTES;
    requireValid(offset + edgeCount * EDGE_BYTES <= bytes.byteLength, "Truncated edges");
    for (let edgeIndex = 0; edgeIndex < edgeCount; edgeIndex++) {
      requireValid(
        view.getUint8(offset + 1) === 0 && view.getUint16(offset + 2, true) === 0,
        "Reserved edge bits"
      );
      const edge = {
        kind: view.getUint8(offset),
        id: view.getUint32(offset + 4, true)
      };
      command2.edges.push(edge);
      offset += EDGE_BYTES;
    }
    batch.commands.push(command2);
  }
  requireValid(offset === bytes.byteLength, "Trailing input bytes");
  validateInputBatch(batch);
  return batch;
}

// src/shared/protocol/input-mapping.ts
var INPUT_MAPPING_CAPABILITY = 1;
var fields3 = [
  "type",
  "runEpoch",
  "connectionEpoch",
  "playerId",
  "snapshotId",
  "snapshotTick",
  "nextSequence",
  "nextCommandTick"
].sort().join(",");
function validateInputMapping(value) {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).sort().join(",") !== fields3)
    throw new ProtocolError("malformed", "Invalid input mapping fields");
  const record = value;
  if (record.type !== "input-mapping")
    throw new ProtocolError("malformed", "Invalid input mapping type");
  for (const key2 of [
    "runEpoch",
    "connectionEpoch",
    "playerId",
    "snapshotId",
    "snapshotTick",
    "nextSequence",
    "nextCommandTick"
  ]) {
    const n = record[key2];
    if (typeof n !== "number" || !Number.isSafeInteger(n) || n < (key2 === "snapshotTick" ? 0 : 1) || n >= COUNTER_LIMIT)
      throw new ProtocolError("malformed", "Invalid input mapping counter");
  }
  if (record.nextCommandTick !== Number(record.snapshotTick) + 1)
    throw new ProtocolError("malformed", "Mapping must start after its snapshot boundary");
  return { ...record };
}
function mappingForSnapshot(snapshot, playerId) {
  const ack = snapshot.acknowledgments.find((value) => value.playerId === playerId);
  if (!ack || ack.connectionEpoch !== snapshot.connectionEpoch)
    throw new ProtocolError("malformed", "Missing mapping owner");
  return validateInputMapping({
    type: "input-mapping",
    runEpoch: snapshot.runEpoch,
    connectionEpoch: snapshot.connectionEpoch,
    playerId,
    snapshotId: snapshot.snapshotId,
    snapshotTick: snapshot.tick,
    nextSequence: ack.lastProcessedSequence + 1,
    nextCommandTick: snapshot.tick + 1
  });
}

// src/shared/protocol/input-stream.ts
function copyCommand(command2) {
  return { ...command2, edges: command2.edges.map((edge) => ({ ...edge })) };
}
function requireValue(condition, message) {
  if (!condition) throw new ProtocolError("malformed", message);
}
function counter2(value, allowZero = false) {
  requireValue(
    Number.isSafeInteger(value) && value >= (allowZero ? 0 : 1) && value < COUNTER_LIMIT,
    "Invalid stream counter"
  );
}
var InputStream = class _InputStream {
  identity;
  playerId;
  tickOffset;
  packets = /* @__PURE__ */ new Map();
  accepted = /* @__PURE__ */ new Map();
  sentSnapshots = /* @__PURE__ */ new Set();
  queue = [];
  admittedEdges = [0, 0, 0, 0, 0];
  ack;
  lastPacket = 0;
  lastSequence = 0;
  lastClientTick = -1;
  lastServerTick;
  lastNowMs = 0;
  freshAtMs = null;
  lastHeld = null;
  sentSnapshot = 0;
  sentEvent = 0;
  snapshotAck = 0;
  eventAck = 0;
  stopped = false;
  applying = false;
  constructor(options) {
    for (const value of [
      options.runEpoch,
      options.connectionEpoch,
      options.playerId,
      options.controlEpoch
    ])
      counter2(value);
    counter2(options.baselineServerTick, true);
    this.identity = { runEpoch: options.runEpoch, connectionEpoch: options.connectionEpoch };
    this.playerId = options.playerId;
    this.lastServerTick = options.baselineServerTick;
    this.tickOffset = options.baselineServerTick + 1;
    this.ack = {
      playerId: options.playerId,
      connectionEpoch: options.connectionEpoch,
      controlEpoch: options.controlEpoch,
      lastProcessedSequence: 0,
      appliedAtServerTick: 0,
      processedEdgeIds: [0, 0, 0, 0, 0]
    };
  }
  get acknowledgment() {
    return { ...this.ack, processedEdgeIds: [...this.ack.processedEdgeIds] };
  }
  get queuedCommands() {
    return this.queue.length;
  }
  get requiresResync() {
    return this.stopped;
  }
  get deliveryAcknowledgments() {
    return { snapshot: this.snapshotAck, event: this.eventAck };
  }
  /** Call only after a full snapshot/event prefix was actually sent to this socket. */
  recordSent(snapshotId, eventCursor) {
    this.guard();
    counter2(snapshotId);
    counter2(eventCursor, true);
    requireValue(
      snapshotId > this.sentSnapshot && eventCursor >= this.sentEvent,
      "Nonmonotonic sent baseline"
    );
    this.sentSnapshots.add(snapshotId);
    this.sentSnapshot = snapshotId;
    this.sentEvent = eventCursor;
    while (this.sentSnapshots.size > MAX_PREDICTION_TICKS) {
      const oldest = this.sentSnapshots.values().next().value;
      if (oldest !== void 0) this.sentSnapshots.delete(oldest);
    }
  }
  /** An authoritative seat/ownership boundary invalidates held intent immediately. */
  setControlEpoch(controlEpoch) {
    this.guard();
    counter2(controlEpoch);
    requireValue(controlEpoch === this.ack.controlEpoch + 1, "Control epoch must increment once");
    this.ack.controlEpoch = controlEpoch;
    this.lastHeld = null;
    this.freshAtMs = null;
  }
  receive(bytes, receivedAtMs, serverTick, policy = "active") {
    this.guard();
    try {
      return this.admit(decodeInputBatch(bytes, this.identity), receivedAtMs, serverTick, policy);
    } catch (error) {
      this.stopped = true;
      throw error;
    }
  }
  admit(batch, nowMs, serverTick, policy) {
    this.time(nowMs, serverTick);
    requireValue(
      serverTick === this.lastServerTick,
      "Admission must use the current simulated tick"
    );
    validateInputBatch(batch);
    const fingerprint = canonical(batch);
    if (batch.packetSequence <= this.lastPacket) {
      const previous = this.packets.get(batch.packetSequence);
      if (previous === void 0)
        throw new ProtocolError("resync-required", "Packet older than immutable history");
      requireValue(previous === fingerprint, "Changed duplicate packet");
      this.lastNowMs = nowMs;
      return { admitted: 0, duplicate: true, renewed: false };
    }
    if (batch.packetSequence !== this.lastPacket + 1)
      throw new ProtocolError("resync-required", "Packet sequence gap");
    requireValue(
      batch.snapshotAck >= this.snapshotAck && batch.eventAck >= this.eventAck && batch.eventAck <= this.sentEvent,
      "Invalid delivery acknowledgment"
    );
    if (batch.snapshotAck !== 0 && !this.sentSnapshots.has(batch.snapshotAck) && batch.snapshotAck !== this.snapshotAck) {
      throw new ProtocolError("resync-required", "Snapshot acknowledgment has no sent baseline");
    }
    const additions = [];
    const edges = [...this.admittedEdges];
    let sequence = this.lastSequence;
    let clientTick = this.lastClientTick;
    let renewed = false;
    for (const command2 of policy === "drain-paused" ? [] : batch.commands) {
      if (command2.sequence <= sequence) {
        const previous = this.accepted.get(command2.sequence);
        if (!previous)
          throw new ProtocolError("resync-required", "Command older than immutable history");
        requireValue(canonical(previous) === canonical(command2), "Changed duplicate command");
        continue;
      }
      if (command2.sequence !== sequence + 1 || command2.clientTick !== clientTick + 1)
        throw new ProtocolError("resync-required", "Command/client tick sequence gap");
      requireValue(command2.controlEpoch <= this.ack.controlEpoch, "Unissued control epoch");
      const targetTick = command2.clientTick + this.tickOffset;
      counter2(targetTick);
      if (targetTick > serverTick + MAX_CLIENT_LEAD_TICKS)
        throw new ProtocolError("resync-required", "Client exceeds server-owned input lead");
      for (const edge of command2.edges) {
        const index = edge.kind - 1;
        const before = edges[index] ?? 0;
        requireValue(
          edge.id > before && edge.id - before <= MAX_EDGE_ADVANCE,
          "Reused or excessive edge identity"
        );
        edges[index] = edge.id;
      }
      additions.push({ command: copyCommand(command2), receivedAtMs: nowMs, targetTick });
      sequence = command2.sequence;
      clientTick = command2.clientTick;
      renewed ||= command2.controlEpoch === this.ack.controlEpoch && serverTick - targetTick < INPUT_STALE_TICKS;
    }
    if (this.queue.length + additions.length > MAX_QUEUED_COMMANDS)
      throw new ProtocolError("resync-required", "Input queue limit");
    this.queue.push(...additions);
    for (const addition of additions)
      this.accepted.set(addition.command.sequence, copyCommand(addition.command));
    while (this.accepted.size > MAX_QUEUED_COMMANDS + MAX_PREDICTION_TICKS) {
      const oldest = this.accepted.keys().next().value;
      if (oldest !== void 0) this.accepted.delete(oldest);
    }
    this.admittedEdges = edges;
    this.lastSequence = sequence;
    this.lastClientTick = clientTick;
    this.lastPacket = batch.packetSequence;
    this.packets.set(batch.packetSequence, fingerprint);
    while (this.packets.size > MAX_PREDICTION_TICKS) {
      const oldest = this.packets.keys().next().value;
      if (oldest !== void 0) this.packets.delete(oldest);
    }
    this.snapshotAck = batch.snapshotAck;
    this.eventAck = batch.eventAck;
    this.lastNowMs = nowMs;
    if (renewed) this.freshAtMs = nowMs;
    return { admitted: additions.length, duplicate: false, renewed };
  }
  /** The single-player adapter uses the same all-or-nothing processing path as a world tick. */
  processTick(serverTick, nowMs, apply) {
    const transaction = _InputStream.processWorldTick([this], serverTick, nowMs, ([prepared]) => {
      if (!prepared) throw new Error("Missing prepared input");
      return {
        state: null,
        outcomes: [{ playerId: this.playerId, edgeResults: apply(prepared.input) }]
      };
    });
    const result = transaction.processed[0];
    if (!result) throw new Error("Missing processed input");
    return result;
  }
  /**
   * Synchronous in-memory commit across all controlling sockets. Evaluate into a candidate world,
   * without publishing it or performing I/O. Validate that candidate before returning it here.
   * A failed evaluation/outcome leaves every queue/ack unchanged and stops the whole cohort.
   * This is not durable storage atomicity; the room still owns checkpoint/recovery publication.
   */
  static processWorldTick(streams, serverTick, nowMs, evaluate2) {
    counter2(serverTick, true);
    requireValue(Number.isFinite(nowMs) && nowMs >= 0, "Invalid world clock");
    requireValue(streams.length <= 4, "Excess world input owners");
    const ordered3 = [...streams].sort((a, b) => a.playerId - b.playerId);
    requireValue(
      new Set(ordered3.map((stream) => stream.playerId)).size === ordered3.length,
      "Duplicate world input owner"
    );
    requireValue(
      ordered3.every((stream) => stream.identity.runEpoch === ordered3[0]?.identity.runEpoch),
      "Mixed world run epochs"
    );
    const staged = ordered3.map((stream) => stream.prepareTick(serverTick, nowMs));
    for (const stream of ordered3) stream.applying = true;
    try {
      const candidate = evaluate2(
        staged.map(
          ({ input, acknowledgment, neutralized }) => structuredClone({ input, acknowledgment, neutralized })
        )
      );
      const state = candidate.state;
      const outcomes = candidate.outcomes;
      requireValue(
        outcomes.length === ordered3.length,
        "World must resolve every input owner exactly once"
      );
      requireValue(
        new Set(outcomes.map((result) => result.playerId)).size === outcomes.length,
        "Duplicate world outcome owner"
      );
      const processed = staged.map((stage) => {
        const outcome = outcomes.find((item) => item.playerId === stage.input.playerId);
        requireValue(Boolean(outcome), "Missing world input outcome");
        if (!outcome) throw new Error("Missing input outcome");
        if (outcome.controlEpoch !== void 0) {
          counter2(outcome.controlEpoch);
          requireValue(
            outcome.controlEpoch === stage.acknowledgment.controlEpoch + 1,
            "World control epoch must increment once"
          );
          stage.acknowledgment.controlEpoch = outcome.controlEpoch;
        }
        return _InputStream.validateTick(stage, outcome.edgeResults);
      });
      for (const [index, stream] of ordered3.entries()) {
        const stage = staged[index];
        if (stage) stream.commitTick(stage);
      }
      return { state, processed };
    } catch (error) {
      for (const stream of ordered3) stream.stopped = true;
      throw error;
    } finally {
      for (const stream of ordered3) stream.applying = false;
    }
  }
  prepareTick(serverTick, nowMs) {
    this.guard();
    this.time(nowMs, serverTick);
    requireValue(serverTick === this.lastServerTick + 1, "Exactly one input step per server tick");
    const candidate = this.queue[0];
    const pending = candidate && candidate.targetTick <= serverTick ? candidate : void 0;
    const expired = this.freshAtMs === null || nowMs - this.freshAtMs >= INPUT_STALE_MS;
    const submitted = pending ? copyCommand(pending.command) : null;
    let outcome = "applied";
    if (pending && pending.command.controlEpoch !== this.ack.controlEpoch) outcome = "old-control";
    else if (pending ? nowMs - pending.receivedAtMs >= INPUT_STALE_MS || serverTick - pending.targetTick >= INPUT_STALE_TICKS : expired)
      outcome = "stale";
    const previousHeld = this.lastHeld;
    const base = submitted ?? previousHeld;
    const command2 = base ? copyCommand(base) : {
      sequence: 0,
      clientTick: 0,
      controlEpoch: this.ack.controlEpoch,
      held: 0,
      aim: 0,
      edges: []
    };
    if (!pending) command2.edges = [];
    if (outcome !== "applied") {
      command2.held = 0;
      command2.aim = 0;
      command2.edges = [];
    }
    const input = {
      playerId: this.playerId,
      command: command2,
      submittedCommand: submitted,
      serverTick,
      outcome,
      repeatedHeld: pending === void 0
    };
    const acknowledgment = this.acknowledgment;
    if (pending) {
      acknowledgment.lastProcessedSequence = pending.command.sequence;
      acknowledgment.appliedAtServerTick = serverTick;
      for (const edge of pending.command.edges)
        acknowledgment.processedEdgeIds[edge.kind - 1] = edge.id;
    }
    return {
      input,
      acknowledgment,
      pending,
      nowMs,
      neutralized: outcome === "stale" && previousHeld !== null && previousHeld.held !== 0
    };
  }
  static validateTick(stage, results) {
    requireValue(
      results.length === stage.input.command.edges.length,
      "Simulation must resolve every delivered edge exactly once"
    );
    for (const [index, result] of results.entries()) {
      const edge = stage.input.command.edges[index];
      requireValue(
        Boolean(
          edge && edge.kind === result.kind && edge.id === result.id && ["applied", "cooldown", "unavailable"].includes(result.outcome)
        ),
        "Invalid simulation edge outcome"
      );
    }
    const edgeResults = stage.input.outcome === "applied" ? results.map((result) => ({ ...result })) : (stage.input.submittedCommand?.edges ?? []).map((edge) => ({
      ...edge,
      outcome: stage.input.outcome
    }));
    return structuredClone({
      input: stage.input,
      acknowledgment: stage.acknowledgment,
      neutralized: stage.neutralized,
      edgeResults
    });
  }
  commitTick(stage) {
    if (stage.pending) this.queue.shift();
    const changedControl = this.ack.controlEpoch !== stage.acknowledgment.controlEpoch;
    this.ack = stage.acknowledgment;
    this.lastHeld = !changedControl && stage.input.outcome === "applied" ? { ...copyCommand(stage.input.command), edges: [] } : null;
    if (changedControl) this.freshAtMs = null;
    this.lastServerTick = stage.input.serverTick;
    this.lastNowMs = stage.nowMs;
  }
  guard() {
    if (this.stopped)
      throw new ProtocolError("resync-required", "Input stream requires a fresh baseline");
    requireValue(!this.applying, "Input stream cannot be reentered during simulation");
  }
  time(nowMs, serverTick) {
    requireValue(Number.isFinite(nowMs) && nowMs >= this.lastNowMs, "Nonmonotonic server clock");
    counter2(serverTick, true);
    requireValue(serverTick >= this.lastServerTick, "Server tick moved backwards");
  }
};

// src/shared/runtime/room-clock.ts
var ROOM_TICK_HZ = 60;
var MAX_CATCH_UP_STEPS = 4;
var MAX_SCHEDULING_DEBT_MS = 250;
var RoomClock = class {
  constructor(options) {
    this.options = options;
    this.tickValue = integer(options.initialTick, 0, COUNTER_LIMIT - 1, "initial clock tick");
  }
  options;
  modeValue = "stopped";
  tickValue;
  originMs = 0;
  epochSteps = 0;
  lastNow = 0;
  inCallback = false;
  notifyingFault = false;
  timer = null;
  faultValue = null;
  get state() {
    return {
      mode: this.modeValue,
      tick: this.tickValue,
      timerPending: this.timer !== null,
      fault: this.faultValue && { ...this.faultValue }
    };
  }
  /** Idempotent in play; resume starts a fresh deadline, never catches up paused wall time. */
  start() {
    if (this.modeValue === "running") return;
    if (this.inCallback || this.notifyingFault)
      throw new Error("Cannot restart the clock inside its callback");
    if (this.modeValue !== "stopped") throw new Error("Clock needs recovery or is closed");
    const now = this.readTime(false);
    if (now === null) return;
    this.originMs = now;
    this.lastNow = now;
    this.epochSteps = 0;
    this.modeValue = "running";
    this.arm(now);
  }
  /** Call on lobby/empty pause. Recovery cannot be bypassed by stop/start. */
  stop() {
    this.cancelTimer();
    if (this.modeValue === "running") this.modeValue = "stopped";
  }
  /** Terminal rooms must construct a new clock for a new run. */
  close() {
    this.cancelTimer();
    this.modeValue = "closed";
  }
  /** Caller must first restore/confirm the authoritative world and resynchronize clients. */
  recover(confirmedTick) {
    if (this.inCallback || this.notifyingFault || this.modeValue !== "recovery") {
      throw new Error("Recover only after a discontinuity callback has returned");
    }
    this.tickValue = integer(confirmedTick, 0, COUNTER_LIMIT - 1, "confirmed recovery tick");
    this.faultValue = null;
    this.modeValue = "stopped";
  }
  deadline() {
    return this.originMs + (this.epochSteps + 1) * 1e3 / ROOM_TICK_HZ;
  }
  cancelTimer() {
    const timer = this.timer;
    this.timer = null;
    if (timer) {
      timer.active = false;
      timer.cancel();
    }
  }
  fail(reason, now, debt = null) {
    this.cancelTimer();
    if (this.modeValue === "closed") return;
    this.modeValue = "recovery";
    this.faultValue = {
      reason,
      lastCompletedTick: this.tickValue,
      observedAtMs: now,
      debtMs: debt
    };
    this.notifyingFault = true;
    try {
      this.options.onDiscontinuity({ ...this.faultValue });
    } finally {
      this.notifyingFault = false;
    }
  }
  readTime(checkRegression) {
    let now;
    try {
      now = this.options.port.now();
    } catch {
      this.fail("invalid_time", null);
      return null;
    }
    if (!Number.isFinite(now) || now < 0 || now > 2 ** 48) {
      this.fail("invalid_time", null);
      return null;
    }
    if (checkRegression && now < this.lastNow) {
      this.fail("time_regression", now);
      return null;
    }
    return now;
  }
  arm(now) {
    const timer = { active: true, cancel: () => {
    } };
    this.timer = timer;
    try {
      timer.cancel = this.options.port.schedule(
        () => {
          if (!timer.active || this.timer !== timer || this.modeValue !== "running") return;
          timer.active = false;
          this.timer = null;
          this.onTimer();
        },
        Math.max(1, this.deadline() - now)
      );
    } catch {
      this.fail("timer_failed", now);
    }
  }
  onTimer() {
    this.inCallback = true;
    try {
      const now = this.readTime(true);
      if (now === null) return;
      this.lastNow = now;
      const firstDeadline = this.deadline();
      const debt = Math.max(0, now - firstDeadline);
      if (now > firstDeadline + MAX_SCHEDULING_DEBT_MS) {
        this.fail("scheduler_debt", now, debt);
        return;
      }
      let steps = 0;
      while (this.modeValue === "running" && steps < MAX_CATCH_UP_STEPS && now >= this.deadline()) {
        if (this.tickValue >= COUNTER_LIMIT - 1) {
          this.fail("tick_exhausted", now);
          return;
        }
        try {
          const result = this.options.step(this.tickValue + 1);
          if (result === "paused") {
            this.stop();
            break;
          }
          if (result !== void 0) {
            if (result instanceof Promise) void result.catch(() => {
            });
            throw new Error("World step must be synchronous and return undefined");
          }
        } catch {
          this.fail("step_failed", now);
          return;
        }
        this.tickValue++;
        this.epochSteps++;
        steps++;
      }
      try {
        this.options.onSample?.({
          observedAtMs: now,
          firstDeadlineMs: firstDeadline,
          latenessMs: debt,
          steps,
          lastCompletedTick: this.tickValue,
          remainingDebtMs: Math.max(0, now - this.deadline())
        });
      } catch {
        this.fail("observer_failed", now);
        return;
      }
      if (this.modeValue === "running") this.arm(now);
    } finally {
      this.inCallback = false;
    }
  }
};

// src/shared/session/profile.ts
var PROFILE_COOKIE_NAME = "edgefall_profile";
var idPattern = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/u;
function isProfileId(value) {
  return typeof value === "string" && idPattern.test(value);
}
function encodeSignature(bytes) {
  return btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/u, "");
}
function key(secret) {
  if (secret.length < 32)
    throw new Error("Profile signing key must contain at least 32 characters");
  return crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"]
  );
}
function profileCookie(header) {
  if (!header || header.length > 8192) return void 0;
  const values = header.split(";").map((part) => part.trim()).filter((part) => part.startsWith(`${PROFILE_COOKIE_NAME}=`));
  return values.length === 1 ? values[0]?.slice(PROFILE_COOKIE_NAME.length + 1) : void 0;
}
async function signProfileIdentity(id2, expires, secret) {
  if (!isProfileId(id2) || !Number.isSafeInteger(expires) || expires <= 0 || expires > 999999999999)
    throw new Error("Invalid profile identity");
  const payload = `${id2}.${expires}`;
  const signature = await crypto.subtle.sign(
    "HMAC",
    await key(secret),
    new TextEncoder().encode(payload)
  );
  const encoded = encodeSignature(new Uint8Array(signature));
  return `${payload}.${encoded}`;
}
async function verifyProfileIdentity(value, secret, nowSeconds) {
  if (!Number.isSafeInteger(nowSeconds) || nowSeconds < 0) throw new Error("Invalid profile clock");
  if (!value || value.length > 128) return void 0;
  const parts = value.split(".");
  const [id2, expiresText, signature] = parts;
  if (parts.length !== 3 || !id2 || !idPattern.test(id2) || !expiresText || !/^[1-9][0-9]{0,11}$/u.test(expiresText) || !signature || !/^[A-Za-z0-9_-]{43}$/u.test(signature))
    return void 0;
  const expires = Number(expiresText);
  if (!Number.isSafeInteger(expires) || expires <= nowSeconds) return void 0;
  const bytes = Uint8Array.from(
    atob(`${signature.replaceAll("-", "+").replaceAll("_", "/")}=`),
    (character) => character.charCodeAt(0)
  );
  if (encodeSignature(bytes) !== signature) return void 0;
  const valid = await crypto.subtle.verify(
    "HMAC",
    await key(secret),
    bytes,
    new TextEncoder().encode(`${id2}.${expiresText}`)
  );
  return valid ? id2 : void 0;
}

// src/shared/session/membership.ts
var RECONNECT_WINDOW_MS = 9e4;
function createMembership() {
  return { format: 1, epoch: 1, nextOrdinal: 1, hostSlot: null, members: [] };
}
function time(now) {
  integer(now, 0, Number.MAX_SAFE_INTEGER - RECONNECT_WINDOW_MS, "membership clock");
}
function changed(state) {
  state.epoch = integer(state.epoch + 1, 1, COUNTER_LIMIT - 1, "membership epoch");
  if (!state.members.some((m) => m.slot === state.hostSlot && m.connected))
    state.hostSlot = state.members.filter((m) => m.connected).sort((a, b) => a.joinedOrdinal - b.joinedOrdinal)[0]?.slot ?? null;
  return state;
}
function admitMember(current, profileId, slot, roomMode, now) {
  time(now);
  integer(slot, 0, 3, "membership slot");
  if (!isProfileId(profileId)) throw new Error("profile-required");
  const state = structuredClone(current);
  const owned = state.members.find((m) => m.profileId === profileId);
  const occupant = state.members.find((m) => m.slot === slot);
  requireAdmissionPhase(roomMode, Boolean(owned));
  if (owned && owned.slot !== slot) throw new Error("profile-slot-mismatch");
  if (!owned) {
    if (occupant && (occupant.connected || now < occupant.reservedUntilMs))
      throw new Error("slot-reserved");
    state.members = state.members.filter((m) => m.slot !== slot);
    state.members.push({
      slot,
      profileId,
      joinedOrdinal: state.nextOrdinal,
      generation: occupant ? integer(occupant.generation + 1, 1, COUNTER_LIMIT - 1, "membership generation") : 1,
      connected: true,
      lastSeenAtMs: now,
      reservedUntilMs: now + RECONNECT_WINDOW_MS
    });
    state.nextOrdinal = integer(state.nextOrdinal + 1, 1, COUNTER_LIMIT - 1, "membership ordinal");
  } else {
    if (!owned.connected && now >= owned.reservedUntilMs)
      throw new Error("reconnect-window-expired");
    owned.generation = integer(owned.generation + 1, 1, COUNTER_LIMIT - 1, "membership generation");
    owned.connected = true;
    owned.lastSeenAtMs = Math.max(now, owned.lastSeenAtMs);
    owned.reservedUntilMs = owned.lastSeenAtMs + RECONNECT_WINDOW_MS;
  }
  state.members.sort((a, b) => a.slot - b.slot);
  return changed(state);
}
function disconnectMember(current, slot, generation, now) {
  time(now);
  const state = structuredClone(current);
  const member = state.members.find((m) => m.slot === slot && m.generation === generation);
  if (!member?.connected) return state;
  member.connected = false;
  member.lastSeenAtMs = Math.max(now, member.lastSeenAtMs);
  member.reservedUntilMs = member.lastSeenAtMs + RECONNECT_WINDOW_MS;
  return changed(state);
}
function checkpointMembership(current, now) {
  time(now);
  const state = structuredClone(current);
  for (const member of state.members)
    if (member.connected) {
      member.lastSeenAtMs = Math.max(member.lastSeenAtMs, now);
      member.reservedUntilMs = member.lastSeenAtMs + RECONNECT_WINDOW_MS;
    }
  return state;
}
function recoverMembership(current) {
  const state = structuredClone(current);
  if (!state.members.some((member) => member.connected)) return state;
  for (const member of state.members) member.connected = false;
  return changed(state);
}
function emptyReservationDeadline(state) {
  if (!state.members.length || state.members.some((member) => member.connected)) return null;
  return Math.max(...state.members.map((member) => member.reservedUntilMs));
}
function decodeMembership(raw) {
  if (raw.length > 4096) throw new Error("Membership size");
  const state = JSON.parse(raw);
  fields4(state, "format epoch nextOrdinal hostSlot members");
  if (state.format !== 1 || !Array.isArray(state.members) || state.members.length > 4)
    throw new Error("Membership format");
  integer(state.epoch, 1, COUNTER_LIMIT - 1, "membership epoch");
  integer(state.nextOrdinal, 1, COUNTER_LIMIT - 1, "membership ordinal");
  const profiles2 = /* @__PURE__ */ new Set(), ordinals = /* @__PURE__ */ new Set();
  let lastSlot = -1;
  for (const member of state.members) {
    fields4(
      member,
      "slot profileId joinedOrdinal generation connected lastSeenAtMs reservedUntilMs"
    );
    integer(member.slot, lastSlot + 1, 3, "membership slot order");
    lastSlot = member.slot;
    integer(member.joinedOrdinal, 1, state.nextOrdinal - 1, "joined ordinal");
    integer(member.generation, 1, COUNTER_LIMIT - 1, "member generation");
    time(member.lastSeenAtMs);
    if (!isProfileId(member.profileId) || profiles2.has(member.profileId) || ordinals.has(member.joinedOrdinal) || typeof member.connected !== "boolean" || member.reservedUntilMs !== member.lastSeenAtMs + RECONNECT_WINDOW_MS)
      throw new Error("Invalid membership record");
    profiles2.add(member.profileId);
    ordinals.add(member.joinedOrdinal);
  }
  if (state.hostSlot === null ? state.members.some((m) => m.connected) : !state.members.some((m) => m.slot === state.hostSlot && m.connected))
    throw new Error("Invalid membership host");
  return state;
}
function fields4(value, expected) {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).sort().join(" ") !== expected.split(" ").sort().join(" "))
    throw new Error("Membership fields");
}

// src/shared/session/room-control.ts
var HOST_COMMANDS = ["load", "start", "continue", "rematch"];
var counter3 = (value) => integer(value, 1, COUNTER_LIMIT - 1, "room control epoch");
function fields5(value, names) {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).sort().join(" ") !== names.split(" ").sort().join(" "))
    throw new Error("Invalid room control fields");
}
function decodeHostCommand(raw) {
  if (new TextEncoder().encode(raw).byteLength > 512) throw new Error("Room command size");
  const value = JSON.parse(raw);
  fields5(value, "command runEpoch connectionEpoch membershipEpoch");
  if (!HOST_COMMANDS.includes(value.command)) throw new Error("Unknown host command");
  counter3(value.runEpoch);
  counter3(value.connectionEpoch);
  counter3(value.membershipEpoch);
  return value;
}
async function readBody2(request, limit) {
  const length2 = request.headers.get("Content-Length");
  if (length2 !== null && (!/^\d{1,4}$/u.test(length2) || Number(length2) > limit))
    throw new Error("Room command size");
  const reader = request.body?.getReader();
  if (!reader) throw new Error("Missing room command");
  let timer;
  try {
    const raw = await Promise.race([
      (async () => {
        let size = 0, text = "";
        const decoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });
        for (; ; ) {
          const chunk = await reader.read();
          if (chunk.done) return text + decoder.decode();
          size += chunk.value.byteLength;
          if (size > limit) throw new Error("Room command size");
          text += decoder.decode(chunk.value, { stream: true });
        }
      })(),
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error("Room command timeout")), 2e3);
      })
    ]);
    return raw;
  } finally {
    if (timer !== void 0) clearTimeout(timer);
    void reader.cancel().catch(() => {
    });
    reader.releaseLock();
  }
}
async function readHostCommand(request) {
  return decodeHostCommand(await readBody2(request, 512));
}
function requireCurrentHost(membership, profileId, runEpoch, connectionEpoch, command2) {
  const member = membership.members.find((m) => m.profileId === profileId);
  if (!member?.connected || member.slot !== membership.hostSlot) throw new Error("host-required");
  if (membership.epoch !== command2.membershipEpoch || runEpoch !== command2.runEpoch || connectionEpoch !== command2.connectionEpoch)
    throw new Error("stale-host-command");
}
function roomControlState(membership, roomMode, runEpoch) {
  return {
    roomMode,
    runEpoch,
    membershipEpoch: membership.epoch,
    hostSlot: membership.hostSlot,
    members: membership.members.map(({ slot, generation, connected, joinedOrdinal }) => ({
      slot,
      generation,
      connected,
      joinedOrdinal
    }))
  };
}

// src/worker/runtime/control-lease.ts
var CONTROL_LEASE_MS = 3e3;
var ControlLease = class {
  lastNow;
  deadline;
  expiredValue = false;
  constructor(nowMs) {
    if (!Number.isFinite(nowMs) || nowMs < 0 || nowMs > 2 ** 48)
      throw new RangeError("Invalid lease clock");
    this.lastNow = nowMs;
    this.deadline = nowMs + CONTROL_LEASE_MS;
  }
  observeAdmission(result, nowMs) {
    if (this.expired(nowMs)) return false;
    if (!result.renewed || result.duplicate || result.admitted === 0) return false;
    this.deadline = nowMs + CONTROL_LEASE_MS;
    return true;
  }
  expired(nowMs) {
    if (!Number.isFinite(nowMs) || nowMs < this.lastNow || nowMs > 2 ** 48)
      throw new RangeError("Nonmonotonic lease clock");
    this.lastNow = nowMs;
    this.expiredValue ||= nowMs >= this.deadline;
    return this.expiredValue;
  }
};

// src/shared/diagnostics/combat-recovery.ts
function settleSeats(state, playerIds, advanceControl = true) {
  state.combat.beams = state.combat.beams.filter((beam) => !playerIds.includes(beam.ownerId));
  const before = structuredClone(state.combat), changes = /* @__PURE__ */ new Map();
  const frame = { tick: state.combat.tick, geometryRevision: state.snapshot.geometryRevision }, index = new CollisionIndex(
    new CollisionGrid(
      combatEndTerrain(state.combat.scenario, state.combat.tick, state.combat.props)
    ),
    [],
    frame
  );
  for (const player2 of state.combat.players) {
    if (!playerIds.includes(player2.playerId) || player2.vehicleId === null) continue;
    const tank = state.combat.tanks.find(
      (tank2) => tankOwner(tank2) === player2.playerId && tank2.body.id === player2.vehicleId
    );
    if (!tank) throw new Error("Combat vehicle handoff owner mismatch");
    releaseCombatTank(state.combat, tank, "disconnect", changes, [], index, frame);
  }
  if (advanceControl) commitCombatSeats(before, state.combat, changes);
  for (const ack of state.snapshot.acknowledgments) {
    const actor = state.combat.players.find((player2) => player2.playerId === ack.playerId);
    if (!actor) throw new Error("Missing settled seat acknowledgment");
    ack.controlEpoch = actor.controlEpoch;
  }
  state.snapshot = combatSnapshot(state.combat, state.snapshot, state.campaign);
}
function replaceWaitingCombatConnection(current, playerId) {
  if (!isWaitingRoom(current.snapshot.roomMode))
    throw new Error("Connection replacement requires waiting phase");
  const state = structuredClone(current);
  settleSeats(state, [playerId]);
  const actor = state.combat.players.find((player2) => player2.playerId === playerId);
  const ack = state.snapshot.acknowledgments.find((value) => value.playerId === playerId);
  if (!actor || !ack) throw new Error("Missing loading connection owner");
  ack.connectionEpoch = nextCounter(ack.connectionEpoch);
  ack.lastProcessedSequence = 0;
  ack.appliedAtServerTick = 0;
  ack.processedEdgeIds = [0, 0, 0, 0, 0];
  actor.jumpBufferTicks = 0;
  actor.processedEdgeIds = [0, 0, 0, 0, 0];
  state.snapshot.players = structuredClone(state.combat.players);
  if (!state.snapshot.acknowledgments.some(
    (a) => a.connectionEpoch === state.snapshot.connectionEpoch
  ))
    state.snapshot.connectionEpoch = ack.connectionEpoch;
  state.snapshot.stateHash = roomWorkloadHash(state.snapshot);
  return state;
}
function transitionCombatRuntime(current, kind) {
  const state = structuredClone(current);
  if (current.snapshot.roomMode === "expired" || current.snapshot.roomMode === "completed" && kind !== "expire")
    throw new Error("Terminal combat room cannot resume");
  if (kind === "continue") {
    if (current.snapshot.roomMode !== "intermission" || current.pausedFrom !== null)
      throw new Error("Continue requires a confirmed wipe boundary");
    settleSeats(
      state,
      state.combat.players.map((player2) => player2.playerId),
      false
    );
    const reset = continueCombatCheckpoint(state.combat, state.campaign, current.snapshot.runEpoch);
    state.combat = reset.combat;
    state.campaign = reset.campaign;
    state.snapshot = combatSnapshot(state.combat, state.snapshot, state.campaign);
    state.snapshot = renewControllerGenerations(state.snapshot);
    state.snapshot.roomMode = "loading";
    state.combat.players = structuredClone(state.snapshot.players);
    state.history = { ...createEventHistory(state.snapshot.runEpoch), tick: state.combat.tick };
    state.connectedPlayerIds = [];
    state.snapshot.baselineEventCursor = 0;
    state.snapshot.snapshotId = 1;
    state.snapshot.connectionEpoch = state.snapshot.acknowledgments[0]?.connectionEpoch ?? 0;
    state.snapshot = combatSnapshot(state.combat, state.snapshot, state.campaign);
  } else if (kind === "pause" || kind === "expire") {
    if (kind === "pause" ? !isPausableRoom(current.snapshot.roomMode) : ![
      "lobby",
      "loading",
      "playing",
      "intermission",
      "paused-empty",
      "recovering",
      "completed"
    ].includes(current.snapshot.roomMode))
      throw new Error("Invalid empty combat boundary");
    settleSeats(
      state,
      state.combat.players.map((player2) => player2.playerId)
    );
    state.snapshot.roomMode = kind === "pause" ? "paused-empty" : "expired";
    state.pausedFrom = kind === "pause" && isPausableRoom(current.snapshot.roomMode) ? current.snapshot.roomMode : null;
    state.connectedPlayerIds = [];
  } else if (kind === "load") {
    if (!["lobby", "intermission"].includes(current.snapshot.roomMode))
      throw new Error("Load requires lobby or intermission");
    if (["wipe", "defeat"].includes(current.campaign.state.phase))
      throw new Error("A wiped campaign cannot load without a continue");
    state.snapshot.roomMode = "loading";
  } else if (kind === "start") {
    if (current.snapshot.roomMode !== "loading")
      throw new Error("Combat start requires loading barrier");
    state.snapshot.roomMode = "playing";
  } else {
    const origin = current.pausedFrom ?? current.snapshot.roomMode;
    settleSeats(
      state,
      state.combat.players.map((player2) => player2.playerId),
      false
    );
    state.snapshot = renewControllerGenerations(state.snapshot);
    if (origin === "lobby" || origin === "intermission") state.snapshot.roomMode = origin;
    state.pausedFrom = null;
    state.combat.players = structuredClone(state.snapshot.players);
    state.combat.events = [];
    state.connectedPlayerIds = [];
    state.history = { ...createEventHistory(state.snapshot.runEpoch), tick: state.combat.tick };
    state.snapshot.baselineEventCursor = 0;
    state.snapshot.snapshotId = 1;
    state.snapshot.connectionEpoch = state.snapshot.acknowledgments[0]?.connectionEpoch ?? 0;
    state.snapshot = combatSnapshot(state.combat, state.snapshot, state.campaign);
  }
  state.snapshot.stateHash = roomWorkloadHash(state.snapshot);
  return state;
}

// src/worker/diagnostics/combat-storage.ts
var MAX_JOURNAL_SEGMENTS = Math.ceil(COMBAT_CHECKPOINT_TICKS / COMBAT_SEGMENT_TICKS);
var CombatStorage = class {
  constructor(storage, identity3, beforeHeadCommit) {
    this.storage = storage;
    this.identity = identity3;
    this.beforeHeadCommit = beforeHeadCommit;
    storage.sql.exec(
      "CREATE TABLE IF NOT EXISTS combat_archive (key TEXT PRIMARY KEY, run_epoch INTEGER NOT NULL, tick INTEGER NOT NULL, payload TEXT NOT NULL)"
    );
  }
  storage;
  identity;
  beforeHeadCommit;
  busy = false;
  commits = [];
  head() {
    return this.storage.sql.exec(
      "SELECT key, run_epoch, tick, payload FROM combat_archive WHERE key = ?",
      "head"
    ).toArray()[0];
  }
  put(key2, runEpoch, tick2, payload) {
    this.storage.sql.exec(
      "INSERT OR REPLACE INTO combat_archive (key, run_epoch, tick, payload) VALUES (?, ?, ?, ?)",
      key2,
      runEpoch,
      tick2,
      payload
    );
  }
  async exclusive(operation) {
    if (this.busy) throw new Error("Combat storage operation already pending");
    this.busy = true;
    try {
      return await operation();
    } finally {
      this.busy = false;
    }
  }
  initialize(current) {
    const state = structuredClone(current);
    return this.exclusive(async () => {
      const raw = await encodeCombatCheckpoint(state, this.identity);
      this.storage.transactionSync(() => {
        if (this.storage.sql.exec("SELECT COUNT(*) AS count FROM combat_archive").one().count !== 0)
          throw new Error("Combat archive already exists; recover it explicitly");
        this.put("checkpoint", state.snapshot.runEpoch, state.combat.tick, raw);
        this.beforeHeadCommit?.();
        this.put("head", state.snapshot.runEpoch, state.combat.tick, combatRuntimeHash(state));
      });
      await this.storage.sync();
    });
  }
  commit(start, entries, accepted) {
    const previous = structuredClone(start), saved = structuredClone([...entries]), state = structuredClone(accepted);
    return this.exclusive(async () => {
      const began = performance.now();
      if (saved.length < 1 || saved.length > COMBAT_SEGMENT_TICKS)
        throw new Error("Combat durable segment must contain 1 to 15 ticks");
      const raw = await encodeAcceptedCombatJournalSegment(previous, saved, state, this.identity);
      const checkpoint2 = this.storage.sql.exec(
        "SELECT key, run_epoch, tick, payload FROM combat_archive WHERE key = ?",
        "checkpoint"
      ).toArray()[0];
      if (!checkpoint2) throw new Error("Missing combat checkpoint");
      const segments = this.storage.sql.exec(
        "SELECT COUNT(*) AS count FROM combat_archive WHERE key LIKE 'segment:%'"
      ).one().count;
      const replace = state.combat.tick - checkpoint2.tick >= COMBAT_CHECKPOINT_TICKS || segments >= MAX_JOURNAL_SEGMENTS;
      const nextCheckpoint = replace ? await encodeCombatCheckpoint(state, this.identity) : null;
      const preparedAt = performance.now();
      this.storage.transactionSync(() => {
        const head = this.head();
        if (!head || head.run_epoch !== previous.snapshot.runEpoch || head.tick !== previous.combat.tick || head.payload !== combatRuntimeHash(previous))
          throw new Error("Combat durable prefix changed");
        if (nextCheckpoint !== null) {
          this.put("checkpoint", state.snapshot.runEpoch, state.combat.tick, nextCheckpoint);
          this.storage.sql.exec("DELETE FROM combat_archive WHERE key LIKE 'segment:%'");
        } else
          this.put(
            `segment:${previous.combat.tick + 1}`,
            state.snapshot.runEpoch,
            state.combat.tick,
            raw
          );
        this.beforeHeadCommit?.();
        this.put("head", state.snapshot.runEpoch, state.combat.tick, combatRuntimeHash(state));
      });
      await this.storage.sync();
      if (this.commits.length < 80)
        this.commits.push({
          runEpoch: state.snapshot.runEpoch,
          fromTick: previous.combat.tick + 1,
          throughTick: state.combat.tick,
          prepareMs: preparedAt - began,
          confirmMs: performance.now() - preparedAt
        });
      return state;
    });
  }
  transition(current, kind, guard) {
    return this.replaceCheckpoint(
      current,
      (previous) => transitionCombatRuntime(previous, kind),
      guard
    );
  }
  replaceWaitingConnection(current, playerId) {
    return this.replaceCheckpoint(
      current,
      (previous) => replaceWaitingCombatConnection(previous, playerId)
    );
  }
  replaceCheckpoint(current, change, guard) {
    const previous = structuredClone(current);
    return this.exclusive(async () => {
      const state = change(previous);
      const raw = await encodeCombatCheckpoint(state, this.identity);
      this.storage.transactionSync(() => {
        guard?.();
        const head = this.head();
        if (!head || head.run_epoch !== previous.snapshot.runEpoch || head.tick !== previous.combat.tick || head.payload !== combatRuntimeHash(previous))
          throw new Error("Combat boundary prefix changed");
        this.put("checkpoint", state.snapshot.runEpoch, state.combat.tick, raw);
        this.storage.sql.exec("DELETE FROM combat_archive WHERE key LIKE 'segment:%'");
        this.beforeHeadCommit?.();
        this.put("head", state.snapshot.runEpoch, state.combat.tick, combatRuntimeHash(state));
      });
      await this.storage.sync();
      return state;
    });
  }
  load() {
    return this.exclusive(async () => {
      const rows = this.storage.sql.exec(
        "SELECT key, run_epoch, tick, payload FROM combat_archive ORDER BY tick, key LIMIT ?",
        MAX_JOURNAL_SEGMENTS + 3
      ).toArray();
      if (rows.length === 0) return null;
      const checkpoint2 = rows.find((row) => row.key === "checkpoint"), head = rows.find((row) => row.key === "head");
      if (!checkpoint2 || !head || rows.length > MAX_JOURNAL_SEGMENTS + 2 || !/^[a-f0-9]{8}$/u.test(head.payload))
        throw new Error("Invalid combat durable metadata");
      let state = await decodeCombatCheckpoint(checkpoint2.payload, this.identity);
      if (checkpoint2.run_epoch !== state.snapshot.runEpoch || checkpoint2.tick !== state.combat.tick)
        throw new Error("Combat checkpoint metadata mismatch");
      for (const segment of rows.filter((row) => row.key !== "checkpoint" && row.key !== "head")) {
        if (segment.key !== `segment:${state.combat.tick + 1}` || segment.run_epoch !== state.snapshot.runEpoch || segment.tick <= state.combat.tick || segment.tick > state.combat.tick + COMBAT_SEGMENT_TICKS)
          throw new Error("Missing/changed combat durable segment");
        state = await restoreCombatJournalSegment(state, segment.payload, this.identity);
        if (state.combat.tick !== segment.tick) throw new Error("Combat segment metadata mismatch");
      }
      if (head.run_epoch !== state.snapshot.runEpoch || head.tick !== state.combat.tick || head.payload !== combatRuntimeHash(state))
        throw new Error("Missing combat durable tail");
      return state;
    });
  }
};

// src/worker/diagnostics/membership-storage.ts
var MembershipStorage = class {
  constructor(storage) {
    this.storage = storage;
    storage.sql.exec(
      "CREATE TABLE IF NOT EXISTS room_membership (id INTEGER PRIMARY KEY CHECK (id = 1), payload TEXT NOT NULL)"
    );
    const raw = storage.sql.exec("SELECT payload FROM room_membership WHERE id = 1").toArray()[0];
    this.state = raw ? recoverMembership(decodeMembership(raw.payload)) : createMembership();
    this.save(this.state);
  }
  storage;
  state;
  save(state) {
    const raw = JSON.stringify(state);
    decodeMembership(raw);
    this.storage.sql.exec(
      "INSERT OR REPLACE INTO room_membership (id, payload) VALUES (1, ?)",
      raw
    );
    this.state = state;
  }
};

// src/worker/diagnostics/room-probe.ts
var RoomLoadProbe = class extends DurableObject {
  instanceId = crypto.randomUUID();
  workload = "standard";
  world = createRoomWorkload(1);
  combat = null;
  campaign = null;
  eventHistory = null;
  connectedPlayerIds = [];
  pausedFrom = null;
  combatStore = null;
  combatWriter = null;
  recoveryBoundary = null;
  persistenceFailure = null;
  failNextPersistence = false;
  holdNextPersistence = false;
  heldPersistence = null;
  starting = false;
  pausing = null;
  alarmAtMs = null;
  alarmDeliveries = 0;
  emptyPause = null;
  identity = Promise.resolve(PROBE_IDENTITY);
  failNextCombatTick = false;
  worldFailure = null;
  peers = /* @__PURE__ */ new Map();
  pendingPeers = /* @__PURE__ */ new Map();
  admissions = /* @__PURE__ */ new Map();
  members = null;
  resolvedIdentity = PROBE_IDENTITY;
  staleSocketEvents = 0;
  connections = [];
  localCpu = [];
  callbacks = [];
  timers = [];
  inputTimeline = [];
  get controllerInputs() {
    return this.workload === "controller" || this.workload === "combat";
  }
  traceInput(peer, kind, runtimeMs, serverTick, firstSequence, lastSequence, outcome) {
    if (!this.controllerInputs || this.inputTimeline.length >= 6400) return;
    this.inputTimeline.push({
      runEpoch: this.world.runEpoch,
      slot: peer.metrics.slot,
      kind,
      runtimeMs,
      serverTick,
      baselineTick: peer.baselineTick,
      firstSequence,
      lastSequence,
      queued: peer.input.queuedCommands,
      outcome
    });
  }
  sampledNow = 0;
  startedAtTick = 0;
  watchdog = null;
  initialization = null;
  recoveries = 0;
  clock = this.createClock(0);
  createClock(initialTick) {
    return new RoomClock({
      initialTick,
      port: {
        now: () => {
          this.sampledNow = performance.now();
          return this.sampledNow;
        },
        schedule: (callback, delay) => {
          const row = [performance.now(), delay, null];
          if (this.timers.length < 2401) this.timers.push(row);
          const timer = setTimeout(() => {
            row[2] = performance.now();
            callback();
          }, delay);
          return () => clearTimeout(timer);
        }
      },
      step: (tick2) => {
        try {
          return this.step(tick2);
        } catch (error) {
          this.worldFailure = String(error).slice(0, 256);
          throw error;
        }
      },
      onSample: (sample) => {
        if (this.callbacks.length >= 2400) {
          this.finish("callback-limit");
          return;
        }
        this.callbacks.push([
          sample.observedAtMs,
          sample.steps,
          sample.lastCompletedTick,
          sample.latenessMs
        ]);
      },
      onDiscontinuity: () => {
        this.world.roomMode = "recovering";
        this.clearWatchdog();
        this.disconnectAll("clock-fault");
      }
    });
  }
  constructor(ctx, env) {
    super(ctx, env);
    for (const socket of ctx.getWebSockets()) socket.close(1012, "probe-restarted");
  }
  clearWatchdog() {
    if (this.watchdog !== null) clearTimeout(this.watchdog);
    this.watchdog = null;
  }
  disconnect(peer, reason, code = 4001, decisionTick = this.world.tick) {
    if (!peer.metrics.active) return;
    peer.metrics.active = false;
    peer.metrics.closeReason = reason;
    peer.metrics.lastHeld = 0;
    if (this.members)
      this.members.save(
        disconnectMember(this.members.state, peer.metrics.slot, peer.generation, Date.now())
      );
    if (reason === "lease-expired") peer.metrics.expiredAtTick = decisionTick;
    try {
      peer.socket.close(code, reason);
    } catch (error) {
      peer.metrics.lastOutputError ??= String(error).slice(0, 256);
    }
    this.pauseEmpty();
    if (this.workload === "combat" && this.world.roomMode === "completed" && !this.hasPeers())
      this.ctx.waitUntil(this.scheduleExpiry());
  }
  disconnectAll(reason) {
    for (const peer of this.peers.values()) this.disconnect(peer, reason, 4003);
    for (const peer of this.pendingPeers.values()) this.disconnect(peer, reason, 4003);
    this.pendingPeers.clear();
    if (this.workload === "combat" && this.world.roomMode !== "expired")
      this.ctx.waitUntil(this.scheduleExpiry());
  }
  hasPeers() {
    return [...this.peers.values(), ...this.pendingPeers.values()].some(
      (peer) => peer.metrics.active
    );
  }
  async scheduleExpiry() {
    const deadline = this.members && emptyReservationDeadline(this.members.state);
    if (deadline !== null && deadline !== void 0) {
      this.alarmAtMs = deadline;
      await this.ctx.storage.setAlarm(deadline);
    }
  }
  async clearExpiry() {
    this.alarmAtMs = null;
    await this.ctx.storage.deleteAlarm();
  }
  pauseEmpty() {
    if (this.workload !== "combat" || this.pausing || this.starting || !isPausableRoom(this.world.roomMode) || this.hasPeers())
      return;
    const accepted = structuredClone(this.combatRuntime());
    this.emptyPause = null;
    this.clock.stop();
    this.clearWatchdog();
    this.world.roomMode = "paused-empty";
    this.world.stateHash = roomWorkloadHash(this.world);
    this.starting = true;
    this.pausing = (async () => {
      await Promise.all(this.admissions.values());
      await this.scheduleExpiry();
      if (!this.combatStore) throw new Error("Missing combat store");
      const durable = this.combatWriter ? await this.combatWriter.seal(accepted) : accepted;
      if (this.world.roomMode !== "paused-empty") return;
      const paused = await this.combatStore.transition(durable, "pause");
      if (this.world.roomMode !== "paused-empty") return;
      this.installCombat(paused);
      this.emptyPause = {
        tick: paused.combat.tick,
        runEpoch: paused.snapshot.runEpoch,
        hash: combatRuntimeHash(paused)
      };
    })().catch((error) => this.pausePersistence(String(error))).finally(() => {
      this.pausing = null;
      this.starting = false;
    });
    this.ctx.waitUntil(this.pausing);
  }
  /** Advertise the nonterminal input pause immediately; host reset stays locked until storage confirms. */
  confirmCampaignBoundary() {
    if (this.starting || this.pausing || this.world.roomMode !== "intermission") return;
    const accepted = structuredClone(this.combatRuntime());
    this.clock.stop();
    this.clearWatchdog();
    this.starting = true;
    for (const peer of this.peers.values()) {
      peer.lease = null;
      if (peer.metrics.active) this.publishSnapshot(peer);
    }
    this.pausing = (async () => {
      if (!this.combatWriter) throw new Error("Missing campaign boundary writer");
      const durable = await this.combatWriter.seal(accepted);
      if (this.world.roomMode !== "intermission") return;
      if (combatRuntimeHash(durable) !== combatRuntimeHash(this.combatRuntime()))
        throw new Error("Campaign boundary changed during confirmation");
      this.combatWriter = null;
    })().catch((error) => this.pausePersistence(String(error))).finally(() => {
      this.pausing = null;
      this.starting = false;
      this.pauseEmpty();
    });
    this.ctx.waitUntil(this.pausing);
  }
  admissionPhase() {
    return this.campaign && ["wipe", "defeat"].includes(this.campaign.state.phase) ? "playing" : this.world.roomMode;
  }
  async alarm() {
    this.alarmDeliveries++;
    this.initialization ??= this.ctx.blockConcurrencyWhile(() => this.initialize("combat"));
    await this.initialization;
    await this.pausing;
    if (this.world.roomMode === "expired" || this.hasPeers()) {
      await this.clearExpiry();
      return;
    }
    if (this.starting || this.admissions.size) {
      this.alarmAtMs = Date.now() + 1e3;
      await this.ctx.storage.setAlarm(this.alarmAtMs);
      return;
    }
    const deadline = this.members && emptyReservationDeadline(this.members.state);
    if (deadline === null || deadline === void 0) return;
    if (Date.now() < deadline) {
      await this.scheduleExpiry();
      return;
    }
    this.starting = true;
    this.clock.close();
    this.clearWatchdog();
    try {
      await this.combatWriter?.retire();
      this.combatWriter = null;
      const previous = await this.combatStore?.load();
      if (!previous || !this.combatStore) throw new Error("Missing expiry checkpoint");
      const expired = previous.snapshot.roomMode === "expired" ? previous : await this.combatStore.transition(previous, "expire");
      this.installCombat(expired);
      this.peers.clear();
      this.pendingPeers.clear();
      await this.clearExpiry();
    } finally {
      this.starting = false;
    }
  }
  finish(reason) {
    this.clock.close();
    this.clearWatchdog();
    this.world.roomMode = "expired";
    this.pausedFrom = null;
    this.disconnectAll(reason);
    this.heldPersistence?.reject();
  }
  context(slot) {
    return this.combat ? combatPeerContext(this.world, slot) : this.controllerInputs ? controllerPeerContext(this.world, slot) : probeContext(slot);
  }
  newInput(slot, baselineServerTick) {
    return new InputStream({
      ...this.context(slot),
      controlEpoch: this.world.players[slot]?.controlEpoch ?? 1,
      baselineServerTick
    });
  }
  welcome(peer) {
    const slot = peer.metrics.slot;
    const welcome = {
      ...this.resolvedIdentity,
      type: "welcome",
      protocolMajor: PROTOCOL_MAJOR,
      protocolMinor: PROTOCOL_MINOR,
      runId: "local-room-workload",
      runEpoch: this.world.runEpoch,
      connectionEpoch: this.context(slot).connectionEpoch,
      playerId: slot + 1,
      entityId: slot + 1,
      simulationHz: 60,
      snapshotHz: 20,
      initialServerTick: this.world.tick,
      capabilities: this.workload === "combat" ? INPUT_MAPPING_CAPABILITY | EVENT_CAPABILITY : this.controllerInputs ? INPUT_MAPPING_CAPABILITY : 0,
      baselineSnapshotId: this.world.snapshotId + 1,
      baselineEventCursor: this.world.baselineEventCursor,
      buildId: "4".repeat(64)
    };
    try {
      peer.socket.send(JSON.stringify(welcome));
      this.world.stateHash = roomWorkloadHash(this.world);
      this.snapshot(peer, void 0, true);
    } catch (error) {
      peer.metrics.lastOutputError = String(error).slice(0, 256);
      this.disconnect(peer, "welcome-failed", 4002);
    }
  }
  snapshot(peer, requestedRepair, initial = false) {
    if (peer.pendingEventBaseline || peer.initialBaseline) return;
    this.world.snapshotId++;
    const context = this.context(peer.metrics.slot);
    this.world.connectionEpoch = context.connectionEpoch;
    const bytes = encodeSnapshot(this.world, context);
    const batches = this.eventHistory && !initial ? eventBatches(
      this.eventHistory,
      peer.input.deliveryAcknowledgments.event,
      context.connectionEpoch
    ) : [];
    let baseline = null;
    if (requestedRepair || batches === null) {
      if (++peer.metrics.eventBaselines > 8) throw new Error("Event baseline repair limit");
      baseline = {
        type: "resync-required",
        scope: "events",
        reason: requestedRepair ?? "history-expired",
        runEpoch: context.runEpoch,
        connectionEpoch: context.connectionEpoch,
        snapshotId: this.world.snapshotId,
        tick: this.world.tick,
        baselineEventCursor: this.world.baselineEventCursor
      };
      peer.eventBeforeBaseline = peer.metrics.eventSentCursor;
      peer.socket.send(JSON.stringify(baseline));
    } else
      for (const batch of batches) {
        const events = encodeEventBatch(batch, combatEventContext(context));
        peer.socket.send(events);
        peer.metrics.eventBytes += events.byteLength;
        peer.metrics.eventFrames++;
      }
    if (this.controllerInputs) {
      const mapping = JSON.stringify(mappingForSnapshot(this.world, context.playerId));
      peer.socket.send(mapping);
      peer.metrics.inputMappingBytes += new TextEncoder().encode(mapping).byteLength;
    }
    peer.socket.send(bytes);
    const cursor = this.eventHistory?.cursor ?? 0;
    peer.input.recordSent(this.world.snapshotId, cursor);
    if (this.world.roomMode === "intermission" && this.campaign && ["wipe", "defeat"].includes(this.campaign.state.phase))
      peer.inputPauseSnapshotId ??= this.world.snapshotId;
    peer.metrics.eventSentCursor = cursor;
    peer.pendingEventBaseline = baseline;
    if (initial && this.workload === "combat")
      peer.initialBaseline = { snapshotId: this.world.snapshotId, cursor };
    peer.metrics.snapshots++;
    peer.metrics.snapshotBytes += bytes.byteLength;
    peer.lastRoomMode = this.world.roomMode;
  }
  publishSnapshot(peer, repair) {
    try {
      this.snapshot(peer, repair);
    } catch (error) {
      peer.metrics.lastOutputError = String(error).slice(0, 256);
      this.disconnect(peer, "snapshot-failed", 4002);
    }
  }
  step(tick2) {
    const cpuStart = performance.now();
    const replacements = [...this.pendingPeers].sort(([a], [b]) => a - b);
    const cohort = new Map([...this.peers, ...replacements]);
    const active = [...cohort].sort(([a], [b]) => a - b).filter(([, peer]) => {
      if (!peer.metrics.active) return false;
      if (peer.lease?.expired(this.sampledNow))
        this.disconnect(peer, "lease-expired", 4001, tick2);
      else if (this.sampledNow - peer.lastAckAt >= 1e3)
        this.disconnect(peer, "reader-stalled", 4002);
      return peer.metrics.active;
    });
    if (this.workload === "combat" && active.length === 0) {
      this.pauseEmpty();
      return "paused";
    }
    const transaction = InputStream.processWorldTick(
      active.map(([, peer]) => peer.input),
      tick2,
      this.sampledNow,
      (prepared) => {
        if (this.workload === "combat") {
          if (!this.combat || !this.eventHistory) throw new Error("Missing combat world/history");
          const changes = replacements.map(([slot, peer]) => ({
            playerId: slot + 1,
            connectionEpoch: peer.input.acknowledgment.connectionEpoch
          }));
          const result = stageCombatRuntime(this.combatRuntime(), prepared, changes);
          const history = result.state.history;
          for (const [slot] of active) {
            const context = combatPeerContext(result.state.snapshot, slot);
            encodeSnapshot(
              { ...result.state.snapshot, connectionEpoch: context.connectionEpoch },
              context
            );
            for (const batch of eventBatches(
              history,
              this.eventHistory.cursor,
              context.connectionEpoch
            ) ?? [])
              encodeEventBatch(batch, combatEventContext(context));
          }
          if (this.failNextCombatTick) {
            this.failNextCombatTick = false;
            throw new Error("injected-combat-commit-failure");
          }
          return { ...result, state: { ...result.state, journal: result.journal } };
        }
        const candidate = structuredClone(this.world);
        const outcomes = prepared.map(({ input }) => ({
          playerId: input.playerId,
          edgeResults: input.command.edges.map((edge) => ({
            ...edge,
            outcome: "unavailable"
          }))
        }));
        if (this.workload === "controller") {
          for (const [slot, actor] of candidate.players.entries()) {
            const item = prepared.find(({ input }) => input.playerId === actor.playerId);
            const command2 = item?.input.command ?? {
              sequence: 0,
              clientTick: 0,
              controlEpoch: actor.controlEpoch,
              held: 0,
              aim: 0,
              edges: []
            };
            const result = stepNetworkController(
              actor,
              { ...command2, controlEpoch: actor.controlEpoch },
              tick2
            );
            candidate.players[slot] = result.actor;
            const outcome = outcomes.find((value) => value.playerId === actor.playerId);
            if (outcome) outcome.edgeResults = result.edges;
          }
          candidate.tick = tick2;
        } else {
          for (const actor of candidate.players) actor.body.vx = 0;
          stepRoomWorkload(
            candidate,
            tick2,
            prepared.map(({ input }) => input)
          );
        }
        for (const item of prepared) {
          const slot = candidate.players.findIndex(
            (actor2) => actor2.playerId === item.input.playerId
          );
          const actor = candidate.players[slot];
          if (!actor) throw new Error("Missing committed input owner");
          candidate.acknowledgments[slot] = item.acknowledgment;
          actor.processedEdgeIds = [...item.acknowledgment.processedEdgeIds];
        }
        for (const [slot] of active) {
          const context = this.context(slot);
          encodeSnapshot({ ...candidate, connectionEpoch: context.connectionEpoch }, context);
        }
        return {
          state: {
            snapshot: candidate,
            combat: this.combat,
            history: this.eventHistory,
            connectedPlayerIds: this.connectedPlayerIds,
            pausedFrom: this.pausedFrom,
            campaign: this.campaign,
            journal: null
          },
          outcomes
        };
      }
    );
    this.world = transaction.state.snapshot;
    this.combat = transaction.state.combat;
    this.eventHistory = transaction.state.history;
    this.connectedPlayerIds = transaction.state.connectedPlayerIds;
    this.pausedFrom = transaction.state.pausedFrom;
    this.campaign = transaction.state.campaign;
    for (const [slot, peer] of replacements) {
      const old = this.peers.get(slot);
      if (old) this.disconnect(old, "connection-replaced", 4003);
      this.peers.set(slot, peer);
      this.pendingPeers.delete(slot);
      peer.baselineTick = tick2;
      peer.input = this.newInput(slot, tick2);
      peer.lastAckAt = this.sampledNow;
      peer.lease = new ControlLease(this.sampledNow);
      this.connections.push({
        tick: tick2,
        slot,
        connectionEpoch: this.context(slot).connectionEpoch,
        controlEpoch: this.world.players[slot]?.controlEpoch ?? 0,
        baselineEventCursor: this.world.baselineEventCursor
      });
    }
    if (transaction.state.journal) {
      try {
        if (!this.combatWriter) throw new Error("Missing combat journal writer");
        this.combatWriter.record(transaction.state.journal, this.combatRuntime());
      } catch (error) {
        this.pausePersistence(String(error));
      }
    }
    for (const [, peer] of replacements) if (peer.metrics.active) this.welcome(peer);
    for (const processed of transaction.processed) {
      const slot = this.world.players.find(
        (actor) => actor.playerId === processed.input.playerId
      )?.slot;
      const peer = slot === void 0 ? void 0 : this.peers.get(slot);
      if (!peer) throw new Error("Missing committed peer");
      const submitted = processed.input.submittedCommand?.sequence ?? 0;
      this.traceInput(
        peer,
        "apply",
        this.sampledNow,
        tick2,
        submitted,
        submitted,
        processed.input.repeatedHeld ? `repeat:${processed.input.outcome}` : processed.input.outcome
      );
      peer.metrics.lastHeld = processed.input.command.held;
      peer.metrics.lastProcessedSequence = processed.acknowledgment.lastProcessedSequence;
      if (processed.neutralized && peer.metrics.neutralizedAtTick === null)
        peer.metrics.neutralizedAtTick = tick2;
    }
    if (this.world.roomMode === "playing" && ![...this.peers.values()].some((peer) => peer.metrics.active)) {
      if (this.workload === "combat") this.pauseEmpty();
      else {
        this.world.roomMode = "paused-empty";
        this.clock.stop();
        this.clearWatchdog();
      }
    }
    if (this.workload === "combat" && this.world.roomMode === "intermission")
      this.confirmCampaignBoundary();
    let encodeMs = 0;
    if (tick2 % 3 === 0 && this.world.roomMode === "playing") {
      this.world.stateHash = roomWorkloadHash(this.world);
      const encodeStart = performance.now();
      for (const peer of this.peers.values()) {
        if (peer.metrics.active && this.sampledNow - peer.lastAckAt < 500)
          this.publishSnapshot(peer);
      }
      encodeMs = performance.now() - encodeStart;
    }
    if (this.localCpu.length < 1200)
      this.localCpu.push([tick2, performance.now() - cpuStart, encodeMs]);
    if (tick2 - this.startedAtTick >= 1200) this.finish("tick-limit");
    return void 0;
  }
  combatRuntime() {
    if (!this.combat || !this.eventHistory || !this.campaign)
      throw new Error("Missing combat continuation");
    return {
      combat: this.combat,
      snapshot: this.world,
      history: this.eventHistory,
      connectedPlayerIds: this.connectedPlayerIds,
      pausedFrom: this.pausedFrom,
      campaign: this.campaign
    };
  }
  installCombat(state) {
    this.world = state.snapshot;
    this.combat = state.combat;
    this.eventHistory = state.history;
    this.connectedPlayerIds = state.connectedPlayerIds;
    this.pausedFrom = state.pausedFrom;
    this.campaign = state.campaign;
  }
  pausePersistence(reason) {
    this.persistenceFailure ??= reason.slice(0, 256);
    this.clock.stop();
    this.clearWatchdog();
    if (this.world.roomMode !== "expired") this.world.roomMode = "recovering";
    this.pausedFrom = null;
    this.disconnectAll("persistence-recovery");
  }
  async persistCombat(start, entries, accepted) {
    if (!this.combatStore) throw new Error("Missing combat store");
    if (this.holdNextPersistence) {
      this.holdNextPersistence = false;
      await new Promise((resolve, reject) => {
        const rejectHeld = () => {
          clearTimeout(timeout);
          this.heldPersistence = null;
          reject(new Error("injected-combat-write-hold-expired"));
        };
        const timeout = setTimeout(rejectHeld, 2e3);
        this.heldPersistence = {
          release: () => {
            clearTimeout(timeout);
            this.heldPersistence = null;
            resolve();
          },
          reject: rejectHeld
        };
      });
    }
    return this.combatStore.commit(start, entries, accepted);
  }
  async restoreCombat(loaded = null) {
    if (!this.combatStore) throw new Error("Missing combat store");
    await this.combatWriter?.retire();
    this.combatWriter = null;
    const previous = loaded ?? await this.combatStore.load();
    if (!previous) throw new Error("Missing durable combat world");
    const state = await this.combatStore.transition(previous, "recover");
    this.recoveryBoundary = {
      fromRunEpoch: previous.snapshot.runEpoch,
      restoredTick: previous.combat.tick,
      restoredHash: combatRuntimeHash(previous),
      runEpoch: state.snapshot.runEpoch
    };
    this.installCombat(state);
    this.emptyPause = null;
    this.clock = this.createClock(state.combat.tick);
    this.recoveries = state.snapshot.runEpoch - 1;
    this.persistenceFailure = null;
    this.worldFailure = null;
  }
  async initialize(workload) {
    this.workload = workload === "combat" ? "combat" : workload === "controller" ? "controller" : workload === "double" ? "double" : "standard";
    this.world = this.workload === "controller" ? createControllerWorkload() : createRoomWorkload(this.workload === "double" ? 2 : 1);
    if (this.workload === "combat") {
      this.members = new MembershipStorage(this.ctx.storage);
      const requested = this.env.PROBE_COMBAT_SCENARIO ?? "range";
      if (!isCombatScenario(requested)) throw new Error("Unsupported room combat scenario");
      const initial = createCombatRuntime(requested, Number(this.env.PROBE_COMBAT_PLAYERS ?? 4));
      initial.snapshot.roomMode = "lobby";
      initial.snapshot.stateHash = roomWorkloadHash(initial.snapshot);
      initial.connectedPlayerIds = [];
      this.installCombat(initial);
      this.identity = combatIdentity();
      const { simulationVersion, simulationBuild, contentFormat, contentHash } = await this.identity;
      this.combatStore = new CombatStorage(
        this.ctx.storage,
        {
          simulationVersion,
          simulationBuild,
          contentFormat,
          contentHash,
          runId: "local-room-workload"
        },
        () => {
          if (this.failNextPersistence) {
            this.failNextPersistence = false;
            throw new Error("injected-combat-storage-failure");
          }
          if (this.members) this.members.save(checkpointMembership(this.members.state, Date.now()));
        }
      );
      const loaded = await this.combatStore.load();
      if (loaded && loaded.combat.scenario !== requested)
        throw new Error("Stored combat scenario differs from deployment");
      if (loaded && loaded.combat.players.length !== initial.combat.players.length)
        throw new Error("Stored combat party size differs from deployment");
      if (loaded && ["paused-empty", "completed", "expired"].includes(loaded.snapshot.roomMode)) {
        this.installCombat(loaded);
        this.clock = this.createClock(loaded.combat.tick);
        this.recoveries = loaded.snapshot.runEpoch - 1;
        if (["completed", "expired"].includes(loaded.snapshot.roomMode)) this.clock.close();
        else
          this.emptyPause = {
            tick: loaded.combat.tick,
            runEpoch: loaded.snapshot.runEpoch,
            hash: combatRuntimeHash(loaded)
          };
      } else if (loaded) await this.restoreCombat(loaded);
      else await this.combatStore.initialize(initial);
      this.alarmAtMs = await this.ctx.storage.getAlarm();
      if (this.world.roomMode !== "expired" && this.alarmAtMs === null && this.alarmDeliveries === 0)
        await this.scheduleExpiry();
    } else
      this.identity = Promise.resolve(
        this.workload === "controller" ? CONTROLLER_IDENTITY : PROBE_IDENTITY
      );
  }
  async fetch(request) {
    const url = new URL(request.url);
    const parts = url.pathname.split("/");
    let action2 = parts[2];
    this.initialization ??= this.ctx.blockConcurrencyWhile(() => this.initialize(parts[1]));
    await this.initialization;
    this.resolvedIdentity = await this.identity;
    const profileId = request.headers.get("X-Edgefall-Profile") ?? "";
    let hostCommand = null;
    const requireHost = () => {
      if (!this.members || !hostCommand) throw new Error("host-required");
      const member = this.members.state.members.find((m) => m.profileId === profileId);
      const peer = member && this.peers.get(member.slot);
      if (!member || !peer?.metrics.active || peer.generation !== member.generation)
        throw new Error("stale-host-command");
      requireCurrentHost(
        this.members.state,
        profileId,
        this.world.runEpoch,
        this.context(member.slot).connectionEpoch,
        hostCommand
      );
    };
    if (action2 === "session") {
      if (request.method !== "GET" || !this.members?.state.members.some((m) => m.profileId === profileId))
        return Response.json({ code: "member-required" }, { status: 403 });
      return Response.json(
        roomControlState(this.members.state, this.world.roomMode, this.world.runEpoch),
        { headers: { "Cache-Control": "no-store" } }
      );
    }
    if (action2 === "control") {
      try {
        hostCommand = await readHostCommand(request);
      } catch (error) {
        return Response.json(
          { code: "invalid-command", detail: String(error).slice(0, 128) },
          { status: 400 }
        );
      }
      try {
        requireHost();
      } catch (error) {
        const code = error instanceof Error ? error.message : "host-required";
        return Response.json({ code }, { status: code === "host-required" ? 403 : 409 });
      }
      action2 = hostCommand.command;
      if (action2 !== "load" && action2 !== "start" && action2 !== "continue")
        return Response.json({ code: "command-unavailable" }, { status: 409 });
    } else if (this.workload === "combat" && ["start", "load", "continue"].includes(action2 ?? ""))
      return Response.json({ code: "host-command-required" }, { status: 401 });
    if (action2 === "disconnect-peer") {
      const slot = Number(url.searchParams.get("slot"));
      const peer = this.peers.get(slot);
      if (request.method !== "POST" || this.workload !== "combat" || this.world.roomMode !== "playing" || url.searchParams.get("slot") === null || !peer?.metrics.active)
        return new Response("Peer unavailable", { status: 409 });
      this.disconnect(peer, "injected-outage", 1012);
      return Response.json({ tick: this.world.tick, slot });
    }
    if (action2 === "admission") {
      const slot = Number(url.searchParams.get("slot"));
      const reply = (code, status2 = 200) => Response.json(
        {
          code,
          roomMode: this.world.roomMode,
          protocolMajor: PROTOCOL_MAJOR,
          protocolMinor: PROTOCOL_MINOR,
          identity: this.resolvedIdentity
        },
        { status: status2, headers: { "Cache-Control": "no-store" } }
      );
      if (request.method !== "GET" || url.searchParams.get("slot") === null || !Number.isInteger(slot) || slot < 0 || slot > 3 || !this.members)
        return reply("protocol-error", 400);
      if (!this.world.players.some((player2) => player2.slot === slot))
        return reply("room-full", 409);
      if (this.world.roomMode === "expired") return reply("room-ended", 410);
      if (this.world.roomMode === "recovering" || this.starting || this.admissions.has(slot) || this.pendingPeers.has(slot))
        return reply("outage", 503);
      try {
        admitMember(
          this.members.state,
          request.headers.get("X-Edgefall-Profile") ?? "",
          slot,
          this.admissionPhase(),
          Date.now()
        );
      } catch (error) {
        const reason = error instanceof Error ? error.message : "outage";
        return reply(
          reason === "reconnect-window-expired" ? "reservation-expired" : reason === "slot-reserved" ? "room-full" : reason === "profile-slot-mismatch" ? "profile-required" : reason,
          409
        );
      }
      return reply("ready");
    }
    if (action2 === "release-write") {
      if (request.method !== "POST" || this.workload !== "combat" || !this.heldPersistence)
        return new Response("No held write", { status: 409 });
      this.heldPersistence.release();
      return Response.json({ released: true });
    }
    if (action2 === "hold-next-write") {
      if (request.method !== "POST" || this.workload !== "combat" || this.world.roomMode !== "playing" || this.heldPersistence || this.holdNextPersistence)
        return new Response("Write hold unavailable", { status: 409 });
      this.holdNextPersistence = true;
      return Response.json({ tick: this.world.tick });
    }
    if (action2 === "fail-next-write") {
      if (request.method !== "POST" || this.workload !== "combat" || this.world.roomMode !== "playing")
        return new Response("Fault injection unavailable", { status: 409 });
      this.failNextPersistence = true;
      return Response.json({ tick: this.world.tick, durability: this.combatWriter?.status });
    }
    if (action2 === "fail-next-tick") {
      if (request.method !== "POST" || this.workload !== "combat" || this.world.roomMode !== "playing")
        return new Response("Fault injection unavailable", { status: 409 });
      this.failNextCombatTick = true;
      return Response.json({
        accepted: true,
        tick: this.world.tick,
        acknowledgments: this.world.acknowledgments,
        combat: this.combat,
        events: this.eventHistory?.entries,
        eventCursor: this.eventHistory?.cursor
      });
    }
    if (action2 === "recover") {
      if (request.method !== "POST") return new Response("Use POST", { status: 405 });
      if (this.workload === "combat") {
        if (this.starting || this.recoveries >= 4 || !["playing", "recovering", "paused-empty"].includes(this.world.roomMode))
          return new Response("Recovery unavailable", { status: 409 });
        this.clock.close();
        this.clearWatchdog();
        this.world.roomMode = "recovering";
        this.disconnectAll("baseline-replaced");
        this.peers.clear();
        this.starting = true;
        try {
          await this.restoreCombat();
        } finally {
          this.starting = false;
        }
        return Response.json({
          runEpoch: this.world.runEpoch,
          tick: this.world.tick,
          roomMode: this.world.roomMode,
          recoveryBoundary: this.recoveryBoundary
        });
      }
      if (this.workload !== "controller" || this.recoveries >= 4 || !["playing", "recovering", "paused-empty"].includes(this.world.roomMode))
        return new Response("Recovery unavailable", { status: 409 });
      const restored = recoverControllerWorld(this.world);
      for (const actor of restored.players)
        encodeSnapshot(
          {
            ...restored,
            connectionEpoch: controllerPeerContext(restored, actor.slot).connectionEpoch
          },
          controllerPeerContext(restored, actor.slot)
        );
      this.clock.close();
      this.clearWatchdog();
      this.disconnectAll("baseline-replaced");
      this.peers.clear();
      this.world = restored;
      this.clock = this.createClock(restored.tick);
      this.recoveries++;
      return Response.json({
        runEpoch: restored.runEpoch,
        tick: restored.tick,
        roomMode: restored.roomMode
      });
    }
    if (action2 === "connect") {
      const slot = Number(url.searchParams.get("slot"));
      if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket")
        return new Response("Upgrade required", { status: 426 });
      if (url.searchParams.get("slot") === null || !Number.isInteger(slot) || slot < 0 || slot > 3)
        return new Response("Invalid slot", { status: 400 });
      if (!this.world.players.some((player2) => player2.slot === slot))
        return new Response("Room full", { status: 409 });
      if (this.workload === "combat" && this.world.roomMode === "paused-empty") {
        if (this.starting) return new Response("Pause persistence pending", { status: 503 });
        try {
          if (!this.members) throw new Error("Missing room membership");
          admitMember(
            this.members.state,
            request.headers.get("X-Edgefall-Profile") ?? "",
            slot,
            this.admissionPhase(),
            Date.now()
          );
        } catch (error) {
          return new Response(error instanceof Error ? error.message : "Admission failed", {
            status: 409
          });
        }
        this.starting = true;
        try {
          await this.restoreCombat();
          this.peers.clear();
        } finally {
          this.starting = false;
        }
      }
      const replacing = this.workload === "combat" && this.world.roomMode === "playing";
      const waitingReplacement = this.workload === "combat" && isWaitingRoom(this.world.roomMode) && (this.peers.has(slot) || this.world.roomMode === "completed" && this.members?.state.members.some((member) => member.slot === slot));
      if ((replacing || waitingReplacement) && (this.world.players[slot]?.vehicleId !== null || this.context(slot).connectionEpoch >= COUNTER_LIMIT - 2))
        return new Response("Connection transition unavailable", { status: 409 });
      if (!replacing && (!(this.workload === "combat" ? isWaitingRoom(this.world.roomMode) : this.world.roomMode === "loading") || !waitingReplacement && this.peers.has(slot)) || waitingReplacement && this.admissions.size > 0 || this.admissions.has(slot) || this.pendingPeers.has(slot) || this.starting || this.connections.length >= 32)
        return new Response("Room admission unavailable", { status: 409 });
      let generation = 0;
      let settleAdmission = () => {
      };
      let admissionSucceeded = false;
      let persistingReplacement = false;
      if (this.members) {
        const profileId2 = request.headers.get("X-Edgefall-Profile") ?? "";
        try {
          const admitted = admitMember(
            this.members.state,
            profileId2,
            slot,
            this.admissionPhase(),
            Date.now()
          );
          generation = admitted.members.find((m) => m.slot === slot)?.generation ?? 0;
          if (waitingReplacement) this.starting = true;
          let settled = () => {
          };
          this.admissions.set(
            slot,
            new Promise((resolve) => {
              settled = resolve;
            })
          );
          settleAdmission = settled;
          const epoch = this.world.runEpoch;
          const phase = this.world.roomMode;
          this.members.save(admitted);
          await this.ctx.storage.sync();
          if (this.world.runEpoch !== epoch || this.world.roomMode !== phase)
            throw new Error("room-boundary-changed");
          if (waitingReplacement) {
            if (!this.combatStore) throw new Error("Missing combat store");
            persistingReplacement = true;
            const replacement = await this.combatStore.replaceWaitingConnection(
              this.combatRuntime(),
              slot + 1
            );
            if (this.world.runEpoch !== epoch || this.world.roomMode !== phase)
              throw new Error("room-boundary-changed");
            this.installCombat(replacement);
          }
          admissionSucceeded = true;
        } catch (error) {
          if (generation) {
            this.members.save(disconnectMember(this.members.state, slot, generation, Date.now()));
            const previous = this.peers.get(slot);
            if (previous) this.disconnect(previous, "admission-cancelled");
          }
          if (persistingReplacement) this.pausePersistence(String(error));
          return new Response(error instanceof Error ? error.message : "Admission failed", {
            status: 409
          });
        } finally {
          this.admissions.delete(slot);
          settleAdmission();
          if (waitingReplacement) {
            this.starting = false;
            if (!admissionSucceeded) this.pauseEmpty();
          }
        }
      }
      const pair = new WebSocketPair();
      const peer = {
        generation,
        initialBaseline: null,
        baselineTick: this.world.tick,
        lastRoomMode: this.world.roomMode,
        inputPauseSnapshotId: null,
        socket: pair[1],
        input: new InputStream({
          ...this.context(slot),
          connectionEpoch: this.context(slot).connectionEpoch + (replacing ? 1 : 0),
          controlEpoch: this.world.players[slot]?.controlEpoch ?? 1,
          baselineServerTick: this.world.tick
        }),
        lease: null,
        lastAckAt: performance.now(),
        pendingEventBaseline: null,
        eventBeforeBaseline: 0,
        metrics: {
          slot,
          active: true,
          inputFrames: 0,
          inputBytes: 0,
          renewedFrames: 0,
          acknowledgmentOnlyFrames: 0,
          snapshots: 0,
          snapshotBytes: 0,
          inputMappingBytes: 0,
          eventBytes: 0,
          eventFrames: 0,
          eventSentCursor: 0,
          eventBaselines: 0,
          maxQueuedCommands: 0,
          neutralizedAtTick: null,
          expiredAtTick: null,
          closeReason: null,
          lastInputError: null,
          lastOutputError: null,
          lastProcessedSequence: 0,
          lastHeld: 0
        }
      };
      this.ctx.acceptWebSocket(pair[1]);
      pair[1].serializeAttachment({ instanceId: this.instanceId, slot, generation });
      if (replacing) this.pendingPeers.set(slot, peer);
      else {
        const old = this.peers.get(slot);
        this.peers.set(slot, peer);
        if (old) this.disconnect(old, "connection-replaced", 4003);
        if (waitingReplacement)
          this.connections.push({
            tick: this.world.tick,
            slot,
            connectionEpoch: this.context(slot).connectionEpoch,
            controlEpoch: this.world.players[slot]?.controlEpoch ?? 0,
            baselineEventCursor: this.world.baselineEventCursor
          });
        this.welcome(peer);
      }
      if (this.members && peer.metrics.active) await this.clearExpiry();
      return new Response(null, { status: 101, webSocket: pair[0] });
    }
    if (action2 !== "status" && request.method !== "POST")
      return new Response("Use POST", { status: 405 });
    if (action2 === "continue") {
      if (this.starting || this.admissions.size || this.world.roomMode !== "intermission" || this.campaign?.state.phase !== "wipe" || !this.combatStore)
        return Response.json({ code: "continue-unavailable" }, { status: 409 });
      this.starting = true;
      try {
        const continued = await this.combatStore.transition(
          this.combatRuntime(),
          "continue",
          requireHost
        );
        requireHost();
        this.installCombat(continued);
        this.combatWriter = null;
        this.clock = this.createClock(continued.combat.tick);
        this.disconnectAll("baseline-replaced");
        this.peers.clear();
        this.emptyPause = null;
      } catch (error) {
        this.pausePersistence(String(error));
        return Response.json({ code: "continue-recovery" }, { status: 503 });
      } finally {
        this.starting = false;
      }
      return Response.json({
        roomMode: this.world.roomMode,
        runEpoch: this.world.runEpoch,
        continuesUsed: this.campaign?.state.continuesUsed
      });
    }
    if (action2 === "load") {
      if (this.starting || this.admissions.size || !["lobby", "intermission"].includes(this.world.roomMode) || this.campaign && ["wipe", "defeat"].includes(this.campaign.state.phase) || !this.combatStore)
        return Response.json({ code: "load-unavailable" }, { status: 409 });
      this.starting = true;
      try {
        const phase = this.world.roomMode;
        const loaded = await this.combatStore.transition(this.combatRuntime(), "load", requireHost);
        requireHost();
        if (this.world.roomMode !== phase) throw new Error("room-boundary-changed");
        this.installCombat(loaded);
        for (const peer of this.peers.values()) if (peer.metrics.active) this.publishSnapshot(peer);
      } catch (error) {
        this.pausePersistence(String(error));
        return Response.json({ code: "load-recovery" }, { status: 503 });
      } finally {
        this.starting = false;
      }
      return Response.json({ roomMode: this.world.roomMode });
    }
    if (action2 === "start") {
      if (this.starting || this.admissions.size > 0 || this.world.roomMode !== "loading" || ![...this.peers.values()].some((peer) => peer.metrics.active) || [...this.peers.values()].filter((peer) => peer.metrics.active).some(
        (peer) => !peer.metrics.active || peer.initialBaseline !== null || this.controllerInputs && peer.input.queuedCommands < CONTROLLER_INPUT_PREFILL_TICKS
      ))
        return new Response("Ready connected clients required", { status: 409 });
      this.starting = true;
      try {
        if (this.workload === "combat") {
          if (!this.combatStore) throw new Error("Missing combat store");
          const started = await this.combatStore.transition(
            this.combatRuntime(),
            "start",
            requireHost
          );
          requireHost();
          if (this.world.roomMode !== "loading") throw new Error("room-boundary-changed");
          this.installCombat(started);
          this.combatWriter = new CombatJournalWriter(
            { commit: (start, entries, accepted) => this.persistCombat(start, entries, accepted) },
            started,
            (reason) => this.pausePersistence(reason),
            (work) => this.ctx.waitUntil(work)
          );
        }
      } catch (error) {
        this.pausePersistence(String(error));
        return new Response("Combat start persistence failed", { status: 503 });
      } finally {
        this.starting = false;
      }
      if (![...this.peers.values()].some((peer) => peer.metrics.active)) {
        this.pauseEmpty();
        return new Response("Start cohort changed", { status: 409 });
      }
      const now = performance.now();
      for (const peer of this.peers.values()) {
        if (!peer.metrics.active) continue;
        peer.lease = new ControlLease(now);
        peer.lastAckAt = now;
      }
      this.world.roomMode = "playing";
      if (this.controllerInputs) {
        this.world.stateHash = roomWorkloadHash(this.world);
        for (const peer of this.peers.values()) this.publishSnapshot(peer);
      }
      this.watchdog = setTimeout(() => this.finish("wall-limit"), 2e4);
      this.startedAtTick = this.world.tick;
      this.clock.start();
    } else if (action2 === "close") this.finish("observer-closed");
    else if (action2 !== "status") return new Response("Not found", { status: 404 });
    const status = {
      emptyPause: this.emptyPause,
      alarmAtMs: this.alarmAtMs,
      alarmDeliveries: this.alarmDeliveries,
      pausedFrom: this.pausedFrom,
      connections: this.connections,
      staleSocketEvents: this.staleSocketEvents,
      membership: this.members ? {
        epoch: this.members.state.epoch,
        hostSlot: this.members.state.hostSlot,
        members: this.members.state.members.map(({ profileId: _private, ...member }) => member)
      } : null,
      instanceId: this.instanceId,
      worldFailure: this.worldFailure,
      durability: this.combatWriter?.status ?? null,
      persistenceFailure: this.persistenceFailure,
      persistenceHeld: this.heldPersistence !== null,
      persistenceCommits: this.combatStore?.commits ?? [],
      recoveryBoundary: this.recoveryBoundary,
      inputStreams: [...this.peers.values()].map((peer) => ({
        acknowledgment: peer.input.acknowledgment,
        queued: peer.input.queuedCommands,
        requiresResync: peer.input.requiresResync,
        delivery: peer.input.deliveryAcknowledgments,
        pendingEventBaseline: peer.pendingEventBaseline,
        initialBaseline: peer.initialBaseline
      })),
      combat: this.combat && this.campaign ? {
        world: this.combat,
        campaign: this.campaign,
        events: this.eventHistory?.entries ?? [],
        eventCursor: this.eventHistory?.cursor ?? 0,
        droppedEvents: this.eventHistory?.capEvictions ?? 0,
        ageEvictions: this.eventHistory?.ageEvictions ?? 0
      } : null,
      runEpoch: this.world.runEpoch,
      recoveries: this.recoveries,
      workload: this.workload,
      tick: this.world.tick,
      roomMode: this.world.roomMode,
      clock: this.clock.state,
      watchdogPending: this.watchdog !== null,
      peers: [...this.peers.values()].map((peer) => ({ ...peer.metrics })),
      inputTimeline: this.inputTimeline,
      localCpu: this.localCpu,
      callbacks: this.callbacks,
      timers: this.timers
    };
    return Response.json(status);
  }
  webSocketMessage(socket, message) {
    const peer = [...this.peers.values()].find((value) => value.socket === socket);
    if (!peer?.metrics.active || isWaitingRoom(this.world.roomMode) && this.admissions.has(peer.metrics.slot)) {
      this.staleSocketEvents = Math.min(1e3, this.staleSocketEvents + 1);
      return;
    }
    if ((typeof message === "string" ? message.length > 512 : message.byteLength > 284) || this.world.roomMode !== "playing" && !(this.controllerInputs && isWaitingRoom(this.world.roomMode))) {
      this.disconnect(peer, "invalid-input", 4004);
      return;
    }
    const now = performance.now();
    if (this.world.roomMode === "playing" && (!peer.lease || peer.lease.expired(now))) {
      this.disconnect(peer, "lease-expired");
      return;
    }
    let firstSequence = 0, lastSequence = 0;
    try {
      if (typeof message === "string") {
        if (this.workload !== "combat" || peer.initialBaseline)
          throw new Error("Unexpected event control");
        const request = decodeEventResyncRequest(message, this.context(peer.metrics.slot));
        if (request.lastEventCursor < peer.input.deliveryAcknowledgments.event || request.lastEventCursor > peer.metrics.eventSentCursor)
          throw new Error("Invalid event repair cursor");
        this.publishSnapshot(peer, "client-gap");
        return;
      }
      const previousAck = peer.input.deliveryAcknowledgments.snapshot;
      const batch = decodeInputBatch(new Uint8Array(message), this.context(peer.metrics.slot));
      const drainPaused = this.world.roomMode === "intermission" && this.campaign && ["wipe", "defeat"].includes(this.campaign.state.phase) && !peer.initialBaseline && (peer.inputPauseSnapshotId === null || batch.snapshotAck < peer.inputPauseSnapshotId);
      if (this.world.roomMode !== "loading" && this.world.roomMode !== "playing" && batch.commands.length && !drainPaused)
        throw new Error("Room phase accepts acknowledgments only");
      if (peer.initialBaseline && (batch.snapshotAck !== peer.initialBaseline.snapshotId || batch.eventAck !== peer.initialBaseline.cursor))
        throw new Error("Fresh baseline acknowledgment required");
      if (this.controllerInputs) {
        firstSequence = batch.commands[0]?.sequence ?? 0;
        lastSequence = batch.commands.at(-1)?.sequence ?? 0;
      }
      const eventBaselineAccepted = acceptsEventBaseline(
        peer.pendingEventBaseline,
        batch.snapshotAck,
        batch.eventAck,
        peer.eventBeforeBaseline
      );
      const result = peer.input.receive(
        new Uint8Array(message),
        now,
        this.clock.state.tick,
        drainPaused ? "drain-paused" : "active"
      );
      if (!result.duplicate) peer.initialBaseline = null;
      if (peer.lastRoomMode !== this.world.roomMode) this.publishSnapshot(peer);
      if (eventBaselineAccepted && !result.duplicate) peer.pendingEventBaseline = null;
      this.traceInput(
        peer,
        "admit",
        now,
        this.clock.state.tick,
        firstSequence,
        lastSequence,
        result.duplicate ? "duplicate" : drainPaused && batch.commands.length ? "discarded-after-pause" : "admitted"
      );
      peer.metrics.inputFrames++;
      peer.metrics.inputBytes += message.byteLength;
      if (result.admitted === 0 && !result.duplicate) peer.metrics.acknowledgmentOnlyFrames++;
      if (peer.lease?.observeAdmission(result, now)) peer.metrics.renewedFrames++;
      if (peer.input.deliveryAcknowledgments.snapshot > previousAck) peer.lastAckAt = now;
      peer.metrics.maxQueuedCommands = Math.max(
        peer.metrics.maxQueuedCommands,
        peer.input.queuedCommands
      );
    } catch (error) {
      peer.metrics.lastInputError = (error instanceof Error ? error.message : String(error)).slice(
        0,
        256
      );
      this.traceInput(
        peer,
        "reject",
        now,
        this.clock.state.tick,
        firstSequence,
        lastSequence,
        peer.metrics.lastInputError
      );
      this.disconnect(peer, "invalid-input", 4004);
    }
  }
  webSocketClose(socket) {
    const peer = [...this.peers.values()].find((value) => value.socket === socket);
    if (peer) this.disconnect(peer, "socket-closed");
    else {
      const pending = [...this.pendingPeers.values()].find((value) => value.socket === socket);
      if (pending) {
        this.disconnect(pending, "socket-closed");
        this.pendingPeers.delete(pending.metrics.slot);
        const previous = this.peers.get(pending.metrics.slot);
        if (previous) this.disconnect(previous, "admission-cancelled");
      } else this.staleSocketEvents = Math.min(1e3, this.staleSocketEvents + 1);
    }
  }
  webSocketError(socket) {
    this.webSocketClose(socket);
  }
};
var room_probe_default = {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!["localhost", "127.0.0.1"].includes(url.hostname))
      return new Response("Local only", { status: 403 });
    if (url.pathname === "/health") return Response.json({ fixture: "edgefall-room-load-probe" });
    const origin = request.headers.get("Origin");
    if (origin) {
      try {
        const source = new URL(origin);
        if (source.protocol !== "http:" || !["localhost", "127.0.0.1"].includes(source.hostname) || source.origin !== origin)
          return new Response("Local origin required", { status: 403 });
      } catch {
        return new Response("Invalid origin", { status: 403 });
      }
    }
    if (url.pathname === "/profile") {
      if (request.method !== "POST") return new Response("Use POST", { status: 405 });
      const now = Math.floor(Date.now() / 1e3);
      const existing = await verifyProfileIdentity(
        profileCookie(request.headers.get("Cookie")),
        env.PROFILE_COOKIE_SECRET,
        now
      );
      const headers = new Headers({ "Cache-Control": "no-store" });
      if (origin) {
        headers.set("Access-Control-Allow-Origin", origin);
        headers.set("Access-Control-Allow-Credentials", "true");
        headers.set("Vary", "Origin");
      }
      if (!existing)
        headers.set(
          "Set-Cookie",
          `${PROFILE_COOKIE_NAME}=${await signProfileIdentity(crypto.randomUUID(), now + 3600, env.PROFILE_COOKIE_SECRET)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=3600`
        );
      return Response.json({ authenticated: true }, { headers });
    }
    const match = /^\/(standard|double|controller|combat)\/(session|control|admission|connect|start|status|close|recover|disconnect-peer|fail-next-tick|fail-next-write|hold-next-write|release-write)$/u.exec(
      url.pathname
    );
    if (!match?.[1]) return new Response("Not found", { status: 404 });
    const forwarded = new Request(request);
    forwarded.headers.delete("X-Edgefall-Profile");
    const cors = (response2) => {
      if (origin && ["admission", "session", "control"].includes(match[2] ?? "")) {
        response2.headers.set("Access-Control-Allow-Origin", origin);
        response2.headers.set("Access-Control-Allow-Credentials", "true");
        response2.headers.set("Vary", "Origin");
      }
      return response2;
    };
    if (match[1] === "combat" && ["connect", "admission", "session", "control"].includes(match[2] ?? "")) {
      if (request.method !== (match[2] === "control" ? "POST" : "GET"))
        return new Response("Method not allowed", { status: 405 });
      const profile = await verifyProfileIdentity(
        profileCookie(request.headers.get("Cookie")),
        env.PROFILE_COOKIE_SECRET,
        Math.floor(Date.now() / 1e3)
      );
      if (!profile) return cors(Response.json({ code: "profile-required" }, { status: 401 }));
      forwarded.headers.set("X-Edgefall-Profile", profile);
    }
    const response = await env.ROOM_PROBES.getByName(match[1]).fetch(forwarded);
    return ["admission", "session", "control"].includes(match[2] ?? "") ? cors(new Response(response.body, response)) : response;
  }
};
export {
  RoomLoadProbe,
  room_probe_default as default
};
