(() => {
  // src/game/core/numeric.ts
  var SUBPIXELS = 256;
  var MAX_POSITION = 2 ** 24;
  var MAX_SHAPE = 2 ** 16;
  var MAX_MOTION = 2 ** 16;
  var COUNTER_LIMIT = 4294963200;
  function integer(value, minimum, maximum, label) {
    if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
      throw new RangeError(`${label} must be an integer in [${minimum}, ${maximum}]`);
    }
    return value;
  }
  function position(value) {
    return integer(value, -MAX_POSITION, MAX_POSITION, "position");
  }
  function motion(value) {
    return integer(value, -MAX_MOTION, MAX_MOTION, "motion");
  }
  function pixels(value) {
    return position(
      integer(value, -MAX_POSITION / SUBPIXELS, MAX_POSITION / SUBPIXELS, "pixels") * SUBPIXELS
    );
  }

  // src/game/content/materials.ts
  var ATTACK_MATERIALS = [
    "bullet",
    "explosive",
    "heat",
    "energy",
    "blade",
    "blunt"
  ];
  var SURFACE_MATERIAL_IDS = ["concrete", "timber", "armor-steel", "open-grating"];
  var opaque = {
    bullet: true,
    explosive: true,
    heat: true,
    energy: true,
    blade: true,
    blunt: true
  };
  var SURFACE_MATERIALS = [
    {
      id: "concrete",
      damageScale: { bullet: 0, explosive: 0, heat: 0, energy: 0, blade: 0, blunt: 0 },
      blocks: { ...opaque }
    },
    {
      id: "timber",
      damageScale: { bullet: 1, explosive: 1, heat: 1, energy: 1, blade: 1, blunt: 1 },
      blocks: { ...opaque }
    },
    {
      id: "armor-steel",
      damageScale: { bullet: 0, explosive: 1, heat: 0, energy: 2, blade: 0, blunt: 0 },
      blocks: { ...opaque }
    },
    {
      id: "open-grating",
      damageScale: { bullet: 1, explosive: 1, heat: 0, energy: 1, blade: 0, blunt: 1 },
      blocks: {
        bullet: true,
        explosive: false,
        heat: false,
        energy: false,
        blade: true,
        blunt: true
      }
    }
  ];
  function validateSurfaceMaterials(definitions) {
    if (definitions.length !== SURFACE_MATERIAL_IDS.length)
      throw new Error("Material roster mismatch");
    for (const [index, material] of definitions.entries()) {
      if (material.id !== SURFACE_MATERIAL_IDS[index] || Object.keys(material).sort().join() !== "blocks,damageScale,id")
        throw new Error("Unknown or malformed surface material");
      for (const table of [material.damageScale, material.blocks])
        if (Object.keys(table).sort().join() !== [...ATTACK_MATERIALS].sort().join())
          throw new Error("Incomplete material response table");
      for (const attack2 of ATTACK_MATERIALS) {
        integer(material.damageScale[attack2], 0, 4, "material damage scale");
        if (typeof material.blocks[attack2] !== "boolean")
          throw new Error("Invalid material blocking policy");
      }
    }
  }
  validateSurfaceMaterials(SURFACE_MATERIALS);
  function surfaceMaterial(id) {
    const material = SURFACE_MATERIALS.find((material2) => material2.id === id);
    if (!material) throw new Error("Unknown surface material");
    return material;
  }

  // src/game/physics/body.ts
  function validateLocalRect(rect) {
    integer(rect.x, -MAX_SHAPE, MAX_SHAPE, "local x");
    integer(rect.y, -MAX_SHAPE, MAX_SHAPE, "local y");
    integer(rect.w, 1, MAX_SHAPE, "local width");
    integer(rect.h, 1, MAX_SHAPE, "local height");
    integer(rect.x + rect.w, -MAX_SHAPE, MAX_SHAPE, "local right edge");
    integer(rect.y + rect.h, -MAX_SHAPE, MAX_SHAPE, "local bottom edge");
  }

  // src/game/combat/area-attack.ts
  function validateAreaProfile(profile, definition) {
    if (definition.kind !== profile.kind || !["shot-volume", "flame-volumes"].includes(profile.kind))
      throw new Error("Unknown area profile");
    if (definition.material !== (profile.kind === "shot-volume" ? "bullet" : "heat"))
      throw new Error("Area profile material mismatch");
    integer(profile.frames.length, 1, 120, "area frames");
    integer(profile.emissionOffsets.length, 1, 4, "area emissions");
    integer(profile.attachedTicks, 0, profile.frames.length, "area attachment");
    integer(profile.maximumReach, 1, MAX_SHAPE, "area reach");
    for (const [index, offset] of profile.emissionOffsets.entries()) {
      integer(
        offset,
        index === 0 ? 0 : (profile.emissionOffsets[index - 1] ?? 0) + 1,
        120,
        "area emission offset"
      );
      if (index === 0 && offset !== 0) throw new Error("Area must begin at its first emission");
    }
    for (const frame of profile.frames) {
      validateLocalRect(frame);
      if (frame.x < 0 || frame.x + frame.w > profile.maximumReach)
        throw new Error("Area frame exceeds reach");
    }
    if (definition.lifetimeTicks !== (profile.emissionOffsets.at(-1) ?? 0) + profile.frames.length || profile.kind === "shot-volume" && (definition.repeatDamageTicks !== 0 || profile.attachedTicks !== 0 || profile.emissionOffsets.length !== 1) || profile.kind === "flame-volumes" && definition.repeatDamageTicks < 1)
      throw new Error("Area lifetime/damage policy mismatch");
  }

  // src/game/core/canonical.ts
  function canonical(value) {
    const ancestors = /* @__PURE__ */ new Set();
    let nodes = 0;
    function encode(item, depth) {
      if (++nodes > 1e5 || depth > 64) throw new RangeError("Canonical state exceeds bounds");
      if (item === null || typeof item === "boolean" || typeof item === "string")
        return JSON.stringify(item);
      if (typeof item === "number" && Number.isSafeInteger(item))
        return String(item === 0 ? 0 : item);
      if (typeof item !== "object" || item === null)
        throw new TypeError("Noncanonical authoritative value");
      if (ancestors.has(item)) throw new TypeError("Cyclic authoritative state");
      ancestors.add(item);
      let result;
      if (Array.isArray(item)) {
        const parts = [];
        for (let index = 0; index < item.length; index++) {
          if (!Object.hasOwn(item, index)) throw new TypeError("Sparse authoritative array");
          parts.push(encode(item[index], depth + 1));
        }
        result = `[${parts.join(",")}]`;
      } else {
        if (Object.getPrototypeOf(item) !== Object.prototype && Object.getPrototypeOf(item) !== null) {
          throw new TypeError("Authoritative records must be plain objects");
        }
        if (Object.getOwnPropertySymbols(item).length)
          throw new TypeError("Symbol state keys are unsupported");
        const record = item;
        result = `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${encode(record[key], depth + 1)}`).join(",")}}`;
      }
      ancestors.delete(item);
      return result;
    }
    return encode(value, 0);
  }

  // src/game/combat/firearm-aim.ts
  function validateFirearmSweep(profile, catalog) {
    const sweep = profile.sweep;
    if (!sweep) return;
    integer(sweep.stepTicks, 1, 60, "firearm heading exposure");
    const reference = catalog.timelines.get(profile.timelineIds[0]);
    if (!reference || sweep.headings.length !== 9) throw new Error("Incomplete firearm sweep");
    for (const [index, heading] of sweep.headings.entries()) {
      if (heading.pitch !== index - 4)
        throw new Error("Firearm headings must cover -4 through 4 in order");
      const timeline = catalog.timelines.get(heading.timelineId);
      if (!timeline || timeline.durationTicks !== reference.durationTicks || canonical(timeline.markers) !== canonical(reference.markers))
        throw new Error("Firearm sweep marker schedules disagree");
      motion(heading.velocity.x);
      motion(heading.velocity.y);
      if (heading.velocity.x < 0 || Math.sign(heading.velocity.y) !== -Math.sign(heading.pitch) || Math.abs(heading.pitch) === 4 !== (heading.velocity.x === 0) || heading.velocity.x === 0 && heading.velocity.y === 0)
        throw new Error("Invalid authored firearm velocity");
      for (const poseId of timeline.poses) {
        const muzzle = catalog.poses.get(poseId)?.sockets.find((socket) => socket.name === "muzzle");
        if (!muzzle || canonical(muzzle.point) !== canonical(heading.muzzle))
          throw new Error("Firearm sweep socket mismatch");
      }
    }
    for (const [pitch, timelineId] of [
      [0, profile.timelineIds[0]],
      [4, profile.timelineIds[1]],
      [-4, profile.timelineIds[2]]
    ])
      if (sweep.headings.find((heading) => heading.pitch === pitch)?.timelineId !== timelineId)
        throw new Error("Firearm cardinal and sweep poses disagree");
  }

  // src/game/content/contract-fixture.ts
  var CONTRACT_FIXTURE = {
    format: 1,
    simulationHz: 60,
    shapes: [
      { id: 1, rect: { x: pixels(-7), y: pixels(-34), w: pixels(14), h: pixels(34) } },
      { id: 2, rect: { x: pixels(-7), y: pixels(-20), w: pixels(14), h: pixels(20) } },
      { id: 3, rect: { x: pixels(-5), y: pixels(-32), w: pixels(10), h: pixels(30) } },
      { id: 4, rect: { x: pixels(-1), y: pixels(-1), w: pixels(2), h: pixels(2) } },
      { id: 5, rect: { x: pixels(-40), y: pixels(-32), w: pixels(80), h: pixels(32) } },
      { id: 6, rect: { x: pixels(-24), y: pixels(-30), w: pixels(48), h: pixels(30) } }
    ],
    poses: [
      {
        id: 1,
        frame: "fixture-operative-idle",
        durationTicks: 6,
        sockets: [
          { name: "muzzle", point: { x: pixels(15), y: pixels(-23) } },
          { name: "hand", point: { x: pixels(10), y: pixels(-20) } }
        ],
        hurtShapeIds: [3]
      },
      {
        id: 2,
        frame: "fixture-tank-idle",
        durationTicks: 12,
        sockets: [
          { name: "seat", point: { x: 0, y: pixels(-20) } },
          { name: "ejection", point: { x: pixels(-40), y: 0 } }
        ],
        hurtShapeIds: [6]
      }
    ],
    timelines: [
      {
        id: 1,
        durationTicks: 6,
        poses: [1],
        markers: [{ tickOffset: 0, kind: "spawn-attack", payloadId: 1, socket: "muzzle" }]
      },
      {
        id: 2,
        durationTicks: 12,
        poses: [2],
        markers: [{ tickOffset: 11, kind: "seat-transfer", payloadId: 1, socket: "seat" }]
      }
    ],
    attacks: [
      {
        id: 1,
        kind: "swept-projectile",
        shapeId: 4,
        damage: 1,
        lifetimeTicks: 30,
        speed: pixels(12),
        maxTargets: 1,
        repeatDamageTicks: 0,
        material: "bullet"
      }
    ],
    weapons: [
      {
        id: "sidearm",
        attackId: 1,
        timelineId: 1,
        cadenceTicks: 10,
        ammoPerAction: 0,
        pickupAmmo: "unlimited",
        aimPolicy: "cardinal",
        visualFamily: "fixture-sidearm",
        audioFamily: "fixture-sidearm"
      }
    ],
    actors: [
      {
        id: 1,
        locomotion: "grounded",
        standingShapeId: 1,
        crouchedShapeId: 2,
        idlePoseId: 1,
        runSpeed: 768,
        jumpVelocity: -1430,
        gravity: 55,
        terminalVelocity: 2048
      },
      {
        id: 2,
        locomotion: "grounded",
        standingShapeId: 6,
        crouchedShapeId: 6,
        idlePoseId: 2,
        runSpeed: 640,
        jumpVelocity: -1200,
        gravity: 60,
        terminalVelocity: 2048
      }
    ],
    vehicles: [
      {
        id: 1,
        kind: "tank",
        actorId: 2,
        armor: 3,
        weaponId: "sidearm",
        seat: {
          socket: { x: 0, y: pixels(-20) },
          ejectionCandidates: [
            { x: pixels(-40), y: 0 },
            { x: pixels(40), y: 0 }
          ],
          boardingSensorShapeId: 5,
          boardingTimelineId: 2
        }
      }
    ],
    terrain: [
      {
        id: 100,
        kind: "solid",
        rect: { x: 0, y: pixels(200), w: pixels(384), h: pixels(16) },
        visibleSurfaceId: "fixture-floor"
      },
      {
        id: 101,
        kind: "one-way",
        rect: { x: pixels(100), y: pixels(145), w: pixels(80), h: pixels(8) },
        visibleSurfaceId: "fixture-platform"
      }
    ],
    encounters: [
      {
        id: 1,
        camera: { x: 0, y: 0, w: pixels(384), h: pixels(216) },
        killBounds: { x: pixels(-64), y: pixels(-64), w: pixels(512), h: pixels(320) },
        checkpoint: { x: pixels(32), y: pixels(200) },
        spawns: [
          {
            id: 102,
            actorId: 1,
            point: { x: pixels(50), y: pixels(200) },
            required: true,
            retreatAllowed: false
          }
        ],
        vehicleSpawns: [{ id: 103, definitionId: 1, point: { x: pixels(250), y: pixels(200) } }]
      }
    ]
  };

  // src/game/content/validate.ts
  function check(condition, message) {
    if (!condition) throw new Error(`Invalid content: ${message}`);
  }
  function unique(values, label) {
    check(values.length <= 4096, `${label} count`);
    const table = /* @__PURE__ */ new Map();
    for (const value of values) {
      if (typeof value.id === "number") integer(value.id, 1, COUNTER_LIMIT - 1, label);
      check(!table.has(value.id), `duplicate ${label} ID ${value.id}`);
      table.set(value.id, value);
    }
    return table;
  }
  function point(value, local = false) {
    const maximum = local ? MAX_SHAPE : 2 ** 24;
    integer(value.x, -maximum, maximum, "point x");
    integer(value.y, -maximum, maximum, "point y");
  }
  function rectangle(rect, local = false) {
    if (local) validateLocalRect(rect);
    point(rect, local);
    integer(rect.w, 1, local ? MAX_SHAPE : 2 ** 24, "rectangle width");
    integer(rect.h, 1, local ? MAX_SHAPE : 2 ** 24, "rectangle height");
    position(rect.x + rect.w);
    position(rect.y + rect.h);
  }
  function validateContent(content) {
    canonical(content);
    check(content.format === 1 && content.simulationHz === 60, "format/tick rate");
    const shapes = unique(content.shapes, "shape");
    const poses = unique(content.poses, "pose");
    const timelines = unique(content.timelines, "timeline");
    const attacks = unique(content.attacks, "attack");
    const weapons = unique(content.weapons, "weapon");
    const actors = unique(content.actors, "actor");
    const vehicles = unique(content.vehicles, "vehicle");
    const entities = new Set(unique(content.terrain, "terrain").keys());
    unique(content.encounters, "encounter");
    for (const shape of content.shapes) rectangle(shape.rect, true);
    for (const pose of content.poses) {
      integer(pose.durationTicks, 1, 3600, "pose duration");
      check(pose.frame.length > 0, "missing frame identity");
      check(
        pose.sockets.length <= 8 && new Set(pose.sockets.map((socket) => socket.name)).size === pose.sockets.length,
        "duplicate/excess sockets"
      );
      for (const socket of pose.sockets) point(socket.point, true);
      check(
        pose.hurtShapeIds.length <= 16 && pose.hurtShapeIds.every((id) => shapes.has(id)),
        "unknown/excess hurt shapes"
      );
    }
    for (const timeline of content.timelines) {
      integer(timeline.durationTicks, 1, 3600, "timeline duration");
      check(
        timeline.poses.length > 0 && timeline.poses.length <= 256 && timeline.poses.every((id) => poses.has(id)),
        "missing/excess timeline poses"
      );
      const duration = timeline.poses.reduce(
        (sum, id) => sum + (poses.get(id)?.durationTicks ?? 0),
        0
      );
      check(duration === timeline.durationTicks, "timeline exposure duration mismatch");
      check(timeline.markers.length <= 128, "excess markers");
      let previous = -1;
      for (const marker of timeline.markers) {
        integer(marker.tickOffset, 0, timeline.durationTicks - 1, "marker tick");
        check(marker.tickOffset >= previous, "unordered markers");
        previous = marker.tickOffset;
        let age = marker.tickOffset;
        const pose = timeline.poses.map((id) => poses.get(id)).find((candidate) => {
          if (!candidate) return false;
          if (age < candidate.durationTicks) return true;
          age -= candidate.durationTicks;
          return false;
        });
        check(
          Boolean(pose?.sockets.some((socket) => socket.name === marker.socket)),
          "missing active pose socket"
        );
        if (marker.kind === "spawn-attack" || marker.kind === "activate-hitbox")
          check(attacks.has(marker.payloadId), "unknown marker attack");
        if (marker.kind === "seat-transfer")
          check(vehicles.has(marker.payloadId), "unknown marker vehicle");
      }
    }
    for (const attack2 of content.attacks) {
      check(ATTACK_MATERIALS.includes(attack2.material), "unknown attack material");
      check(shapes.has(attack2.shapeId), "unknown attack shape");
      motion(attack2.speed);
      integer(attack2.damage, 1, 65535, "damage");
      integer(attack2.lifetimeTicks, 1, 3600, "attack lifetime");
      integer(attack2.maxTargets, 1, 256, "attack target limit");
      integer(attack2.repeatDamageTicks, 0, 3600, "damage interval");
    }
    for (const weapon of content.weapons) {
      check(
        attacks.has(weapon.attackId) && timelines.has(weapon.timelineId),
        "unknown weapon action"
      );
      integer(weapon.cadenceTicks, 1, 3600, "weapon cadence");
      integer(weapon.ammoPerAction, 0, 65535, "ammo cost");
      if (weapon.pickupAmmo !== "unlimited")
        integer(weapon.pickupAmmo, 1, 65535, "pickup ammunition");
      check(
        weapon.pickupAmmo === "unlimited" ? weapon.ammoPerAction === 0 : weapon.ammoPerAction > 0,
        "inconsistent ammo policy"
      );
      check(
        weapon.visualFamily.length > 0 && weapon.audioFamily.length > 0,
        "missing weapon media family"
      );
    }
    for (const actor of content.actors) {
      check(
        shapes.has(actor.standingShapeId) && shapes.has(actor.crouchedShapeId) && poses.has(actor.idlePoseId),
        "unknown actor shape/pose"
      );
      for (const value of [actor.runSpeed, actor.jumpVelocity, actor.gravity, actor.terminalVelocity])
        motion(value);
      check(
        actor.runSpeed >= 0 && actor.gravity >= 0 && actor.terminalVelocity > 0 && actor.jumpVelocity <= 0,
        "actor movement signs"
      );
    }
    for (const vehicle of content.vehicles) {
      check(
        actors.has(vehicle.actorId) && weapons.has(vehicle.weaponId) && shapes.has(vehicle.seat.boardingSensorShapeId) && timelines.has(vehicle.seat.boardingTimelineId),
        "unknown vehicle reference"
      );
      integer(vehicle.armor, 1, 65535, "vehicle armor");
      point(vehicle.seat.socket, true);
      check(
        vehicle.seat.ejectionCandidates.length > 0 && vehicle.seat.ejectionCandidates.length <= 8,
        "ejection candidates"
      );
      for (const candidate of vehicle.seat.ejectionCandidates) point(candidate, true);
    }
    for (const terrain of content.terrain) {
      rectangle(terrain.rect);
      check(terrain.visibleSurfaceId.length > 0, "invisible terrain");
    }
    for (const encounter of content.encounters) {
      rectangle(encounter.camera);
      rectangle(encounter.killBounds);
      point(encounter.checkpoint);
      check(
        encounter.spawns.length <= 256 && encounter.vehicleSpawns.length <= 16,
        "encounter entity budget"
      );
      for (const spawn of [...encounter.spawns, ...encounter.vehicleSpawns]) {
        integer(spawn.id, 1, COUNTER_LIMIT - 1, "spawn ID");
        check(!entities.has(spawn.id), "reused world entity ID");
        entities.add(spawn.id);
        point(spawn.point);
        if ("actorId" in spawn) check(actors.has(spawn.actorId), "unknown spawn actor");
        else check(vehicles.has(spawn.definitionId), "unknown spawn vehicle");
      }
    }
  }

  // src/game/combat/beam.ts
  function validateBeamProfile(profile) {
    integer(profile.range, 1, MAX_SHAPE * 4, "beam range");
    integer(profile.width, 1, 4096, "beam width");
    integer(profile.pulseTicks, 1, 120, "beam pulse interval");
  }

  // src/game/content/weapons/laser.ts
  var LASER_WEAPON = {
    id: "laser",
    attackId: 18,
    timelineId: 230,
    cadenceTicks: 6,
    ammoPerAction: 1,
    pickupAmmo: 120,
    aimPolicy: "cardinal",
    visualFamily: "fixture-laser",
    audioFamily: "fixture-laser"
  };
  var LASER_PROFILE = { range: pixels(512), width: pixels(4), pulseTicks: 6 };
  var LASER_SHAPE = {
    id: 21,
    rect: { x: 0, y: -pixels(2), w: pixels(256), h: pixels(4) }
  };
  var LASER_ATTACK = {
    id: LASER_WEAPON.attackId,
    kind: "beam",
    shapeId: LASER_SHAPE.id,
    damage: 2,
    lifetimeTicks: 6,
    speed: 0,
    maxTargets: 8,
    repeatDamageTicks: 6,
    material: "energy"
  };
  validateBeamProfile(LASER_PROFILE);

  // src/game/combat/rocket.ts
  var QUADRANT = [
    [16384, 0],
    [16069, 3196],
    [15137, 6270],
    [13623, 9102],
    [11585, 11585],
    [9102, 13623],
    [6270, 15137],
    [3196, 16069]
  ];
  var HEADINGS = [0, 1, 2, 3].flatMap(
    (quadrant) => QUADRANT.map(
      ([x, y]) => quadrant === 0 ? [x, y] : quadrant === 1 ? [-y, x] : quadrant === 2 ? [-x, -y] : [y, -x]
    )
  );
  function validateRocketProfile(profile) {
    integer(profile.bodyShapeId, 1, COUNTER_LIMIT - 1, "rocket shape");
    integer(profile.launchSpeed, 1, MAX_MOTION, "rocket launch speed");
    integer(profile.maximumSpeed, profile.launchSpeed, MAX_MOTION, "rocket maximum speed");
    integer(profile.acceleration, 1, MAX_MOTION, "rocket acceleration");
    integer(profile.lifetimeTicks, 1, 3600, "rocket lifetime");
    integer(profile.blastRadius, 1, 2 ** 16, "rocket blast radius");
    integer(profile.acquireRange, 1, MAX_MOTION, "rocket acquisition range");
    integer(profile.retainRange, profile.acquireRange, MAX_MOTION, "rocket retention range");
    integer(profile.acquireSteps, 0, 7, "rocket acquisition cone");
    integer(profile.retainSteps, profile.acquireSteps, 7, "rocket retention cone");
    integer(profile.launchLeashSteps, 0, 7, "rocket launch leash");
    integer(profile.acquireIntervalTicks, 1, 60, "rocket acquisition interval");
    integer(profile.turnIntervalTicks, 1, 60, "rocket turn interval");
  }

  // src/game/content/weapons/rocket-launcher.ts
  var ROCKET_WEAPON = {
    id: "rocket-launcher",
    attackId: 17,
    timelineId: 220,
    cadenceTicks: 24,
    ammoPerAction: 1,
    pickupAmmo: 20,
    aimPolicy: "cardinal",
    visualFamily: "fixture-rocket",
    audioFamily: "fixture-rocket"
  };
  var ROCKET_SHAPE = {
    id: 19,
    rect: { x: -pixels(2), y: -pixels(2), w: pixels(4), h: pixels(4) }
  };
  var ROCKET_BLAST_SHAPE = {
    id: 20,
    rect: { x: -pixels(48), y: -pixels(48), w: pixels(96), h: pixels(96) }
  };
  var ROCKET_PROFILE = {
    bodyShapeId: ROCKET_SHAPE.id,
    launchSpeed: pixels(2),
    acceleration: 128,
    maximumSpeed: pixels(6),
    lifetimeTicks: 90,
    blastRadius: pixels(48),
    acquireRange: pixels(240),
    retainRange: pixels(256),
    acquireSteps: 2,
    retainSteps: 4,
    launchLeashSteps: 4,
    acquireIntervalTicks: 6,
    turnIntervalTicks: 3
  };
  var ROCKET_ATTACK = {
    id: ROCKET_WEAPON.attackId,
    kind: "explosion",
    shapeId: ROCKET_BLAST_SHAPE.id,
    damage: 4,
    lifetimeTicks: ROCKET_PROFILE.lifetimeTicks,
    speed: ROCKET_PROFILE.launchSpeed,
    maxTargets: 16,
    repeatDamageTicks: 0,
    material: "explosive"
  };
  validateRocketProfile(ROCKET_PROFILE);

  // src/game/content/weapons/tank-cannon.ts
  var CANNON_SHAPE = {
    id: 22,
    rect: { x: pixels(-4), y: pixels(-4), w: pixels(8), h: pixels(8) }
  };
  var CANNON_BLAST_SHAPE = {
    id: 23,
    rect: { x: pixels(-56), y: pixels(-56), w: pixels(112), h: pixels(112) }
  };
  var CANNON_ATTACK = {
    id: 19,
    kind: "explosion",
    shapeId: CANNON_BLAST_SHAPE.id,
    damage: 6,
    lifetimeTicks: 90,
    speed: pixels(12),
    maxTargets: 16,
    repeatDamageTicks: 0,
    material: "explosive"
  };
  var CANNON_PROFILE = {
    attackId: CANNON_ATTACK.id,
    bodyShapeId: CANNON_SHAPE.id,
    stock: 10,
    cadenceTicks: 45,
    blastRadius: pixels(56),
    fireTimelineIds: Array.from({ length: 8 }, (_, heading) => 240 + heading),
    releaseTick: 3,
    // The muzzle stays extended through release, then the barrel recoils and returns.
    recoil: [0, 0, 0, 0, 3, 4, 3, 2, 1, 0, 0, 0].map(pixels),
    hardpoint: { x: 0, y: pixels(-14) },
    headings: [
      [30, -14, 12, 0],
      [22, -36, 8, -8],
      [0, -44, 0, -12],
      [-22, -36, -8, -8],
      [-30, -14, -12, 0],
      [-22, 8, -8, 8],
      [0, 16, 0, 12],
      [22, 8, 8, 8]
    ].map(([x = 0, y = 0, vx = 0, vy = 0]) => ({
      muzzle: { x: pixels(x), y: pixels(y) },
      velocity: { x: pixels(vx), y: pixels(vy) }
    }))
  };

  // src/game/content/weapons/tank-special.ts
  var TANK_SPECIAL_SHAPE = {
    id: 24,
    rect: { x: pixels(-72), y: pixels(-72), w: pixels(144), h: pixels(144) }
  };
  var TANK_SPECIAL_ATTACK = {
    id: 20,
    kind: "explosion",
    shapeId: TANK_SPECIAL_SHAPE.id,
    damage: 8,
    lifetimeTicks: 60,
    speed: pixels(6),
    maxTargets: 16,
    repeatDamageTicks: 0,
    material: "explosive"
  };
  var TANK_SPECIAL_PROFILE = {
    armTicks: 30,
    attackId: TANK_SPECIAL_ATTACK.id,
    chargeTicks: TANK_SPECIAL_ATTACK.lifetimeTicks,
    speed: TANK_SPECIAL_ATTACK.speed,
    blastRadius: pixels(72)
  };

  // src/game/combat/timeline.ts
  function actionPose(catalog, definitionId, age) {
    const timeline = catalog.timelines.get(definitionId);
    if (!timeline) throw new Error("Missing action timeline");
    integer(age, 0, COUNTER_LIMIT - 1, "action age");
    if (age >= timeline.durationTicks) return null;
    let remaining = age;
    for (const id of timeline.poses) {
      const pose = catalog.poses.get(id);
      if (!pose) throw new Error("Missing action pose");
      if (remaining < pose.durationTicks) return pose;
      remaining -= pose.durationTicks;
    }
    throw new Error("Action pose exposures do not cover timeline");
  }

  // src/game/input/types.ts
  var Held = {
    Left: 1 << 0,
    Right: 1 << 1,
    Up: 1 << 2,
    Down: 1 << 3,
    Fire: 1 << 4,
    VehicleSpecial: 1 << 5
  };

  // src/game/rules.ts
  var ARCADE = Object.freeze({
    width: 384,
    height: 216,
    simulationHz: 60,
    snapshotHz: 20,
    maxPlayers: 4,
    staleInputMs: 250,
    reservationMs: 9e4,
    initialLives: 3,
    initialGrenades: 10,
    respawnProtectionTicks: 120,
    deathTicks: 30,
    respawnEntryTicks: 12,
    boardingTicks: 12,
    reboardCooldownTicks: 30,
    vehicleSpecialHoldTicks: 30,
    jumpBufferTicks: 5,
    coyoteTicks: 4,
    dropThroughTicks: 12
  });
  var RULE_PRESETS = Object.freeze({
    classic: Object.freeze({ footHealth: 1, tankArmor: 3, sharedContinues: 3 }),
    accessible: Object.freeze({ footHealth: 3, tankArmor: 3, sharedContinues: 9 })
  });
  var DEFAULT_BINDINGS = Object.freeze({
    left: ["ArrowLeft", "KeyA"],
    right: ["ArrowRight", "KeyD"],
    up: ["ArrowUp", "KeyW"],
    down: ["ArrowDown", "KeyS"],
    fire: ["KeyJ", "KeyZ"],
    jump: ["Space", "KeyK", "KeyX"],
    grenade: ["KeyL", "KeyC"],
    interact: ["KeyE"],
    vehicleSpecial: ["KeyV"]
  });
  var DEFAULT_GAMEPAD = Object.freeze({
    jump: 0,
    fire: 2,
    grenade: 1,
    interact: 3,
    vehicleSpecial: 4
  });

  // src/game/vehicles/tank.ts
  function validateTankProfile(profile, shapes, catalog) {
    if (profile.definition.kind !== "tank" || profile.definition.actorId !== profile.locomotion.id || profile.locomotion.standingShapeId !== profile.locomotion.crouchedShapeId)
      throw new Error("Invalid tank controller definition");
    integer(profile.headings.length, 8, 8, "tank headings");
    integer(profile.fireTimelineIds.length, 8, 8, "tank fire poses");
    for (const id of [
      profile.definition.seat.boardingSensorShapeId,
      profile.locomotion.standingShapeId
    ])
      if (!shapes.has(id)) throw new Error("Missing tank shape");
    for (const id of [
      profile.definition.seat.boardingTimelineId,
      profile.exitTimelineId,
      ...profile.fireTimelineIds
    ])
      if (!catalog.timelines.has(id)) throw new Error("Missing tank timeline");
    for (const ticks of [
      profile.fireCadenceTicks,
      profile.turnTicks,
      profile.damageProtectionTicks,
      profile.reboardTicks,
      profile.exitProtectionTicks,
      profile.disconnectGraceTicks
    ])
      integer(ticks, 1, 120, "tank timing");
    integer(profile.special.armTicks, 2, 120, "tank arming time");
    integer(profile.special.chargeTicks, 1, 120, "tank charge duration");
    integer(profile.special.speed, 1, MAX_MOTION, "tank charge speed");
    integer(profile.special.blastRadius, 1, 2 ** 16, "tank sacrifice radius");
    const cannon = profile.cannon;
    integer(cannon.stock, 1, 65535, "cannon stock");
    integer(cannon.recoil.length, 1, 120, "cannon action duration");
    integer(cannon.cadenceTicks, cannon.recoil.length, 120, "cannon cadence");
    integer(cannon.releaseTick, 0, cannon.recoil.length - 1, "cannon release tick");
    integer(cannon.blastRadius, 1, 2 ** 16, "cannon blast radius");
    integer(cannon.headings.length, 8, 8, "cannon headings");
    integer(cannon.fireTimelineIds.length, 8, 8, "cannon fire poses");
    if (!shapes.has(cannon.bodyShapeId) || (/* @__PURE__ */ new Set([...profile.fireTimelineIds, ...cannon.fireTimelineIds])).size !== 16)
      throw new Error("Invalid cannon content identity");
    position(cannon.hardpoint.x);
    position(cannon.hardpoint.y);
    for (const [age, recoil] of cannon.recoil.entries()) {
      integer(recoil, 0, pixels(16), "cannon recoil");
      if (age <= cannon.releaseTick && recoil !== 0) throw new Error("Cannon recoils before release");
    }
    for (const [index, heading] of cannon.headings.entries()) {
      position(heading.muzzle.x);
      position(heading.muzzle.y);
      motion(heading.velocity.x);
      motion(heading.velocity.y);
      integer(
        Math.abs(heading.velocity.x) + Math.abs(heading.velocity.y),
        1,
        MAX_MOTION,
        "cannon flight speed"
      );
      const id = cannon.fireTimelineIds[index], timeline = id === void 0 ? void 0 : catalog.timelines.get(id);
      if (!timeline || timeline.durationTicks !== cannon.recoil.length || timeline.markers.length !== 2 || timeline.markers.some(
        (marker, i) => marker.kind !== (i === 0 ? "spawn-attack" : "sound") || marker.tickOffset !== cannon.releaseTick || marker.payloadId !== cannon.attackId || marker.socket !== "muzzle"
      ))
        throw new Error("Invalid cannon release timeline");
      const socket = actionPose(catalog, timeline.id, cannon.releaseTick)?.sockets.find(
        (socket2) => socket2.name === "muzzle"
      );
      if (!socket || canonical(socket.point) !== canonical(heading.muzzle))
        throw new Error("Cannon release socket mismatch");
    }
  }

  // src/game/content/scenarios/materials.ts
  var MATERIAL_LAB_WEAPONS = [
    "sidearm",
    "heavy-machine-gun",
    "shotgun",
    "rocket-launcher",
    "flamethrower",
    "laser",
    "knife",
    "grenade"
  ];
  var MATERIAL_TARGET_MOTIONS = ["stationary", "patrol"];
  var MATERIAL_CASES = MATERIAL_LAB_WEAPONS.flatMap(
    (weapon) => SURFACE_MATERIAL_IDS.flatMap(
      (materialId) => MATERIAL_TARGET_MOTIONS.map((targetMotion) => ({ weapon, materialId, targetMotion }))
    )
  );
  function materialScenario(definition) {
    if (!MATERIAL_LAB_WEAPONS.includes(definition.weapon) || !MATERIAL_TARGET_MOTIONS.includes(definition.targetMotion))
      throw new Error("Unknown material calibration case");
    surfaceMaterial(definition.materialId);
    return `material:${definition.weapon}:${definition.materialId}:${definition.targetMotion}`;
  }
  var MATERIAL_SCENARIOS = MATERIAL_CASES.map(materialScenario);
  var cases = new Map(
    MATERIAL_SCENARIOS.map((scenario, index) => [scenario, MATERIAL_CASES[index]])
  );
  var MATERIAL_CALIBRATION = {
    definitionId: 5,
    firstTargetX: pixels(112),
    targetSpacing: pixels(24),
    targetY: pixels(200),
    targetHealth: 32,
    patrolSpeed: 64,
    bounds: { x: 0, y: 0, w: pixels(384), h: pixels(232) },
    fallBoundary: pixels(248)
  };

  // src/game/labs/foot-fixture.ts
  var FOOT_SHAPES = new Map(CONTRACT_FIXTURE.shapes.map((shape) => [shape.id, shape]));
  var FOOT_DEFINITION = CONTRACT_FIXTURE.actors[0];
  if (!FOOT_DEFINITION) throw new Error("Missing foot fixture definition");
  function footTerrain(id, x, y, w, h, kind = "solid") {
    return {
      id,
      rect: { x: pixels(x), y: pixels(y), w: pixels(w), h: pixels(h) },
      kind,
      delta: { x: 0, y: 0 }
    };
  }
  var FOOT_FLOOR = footTerrain(100, -200, 0, 400, 16);

  // src/game/labs/combat-terrain.ts
  var COMBAT_SUPPORT = [
    {
      id: 104,
      definitionId: 1,
      rect: { x: pixels(176), y: pixels(160), w: pixels(152), h: pixels(56) },
      health: 8,
      materialId: "timber"
    }
  ];
  var COMBAT_ORDNANCE = [
    {
      id: 102,
      shapeId: 17,
      x: pixels(24),
      y: pixels(160),
      w: pixels(240),
      h: pixels(8),
      start: 0,
      end: 50,
      dx: pixels(1),
      dy: 0
    },
    {
      id: 103,
      shapeId: 18,
      x: pixels(190),
      y: pixels(90),
      w: pixels(132),
      h: pixels(10),
      start: 55,
      end: 85,
      dx: 0,
      dy: pixels(2)
    }
  ];

  // src/game/labs/combat-content.ts
  var COMBAT_CONTENT = structuredClone(CONTRACT_FIXTURE);
  COMBAT_CONTENT.shapes.push(
    { id: 7, rect: { x: pixels(-5), y: pixels(-18), w: pixels(10), h: pixels(16) } },
    { id: 8, rect: { x: pixels(5), y: pixels(-30), w: pixels(4), h: pixels(28) } },
    { id: 9, rect: { x: pixels(-10), y: pixels(-8), w: pixels(34), h: pixels(16) } },
    { id: 10, rect: { x: pixels(-3), y: pixels(-3), w: pixels(6), h: pixels(6) } },
    { id: 11, rect: { x: pixels(-48), y: pixels(-48), w: pixels(96), h: pixels(96) } },
    { id: 12, rect: { x: 0, y: pixels(-10), w: pixels(30), h: pixels(24) } },
    { id: 13, rect: { x: 0, y: pixels(-3), w: pixels(20), h: pixels(6) } },
    { id: 14, rect: { x: 0, y: pixels(-8), w: pixels(14), h: pixels(8) } },
    structuredClone(ROCKET_SHAPE),
    structuredClone(ROCKET_BLAST_SHAPE),
    structuredClone(LASER_SHAPE)
  );
  var sidearm = COMBAT_CONTENT.weapons[0];
  var attack = COMBAT_CONTENT.attacks[0];
  if (!sidearm || !attack) throw new Error("Missing baseline firearm content");
  sidearm.cadenceTicks = 8;
  var hmg = {
    ...sidearm,
    id: "heavy-machine-gun",
    attackId: 2,
    cadenceTicks: 5,
    ammoPerAction: 1,
    pickupAmmo: 150,
    timelineId: 14,
    visualFamily: "fixture-hmg",
    audioFamily: "fixture-hmg"
  };
  COMBAT_CONTENT.weapons.push(hmg);
  COMBAT_CONTENT.attacks.push({ ...attack, id: 2, speed: pixels(18) });
  var HMG_SWEEP = {
    stepTicks: 2,
    headings: [
      [-4, 16, 2, 0, 0, 4608],
      [-3, 200, 6, -7, 1763, 4257],
      [-2, 201, 11, -12, 3258, 3258],
      [-1, 202, 14, -17, 4257, 1763],
      [0, 14, 15, -23, 4608, 0],
      [1, 203, 14, -29, 4257, -1763],
      [2, 204, 11, -34, 3258, -3258],
      [3, 205, 6, -37, 1763, -4257],
      [4, 15, 2, -38, 0, -4608]
    ].map(([pitch = 0, timelineId = 0, x = 0, y = 0, vx = 0, vy = 0]) => ({
      pitch,
      timelineId,
      muzzle: { x: pixels(x), y: pixels(y) },
      velocity: { x: vx, y: vy }
    }))
  };
  var shotgun = {
    ...sidearm,
    id: "shotgun",
    attackId: 10,
    cadenceTicks: 28,
    ammoPerAction: 1,
    pickupAmmo: 24,
    visualFamily: "fixture-shotgun",
    audioFamily: "fixture-shotgun"
  };
  var flame = {
    ...sidearm,
    id: "flamethrower",
    attackId: 11,
    cadenceTicks: 30,
    ammoPerAction: 1,
    pickupAmmo: 30,
    visualFamily: "fixture-flame",
    audioFamily: "fixture-flame"
  };
  var rocket = structuredClone(ROCKET_WEAPON);
  var laser = structuredClone(LASER_WEAPON);
  COMBAT_CONTENT.weapons.push(shotgun, flame, rocket, laser);
  COMBAT_CONTENT.attacks.push(
    structuredClone(ROCKET_ATTACK),
    structuredClone(LASER_ATTACK),
    {
      id: 10,
      kind: "shot-volume",
      shapeId: 13,
      damage: 4,
      lifetimeTicks: 6,
      speed: 0,
      maxTargets: 16,
      repeatDamageTicks: 0,
      material: "bullet"
    },
    {
      id: 11,
      kind: "flame-volumes",
      shapeId: 14,
      damage: 1,
      lifetimeTicks: 30,
      speed: 0,
      maxTargets: 16,
      repeatDamageTicks: 6,
      material: "heat"
    }
  );
  var AREA_PROFILES = /* @__PURE__ */ new Map([
    [
      10,
      {
        kind: "shot-volume",
        emissionOffsets: [0],
        attachedTicks: 0,
        maximumReach: pixels(110),
        frames: [20, 40, 60, 80, 100, 110].map((length, age) => ({
          x: 0,
          y: -pixels(3 + age * 2),
          w: pixels(length),
          h: pixels(6 + age * 4)
        }))
      }
    ],
    [
      11,
      {
        kind: "flame-volumes",
        emissionOffsets: [0, 6, 12],
        attachedTicks: 6,
        maximumReach: pixels(90),
        frames: Array.from({ length: 18 }, (_, age) => {
          const width = age < 6 ? [14, 18, 24, 28, 32, 36][age] ?? 0 : 36;
          const height = age < 6 ? 8 + Math.min(age, 3) * 2 : age < 14 ? 14 : 10;
          return {
            x: age < 6 ? 0 : (age - 5) * (pixels(4) + 128),
            y: pixels((age < 6 ? [-4, -2, 0, 2, 4, 2][age] ?? 0 : 2) - height / 2),
            w: pixels(width),
            h: pixels(height)
          };
        })
      }
    ]
  ]);
  var FOOT_ACTION_PROFILES = {
    melee: { timelineIds: [40, 41], cooldownTicks: 18 },
    grenade: { timelineIds: [50, 51], cooldownTicks: 20 }
  };
  var GRENADE_PROFILE = {
    bodyShapeId: 10,
    fuseTicks: 90,
    gravity: 55,
    terminalVelocity: 2048,
    maximumBounces: 3,
    radius: pixels(48),
    standingVelocity: { x: pixels(2) + 128, y: -pixels(4) - 128 },
    crouchedVelocity: { x: pixels(4), y: -pixels(1) - 128 },
    inheritedVelocityLimit: { x: pixels(8), y: pixels(8) }
  };
  COMBAT_CONTENT.attacks.push(
    {
      id: 4,
      kind: "melee",
      shapeId: 9,
      damage: 1,
      lifetimeTicks: 4,
      speed: 0,
      maxTargets: 4,
      repeatDamageTicks: 0,
      material: "blade"
    },
    {
      id: 5,
      kind: "explosion",
      shapeId: 11,
      damage: 1,
      lifetimeTicks: GRENADE_PROFILE.fuseTicks,
      speed: GRENADE_PROFILE.standingVelocity.x,
      maxTargets: 16,
      repeatDamageTicks: 0,
      material: "explosive"
    }
  );
  for (const kind of ["melee", "grenade"]) {
    const profile = FOOT_ACTION_PROFILES[kind];
    for (const [stance, id] of profile.timelineIds.entries()) {
      const durations = kind === "melee" ? [5, 4, 9] : [4, 1, 15];
      const poseIds = [id, id + 2, id + 4];
      for (const [phase, poseId] of poseIds.entries())
        COMBAT_CONTENT.poses.push({
          id: poseId,
          frame: `engineering-${kind}-${stance}-${phase}`,
          durationTicks: durations[phase] ?? 0,
          sockets: [
            {
              name: "hand",
              point: { x: pixels(10), y: pixels(stance === 1 ? -12 : kind === "melee" ? -20 : -24) }
            }
          ],
          hurtShapeIds: [stance === 1 ? 7 : 3]
        });
      COMBAT_CONTENT.timelines.push({
        id,
        durationTicks: profile.cooldownTicks,
        poses: poseIds,
        markers: [
          {
            tickOffset: durations[0] ?? 0,
            kind: kind === "melee" ? "activate-hitbox" : "spawn-attack",
            payloadId: kind === "melee" ? 4 : 5,
            socket: "hand"
          },
          {
            tickOffset: durations[0] ?? 0,
            kind: "sound",
            payloadId: kind === "melee" ? 4 : 5,
            socket: "hand"
          }
        ]
      });
    }
  }
  var RIFLE_PROFILE = {
    timelineIds: [30, 31],
    raiseTicks: 24,
    lastReleaseTick: 36,
    range: pixels(240),
    upAlignment: pixels(24),
    upHeight: pixels(48),
    aimHeight: pixels(16)
  };
  COMBAT_CONTENT.attacks.push({ ...attack, id: 3, speed: pixels(3), lifetimeTicks: 150 });
  for (const [aim, id] of RIFLE_PROFILE.timelineIds.entries()) {
    const muzzle = aim === 0 ? { x: pixels(15), y: pixels(-23) } : { x: pixels(2), y: pixels(-36) };
    const poseIds = [id, id + 2, id + 4];
    for (const [phase, poseId] of poseIds.entries())
      COMBAT_CONTENT.poses.push({
        id: poseId,
        frame: `engineering-rifle-${aim}-${phase}`,
        durationTicks: [24, 13, 35][phase] ?? 0,
        sockets: [
          { name: "muzzle", point: muzzle },
          { name: "hand", point: { x: 0, y: pixels(-23) } }
        ],
        hurtShapeIds: [3]
      });
    COMBAT_CONTENT.timelines.push({
      id,
      durationTicks: 72,
      poses: poseIds,
      markers: [24, 30, 36].flatMap((tickOffset) => [
        { tickOffset, kind: "spawn-attack", payloadId: 3, socket: "muzzle" },
        { tickOffset, kind: "sound", payloadId: 3, socket: "muzzle" }
      ])
    });
  }
  var SHIELD_PROFILE = {
    timelineIds: { brace: 100, advance: 101, turn: 102, bash: 103, stunned: 104 },
    integrity: 2,
    speed: pixels(1),
    sightRange: pixels(384),
    bashRange: pixels(29),
    bashHeight: pixels(24),
    bashActiveTick: 12,
    bashActiveTicks: 4,
    damageByMaterial: { bullet: 0, explosive: 2, heat: 1, energy: 1, blade: 0, blunt: 1 }
  };
  COMBAT_CONTENT.attacks.push({
    id: 6,
    kind: "melee",
    shapeId: 12,
    damage: 1,
    lifetimeTicks: 4,
    speed: 0,
    maxTargets: 4,
    repeatDamageTicks: 0,
    material: "blunt"
  });
  for (const [index, durationTicks] of [24, 36, 9, 9, 12, 4, 14, 36].entries())
    COMBAT_CONTENT.poses.push({
      id: 100 + index,
      frame: `engineering-shield-${index}`,
      durationTicks,
      sockets: [{ name: "hand", point: { x: 0, y: pixels(-18) } }],
      hurtShapeIds: [3]
    });
  COMBAT_CONTENT.timelines.push(
    { id: 100, durationTicks: 24, poses: [100], markers: [] },
    { id: 101, durationTicks: 36, poses: [101], markers: [] },
    {
      id: 102,
      durationTicks: 18,
      poses: [102, 103],
      markers: [
        { tickOffset: 9, kind: "face", payloadId: 1, socket: "hand" },
        { tickOffset: 9, kind: "sound", payloadId: 8, socket: "hand" }
      ]
    },
    {
      id: 103,
      durationTicks: 30,
      poses: [104, 105, 106],
      markers: [
        { tickOffset: 12, kind: "activate-hitbox", payloadId: 6, socket: "hand" },
        { tickOffset: 12, kind: "sound", payloadId: 6, socket: "hand" }
      ]
    },
    {
      id: 104,
      durationTicks: 36,
      poses: [107],
      markers: [{ tickOffset: 0, kind: "sound", payloadId: 7, socket: "hand" }]
    }
  );
  var profiles = [];
  for (const [index, weapon] of [sidearm, hmg, shotgun, flame, rocket, laser].entries()) {
    const base = weapon.id === "laser" ? LASER_WEAPON.timelineId : weapon.id === "rocket-launcher" ? ROCKET_WEAPON.timelineId : 10 + index * 4;
    const timelineIds = [base, base + 1, base + 2, base + 3];
    weapon.timelineId = base;
    const duration = weapon.id === "laser" ? LASER_WEAPON.cadenceTicks : weapon.id === "flamethrower" ? 30 : weapon.id === "shotgun" || weapon.id === "rocket-launcher" ? 12 : 4;
    const emissions = AREA_PROFILES.get(weapon.attackId)?.emissionOffsets ?? [0];
    for (const [poseIndex, id] of timelineIds.entries()) {
      const muzzle = (weapon.id === "heavy-machine-gun" && poseIndex !== 3 ? HMG_SWEEP.headings.find((heading) => heading.timelineId === id)?.muzzle : void 0) ?? [
        { x: pixels(15), y: pixels(-23) },
        { x: pixels(2), y: pixels(-36) },
        { x: pixels(2), y: 0 },
        { x: pixels(15), y: pixels(-12) }
      ][poseIndex];
      if (!muzzle) throw new Error("Missing firearm socket");
      COMBAT_CONTENT.poses.push({
        id,
        frame: `engineering-${weapon.id}-${poseIndex}`,
        durationTicks: duration,
        sockets: [
          { name: "muzzle", point: muzzle },
          { name: "hand", point: { x: 0, y: poseIndex === 3 ? pixels(-12) : pixels(-23) } }
        ],
        hurtShapeIds: [poseIndex === 3 ? 7 : 3]
      });
      COMBAT_CONTENT.timelines.push({
        id,
        durationTicks: duration,
        poses: [id],
        markers: [
          ...emissions.flatMap((tickOffset) => [
            {
              tickOffset,
              kind: "spawn-attack",
              payloadId: weapon.attackId,
              socket: "muzzle"
            },
            {
              tickOffset,
              kind: "sound",
              payloadId: weapon.attackId,
              socket: "muzzle"
            }
          ]),
          ...["flamethrower", "laser"].includes(weapon.id) ? [] : [
            {
              tickOffset: 2,
              kind: "sound",
              payloadId: weapon.attackId,
              socket: "hand"
            }
          ]
        ]
      });
    }
    profiles.push({
      weapon,
      timelineIds,
      ...weapon.id === "heavy-machine-gun" ? { sweep: HMG_SWEEP } : {}
    });
  }
  for (const heading of HMG_SWEEP.headings.filter((heading2) => heading2.timelineId >= 200)) {
    const reference = COMBAT_CONTENT.timelines.find((timeline) => timeline.id === 14);
    if (!reference) throw new Error("Missing HMG timing");
    COMBAT_CONTENT.poses.push({
      id: heading.timelineId,
      frame: `engineering-heavy-machine-gun-pitch-${heading.pitch}`,
      durationTicks: reference.durationTicks,
      sockets: [
        { name: "muzzle", point: heading.muzzle },
        { name: "hand", point: { x: 0, y: pixels(-23) } }
      ],
      hurtShapeIds: [3]
    });
    COMBAT_CONTENT.timelines.push({
      ...structuredClone(reference),
      id: heading.timelineId,
      poses: [heading.timelineId]
    });
  }
  var tankActor = {
    id: 2,
    locomotion: "grounded",
    standingShapeId: 15,
    crouchedShapeId: 15,
    idlePoseId: 130,
    runSpeed: pixels(3),
    jumpVelocity: -pixels(5),
    gravity: 64,
    terminalVelocity: pixels(8)
  };
  var tankDefinition = {
    id: 1,
    kind: "tank",
    actorId: 2,
    armor: 3,
    weaponId: "heavy-machine-gun",
    seat: {
      socket: { x: 0, y: -pixels(6) },
      ejectionCandidates: [
        { x: pixels(30), y: 0 },
        { x: -pixels(30), y: 0 },
        { x: 0, y: -pixels(38) }
      ],
      boardingSensorShapeId: 16,
      boardingTimelineId: 130
    }
  };
  var TANK_PROFILE = {
    cannon: CANNON_PROFILE,
    special: TANK_SPECIAL_PROFILE,
    definition: tankDefinition,
    locomotion: tankActor,
    exitTimelineId: 131,
    fireTimelineIds: Array.from({ length: 8 }, (_, i) => 140 + i),
    attackId: 16,
    fireCadenceTicks: 5,
    turnTicks: 3,
    damageProtectionTicks: 30,
    reboardTicks: 30,
    exitProtectionTicks: 12,
    disconnectGraceTicks: 15,
    fallBoundary: pixels(248),
    hardpoint: { x: 0, y: -pixels(24) },
    headings: [
      [26, -24, 20, 0],
      [20, -44, 14, -14],
      [0, -50, 0, -20],
      [-20, -44, -14, -14],
      [-26, -24, -20, 0],
      [-20, -4, -14, 14],
      [0, 2, 0, 20],
      [20, -4, 14, 14]
    ].map(([x = 0, y = 0, vx = 0, vy = 0]) => ({
      muzzle: { x: pixels(x), y: pixels(y) },
      velocity: { x: pixels(vx), y: pixels(vy) }
    }))
  };
  COMBAT_CONTENT.actors = COMBAT_CONTENT.actors.map((actor) => actor.id === 2 ? tankActor : actor);
  COMBAT_CONTENT.vehicles = [tankDefinition];
  COMBAT_CONTENT.shapes.push(
    { id: 15, rect: { x: -pixels(20), y: -pixels(24), w: pixels(40), h: pixels(24) } },
    { id: 16, rect: { x: -pixels(40), y: -pixels(40), w: pixels(80), h: pixels(40) } },
    structuredClone(CANNON_SHAPE),
    structuredClone(CANNON_BLAST_SHAPE),
    structuredClone(TANK_SPECIAL_SHAPE)
  );
  COMBAT_CONTENT.attacks.push(structuredClone(CANNON_ATTACK), structuredClone(TANK_SPECIAL_ATTACK));
  COMBAT_CONTENT.attacks.push({
    id: 16,
    kind: "swept-projectile",
    shapeId: 4,
    damage: 1,
    lifetimeTicks: 40,
    speed: pixels(20),
    maxTargets: 1,
    repeatDamageTicks: 0,
    material: "bullet"
  });
  for (const [id, duration] of [
    [130, 12],
    [131, 8]
  ]) {
    COMBAT_CONTENT.poses.push({
      id,
      frame: `engineering-tank-${id === 130 ? "board" : "exit"}`,
      durationTicks: duration,
      sockets: [
        { name: "seat", point: tankDefinition.seat.socket },
        { name: "ejection", point: { x: pixels(30), y: 0 } }
      ],
      hurtShapeIds: [15]
    });
    COMBAT_CONTENT.timelines.push({
      id,
      durationTicks: duration,
      poses: [id],
      markers: [
        {
          tickOffset: duration - 1,
          kind: "seat-transfer",
          payloadId: 1,
          socket: id === 130 ? "seat" : "ejection"
        }
      ]
    });
  }
  for (const [heading, exposure] of TANK_PROFILE.headings.entries()) {
    const id = 140 + heading;
    COMBAT_CONTENT.poses.push({
      id,
      frame: `engineering-tank-fire-${heading}`,
      durationTicks: 3,
      sockets: [{ name: "muzzle", point: exposure.muzzle }],
      hurtShapeIds: [15]
    });
    COMBAT_CONTENT.timelines.push({
      id,
      durationTicks: 3,
      poses: [id],
      markers: [
        { tickOffset: 0, kind: "spawn-attack", payloadId: 16, socket: "muzzle" },
        { tickOffset: 0, kind: "sound", payloadId: 16, socket: "muzzle" }
      ]
    });
  }
  for (const [heading, exposure] of CANNON_PROFILE.headings.entries()) {
    const id = CANNON_PROFILE.fireTimelineIds[heading];
    if (id === void 0) throw new Error("Missing cannon timeline");
    COMBAT_CONTENT.poses.push({
      id,
      frame: `engineering-tank-cannon-${heading}`,
      durationTicks: CANNON_PROFILE.recoil.length,
      sockets: [{ name: "muzzle", point: exposure.muzzle }],
      hurtShapeIds: [15]
    });
    COMBAT_CONTENT.timelines.push({
      id,
      durationTicks: CANNON_PROFILE.recoil.length,
      poses: [id],
      markers: [
        {
          tickOffset: CANNON_PROFILE.releaseTick,
          kind: "spawn-attack",
          payloadId: CANNON_ATTACK.id,
          socket: "muzzle"
        },
        {
          tickOffset: CANNON_PROFILE.releaseTick,
          kind: "sound",
          payloadId: CANNON_ATTACK.id,
          socket: "muzzle"
        }
      ]
    });
  }
  for (const platform of COMBAT_ORDNANCE)
    COMBAT_CONTENT.shapes.push({
      id: platform.shapeId,
      rect: { x: 0, y: 0, w: platform.w, h: platform.h }
    });
  validateContent(COMBAT_CONTENT);
  for (const [id, profile] of AREA_PROFILES) {
    const definition = COMBAT_CONTENT.attacks.find((attack2) => attack2.id === id);
    if (!definition) throw new Error("Missing area attack definition");
    validateAreaProfile(profile, definition);
  }
  var COMBAT_CATALOG = {
    firearms: new Map(profiles.map((profile) => [profile.weapon.id, profile])),
    timelines: new Map(COMBAT_CONTENT.timelines.map((timeline) => [timeline.id, timeline])),
    poses: new Map(COMBAT_CONTENT.poses.map((pose) => [pose.id, pose]))
  };
  var COMBAT_SHAPES = new Map(COMBAT_CONTENT.shapes.map((shape) => [shape.id, shape]));
  for (const profile of profiles) validateFirearmSweep(profile, COMBAT_CATALOG);
  validateTankProfile(TANK_PROFILE, COMBAT_SHAPES, COMBAT_CATALOG);
  var COMBAT_ATTACKS = new Map(
    COMBAT_CONTENT.attacks.map((definition) => [definition.id, definition])
  );

  // src/shared/animation/combat-audio.ts
  function combatAudioLoops(state, disconnected = /* @__PURE__ */ new Set()) {
    const loops = [];
    for (const tank of state.tanks) {
      if (tank.special.phase === "charging") {
        loops.push({
          id: `charge:${tank.body.id}:${tank.special.actionInstanceId}`,
          kind: "engine",
          x: tank.body.x / 256,
          rate: 1.6
        });
        continue;
      }
      const player = state.players.find((p) => p.playerId === tank.occupantId);
      if (tank.lifecycle !== "occupied" || tank.armor <= 0 || tank.disconnectedTicks > 0 || !player || player.life !== "alive" || player.controlEpoch !== tank.ownerControlEpoch || disconnected.has(player.playerId))
        continue;
      loops.push({
        id: `engine:${tank.body.id}:${tank.controlEpoch}:${player.controlEpoch}`,
        kind: "engine",
        x: tank.body.x / 256,
        rate: tank.special.phase === "arming" ? 1 + 0.6 * (state.tick - tank.special.startTick + 1) / TANK_PROFILE.special.armTicks : 0.85 + Math.min(0.45, Math.abs(tank.body.vx) / 256 * 0.13)
      });
    }
    for (const player of state.players) {
      if (player.life !== "alive" || player.bodyPresence !== "present" || player.vehicleId !== null || player.weapon.id !== "flamethrower" || disconnected.has(player.playerId))
        continue;
      const active = state.areas.some((area) => {
        const profile = AREA_PROFILES.get(area.definitionId);
        return area.ownerId === player.playerId && area.definitionId === 11 && area.cancelledTick === null && profile && area.lobes.some((lobe) => {
          const emitted = area.startTick + (profile.emissionOffsets[lobe.index] ?? -1e3);
          return state.tick >= emitted && state.tick < emitted + profile.attachedTicks;
        });
      });
      if (active)
        loops.push({
          id: `flame:${player.playerId}:${player.controlEpoch}`,
          kind: "flame",
          x: player.body.x / 256,
          rate: 1
        });
    }
    return loops;
  }

  // src/shared/animation/sfx-profile.ts
  var cue = (names, gain, priority, maximum, range = 768, cooldown = 0) => ({
    files: names.split(" ").map((name) => `sfx/${name}.ogg`),
    gain: [gain * 0.94, gain],
    rate: [0.985, 1.015],
    priority,
    maximum,
    cooldown,
    range,
    loop: false
  });
  var COMBAT_AUDIO = {
    sidearm: cue("sidearm-a sidearm-b", 0.43, 60, 8),
    hmg: cue("hmg-a hmg-b hmg-c", 0.31, 55, 12, 768, 2),
    rifle: cue("rifle-a rifle-b", 0.32, 50, 8),
    shotgun: cue("shotgun-a shotgun-b", 0.52, 65, 4),
    tank: cue("tank-a tank-b", 0.43, 60, 8),
    knife: cue("knife", 0.35, 50, 4, 384),
    bash: cue("bash", 0.48, 65, 4, 512),
    throw: cue("throw", 0.3, 50, 4, 384),
    "grenade-bounce": cue("grenade-bounce", 0.22, 25, 6, 384),
    explosion: cue("explosion-a explosion-b", 0.6, 75, 6),
    shield: cue("shield-a shield-b", 0.3, 30, 16),
    "shield-break": cue("shield-break", 0.45, 70, 4),
    "wood-break": cue("wood-break", 0.4, 45, 4),
    "impact-metal": cue("impact-metal-a impact-metal-b", 0.19, 20, 24),
    "impact-body": cue("impact-body", 0.24, 25, 16),
    "impact-stone": cue("impact-stone", 0.18, 20, 16),
    hurt: cue("hurt", 0.55, 100, 4),
    death: cue("death", 0.52, 100, 4),
    "enemy-death": cue("death", 0.35, 40, 8),
    entry: cue("entry", 0.3, 85, 4),
    step: cue("step-a step-b", 0.12, 10, 8, 320, 3),
    jump: cue("jump", 0.2, 20, 4, 384),
    land: cue("land", 0.32, 30, 4, 512),
    "tank-land": cue("tank-land", 0.43, 55, 4),
    "tank-hit": cue("tank-hit", 0.45, 95, 4),
    "tank-destroyed": cue("tank-destroyed", 0.55, 100, 4),
    board: cue("board", 0.45, 90, 4),
    exit: cue("exit", 0.4, 90, 4),
    eject: cue("eject", 0.48, 95, 4),
    pickup: cue("pickup", 0.32, 80, 4),
    checkpoint: cue("checkpoint", 0.3, 80, 1),
    victory: cue("victory", 0.35, 100, 1),
    defeat: cue("defeat", 0.35, 100, 1),
    "boss-warning": cue("boss-warning", 0.56, 110, 2, 1536),
    "boss-fire": cue("boss-fire", 0.44, 80, 4, 1536),
    "boss-hit": cue("boss-hit", 0.24, 35, 12),
    "boss-destroyed": cue("boss-destroyed", 0.58, 105, 1, 1536),
    "flame-ignite": cue("flame-ignite", 0.32, 60, 4),
    "flame-tail": cue("flame-tail", 0.23, 25, 4),
    "engine-start": cue("engine-start", 0.34, 65, 4),
    "engine-stop": cue("engine-stop", 0.28, 30, 4)
  };
  var COMBAT_LOOPS = {
    engine: { ...cue("engine-loop", 0.3, 15, 4, 512), rate: [1, 1], loop: true },
    flame: { ...cue("flame-loop", 0.3, 25, 4, 512), rate: [1, 1], loop: true }
  };
  var SFX_PROFILES = {
    ...COMBAT_AUDIO,
    ...COMBAT_LOOPS
  };
  var SFX_VOICES = 32;
  var SFX_LOOPS = 8;
  function weakest(a, b) {
    return SFX_PROFILES[a.kind].priority - SFX_PROFILES[b.kind].priority || a.level - b.level || a.started - b.started || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  }
  function admitSfx(voices, incoming) {
    if (incoming.level <= 0) return { accepted: false, reason: "inaudible" };
    const profile = SFX_PROFILES[incoming.kind], same = voices.filter((voice) => voice.kind === incoming.kind), loops = voices.filter((voice) => SFX_PROFILES[voice.kind].loop), candidates = same.length >= profile.maximum ? same : profile.loop && loops.length >= SFX_LOOPS ? loops : voices.length >= SFX_VOICES ? voices : [];
    if (!candidates.length) return { accepted: true, replace: null };
    const victim = [...candidates].sort(weakest)[0];
    if (!victim) throw new Error("Missing voice candidate");
    const priority = SFX_PROFILES[victim.kind].priority;
    if (profile.priority < priority || profile.priority === priority && (incoming.level < victim.level || profile.loop && incoming.level === victim.level))
      return { accepted: false, reason: "priority" };
    return { accepted: true, replace: victim.id };
  }
  function sfxSpatial(x, listener, range) {
    const distance = Math.abs(x - listener), attenuation = distance <= 96 ? 1 : Math.max(0, 1 - (distance - 96) / (range - 96));
    return {
      attenuation: attenuation * attenuation,
      pan: Math.max(-0.8, Math.min(0.8, (x - listener) / 240))
    };
  }
  function sfxVariation(id, profile) {
    let hash = 2166136261;
    for (const character of id) hash = Math.imul(hash ^ character.charCodeAt(0), 16777619) >>> 0;
    return {
      file: profile.files[hash % profile.files.length] ?? "",
      gain: profile.gain[0] + (profile.gain[1] - profile.gain[0]) * (hash >>> 8 & 255) / 255,
      rate: profile.rate[0] + (profile.rate[1] - profile.rate[0]) * (hash >>> 16 & 255) / 255
    };
  }

  // src/client/combat-mixer.ts
  var CombatMixer = class {
    constructor(context, output, buffers) {
      this.context = context;
      this.output = output;
      this.buffers = buffers;
    }
    context;
    output;
    buffers;
    voices = /* @__PURE__ */ new Map();
    retiring = /* @__PURE__ */ new Map();
    recent = /* @__PURE__ */ new Set();
    cooldowns = /* @__PURE__ */ new Map();
    cues = [];
    decisions = [];
    loopChanges = [];
    serial = 0;
    listenerX = 192;
    dropped = 0;
    criticalDropped = 0;
    stolen = 0;
    virtualized = 0;
    coalesced = 0;
    maxActiveVoices = 0;
    maxSourceNodes = 0;
    desiredLoops = [];
    setListenerX(x) {
      this.listenerX = x;
    }
    drop(id, kind, reason) {
      if (reason === "inaudible") this.virtualized++;
      else if (reason === "cooldown") this.coalesced++;
      else {
        this.dropped++;
        if (SFX_PROFILES[kind].priority >= 90) this.criticalDropped++;
      }
      this.decisions.push({ id, kind, reason });
      if (this.decisions.length > 64) this.decisions.shift();
    }
    release(voice) {
      voice.source.onended = null;
      voice.source.disconnect();
      voice.gain.disconnect();
      voice.pan.disconnect();
      this.voices.delete(voice.id);
      this.retiring.delete(voice.id);
    }
    prune() {
      for (const voice of [...this.voices.values(), ...this.retiring.values()])
        if (voice.end <= this.context.currentTime) this.release(voice);
    }
    change(voice, reason) {
      this.loopChanges.push({ ...voice, reason, time: this.context.currentTime });
      if (this.loopChanges.length > 128) this.loopChanges.shift();
    }
    finishLoop(voice, reason) {
      if (!voice.loopId) return;
      this.change({ id: voice.loopId, kind: voice.kind }, reason);
      voice.loopId = null;
      const now = this.context.currentTime;
      voice.gain.gain.cancelAndHoldAtTime(now);
      voice.gain.gain.linearRampToValueAtTime(0, now + 0.02);
      voice.end = now + 0.02;
      voice.source.stop(voice.end);
    }
    allocate(kind, identity, x, loop) {
      this.prune();
      const profile = SFX_PROFILES[kind], variation = sfxVariation(identity, profile), spatial = sfxSpatial(x, this.listenerX, profile.range), id = `voice:${++this.serial}`, intent = {
        id,
        kind,
        level: variation.gain * spatial.attenuation,
        started: this.context.currentTime
      }, decision = admitSfx([...this.voices.values()], intent);
      if (!decision.accepted) {
        if (!loop) this.drop(identity, kind, decision.reason);
        return null;
      }
      const buffer = this.buffers.get(variation.file);
      if (!buffer) {
        this.drop(identity, kind, "missing-buffer");
        return null;
      }
      let start = this.context.currentTime;
      if (decision.replace !== null) {
        const victim = this.voices.get(decision.replace);
        if (!victim) throw new Error("Missing allocated voice");
        const now = this.context.currentTime;
        if (victim.loopId)
          this.change({ id: victim.loopId, kind: victim.kind }, "virtualized-for-priority");
        if (victim.started > now) {
          start = victim.started;
          victim.source.stop(now);
          this.release(victim);
        } else {
          start = now + 5e-3;
          victim.gain.gain.cancelAndHoldAtTime(now);
          victim.gain.gain.linearRampToValueAtTime(0, start);
          victim.end = start;
          victim.source.stop(start);
          this.voices.delete(victim.id);
          this.retiring.set(victim.id, victim);
        }
        this.stolen++;
      }
      const source = this.context.createBufferSource(), gain = this.context.createGain(), pan = this.context.createStereoPanner();
      source.buffer = buffer;
      const speed = loop?.rate ?? variation.rate;
      source.playbackRate.value = speed;
      source.loop = profile.loop;
      source.loopStart = 0;
      source.loopEnd = buffer.duration;
      const end = loop ? Number.POSITIVE_INFINITY : start + buffer.duration / speed;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(intent.level, start + (loop ? 0.02 : 2e-3));
      if (!loop) {
        gain.gain.setValueAtTime(intent.level, end - Math.min(0.015, buffer.duration / speed / 4));
        gain.gain.linearRampToValueAtTime(0, end);
      }
      pan.pan.value = spatial.pan;
      source.connect(gain).connect(pan).connect(this.output);
      const voice = {
        ...intent,
        started: start,
        source,
        gain,
        pan,
        end,
        loopId: loop?.id ?? null,
        x,
        baseGain: variation.gain
      };
      this.voices.set(id, voice);
      source.onended = () => this.release(voice);
      source.start(start);
      if (!loop) source.stop(end);
      else this.change({ id: loop.id, kind }, "start");
      this.maxActiveVoices = Math.max(this.maxActiveVoices, this.voices.size);
      this.maxSourceNodes = Math.max(this.maxSourceNodes, this.voices.size + this.retiring.size);
      return voice;
    }
    play(cues, scope) {
      const played = /* @__PURE__ */ new Set();
      for (const cue2 of [...cues].sort(
        (a, b) => COMBAT_AUDIO[b.kind].priority - COMBAT_AUDIO[a.kind].priority
      )) {
        const key = `${scope}:${cue2.id}`;
        if (this.recent.has(key)) continue;
        this.recent.add(key);
        if (this.recent.size > 4096) this.recent.delete(this.recent.values().next().value ?? "");
        const profile = COMBAT_AUDIO[cue2.kind], cooldownKey = `${scope}:${cue2.emitter}:${cue2.kind}`;
        if (cue2.tick - (this.cooldowns.get(cooldownKey) ?? -1e4) < profile.cooldown) {
          this.drop(cue2.id, cue2.kind, "cooldown");
          continue;
        }
        this.cooldowns.set(cooldownKey, cue2.tick);
        if (this.cooldowns.size > 1024)
          this.cooldowns.delete(this.cooldowns.keys().next().value ?? "");
        if (this.allocate(cue2.kind, cue2.id, cue2.x, null)) played.add(cue2.id);
      }
      for (const cue2 of cues) if (played.delete(cue2.id)) this.cues.push(cue2);
      if (this.cues.length > 4096) this.cues.splice(0, this.cues.length - 4096);
    }
    syncLoops(loops) {
      this.prune();
      this.desiredLoops = loops;
      for (const voice of this.voices.values()) {
        if (!voice.loopId) continue;
        const desired = loops.find((loop) => loop.id === voice.loopId);
        if (!desired) {
          this.finishLoop(voice, "state-ended");
          continue;
        }
        const spatial = sfxSpatial(desired.x, this.listenerX, SFX_PROFILES[voice.kind].range);
        if (spatial.attenuation === 0) {
          this.finishLoop(voice, "inaudible");
          continue;
        }
        voice.x = desired.x;
        voice.level = voice.baseGain * spatial.attenuation;
        const now = Math.max(this.context.currentTime, voice.started);
        voice.gain.gain.cancelAndHoldAtTime(now);
        voice.gain.gain.linearRampToValueAtTime(voice.level, now + 0.02);
        voice.pan.pan.setTargetAtTime(spatial.pan, now, 0.01);
        voice.source.playbackRate.setTargetAtTime(desired.rate, now, 0.04);
      }
      const candidates = [...loops].sort(
        (a, b) => Math.abs(a.x - this.listenerX) - Math.abs(b.x - this.listenerX)
      );
      for (const loop of candidates)
        if (![...this.voices.values()].some((voice) => voice.loopId === loop.id))
          this.allocate(loop.kind, loop.id, loop.x, loop);
    }
    finishLoops() {
      this.desiredLoops = [];
      for (const voice of this.voices.values()) this.finishLoop(voice, "scene-finished");
    }
    hush() {
      this.desiredLoops = [];
      for (const voice of [...this.voices.values(), ...this.retiring.values()]) {
        if (voice.loopId) this.change({ id: voice.loopId, kind: voice.kind }, "hush");
        voice.source.stop();
        this.release(voice);
      }
    }
    reset() {
      this.hush();
      this.recent.clear();
      this.cooldowns.clear();
      this.cues.length = this.decisions.length = this.loopChanges.length = 0;
      this.dropped = this.criticalDropped = this.stolen = this.virtualized = this.coalesced = 0;
      this.maxActiveVoices = this.maxSourceNodes = 0;
    }
    inspect() {
      this.prune();
      const loops = [...this.voices.values()].filter((voice) => voice.loopId !== null), now = this.context.currentTime;
      return {
        activeVoices: this.voices.size,
        audibleVoices: [...this.voices.values(), ...this.retiring.values()].filter(
          (v) => v.started <= now && v.end > now
        ).length,
        maxActiveVoices: this.maxActiveVoices,
        sourceNodes: this.voices.size + this.retiring.size,
        maxSourceNodes: this.maxSourceNodes,
        voiceBudget: SFX_VOICES,
        loopBudget: SFX_LOOPS,
        loops: loops.map((voice) => ({
          id: voice.loopId,
          kind: voice.kind,
          level: voice.level,
          rate: voice.source.playbackRate.value,
          started: voice.started
        })),
        virtualLoops: this.desiredLoops.filter((loop) => !loops.some((voice) => voice.loopId === loop.id)).map((loop) => loop.id),
        loopChanges: [...this.loopChanges],
        dropped: this.dropped,
        criticalDropped: this.criticalDropped,
        stolen: this.stolen,
        virtualized: this.virtualized,
        coalesced: this.coalesced,
        droppedExamples: [...this.decisions],
        cues: [...this.cues]
      };
    }
  };

  // src/client/mission-music.ts
  var MissionMusic = class {
    constructor(context, output = context.destination) {
      this.context = context;
      this.bus = context.createGain();
      this.bus.gain.value = 0.35;
      this.bus.connect(output);
    }
    context;
    bus;
    buffers = /* @__PURE__ */ new Map();
    voices = /* @__PURE__ */ new Set();
    abort = new AbortController();
    loading;
    enabled = false;
    playing = false;
    disposed = false;
    phase = "breakwater-quay";
    origin = 0;
    offset = 0;
    beat = 60 / 144;
    transitions = [];
    async setEnabled(enabled) {
      this.enabled = enabled;
      if (!enabled) {
        this.stopVoices();
        return;
      }
      if (!this.buffers.size && !this.loading) {
        this.loading = this.load().finally(() => {
          this.loading = void 0;
        });
      }
      await this.loading;
      if (this.enabled && this.playing && !this.voices.size && !this.disposed)
        this.schedule(this.context.currentTime);
    }
    async load() {
      const request = async (path) => {
        const response = await fetch(path, { signal: this.abort.signal });
        if (!response.ok) throw new Error(`Missing mission music ${path}`);
        return response;
      };
      const metadata = await (await request("/assets/audio/breakwater-music.json")).json();
      if (metadata.tracks.length !== 2) throw new Error("Invalid mission arrangements");
      const loaded = await Promise.all(
        metadata.tracks.map(async (track) => {
          if (!["breakwater-quay", "lock-engine"].includes(track.id) || track.seconds > 30 || track.seconds < 20)
            throw new Error("Invalid mission loop");
          const buffer = await this.context.decodeAudioData(
            await (await request(`/${track.file}`)).arrayBuffer()
          );
          if (Math.abs(buffer.duration - track.seconds) > 1 / buffer.sampleRate)
            throw new Error("Music decode changed the loop duration");
          return { buffer, track };
        })
      );
      if (loaded.reduce((sum, item) => sum + item.buffer.length * item.buffer.numberOfChannels * 4, 0) > 24 * 1024 * 1024)
        throw new Error("Music decode budget exceeded");
      if (!this.disposed) for (const item of loaded) this.buffers.set(item.track.id, item);
    }
    setVolume(value) {
      if (!Number.isFinite(value) || value < 0 || value > 1) throw new Error("Invalid music volume");
      this.bus.gain.setTargetAtTime(value, this.context.currentTime, 0.015);
    }
    setPhase(phase) {
      if (phase === this.phase) return;
      this.phase = phase;
      if (!this.playing || !this.enabled || this.buffers.size !== 2) return;
      const now = this.context.currentTime, bar = this.beat * 4;
      const when = this.origin + Math.ceil((now - this.origin + 0.03) / bar) * bar;
      for (const voice of [...this.voices]) {
        if (voice.start > now || voice.end !== null) this.release(voice, true);
        else {
          voice.gain.gain.cancelScheduledValues(now);
          voice.gain.gain.setValueAtTime(1, when);
          voice.gain.gain.linearRampToValueAtTime(0, when + this.beat);
          voice.end = when + this.beat;
          voice.source.stop(voice.end);
        }
      }
      this.schedule(when, this.beat);
    }
    play() {
      if (this.playing || this.disposed) return;
      this.playing = true;
      this.origin = this.context.currentTime - this.offset;
      if (this.enabled && this.buffers.size === 2) this.schedule(this.context.currentTime);
    }
    pause() {
      if (this.playing) this.offset = this.context.currentTime - this.origin;
      this.playing = false;
      this.stopVoices();
    }
    finish() {
      if (this.playing) this.offset = this.context.currentTime - this.origin;
      this.playing = false;
      const now = this.context.currentTime;
      for (const voice of [...this.voices]) {
        if (voice.start > now) this.release(voice, true);
        else {
          voice.gain.gain.cancelAndHoldAtTime(now);
          voice.gain.gain.linearRampToValueAtTime(0, now + 0.6);
          voice.end = now + 0.6;
          voice.source.stop(voice.end);
        }
      }
    }
    reset() {
      this.pause();
      this.phase = "breakwater-quay";
      this.offset = 0;
      this.transitions.length = 0;
    }
    schedule(when, fade = 0.02) {
      const item = this.buffers.get(this.phase);
      if (!item) return;
      const source = this.context.createBufferSource(), gain = this.context.createGain(), offset = ((when - this.origin) % item.track.seconds + item.track.seconds) % item.track.seconds;
      source.buffer = item.buffer;
      source.loop = true;
      source.loopStart = item.track.loopStart;
      source.loopEnd = item.track.loopEnd;
      gain.gain.setValueAtTime(0, when);
      gain.gain.linearRampToValueAtTime(1, when + fade);
      source.connect(gain).connect(this.bus);
      const voice = { source, gain, phase: this.phase, start: when, end: null };
      this.voices.add(voice);
      source.onended = () => this.release(voice);
      source.start(when, offset);
      this.transitions.push({ phase: this.phase, when, offset });
      if (this.transitions.length > 128) this.transitions.shift();
    }
    release(voice, stop = false) {
      if (!this.voices.delete(voice)) return;
      voice.source.onended = null;
      if (stop) voice.source.stop();
      voice.source.disconnect();
      voice.gain.disconnect();
    }
    stopVoices() {
      for (const voice of [...this.voices]) this.release(voice, true);
    }
    dispose() {
      this.disposed = true;
      this.abort.abort();
      this.pause();
      this.bus.disconnect();
      this.buffers.clear();
    }
    inspect() {
      return {
        ready: this.buffers.size === 2,
        enabled: this.enabled,
        playing: this.playing,
        phase: this.phase,
        voices: this.voices.size,
        seconds: this.playing ? this.context.currentTime - this.origin : this.offset,
        decodedBytes: [...this.buffers.values()].reduce(
          (sum, item) => sum + item.buffer.length * item.buffer.numberOfChannels * 4,
          0
        ),
        transitions: [...this.transitions]
      };
    }
  };

  // src/client/scene-audio-output.ts
  var SceneAudioOutput = class {
    input;
    ceiling;
    constructor(context) {
      this.input = context.createGain();
      this.input.gain.value = 0.25;
      this.ceiling = context.createWaveShaper();
      const curve = new Float32Array(16385);
      for (let i = 0; i < curve.length; i++) {
        const sample = (i / (curve.length - 1) * 2 - 1) * 4, magnitude = Math.abs(sample);
        curve[i] = magnitude <= 0.7 ? sample : Math.sign(sample) * (0.7 + 0.15 * (1 - Math.exp(-(magnitude - 0.7) / 0.15)));
      }
      this.ceiling.curve = curve;
      this.ceiling.oversample = "4x";
      this.input.connect(this.ceiling);
      this.ceiling.connect(context.destination);
    }
    connect(destination) {
      this.ceiling.connect(destination);
    }
    disconnect(destination) {
      this.ceiling.disconnect(destination);
    }
    dispose() {
      this.input.disconnect();
      this.ceiling.disconnect();
    }
  };

  // src/client/cast-audio.ts
  var CastAudio = class {
    context;
    music;
    output;
    musicEnabled = false;
    musicVolume = 0.35;
    gain;
    capture;
    recorder;
    captureChunks = [];
    rejectCapture;
    loading;
    buffers = /* @__PURE__ */ new Map();
    mixer;
    latest;
    playing = false;
    epoch = 0;
    disposed = false;
    abort = new AbortController();
    enabled = false;
    ready = false;
    volume = 0.4;
    lastTick = -1;
    listenerX = 192;
    lastAudioTime = -1;
    stalledAudioTicks = 0;
    maxStalledAudioTicks = 0;
    setListenerX(x) {
      if (!Number.isFinite(x)) throw new Error("Invalid audio listener position");
      this.listenerX = x;
      this.mixer?.setListenerX(x);
    }
    async setEnabled(enabled) {
      if (this.disposed) throw new Error("Audio scene is disposed");
      this.enabled = enabled;
      if (!enabled) {
        this.hush();
        await this.music?.setEnabled(false);
        return;
      }
      if (!this.context) {
        this.context = new AudioContext({ sampleRate: 48e3 });
        this.output = new SceneAudioOutput(this.context);
        this.music = new MissionMusic(this.context, this.output.input);
        this.music.setVolume(this.musicVolume);
        this.gain = this.context.createGain();
        this.gain.gain.value = this.volume;
        this.gain.connect(this.output.input);
        this.mixer = new CombatMixer(this.context, this.gain, this.buffers);
        this.mixer.setListenerX(this.listenerX);
      }
      if (!this.ready && !this.loading) {
        const context = this.context;
        this.loading = Promise.all(
          [...new Set(Object.values(SFX_PROFILES).flatMap((cue2) => cue2.files))].map(async (file) => {
            const response = await fetch(`/assets/audio/${file}`, { signal: this.abort.signal });
            if (!response.ok) throw new Error(`Missing audio sample ${file}`);
            const buffer = await context.decodeAudioData(await response.arrayBuffer());
            if (!this.disposed) this.buffers.set(file, buffer);
          })
        ).then(() => {
          this.ready = !this.disposed;
        }).finally(() => {
          this.loading = void 0;
        });
      }
      await this.context.resume();
      await this.loading;
      if (this.disposed) return;
      if (this.enabled && this.playing && this.latest)
        this.mixer?.syncLoops(combatAudioLoops(this.latest));
      await this.music?.setEnabled(this.musicEnabled && this.enabled);
    }
    async setMusicEnabled(enabled) {
      this.musicEnabled = enabled;
      await this.music?.setEnabled(enabled && this.enabled);
    }
    setMusicVolume(value) {
      if (!Number.isFinite(value) || value < 0 || value > 1) throw new Error("Invalid music volume");
      this.musicVolume = value;
      this.music?.setVolume(value);
    }
    playMusic() {
      if (this.enabled) this.music?.play();
    }
    setMusicPhase(boss) {
      this.music?.setPhase(boss ? "lock-engine" : "breakwater-quay");
    }
    finish() {
      this.playing = false;
      this.mixer?.finishLoops();
      this.music?.finish();
    }
    resume(state) {
      this.playing = true;
      this.latest = state;
      if (this.enabled && this.ready && this.context?.state === "running")
        this.mixer?.syncLoops(combatAudioLoops(state));
    }
    setVolume(value) {
      if (!Number.isFinite(value) || value < 0 || value > 1) throw new Error("Invalid audio volume");
      this.volume = value;
      if (this.gain) this.gain.gain.value = value;
    }
    hush() {
      this.playing = false;
      this.music?.pause();
      this.mixer?.hush();
    }
    reset() {
      this.hush();
      this.music?.reset();
      this.mixer?.reset();
      this.latest = void 0;
      this.epoch++;
      this.lastTick = -1;
      this.lastAudioTime = -1;
      this.stalledAudioTicks = this.maxStalledAudioTicks = 0;
    }
    consume(next, cues, continuous = false) {
      if (next.tick <= this.lastTick) return;
      this.lastTick = next.tick;
      this.latest = next;
      this.playing = continuous;
      if (!this.enabled || !this.ready || this.context?.state !== "running") return;
      const audioTime = this.context.currentTime;
      this.stalledAudioTicks = audioTime === this.lastAudioTime ? this.stalledAudioTicks + 1 : 0;
      this.lastAudioTime = audioTime;
      this.maxStalledAudioTicks = Math.max(this.maxStalledAudioTicks, this.stalledAudioTicks);
      this.mixer?.play(cues, this.epoch);
      this.mixer?.syncLoops(continuous ? combatAudioLoops(next) : []);
    }
    startCapture(video) {
      if (!this.enabled || !this.inspect().ready || this.context?.state !== "running" || !this.gain || this.recorder)
        throw new Error("Enable audio before starting a new capture");
      this.capture = this.context.createMediaStreamDestination();
      this.output?.connect(this.capture);
      const stream = video ? new MediaStream([...video.getVideoTracks(), ...this.capture.stream.getAudioTracks()]) : this.capture.stream;
      this.recorder = new MediaRecorder(stream, {
        mimeType: video ? "video/webm;codecs=vp9,opus" : "audio/webm;codecs=opus"
      });
      this.captureChunks = [];
      this.recorder.ondataavailable = (event) => {
        if (event.data.size) this.captureChunks.push(event.data);
      };
      this.recorder.start(1e3);
    }
    stopCapture() {
      const recorder = this.recorder;
      if (recorder?.state !== "recording") throw new Error("No active audio capture");
      return new Promise((resolve, reject) => {
        this.rejectCapture = reject;
        recorder.onerror = () => {
          this.rejectCapture = void 0;
          reject(new Error("Audio capture failed"));
        };
        recorder.onstop = () => {
          this.rejectCapture = void 0;
          for (const track of recorder.stream.getVideoTracks()) track.stop();
          if (this.capture) {
            this.output?.disconnect(this.capture);
            for (const track of this.capture.stream.getTracks()) track.stop();
            this.capture = void 0;
          }
          this.recorder = void 0;
          const blob = new Blob(this.captureChunks, { type: recorder.mimeType });
          this.captureChunks = [];
          resolve(blob);
        };
        recorder.stop();
      });
    }
    inspect() {
      return {
        enabled: this.enabled,
        ready: this.ready && (!this.musicEnabled || this.music?.inspect().ready === true),
        state: this.context?.state ?? "locked",
        contextSeconds: this.context?.currentTime ?? 0,
        decodedSamples: this.buffers.size,
        decodedBytes: [...this.buffers.values()].reduce(
          (sum, buffer) => sum + buffer.length * buffer.numberOfChannels * 4,
          0
        ),
        music: this.music?.inspect() ?? null,
        output: { linearThrough: 0.7, softCeiling: 0.85, oversample: "4x" },
        ...this.mixer?.inspect() ?? {
          activeVoices: 0,
          audibleVoices: 0,
          maxActiveVoices: 0,
          sourceNodes: 0,
          maxSourceNodes: 0,
          voiceBudget: SFX_VOICES,
          loopBudget: SFX_LOOPS,
          loops: [],
          virtualLoops: [],
          loopChanges: [],
          dropped: 0,
          criticalDropped: 0,
          stolen: 0,
          virtualized: 0,
          coalesced: 0,
          droppedExamples: [],
          cues: []
        },
        maxStalledAudioTicks: this.maxStalledAudioTicks
      };
    }
    dispose() {
      if (this.disposed) return;
      this.disposed = true;
      this.enabled = this.ready = false;
      this.abort.abort();
      this.rejectCapture?.(new Error("Audio scene disposed during capture"));
      this.rejectCapture = void 0;
      if (this.recorder) {
        this.recorder.ondataavailable = this.recorder.onstop = this.recorder.onerror = null;
        if (this.recorder.state === "recording") this.recorder.stop();
        for (const track of this.recorder.stream.getTracks()) track.stop();
        this.recorder = void 0;
        this.captureChunks = [];
      }
      if (this.capture) {
        this.output?.disconnect(this.capture);
        for (const track of this.capture.stream.getTracks()) track.stop();
        this.capture = void 0;
      }
      this.hush();
      this.music?.dispose();
      this.buffers.clear();
      this.gain?.disconnect();
      this.output?.dispose();
      void this.context?.close();
    }
  };

  // <stdin>
  var audio = new CastAudio();
  globalThis.audioProof = {
    audio: () => audio,
    recreate: () => {
      audio.dispose();
      audio = new CastAudio();
    },
    async stress(loops) {
      const context = new AudioContext({ sampleRate: 48e3 });
      await context.resume();
      const scene = new SceneAudioOutput(context), output = context.createGain();
      output.gain.value = 1;
      output.connect(scene.input);
      const music = new MissionMusic(context, scene.input);
      music.setVolume(1);
      await music.setEnabled(true);
      const buffers = /* @__PURE__ */ new Map();
      for (const file of new Set(Object.values(SFX_PROFILES).flatMap((p) => p.files)))
        buffers.set(file, await context.decodeAudioData(await (await fetch("/assets/audio/" + file)).arrayBuffer()));
      const mixer = new CombatMixer(context, output, buffers), capture = context.createMediaStreamDestination();
      scene.connect(capture);
      const recorder = new MediaRecorder(capture.stream, { mimeType: "audio/webm;codecs=opus" }), chunks = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size) chunks.push(e.data);
      };
      recorder.start();
      music.play();
      mixer.syncLoops(loops);
      const initial = mixer.inspect();
      const shots = Array.from({ length: 36 }, (_, i) => ({ id: "stress:" + i, kind: i < 12 ? "hmg" : i < 20 ? "sidearm" : "impact-metal", tick: 1, x: 192, emitter: "actor:" + i }));
      mixer.play(shots, 1);
      mixer.play([{ id: "critical", kind: "boss-warning", tick: 1, x: 192, emitter: "boss" }], 1);
      const admitted = mixer.inspect();
      let maxAudible = 0;
      for (let i = 0; i < 20; i++) {
        await new Promise((r) => setTimeout(r, 5));
        maxAudible = Math.max(maxAudible, mixer.inspect().audibleVoices);
      }
      await new Promise((r) => setTimeout(r, 550));
      mixer.syncLoops(loops);
      const restored = mixer.inspect();
      mixer.hush();
      await new Promise((r) => setTimeout(r, 60));
      const bytes = await new Promise((resolve) => {
        recorder.onstop = async () => resolve([...new Uint8Array(await new Blob(chunks).arrayBuffer())]);
        recorder.stop();
      });
      for (const track of capture.stream.getTracks()) track.stop();
      music.dispose();
      scene.dispose();
      await context.close();
      return { sfxVolume: 1, musicVolume: 1, initial, admitted, restored, maxAudible, bytes, closed: context.state };
    },
    async comparison() {
      audio.reset();
      audio.startCapture();
      const rows = [];
      let tick = 1;
      for (const kind of ["sidearm", "hmg", "rifle", "shotgun", "tank", "boss-fire", "boss-warning", "knife", "throw", "grenade-bounce", "explosion", "shield", "shield-break", "wood-break", "board", "exit", "eject", "tank-hit", "tank-land", "tank-destroyed", "boss-destroyed", "pickup", "entry"]) {
        rows.push({ kind, time: performance.now(), audioTime: audio.inspect().contextSeconds });
        for (let i = 0; i < (kind === "hmg" ? 6 : 1); i++) {
          const state = { tick, players: [], tanks: [], areas: [] };
          audio.consume(state, [{ id: "comparison:" + tick, kind, tick, x: 192, emitter: "comparison" }]);
          tick += kind === "hmg" ? 6 : 66;
          if (kind === "hmg") await new Promise((r) => setTimeout(r, 100));
        }
        await new Promise((r) => setTimeout(r, 1100));
      }
      const inspect = audio.inspect(), blob = await audio.stopCapture();
      audio.hush();
      return { rows, inspect, bytes: [...new Uint8Array(await blob.arrayBuffer())] };
    }
  };
  document.querySelector("button").onclick = () => audio.setEnabled(true);
})();
