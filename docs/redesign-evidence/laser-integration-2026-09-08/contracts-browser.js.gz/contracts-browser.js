"use strict";
var EdgefallContractProof = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // test/fixtures/contract-proof.ts
  var contract_proof_exports = {};
  __export(contract_proof_exports, {
    contractProof: () => contractProof
  });

  // src/game/core/canonical.ts
  function canonical(value) {
    const ancestors = /* @__PURE__ */ new Set();
    let nodes = 0;
    function encode(item, depth) {
      if (++nodes > 1e5 || depth > 64) throw new RangeError("Canonical state exceeds bounds");
      if (item === null || typeof item === "boolean" || typeof item === "string")
        return JSON.stringify(item);
      if (typeof item === "number" && Number.isSafeInteger(item))
        return String(item === 0 ? 0 : item);
      if (typeof item !== "object" || item === null)
        throw new TypeError("Noncanonical authoritative value");
      if (ancestors.has(item)) throw new TypeError("Cyclic authoritative state");
      ancestors.add(item);
      let result;
      if (Array.isArray(item)) {
        const parts = [];
        for (let index = 0; index < item.length; index++) {
          if (!Object.hasOwn(item, index)) throw new TypeError("Sparse authoritative array");
          parts.push(encode(item[index], depth + 1));
        }
        result = `[${parts.join(",")}]`;
      } else {
        if (Object.getPrototypeOf(item) !== Object.prototype && Object.getPrototypeOf(item) !== null) {
          throw new TypeError("Authoritative records must be plain objects");
        }
        if (Object.getOwnPropertySymbols(item).length)
          throw new TypeError("Symbol state keys are unsupported");
        const record2 = item;
        result = `{${Object.keys(record2).sort().map((key) => `${JSON.stringify(key)}:${encode(record2[key], depth + 1)}`).join(",")}}`;
      }
      ancestors.delete(item);
      return result;
    }
    return encode(value, 0);
  }
  function stateHash(value) {
    const text = canonical(value);
    let hash = 2166136261;
    for (let index = 0; index < text.length; index++)
      hash = Math.imul(hash ^ text.charCodeAt(index), 16777619);
    return (hash >>> 0).toString(16).padStart(8, "0");
  }

  // src/game/input/types.ts
  var Held = {
    Left: 1 << 0,
    Right: 1 << 1,
    Up: 1 << 2,
    Down: 1 << 3,
    Fire: 1 << 4,
    VehicleSpecial: 1 << 5
  };
  var HELD_MASK = 63;
  var EDGE_KINDS = [1, 2, 3, 4, 5];
  var Edge = { Jump: 1, Grenade: 2, Interact: 3, VehicleSpecial: 4, FireOnset: 5 };
  function directionalIntent(held, facing2, grounded) {
    const horizontal = Number(Boolean(held & Held.Right)) - Number(Boolean(held & Held.Left));
    const vertical = Number(Boolean(held & Held.Down)) - Number(Boolean(held & Held.Up));
    const nextFacing = horizontal === 0 ? facing2 : horizontal < 0 ? -1 : 1;
    return {
      horizontal,
      vertical,
      facing: nextFacing,
      crouch: grounded && vertical > 0,
      aim: vertical < 0 ? 1 : vertical > 0 && !grounded ? 2 : 0
    };
  }

  // src/game/core/numeric.ts
  var SUBPIXELS = 256;
  var MAX_POSITION = 2 ** 24;
  var MAX_SHAPE = 2 ** 16;
  var MAX_MOTION = 2 ** 16;
  var COUNTER_LIMIT = 4294963200;
  function integer(value, minimum, maximum, label) {
    if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
      throw new RangeError(`${label} must be an integer in [${minimum}, ${maximum}]`);
    }
    return value;
  }
  function position(value) {
    return integer(value, -MAX_POSITION, MAX_POSITION, "position");
  }
  function motion(value) {
    return integer(value, -MAX_MOTION, MAX_MOTION, "motion");
  }
  function pixels(value) {
    return position(
      integer(value, -MAX_POSITION / SUBPIXELS, MAX_POSITION / SUBPIXELS, "pixels") * SUBPIXELS
    );
  }
  function divide(numerator, denominator) {
    integer(numerator, -Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER, "numerator");
    integer(denominator, 1, Number.MAX_SAFE_INTEGER, "denominator");
    const quotient = Math.trunc(numerator / denominator) || 0;
    return { quotient, remainder: numerator - quotient * denominator };
  }
  function compareContactTime(an, ad, bn, bd) {
    for (const n of [an, bn]) integer(n, -(2 ** 26), 2 ** 26, "contact numerator");
    for (const d of [ad, bd]) integer(d, 1, 2 ** 17, "contact denominator");
    const left = an * bd;
    const right = bn * ad;
    return left < right ? -1 : left > right ? 1 : 0;
  }
  function nextCounter(current) {
    integer(current, 0, COUNTER_LIMIT - 2, "counter requiring session rotation");
    return current + 1;
  }
  function randomStep(state) {
    integer(state, 1, 4294967295, "nonzero random state");
    let next = state ^ state << 13;
    next ^= next >>> 17;
    next ^= next << 5;
    return next >>> 0;
  }

  // src/shared/protocol/limits.ts
  var PROTOCOL_MAJOR = 3;
  var PROTOCOL_MINOR = 12;
  var MAGIC = 17989;
  var INPUT_TYPE = 1;
  var INPUT_HEADER_BYTES = 32;
  var COMMAND_BYTES = 20;
  var EDGE_BYTES = 8;
  var MAX_COMMANDS = 3;
  var MAX_EDGES_PER_COMMAND = 8;
  var MAX_INPUT_BYTES = 284;
  var ACK_BYTES = 40;
  var MAX_QUEUED_COMMANDS = 120;
  var MAX_PREDICTION_TICKS = 180;
  var MAX_EDGE_ADVANCE = 256;
  var MAX_CLIENT_LEAD_TICKS = 6;
  var INPUT_STALE_TICKS = 15;
  var INPUT_STALE_MS = 250;

  // src/shared/protocol/schema.ts
  var ProtocolError = class extends Error {
    constructor(code, message) {
      super(message);
      this.code = code;
      this.name = "ProtocolError";
    }
    code;
  };

  // src/shared/protocol/codec.ts
  function requireValid(condition, message) {
    if (!condition) throw new ProtocolError("malformed", message);
  }
  function bounded(value, min, max, field) {
    requireValid(Number.isSafeInteger(value) && value >= min && value <= max, `Invalid ${field}`);
  }
  function counter(value, field, allowZero = false) {
    bounded(value, allowZero ? 0 : 1, COUNTER_LIMIT - 1, field);
  }
  function validateInputBatch(batch) {
    counter(batch.runEpoch, "runEpoch");
    counter(batch.connectionEpoch, "connectionEpoch");
    counter(batch.packetSequence, "packetSequence");
    counter(batch.snapshotAck, "snapshotAck", true);
    counter(batch.eventAck, "eventAck", true);
    requireValid(
      Array.isArray(batch.commands) && batch.commands.length <= MAX_COMMANDS,
      "Invalid command count"
    );
    let previous;
    const edgeHighWater = /* @__PURE__ */ new Map();
    for (const command2 of batch.commands) {
      counter(command2.sequence, "sequence");
      counter(command2.clientTick, "clientTick", true);
      counter(command2.controlEpoch, "controlEpoch");
      bounded(command2.held, 0, HELD_MASK, "held bits");
      bounded(command2.aim, 0, 2, "aim");
      requireValid(
        Array.isArray(command2.edges) && command2.edges.length <= MAX_EDGES_PER_COMMAND,
        "Invalid edge count"
      );
      if (previous) {
        requireValid(command2.sequence === previous.sequence + 1, "Noncontiguous command sequence");
        requireValid(command2.clientTick === previous.clientTick + 1, "Noncontiguous client tick");
      }
      previous = command2;
      for (const edge of command2.edges) {
        bounded(edge.kind, 1, 5, "edge kind");
        counter(edge.id, "edge ID");
        const before = edgeHighWater.get(edge.kind);
        if (before !== void 0)
          requireValid(
            edge.id > before && edge.id - before <= MAX_EDGE_ADVANCE,
            "Nonmonotonic edge ID"
          );
        edgeHighWater.set(edge.kind, edge.id);
      }
    }
  }
  function encodeInputBatch(batch) {
    validateInputBatch(batch);
    const length2 = INPUT_HEADER_BYTES + batch.commands.reduce(
      (size, command2) => size + COMMAND_BYTES + EDGE_BYTES * command2.edges.length,
      0
    );
    const bytes = new Uint8Array(length2);
    const view = new DataView(bytes.buffer);
    view.setUint16(0, MAGIC, true);
    view.setUint8(2, PROTOCOL_MAJOR);
    view.setUint8(3, PROTOCOL_MINOR);
    view.setUint8(4, INPUT_TYPE);
    view.setUint16(6, length2, true);
    [
      batch.runEpoch,
      batch.connectionEpoch,
      batch.packetSequence,
      batch.snapshotAck,
      batch.eventAck
    ].forEach((value, index) => {
      view.setUint32(8 + index * 4, value, true);
    });
    view.setUint8(28, batch.commands.length);
    let offset = INPUT_HEADER_BYTES;
    for (const command2 of batch.commands) {
      view.setUint32(offset, command2.sequence, true);
      view.setUint32(offset + 4, command2.clientTick, true);
      view.setUint32(offset + 8, command2.controlEpoch, true);
      view.setUint16(offset + 12, command2.held, true);
      view.setUint8(offset + 14, command2.aim);
      view.setUint8(offset + 15, command2.edges.length);
      offset += COMMAND_BYTES;
      for (const edge of command2.edges) {
        view.setUint8(offset, edge.kind);
        view.setUint32(offset + 4, edge.id, true);
        offset += EDGE_BYTES;
      }
    }
    return bytes;
  }
  function decodeInputBatch(bytes, expected) {
    requireValid(
      bytes.byteLength >= INPUT_HEADER_BYTES && bytes.byteLength <= MAX_INPUT_BYTES,
      "Input frame size"
    );
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    requireValid(
      view.getUint16(0, true) === MAGIC && view.getUint8(2) === PROTOCOL_MAJOR && view.getUint8(3) === PROTOCOL_MINOR && view.getUint8(4) === INPUT_TYPE,
      "Unsupported frame header"
    );
    requireValid(
      view.getUint8(5) === 0 && view.getUint16(6, true) === bytes.byteLength,
      "Invalid flags/length"
    );
    requireValid(view.getUint8(29) === 0 && view.getUint16(30, true) === 0, "Reserved header bits");
    const count = view.getUint8(28);
    requireValid(count <= MAX_COMMANDS, "Command count");
    const batch = {
      runEpoch: view.getUint32(8, true),
      connectionEpoch: view.getUint32(12, true),
      packetSequence: view.getUint32(16, true),
      snapshotAck: view.getUint32(20, true),
      eventAck: view.getUint32(24, true),
      commands: []
    };
    if (batch.runEpoch !== expected.runEpoch || batch.connectionEpoch !== expected.connectionEpoch)
      throw new ProtocolError("identity-mismatch", "Input belongs to another run/socket epoch");
    let offset = INPUT_HEADER_BYTES;
    for (let index = 0; index < count; index++) {
      requireValid(offset + COMMAND_BYTES <= bytes.byteLength, "Truncated command");
      const edgeCount = view.getUint8(offset + 15);
      requireValid(
        edgeCount <= MAX_EDGES_PER_COMMAND && view.getUint32(offset + 16, true) === 0,
        "Edge count/reserved command bits"
      );
      const command2 = {
        sequence: view.getUint32(offset, true),
        clientTick: view.getUint32(offset + 4, true),
        controlEpoch: view.getUint32(offset + 8, true),
        held: view.getUint16(offset + 12, true),
        aim: view.getUint8(offset + 14),
        edges: []
      };
      offset += COMMAND_BYTES;
      requireValid(offset + edgeCount * EDGE_BYTES <= bytes.byteLength, "Truncated edges");
      for (let edgeIndex = 0; edgeIndex < edgeCount; edgeIndex++) {
        requireValid(
          view.getUint8(offset + 1) === 0 && view.getUint16(offset + 2, true) === 0,
          "Reserved edge bits"
        );
        const edge = {
          kind: view.getUint8(offset),
          id: view.getUint32(offset + 4, true)
        };
        command2.edges.push(edge);
        offset += EDGE_BYTES;
      }
      batch.commands.push(command2);
    }
    requireValid(offset === bytes.byteLength, "Trailing input bytes");
    validateInputBatch(batch);
    return batch;
  }
  function encodeAcknowledgment(ack) {
    const fields3 = [
      ack.playerId,
      ack.connectionEpoch,
      ack.controlEpoch,
      ack.lastProcessedSequence,
      ack.appliedAtServerTick,
      ...ack.processedEdgeIds
    ];
    requireValid(ack.processedEdgeIds.length === 5, "Acknowledgment edge cursors");
    const bytes = new Uint8Array(ACK_BYTES);
    const view = new DataView(bytes.buffer);
    fields3.forEach((value, index) => {
      counter(value, "acknowledgment field", index >= 3);
      view.setUint32(index * 4, value, true);
    });
    return bytes;
  }

  // src/shared/protocol/input-stream.ts
  function copyCommand(command2) {
    return { ...command2, edges: command2.edges.map((edge) => ({ ...edge })) };
  }
  function requireValue(condition, message) {
    if (!condition) throw new ProtocolError("malformed", message);
  }
  function counter2(value, allowZero = false) {
    requireValue(
      Number.isSafeInteger(value) && value >= (allowZero ? 0 : 1) && value < COUNTER_LIMIT,
      "Invalid stream counter"
    );
  }
  var InputStream = class _InputStream {
    identity;
    playerId;
    tickOffset;
    packets = /* @__PURE__ */ new Map();
    accepted = /* @__PURE__ */ new Map();
    sentSnapshots = /* @__PURE__ */ new Set();
    queue = [];
    admittedEdges = [0, 0, 0, 0, 0];
    ack;
    lastPacket = 0;
    lastSequence = 0;
    lastClientTick = -1;
    lastServerTick;
    lastNowMs = 0;
    freshAtMs = null;
    lastHeld = null;
    sentSnapshot = 0;
    sentEvent = 0;
    snapshotAck = 0;
    eventAck = 0;
    stopped = false;
    applying = false;
    constructor(options) {
      for (const value of [
        options.runEpoch,
        options.connectionEpoch,
        options.playerId,
        options.controlEpoch
      ])
        counter2(value);
      counter2(options.baselineServerTick, true);
      this.identity = { runEpoch: options.runEpoch, connectionEpoch: options.connectionEpoch };
      this.playerId = options.playerId;
      this.lastServerTick = options.baselineServerTick;
      this.tickOffset = options.baselineServerTick + 1;
      this.ack = {
        playerId: options.playerId,
        connectionEpoch: options.connectionEpoch,
        controlEpoch: options.controlEpoch,
        lastProcessedSequence: 0,
        appliedAtServerTick: 0,
        processedEdgeIds: [0, 0, 0, 0, 0]
      };
    }
    get acknowledgment() {
      return { ...this.ack, processedEdgeIds: [...this.ack.processedEdgeIds] };
    }
    get queuedCommands() {
      return this.queue.length;
    }
    get requiresResync() {
      return this.stopped;
    }
    get deliveryAcknowledgments() {
      return { snapshot: this.snapshotAck, event: this.eventAck };
    }
    /** Call only after a full snapshot/event prefix was actually sent to this socket. */
    recordSent(snapshotId, eventCursor) {
      this.guard();
      counter2(snapshotId);
      counter2(eventCursor, true);
      requireValue(
        snapshotId > this.sentSnapshot && eventCursor >= this.sentEvent,
        "Nonmonotonic sent baseline"
      );
      this.sentSnapshots.add(snapshotId);
      this.sentSnapshot = snapshotId;
      this.sentEvent = eventCursor;
      while (this.sentSnapshots.size > MAX_PREDICTION_TICKS) {
        const oldest = this.sentSnapshots.values().next().value;
        if (oldest !== void 0) this.sentSnapshots.delete(oldest);
      }
    }
    /** An authoritative seat/ownership boundary invalidates held intent immediately. */
    setControlEpoch(controlEpoch) {
      this.guard();
      counter2(controlEpoch);
      requireValue(controlEpoch === this.ack.controlEpoch + 1, "Control epoch must increment once");
      this.ack.controlEpoch = controlEpoch;
      this.lastHeld = null;
      this.freshAtMs = null;
    }
    receive(bytes, receivedAtMs, serverTick, policy = "active") {
      this.guard();
      try {
        return this.admit(decodeInputBatch(bytes, this.identity), receivedAtMs, serverTick, policy);
      } catch (error) {
        this.stopped = true;
        throw error;
      }
    }
    admit(batch, nowMs, serverTick, policy) {
      this.time(nowMs, serverTick);
      requireValue(
        serverTick === this.lastServerTick,
        "Admission must use the current simulated tick"
      );
      validateInputBatch(batch);
      const fingerprint = canonical(batch);
      if (batch.packetSequence <= this.lastPacket) {
        const previous = this.packets.get(batch.packetSequence);
        if (previous === void 0)
          throw new ProtocolError("resync-required", "Packet older than immutable history");
        requireValue(previous === fingerprint, "Changed duplicate packet");
        this.lastNowMs = nowMs;
        return { admitted: 0, duplicate: true, renewed: false };
      }
      if (batch.packetSequence !== this.lastPacket + 1)
        throw new ProtocolError("resync-required", "Packet sequence gap");
      requireValue(
        batch.snapshotAck >= this.snapshotAck && batch.eventAck >= this.eventAck && batch.eventAck <= this.sentEvent,
        "Invalid delivery acknowledgment"
      );
      if (batch.snapshotAck !== 0 && !this.sentSnapshots.has(batch.snapshotAck) && batch.snapshotAck !== this.snapshotAck) {
        throw new ProtocolError("resync-required", "Snapshot acknowledgment has no sent baseline");
      }
      const additions = [];
      const edges = [...this.admittedEdges];
      let sequence = this.lastSequence;
      let clientTick = this.lastClientTick;
      let renewed = false;
      for (const command2 of policy === "drain-paused" ? [] : batch.commands) {
        if (command2.sequence <= sequence) {
          const previous = this.accepted.get(command2.sequence);
          if (!previous)
            throw new ProtocolError("resync-required", "Command older than immutable history");
          requireValue(canonical(previous) === canonical(command2), "Changed duplicate command");
          continue;
        }
        if (command2.sequence !== sequence + 1 || command2.clientTick !== clientTick + 1)
          throw new ProtocolError("resync-required", "Command/client tick sequence gap");
        requireValue(command2.controlEpoch <= this.ack.controlEpoch, "Unissued control epoch");
        const targetTick = command2.clientTick + this.tickOffset;
        counter2(targetTick);
        if (targetTick > serverTick + MAX_CLIENT_LEAD_TICKS)
          throw new ProtocolError("resync-required", "Client exceeds server-owned input lead");
        for (const edge of command2.edges) {
          const index = edge.kind - 1;
          const before = edges[index] ?? 0;
          requireValue(
            edge.id > before && edge.id - before <= MAX_EDGE_ADVANCE,
            "Reused or excessive edge identity"
          );
          edges[index] = edge.id;
        }
        additions.push({ command: copyCommand(command2), receivedAtMs: nowMs, targetTick });
        sequence = command2.sequence;
        clientTick = command2.clientTick;
        renewed ||= command2.controlEpoch === this.ack.controlEpoch && serverTick - targetTick < INPUT_STALE_TICKS;
      }
      if (this.queue.length + additions.length > MAX_QUEUED_COMMANDS)
        throw new ProtocolError("resync-required", "Input queue limit");
      this.queue.push(...additions);
      for (const addition of additions)
        this.accepted.set(addition.command.sequence, copyCommand(addition.command));
      while (this.accepted.size > MAX_QUEUED_COMMANDS + MAX_PREDICTION_TICKS) {
        const oldest = this.accepted.keys().next().value;
        if (oldest !== void 0) this.accepted.delete(oldest);
      }
      this.admittedEdges = edges;
      this.lastSequence = sequence;
      this.lastClientTick = clientTick;
      this.lastPacket = batch.packetSequence;
      this.packets.set(batch.packetSequence, fingerprint);
      while (this.packets.size > MAX_PREDICTION_TICKS) {
        const oldest = this.packets.keys().next().value;
        if (oldest !== void 0) this.packets.delete(oldest);
      }
      this.snapshotAck = batch.snapshotAck;
      this.eventAck = batch.eventAck;
      this.lastNowMs = nowMs;
      if (renewed) this.freshAtMs = nowMs;
      return { admitted: additions.length, duplicate: false, renewed };
    }
    /** The single-player adapter uses the same all-or-nothing processing path as a world tick. */
    processTick(serverTick, nowMs, apply) {
      const transaction = _InputStream.processWorldTick([this], serverTick, nowMs, ([prepared]) => {
        if (!prepared) throw new Error("Missing prepared input");
        return {
          state: null,
          outcomes: [{ playerId: this.playerId, edgeResults: apply(prepared.input) }]
        };
      });
      const result = transaction.processed[0];
      if (!result) throw new Error("Missing processed input");
      return result;
    }
    /**
     * Synchronous in-memory commit across all controlling sockets. Evaluate into a candidate world,
     * without publishing it or performing I/O. Validate that candidate before returning it here.
     * A failed evaluation/outcome leaves every queue/ack unchanged and stops the whole cohort.
     * This is not durable storage atomicity; the room still owns checkpoint/recovery publication.
     */
    static processWorldTick(streams, serverTick, nowMs, evaluate2) {
      counter2(serverTick, true);
      requireValue(Number.isFinite(nowMs) && nowMs >= 0, "Invalid world clock");
      requireValue(streams.length <= 4, "Excess world input owners");
      const ordered3 = [...streams].sort((a, b) => a.playerId - b.playerId);
      requireValue(
        new Set(ordered3.map((stream) => stream.playerId)).size === ordered3.length,
        "Duplicate world input owner"
      );
      requireValue(
        ordered3.every((stream) => stream.identity.runEpoch === ordered3[0]?.identity.runEpoch),
        "Mixed world run epochs"
      );
      const staged = ordered3.map((stream) => stream.prepareTick(serverTick, nowMs));
      for (const stream of ordered3) stream.applying = true;
      try {
        const candidate = evaluate2(
          staged.map(
            ({ input, acknowledgment, neutralized }) => structuredClone({ input, acknowledgment, neutralized })
          )
        );
        const state = candidate.state;
        const outcomes = candidate.outcomes;
        requireValue(
          outcomes.length === ordered3.length,
          "World must resolve every input owner exactly once"
        );
        requireValue(
          new Set(outcomes.map((result) => result.playerId)).size === outcomes.length,
          "Duplicate world outcome owner"
        );
        const processed = staged.map((stage) => {
          const outcome = outcomes.find((item) => item.playerId === stage.input.playerId);
          requireValue(Boolean(outcome), "Missing world input outcome");
          if (!outcome) throw new Error("Missing input outcome");
          if (outcome.controlEpoch !== void 0) {
            counter2(outcome.controlEpoch);
            requireValue(
              outcome.controlEpoch === stage.acknowledgment.controlEpoch + 1,
              "World control epoch must increment once"
            );
            stage.acknowledgment.controlEpoch = outcome.controlEpoch;
          }
          return _InputStream.validateTick(stage, outcome.edgeResults);
        });
        for (const [index, stream] of ordered3.entries()) {
          const stage = staged[index];
          if (stage) stream.commitTick(stage);
        }
        return { state, processed };
      } catch (error) {
        for (const stream of ordered3) stream.stopped = true;
        throw error;
      } finally {
        for (const stream of ordered3) stream.applying = false;
      }
    }
    prepareTick(serverTick, nowMs) {
      this.guard();
      this.time(nowMs, serverTick);
      requireValue(serverTick === this.lastServerTick + 1, "Exactly one input step per server tick");
      const candidate = this.queue[0];
      const pending = candidate && candidate.targetTick <= serverTick ? candidate : void 0;
      const expired = this.freshAtMs === null || nowMs - this.freshAtMs >= INPUT_STALE_MS;
      const submitted = pending ? copyCommand(pending.command) : null;
      let outcome = "applied";
      if (pending && pending.command.controlEpoch !== this.ack.controlEpoch) outcome = "old-control";
      else if (pending ? nowMs - pending.receivedAtMs >= INPUT_STALE_MS || serverTick - pending.targetTick >= INPUT_STALE_TICKS : expired)
        outcome = "stale";
      const previousHeld = this.lastHeld;
      const base = submitted ?? previousHeld;
      const command2 = base ? copyCommand(base) : {
        sequence: 0,
        clientTick: 0,
        controlEpoch: this.ack.controlEpoch,
        held: 0,
        aim: 0,
        edges: []
      };
      if (!pending) command2.edges = [];
      if (outcome !== "applied") {
        command2.held = 0;
        command2.aim = 0;
        command2.edges = [];
      }
      const input = {
        playerId: this.playerId,
        command: command2,
        submittedCommand: submitted,
        serverTick,
        outcome,
        repeatedHeld: pending === void 0
      };
      const acknowledgment = this.acknowledgment;
      if (pending) {
        acknowledgment.lastProcessedSequence = pending.command.sequence;
        acknowledgment.appliedAtServerTick = serverTick;
        for (const edge of pending.command.edges)
          acknowledgment.processedEdgeIds[edge.kind - 1] = edge.id;
      }
      return {
        input,
        acknowledgment,
        pending,
        nowMs,
        neutralized: outcome === "stale" && previousHeld !== null && previousHeld.held !== 0
      };
    }
    static validateTick(stage, results) {
      requireValue(
        results.length === stage.input.command.edges.length,
        "Simulation must resolve every delivered edge exactly once"
      );
      for (const [index, result] of results.entries()) {
        const edge = stage.input.command.edges[index];
        requireValue(
          Boolean(
            edge && edge.kind === result.kind && edge.id === result.id && ["applied", "cooldown", "unavailable"].includes(result.outcome)
          ),
          "Invalid simulation edge outcome"
        );
      }
      const edgeResults = stage.input.outcome === "applied" ? results.map((result) => ({ ...result })) : (stage.input.submittedCommand?.edges ?? []).map((edge) => ({
        ...edge,
        outcome: stage.input.outcome
      }));
      return structuredClone({
        input: stage.input,
        acknowledgment: stage.acknowledgment,
        neutralized: stage.neutralized,
        edgeResults
      });
    }
    commitTick(stage) {
      if (stage.pending) this.queue.shift();
      const changedControl = this.ack.controlEpoch !== stage.acknowledgment.controlEpoch;
      this.ack = stage.acknowledgment;
      this.lastHeld = !changedControl && stage.input.outcome === "applied" ? { ...copyCommand(stage.input.command), edges: [] } : null;
      if (changedControl) this.freshAtMs = null;
      this.lastServerTick = stage.input.serverTick;
      this.lastNowMs = stage.nowMs;
    }
    guard() {
      if (this.stopped)
        throw new ProtocolError("resync-required", "Input stream requires a fresh baseline");
      requireValue(!this.applying, "Input stream cannot be reentered during simulation");
    }
    time(nowMs, serverTick) {
      requireValue(Number.isFinite(nowMs) && nowMs >= this.lastNowMs, "Nonmonotonic server clock");
      counter2(serverTick, true);
      requireValue(serverTick >= this.lastServerTick, "Server tick moved backwards");
    }
  };

  // src/game/physics/sweep.ts
  var ZERO = { x: 0, y: 0 };
  var START = { numerator: 0, denominator: 1 };
  var END = { numerator: 1, denominator: 1 };
  function compare(a, b) {
    return compareContactTime(a.numerator, a.denominator, b.numerator, b.denominator);
  }
  function validate(rect, delta, segment) {
    position(rect.x);
    position(rect.y);
    integer(rect.w, segment ? 0 : 1, MAX_POSITION, "sweep width");
    integer(rect.h, segment ? 0 : 1, MAX_POSITION, "sweep height");
    position(rect.x + rect.w);
    position(rect.y + rect.h);
    motion(delta.x);
    motion(delta.y);
    position(rect.x + delta.x);
    position(rect.y + delta.y);
    position(rect.x + rect.w + delta.x);
    position(rect.y + rect.h + delta.y);
  }
  function validateSweepTarget(target) {
    integer(target.id, 1, COUNTER_LIMIT - 1, "collision entity ID");
    if (target.kind !== "solid" && target.kind !== "one-way")
      throw new Error("Unsupported collision terrain");
    validate(target.rect, target.delta, false);
  }
  function sweepBounds(rect, delta = ZERO) {
    validate(rect, delta, true);
    return {
      minX: rect.x + Math.min(0, delta.x),
      minY: rect.y + Math.min(0, delta.y),
      maxX: rect.x + rect.w + Math.max(0, delta.x),
      maxY: rect.y + rect.h + Math.max(0, delta.y)
    };
  }
  function slab(min, max, targetMin, targetMax, delta) {
    if (delta === 0) return min < targetMax && max > targetMin ? "inside" : null;
    const denominator = Math.abs(delta);
    return delta > 0 ? {
      enter: { numerator: targetMin - max, denominator },
      exit: { numerator: targetMax - min, denominator },
      normal: -1
    } : {
      enter: { numerator: min - targetMax, denominator },
      exit: { numerator: max - targetMin, denominator },
      normal: 1
    };
  }
  function sweepAabb(body4, delta, target, targetDelta = ZERO) {
    validate(body4, delta, true);
    validate(target, targetDelta, false);
    if (body4.x < target.x + target.w && body4.x + body4.w > target.x && body4.y < target.y + target.h && body4.y + body4.h > target.y)
      return { kind: "overlap" };
    const axes = [
      slab(body4.x, body4.x + body4.w, target.x, target.x + target.w, delta.x - targetDelta.x),
      slab(body4.y, body4.y + body4.h, target.y, target.y + target.h, delta.y - targetDelta.y)
    ];
    let enter3;
    let exit;
    const normals = [];
    for (const [index, axis] of axes.entries()) {
      if (axis === null) return null;
      if (axis === "inside") continue;
      if (!enter3 || compare(axis.enter, enter3) > 0) enter3 = axis.enter;
      if (!exit || compare(axis.exit, exit) < 0) exit = axis.exit;
      normals.push({
        time: axis.enter,
        normal: index === 0 ? { x: axis.normal, y: 0 } : { x: 0, y: axis.normal }
      });
    }
    if (!enter3 || !exit || compare(enter3, START) < 0 || compare(enter3, END) > 0 || compare(enter3, exit) >= 0)
      return null;
    return {
      kind: "hit",
      time: enter3,
      normals: normals.filter((item) => compare(item.time, enter3) === 0).map((item) => item.normal)
    };
  }
  function sweepOneWay(body4, delta, target, targetDelta = ZERO) {
    validate(body4, delta, true);
    validate(target, targetDelta, false);
    const distance = target.y - (body4.y + body4.h);
    const relativeY = delta.y - targetDelta.y;
    if (distance < 0 || relativeY <= 0 || distance > relativeY) return null;
    const time = { numerator: distance, denominator: relativeY };
    const relativeX = delta.x - targetDelta.x;
    if ((body4.x - target.x - target.w) * relativeY + relativeX * distance >= 0 || (body4.x + body4.w - target.x) * relativeY + relativeX * distance <= 0)
      return null;
    return { kind: "hit", time, normals: [{ x: 0, y: -1 }] };
  }
  function earliestSweep(body4, delta, targets2, ignoredOneWayId) {
    validate(body4, delta, true);
    integer(targets2.length, 0, 4096, "sweep candidate count");
    const ids2 = /* @__PURE__ */ new Set();
    const overlaps2 = [];
    let contacts = [];
    let earliest;
    for (const target of [...targets2].sort((a, b) => a.id - b.id)) {
      validateSweepTarget(target);
      if (ids2.has(target.id)) throw new Error("Duplicate collision entity ID");
      ids2.add(target.id);
      if (target.kind === "one-way" && target.id === ignoredOneWayId) continue;
      const result = target.kind === "solid" ? sweepAabb(body4, delta, target.rect, target.delta) : sweepOneWay(body4, delta, target.rect, target.delta);
      if (result?.kind === "overlap") {
        overlaps2.push(target.id);
        continue;
      }
      if (!result || earliest && compare(result.time, earliest) > 0) continue;
      if (!earliest || compare(result.time, earliest) < 0) contacts = [];
      earliest = result.time;
      for (const normal of result.normals)
        contacts.push({ otherId: target.id, kind: target.kind, time: result.time, normal });
    }
    return { overlaps: overlaps2, contacts };
  }
  function displacementAtContact(delta, time) {
    motion(delta.x);
    motion(delta.y);
    integer(time.denominator, 1, MAX_MOTION * 2, "contact denominator");
    integer(time.numerator, 0, time.denominator, "contact numerator");
    return {
      x: Math.trunc(delta.x * time.numerator / time.denominator) || 0,
      y: Math.trunc(delta.y * time.numerator / time.denominator) || 0
    };
  }

  // src/game/physics/grid.ts
  var MAX_TARGETS = 4096;
  var MAX_ENTRY_CELLS = 256;
  var MAX_GRID_REFERENCES = 65536;
  var MAX_QUERY_CELLS = 4096;
  function validateBounds(bounds) {
    for (const value of [bounds.minX, bounds.minY, bounds.maxX, bounds.maxY]) position(value);
    if (bounds.minX > bounds.maxX || bounds.minY > bounds.maxY)
      throw new Error("Inverted spatial bounds");
  }
  function intersects(a, b) {
    return a.minX <= b.maxX && a.maxX >= b.minX && a.minY <= b.maxY && a.maxY >= b.minY;
  }
  function sorted(values) {
    return Object.freeze([...values].sort((a, b) => a.id - b.id));
  }
  var CollisionGrid = class {
    constructor(targets2, cellPixels = 64) {
      this.cellPixels = cellPixels;
      if (cellPixels !== 32 && cellPixels !== 64)
        throw new Error("Spatial cell size must be 32 or 64 pixels");
      integer(targets2.length, 0, MAX_TARGETS, "spatial target count");
      let references = 0;
      for (const value of [...targets2].sort((a, b) => a.id - b.id)) {
        validateSweepTarget(value);
        if (this.#entries.has(value.id)) throw new Error("Duplicate collision entity ID");
        const target = Object.freeze({
          ...value,
          rect: Object.freeze({ ...value.rect }),
          delta: Object.freeze({ ...value.delta })
        });
        const bounds = sweepBounds(target.rect, target.delta);
        this.#entries.set(target.id, { target, bounds });
        const range = this.#range(bounds);
        if (range.count > MAX_ENTRY_CELLS || references + range.count > MAX_GRID_REFERENCES) {
          this.#overflow.push(target.id);
          continue;
        }
        references += range.count;
        for (let x = range.minX; x <= range.maxX; x++) {
          for (let y = range.minY; y <= range.maxY; y++) {
            const key = `${x},${y}`;
            const bucket = this.#buckets.get(key) ?? [];
            bucket.push(target.id);
            this.#buckets.set(key, bucket);
          }
        }
      }
      this.targets = sorted([...this.#entries.values()].map((entry) => entry.target));
      this.hasMotion = this.targets.some((target) => target.delta.x !== 0 || target.delta.y !== 0);
      this.statistics = Object.freeze({
        targets: targets2.length,
        cells: this.#buckets.size,
        references,
        overflow: this.#overflow.length
      });
      Object.freeze(this);
    }
    cellPixels;
    targets;
    hasMotion;
    statistics;
    #buckets = /* @__PURE__ */ new Map();
    #entries = /* @__PURE__ */ new Map();
    #overflow = [];
    #range(bounds) {
      const size = this.cellPixels * SUBPIXELS;
      const minX = Math.floor(bounds.minX / size);
      const minY = Math.floor(bounds.minY / size);
      const maxX = Math.floor(bounds.maxX / size);
      const maxY = Math.floor(bounds.maxY / size);
      return { minX, minY, maxX, maxY, count: (maxX - minX + 1) * (maxY - minY + 1) };
    }
    query(bounds) {
      return this.inspectQuery(bounds).targets;
    }
    get(id2) {
      return this.#entries.get(id2)?.target;
    }
    inspectQuery(bounds) {
      validateBounds(bounds);
      const range = this.#range(bounds);
      const ids2 = /* @__PURE__ */ new Set();
      const scan = range.count > MAX_QUERY_CELLS;
      if (scan) {
        for (const id2 of this.#entries.keys()) ids2.add(id2);
      } else {
        for (const id2 of this.#overflow) ids2.add(id2);
        for (let x = range.minX; x <= range.maxX; x++) {
          for (let y = range.minY; y <= range.maxY; y++) {
            for (const id2 of this.#buckets.get(`${x},${y}`) ?? []) ids2.add(id2);
          }
        }
      }
      const targets2 = [];
      for (const id2 of ids2) {
        const entry = this.#entries.get(id2);
        if (!entry) throw new Error("Missing spatial entry");
        if (intersects(entry.bounds, bounds)) targets2.push(entry.target);
      }
      return {
        targets: sorted(targets2),
        mode: scan ? "scan" : "cells",
        cellsVisited: scan ? 0 : range.count,
        candidatesTested: ids2.size
      };
    }
  };
  var CollisionIndex = class {
    constructor(fixed, moving, frame) {
      this.fixed = fixed;
      if (fixed.hasMotion) throw new Error("Static collision grid contains moving geometry");
      integer(fixed.targets.length + moving.length, 0, MAX_TARGETS, "collision frame target count");
      integer(frame.geometryRevision, 1, COUNTER_LIMIT - 1, "geometry revision");
      integer(frame.tick, 0, COUNTER_LIMIT - 1, "collision tick");
      this.dynamic = new CollisionGrid(moving, fixed.cellPixels);
      this.targets = sorted([...fixed.targets, ...this.dynamic.targets]);
      if (new Set(this.targets.map((target) => target.id)).size !== this.targets.length)
        throw new Error("Duplicate collision entity ID across static/dynamic grids");
      this.frame = Object.freeze({ ...frame });
      Object.freeze(this);
    }
    fixed;
    dynamic;
    targets;
    frame;
    assertFrame(frame) {
      if (!frame || frame.geometryRevision !== this.frame.geometryRevision || frame.tick !== this.frame.tick)
        throw new Error("Stale or missing collision frame identity");
    }
    query(bounds) {
      return sorted([...this.fixed.query(bounds), ...this.dynamic.query(bounds)]);
    }
    get(id2) {
      return this.fixed.get(id2) ?? this.dynamic.get(id2);
    }
  };

  // src/game/physics/move.ts
  var ZERO2 = { x: 0, y: 0 };
  var MAX_CORRECTION = SUBPIXELS;
  function translate(rect, delta) {
    const result = { ...rect, x: position(rect.x + delta.x), y: position(rect.y + delta.y) };
    position(result.x + result.w);
    position(result.y + result.h);
    return result;
  }
  function overlaps(a, b) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }
  function inWorld(rect) {
    return rect.x >= -MAX_POSITION && rect.y >= -MAX_POSITION && rect.x + rect.w <= MAX_POSITION && rect.y + rect.h <= MAX_POSITION;
  }
  function correctOverlap(rect, targets2, ids2, ignoredId) {
    if (ids2.length === 0) return { ...ZERO2 };
    if (ids2.length > 8) return null;
    const overlapping = new Set(ids2);
    const candidates = [];
    for (const target of targets2) {
      if (!overlapping.has(target.id)) continue;
      const b = target.rect;
      candidates.push(
        { delta: { x: b.x - rect.x - rect.w, y: 0 }, order: 0, id: target.id },
        { delta: { x: b.x + b.w - rect.x, y: 0 }, order: 1, id: target.id },
        { delta: { x: 0, y: b.y - rect.y - rect.h }, order: 2, id: target.id },
        { delta: { x: 0, y: b.y + b.h - rect.y }, order: 3, id: target.id }
      );
    }
    const distance = (delta) => Math.abs(delta.x) + Math.abs(delta.y);
    candidates.sort(
      (a, b) => distance(a.delta) - distance(b.delta) || a.order - b.order || a.id - b.id
    );
    for (const { delta } of candidates) {
      if (distance(delta) > MAX_CORRECTION) continue;
      const next = { ...rect, x: rect.x + delta.x, y: rect.y + delta.y };
      if (!inWorld(next)) continue;
      if (targets2.some((target) => target.kind === "solid" && overlaps(next, target.rect))) continue;
      const blocked = targets2.some((target) => {
        if (overlapping.has(target.id) || target.kind === "one-way" && target.id === ignoredId)
          return false;
        const hit = target.kind === "solid" ? sweepAabb(rect, delta, target.rect) : sweepOneWay(rect, delta, target.rect);
        return hit?.kind === "hit" && hit.time.numerator < hit.time.denominator;
      });
      if (!blocked) return delta;
    }
    return null;
  }
  function support(rect, targets2, previousId, credited, ignoredId) {
    const candidates = targets2.filter((target) => {
      if (target.kind === "one-way" && target.id === ignoredId) return false;
      const gap = target.rect.y - rect.y - rect.h;
      return gap >= 0 && gap <= (credited.has(target.id) ? 1 : 0) && rect.x < target.rect.x + target.rect.w && rect.x + rect.w > target.rect.x;
    });
    return candidates.find((target) => target.id === previousId)?.id ?? candidates[0]?.id ?? null;
  }
  function redundantSeam(rect, corner, constraints, byId) {
    const target = byId.get(corner.id);
    if (!target) return false;
    const axis = corner.normal.x !== 0 ? "y" : "x";
    const extent = axis === "x" ? "w" : "h";
    return constraints.some((face) => {
      const other = byId.get(face.id);
      if (!other || face.normal[axis] === 0 || !touching(rect, other, face.normal, 0)) return false;
      if (target.delta[axis] !== other.delta[axis]) return false;
      if (face.normal[axis] === -1)
        return rect[axis] + rect[extent] === target.rect[axis] && target.rect[axis] === other.rect[axis];
      return rect[axis] === target.rect[axis] + target.rect[extent] && target.rect[axis] + target.rect[extent] === other.rect[axis] + other.rect[extent];
    });
  }
  function touching(rect, target, normal, tolerance) {
    const b = target.rect;
    const horizontal = rect.x < b.x + b.w && rect.x + rect.w > b.x;
    const vertical = rect.y < b.y + b.h && rect.y + rect.h > b.y;
    const gap = normal.x === -1 ? b.x - rect.x - rect.w : normal.x === 1 ? rect.x - b.x - b.w : normal.y === -1 ? b.y - rect.y - rect.h : rect.y - b.y - b.h;
    return gap >= 0 && gap <= tolerance && (normal.x === 0 ? horizontal : vertical);
  }
  function contactGap(rect, target, normal) {
    const b = target.rect;
    const gap = normal.x === -1 ? b.x - rect.x - rect.w : normal.x === 1 ? rect.x - b.x - b.w : normal.y === -1 ? b.y - rect.y - rect.h : rect.y - b.y - b.h;
    return Math.max(0, Math.min(1, gap));
  }
  function closingTrap(rect, active, targets2, byId, remaining, axis) {
    const otherAxis = axis === "x" ? "y" : "x";
    const otherSize = otherAxis === "x" ? "w" : "h";
    let lower = -MAX_MOTION;
    let upper = MAX_MOTION;
    for (const constraint of active) {
      if (constraint.normal[otherAxis] === 1) lower = Math.max(lower, constraint.delta[otherAxis]);
      if (constraint.normal[otherAxis] === -1) upper = Math.min(upper, constraint.delta[otherAxis]);
    }
    if (lower > upper) return false;
    const sideways = Math.max(lower, Math.min(upper, remaining[otherAxis]));
    return active.some((a) => {
      const left = byId.get(a.id);
      if (a.normal[axis] !== 1 || !left || !touching(rect, left, a.normal, 1)) return false;
      return active.some((b) => {
        const right = byId.get(b.id);
        if (b.normal[axis] !== -1 || !right || !touching(rect, right, b.normal, 1)) return false;
        const size = axis === "x" ? "w" : "h";
        const space = right.rect[axis] - left.rect[axis] - left.rect[size] - rect[size];
        const closing = a.delta[axis] - b.delta[axis];
        if (closing <= space) return false;
        for (const target of [left, right]) {
          const relative = sideways - target.delta[otherAxis];
          if ((rect[otherAxis] - target.rect[otherAxis] - target.rect[otherSize]) * closing + relative * space >= 0 || (rect[otherAxis] + rect[otherSize] - target.rect[otherAxis]) * closing + relative * space <= 0)
            return false;
        }
        return !targets2.some((target) => {
          const relative = sideways - target.delta[otherAxis];
          if (relative === 0) return false;
          const distance = relative > 0 ? target.rect[otherAxis] - rect[otherAxis] - rect[otherSize] : rect[otherAxis] - target.rect[otherAxis] - target.rect[otherSize];
          return distance >= 0 && distance * closing <= space * Math.abs(relative);
        });
      });
    });
  }
  function moveKinematic(state, terrain, options = {}) {
    const limit = integer(options.maxIterations ?? 4, 1, 4, "movement contact limit");
    if (state.supportId !== null) integer(state.supportId, 1, COUNTER_LIMIT - 1, "support ID");
    if (options.ignoredOneWayId !== void 0)
      integer(options.ignoredOneWayId, 1, COUNTER_LIMIT - 1, "ignored support ID");
    integer(state.rect.w, 1, MAX_POSITION, "body width");
    integer(state.rect.h, 1, MAX_POSITION, "body height");
    const index = terrain instanceof CollisionIndex ? terrain : void 0;
    index?.assertFrame(options.frame);
    const source3 = terrain instanceof CollisionIndex ? terrain.targets : terrain;
    const targets2 = source3.map((target) => ({ ...target, rect: { ...target.rect }, delta: { ...target.delta } })).sort((a, b) => a.id - b.id);
    const byId = new Map(targets2.map((target) => [target.id, target]));
    const query = (rect, delta) => {
      const candidates = index ? index.query(sweepBounds(rect, delta)).map((target) => {
        const current = byId.get(target.id);
        if (!current) throw new Error("Missing current collision target");
        return current;
      }) : targets2;
      return earliestSweep(rect, delta, candidates, options.ignoredOneWayId);
    };
    const initial = query(state.rect, state.motion);
    const correction = correctOverlap(state.rect, targets2, initial.overlaps, options.ignoredOneWayId);
    const result = {
      rect: { ...state.rect },
      motion: { ...state.motion },
      supportId: null,
      status: "complete",
      contacts: [],
      correction: correction ?? { ...ZERO2 },
      remaining: { ...state.motion },
      iterations: 0,
      diagnosticIds: []
    };
    if (!correction) return { ...result, status: "initial-overlap", diagnosticIds: initial.overlaps };
    result.rect = translate(result.rect, correction);
    const credited = new Set(state.supportId === null ? [] : [state.supportId]);
    const startingSupport = state.motion.y < 0 ? null : support(result.rect, targets2, state.supportId, credited, options.ignoredOneWayId);
    const carry = options.carrySupport === false ? ZERO2 : byId.get(startingSupport ?? 0)?.delta ?? ZERO2;
    result.remaining = { x: motion(state.motion.x + carry.x), y: motion(state.motion.y + carry.y) };
    if (startingSupport !== null) credited.add(startingSupport);
    let active = [];
    for (let iteration = 0; iteration < limit; iteration++) {
      const hits = query(result.rect, result.remaining);
      if (hits.overlaps.length)
        return { ...result, status: "residual-overlap", diagnosticIds: hits.overlaps };
      if (!hits.contacts.length) {
        result.rect = translate(result.rect, result.remaining);
        for (const target of targets2) target.rect = translate(target.rect, target.delta);
        result.remaining = { ...ZERO2 };
        result.supportId = result.motion.y < 0 ? null : support(result.rect, targets2, startingSupport, credited, options.ignoredOneWayId);
        return result;
      }
      const first = hits.contacts[0];
      if (!first) throw new Error("Missing movement contact");
      result.iterations++;
      const moved = displacementAtContact(result.remaining, first.time);
      result.rect = translate(result.rect, moved);
      result.remaining = { x: result.remaining.x - moved.x, y: result.remaining.y - moved.y };
      for (const target of targets2) {
        const movedTarget = displacementAtContact(target.delta, first.time);
        target.rect = translate(target.rect, movedTarget);
        target.delta = { x: target.delta.x - movedTarget.x, y: target.delta.y - movedTarget.y };
      }
      const current = hits.contacts.map((contact) => {
        result.contacts.push({ ...contact, iteration });
        if (contact.normal.y === -1) credited.add(contact.otherId);
        const target = byId.get(contact.otherId);
        if (!target) throw new Error("Missing contact target");
        return { id: target.id, normal: contact.normal, delta: target.delta };
      });
      active = active.flatMap((constraint) => {
        const target = byId.get(constraint.id);
        return target && touching(result.rect, target, constraint.normal, 1) ? [{ ...constraint, delta: target.delta }] : [];
      });
      const witnessed = [...active, ...current];
      for (const constraint of current) {
        if (redundantSeam(result.rect, constraint, witnessed, byId)) continue;
        if (!active.some(
          (item) => item.id === constraint.id && item.normal.x === constraint.normal.x && item.normal.y === constraint.normal.y
        ))
          active.push(constraint);
      }
      for (const axis of ["x", "y"]) {
        let lower = -MAX_MOTION;
        let upper = MAX_MOTION;
        for (const constraint of active) {
          const normal = constraint.normal[axis];
          const target = byId.get(constraint.id);
          if (!target) throw new Error("Missing active contact target");
          const gap = contactGap(result.rect, target, constraint.normal);
          if (normal === 1) lower = Math.max(lower, constraint.delta[axis] - gap);
          if (normal === -1) upper = Math.min(upper, constraint.delta[axis] + gap);
          if (result.motion[axis] * normal < 0) result.motion[axis] = 0;
        }
        if (lower > upper) {
          const exact = active.filter((constraint) => {
            const target = byId.get(constraint.id);
            return target && touching(result.rect, target, constraint.normal, 0);
          });
          const crush = exact.some(
            (a) => a.normal[axis] === 1 && exact.some((b) => b.normal[axis] === -1 && a.delta[axis] > b.delta[axis])
          ) || closingTrap(result.rect, active, targets2, byId, result.remaining, axis);
          return {
            ...result,
            status: crush ? "crushed" : "unresolved-contact",
            diagnosticIds: [
              ...new Set(
                active.filter((constraint) => constraint.normal[axis] !== 0).map((constraint) => constraint.id)
              )
            ].sort((a, b) => a - b)
          };
        }
        result.remaining[axis] = Math.max(lower, Math.min(upper, result.remaining[axis]));
      }
      if (result.remaining.x === 0 && result.remaining.y === 0 && targets2.every((target) => target.delta.x === 0 && target.delta.y === 0)) {
        result.supportId = support(
          result.rect,
          targets2,
          startingSupport,
          credited,
          options.ignoredOneWayId
        );
        return result;
      }
    }
    return {
      ...result,
      status: "contact-limit",
      diagnosticIds: [...new Set(result.contacts.map((contact) => contact.otherId))].sort(
        (a, b) => a - b
      )
    };
  }

  // src/game/physics/body.ts
  var ZERO3 = { x: 0, y: 0 };
  var NORMALS = [
    { x: -1, y: 0 },
    { x: 1, y: 0 },
    { x: 0, y: -1 },
    { x: 0, y: 1 }
  ];
  function validateLocalRect(rect) {
    integer(rect.x, -MAX_SHAPE, MAX_SHAPE, "local x");
    integer(rect.y, -MAX_SHAPE, MAX_SHAPE, "local y");
    integer(rect.w, 1, MAX_SHAPE, "local width");
    integer(rect.h, 1, MAX_SHAPE, "local height");
    integer(rect.x + rect.w, -MAX_SHAPE, MAX_SHAPE, "local right edge");
    integer(rect.y + rect.h, -MAX_SHAPE, MAX_SHAPE, "local bottom edge");
  }
  function facing(value) {
    if (value !== -1 && value !== 1) throw new Error("Invalid body facing");
  }
  function worldRect(root, local, direction) {
    facing(direction);
    validateLocalRect(local);
    position(root.x);
    position(root.y);
    const rect = {
      x: position(root.x + (direction === 1 ? local.x : -local.x - local.w)),
      y: position(root.y + local.y),
      w: local.w,
      h: local.h
    };
    position(rect.x + rect.w);
    position(rect.y + rect.h);
    return rect;
  }
  function worldSocket(root, local, direction) {
    facing(direction);
    position(root.x);
    position(root.y);
    integer(local.x, -MAX_SHAPE, MAX_SHAPE, "socket x");
    integer(local.y, -MAX_SHAPE, MAX_SHAPE, "socket y");
    return { x: position(root.x + local.x * direction), y: position(root.y + local.y) };
  }
  function bodyRect(body4, shape, direction) {
    integer(body4.id, 1, COUNTER_LIMIT - 1, "body ID");
    integer(shape.id, 1, COUNTER_LIMIT - 1, "shape ID");
    if (body4.shapeId !== shape.id) throw new Error("Body/shape identity mismatch");
    if (body4.grounded !== (body4.supportId !== null)) throw new Error("Ground/support mismatch");
    if (body4.supportId !== null) integer(body4.supportId, 1, COUNTER_LIMIT - 1, "body support ID");
    motion(body4.vx);
    motion(body4.vy);
    motion(body4.remainderX);
    motion(body4.remainderY);
    return worldRect(body4, shape.rect, direction);
  }
  function targetRect(rect, delta, phase) {
    return phase === "start" ? rect : { ...rect, x: rect.x + delta.x, y: rect.y + delta.y };
  }
  function poseCandidates(rect, index) {
    return index.query({
      minX: Math.max(-MAX_POSITION, rect.x - 1),
      minY: Math.max(-MAX_POSITION, rect.y - 1),
      maxX: Math.min(MAX_POSITION, rect.x + rect.w + 1),
      maxY: Math.min(MAX_POSITION, rect.y + rect.h + 1)
    });
  }
  function blockingShapes(root, local, direction, index, frame, phase = "start") {
    index.assertFrame(frame);
    const proposed = worldRect(root, local, direction);
    return index.query(sweepBounds(proposed)).filter(
      (target) => target.kind === "solid" && sweepAabb(proposed, ZERO3, targetRect(target.rect, target.delta, phase))?.kind === "overlap"
    ).map((target) => target.id);
  }
  function tryBodyShape(body4, current, desired, oldFacing, nextFacing, index, frame, phase = "start") {
    bodyRect(body4, current, oldFacing);
    validateLocalRect(desired.rect);
    integer(desired.id, 1, COUNTER_LIMIT - 1, "desired shape ID");
    if (current.rect.y + current.rect.h !== desired.rect.y + desired.rect.h)
      throw new Error("Stance changes the feet anchor");
    const blockedBy = blockingShapes(body4, desired.rect, nextFacing, index, frame, phase);
    return blockedBy.length ? { accepted: false, blockedBy, body: body4, facing: oldFacing } : {
      accepted: true,
      blockedBy,
      body: {
        ...body4,
        shapeId: desired.id,
        contacts: desired.id !== current.id || oldFacing !== nextFacing ? [] : body4.contacts
      },
      facing: nextFacing
    };
  }
  function startSupport(body4, shape, direction, index, frame, ignoredId) {
    index.assertFrame(frame);
    const rect = bodyRect(body4, shape, direction);
    const candidates = poseCandidates(rect, index).filter((target) => {
      if (target.kind === "one-way" && target.id === ignoredId) return false;
      const gap = target.rect.y - rect.y - rect.h;
      return gap >= 0 && gap <= (target.id === body4.supportId ? 1 : 0) && rect.x < target.rect.x + target.rect.w && rect.x + rect.w > target.rect.x;
    });
    return candidates.find((target) => target.id === body4.supportId)?.id ?? candidates[0]?.id ?? null;
  }
  function endContacts(rect, movement, index) {
    const result = [];
    const candidates = poseCandidates(rect, index);
    const witnesses = new Set(
      movement.contacts.map(
        (contact) => `${contact.otherId}:${contact.normal.x}:${contact.normal.y}`
      )
    );
    for (const normal of NORMALS) {
      const matching = candidates.filter((target2) => {
        const witnessed = witnesses.has(`${target2.id}:${normal.x}:${normal.y}`);
        const supported = normal.y === -1 && movement.supportId === target2.id;
        if (target2.kind === "one-way" && !(normal.y === -1 && (witnessed || supported))) return false;
        const b = targetRect(target2.rect, target2.delta, "end");
        const gap = normal.x === -1 ? b.x - rect.x - rect.w : normal.x === 1 ? rect.x - b.x - b.w : normal.y === -1 ? b.y - rect.y - rect.h : rect.y - b.y - b.h;
        return gap >= 0 && gap <= (witnessed || supported ? 1 : 0) && (normal.x === 0 ? rect.x < b.x + b.w && rect.x + rect.w > b.x : rect.y < b.y + b.h && rect.y + rect.h > b.y);
      });
      const target = (normal.y === -1 ? matching.find((target2) => target2.id === movement.supportId) : void 0) ?? matching[0];
      if (target)
        result.push({
          otherId: target.id,
          normalX: normal.x,
          normalY: normal.y,
          toiNumerator: 1,
          toiDenominator: 1,
          kind: target.kind
        });
    }
    return result.sort(
      (a, b) => a.otherId - b.otherId || a.normalX - b.normalX || a.normalY - b.normalY
    );
  }
  function stepBody(body4, shape, direction, index, options) {
    const rect = bodyRect(body4, shape, direction);
    const movement = moveKinematic(
      { rect, motion: { x: body4.vx, y: body4.vy }, supportId: body4.supportId },
      index,
      options
    );
    if (movement.status !== "complete")
      return { status: "failed", reason: movement.status, movement };
    return {
      status: "complete",
      movement,
      body: {
        ...body4,
        x: position(body4.x + movement.rect.x - rect.x),
        y: position(body4.y + movement.rect.y - rect.y),
        vx: movement.motion.x,
        vy: movement.motion.y,
        supportId: movement.supportId,
        grounded: movement.supportId !== null,
        contacts: endContacts(movement.rect, movement, index)
      }
    };
  }

  // src/game/rules.ts
  var ARCADE = Object.freeze({
    width: 384,
    height: 216,
    simulationHz: 60,
    snapshotHz: 20,
    maxPlayers: 4,
    staleInputMs: 250,
    reservationMs: 9e4,
    initialLives: 3,
    initialGrenades: 10,
    respawnProtectionTicks: 120,
    deathTicks: 30,
    respawnEntryTicks: 12,
    boardingTicks: 12,
    reboardCooldownTicks: 30,
    vehicleSpecialHoldTicks: 30,
    jumpBufferTicks: 5,
    coyoteTicks: 4,
    dropThroughTicks: 12
  });
  var RULE_PRESETS = Object.freeze({
    classic: Object.freeze({ footHealth: 1, tankArmor: 3, sharedContinues: 3 }),
    accessible: Object.freeze({ footHealth: 3, tankArmor: 3, sharedContinues: 9 })
  });
  var DEFAULT_BINDINGS = Object.freeze({
    left: ["ArrowLeft", "KeyA"],
    right: ["ArrowRight", "KeyD"],
    up: ["ArrowUp", "KeyW"],
    down: ["ArrowDown", "KeyS"],
    fire: ["KeyJ", "KeyZ"],
    jump: ["Space", "KeyK", "KeyX"],
    grenade: ["KeyL", "KeyC"],
    interact: ["KeyE"],
    vehicleSpecial: ["KeyV"]
  });
  var DEFAULT_GAMEPAD = Object.freeze({
    jump: 0,
    fire: 2,
    grenade: 1,
    interact: 3,
    vehicleSpecial: 4
  });

  // src/game/campaign/life.ts
  function check(ok, reason) {
    if (!ok) throw new Error(`Player life: ${reason}`);
  }
  function validBodyPresence(actor) {
    if (actor.life !== "alive" && (actor.vehicleId !== null || actor.action.kind !== "ready"))
      return false;
    if (actor.bodyPresence === "present") return actor.life !== "spectating";
    if (actor.life === "alive") return false;
    const body4 = actor.body;
    return actor.bodyPresence === "removed" && actor.locomotion === "airborne" && body4.vx === 0 && body4.vy === 0 && body4.remainderX === 0 && body4.remainderY === 0 && !body4.grounded && body4.supportId === null && body4.contacts.length === 0;
  }
  function validatePlayerLife(actor, tick2, ruleset) {
    integer(tick2, 0, COUNTER_LIMIT - 1, "life tick");
    integer(actor.lifeStartTick, 0, tick2, "life phase tick");
    integer(actor.lives, 0, ARCADE.initialLives, "player lives");
    const rule = RULE_PRESETS[ruleset];
    check(rule, "unknown ruleset");
    integer(actor.health, 0, rule.footHealth, "foot health");
    integer(actor.invulnerableTicks, 0, ARCADE.respawnProtectionTicks, "entry protection");
    check(validBodyPresence(actor), "inconsistent body presence");
    check(
      actor.life === "alive" || actor.life === "respawning" ? actor.health > 0 && actor.lives > 0 : actor.life === "death" || actor.life === "spectating" ? actor.health === 0 && (actor.life !== "spectating" || actor.lives === 0) : false,
      "inconsistent life state"
    );
  }
  function notice(actor, tick2, kind) {
    return { kind, tick: tick2, playerId: actor.playerId, lives: actor.lives };
  }
  function clearAction(actor, tick2) {
    actor.firearmAim = { pitch: 0, nextStepTick: 0 };
    actor.action = {
      kind: "ready",
      actionInstanceId: 0,
      stateStartTick: tick2,
      definitionId: 0,
      nextMarkerIndex: 0
    };
    actor.jumpBufferTicks = 0;
    actor.coyoteTicks = 0;
    actor.ignoredSupportId = null;
    actor.ignoredSupportTicks = 0;
  }
  function removeBody(actor) {
    actor.bodyPresence = "removed";
    actor.body.vx = actor.body.vy = actor.body.remainderX = actor.body.remainderY = 0;
    actor.body.grounded = false;
    actor.body.supportId = null;
    actor.body.contacts = [];
    actor.locomotion = "airborne";
  }
  function stepPassiveBody(actor, context2) {
    if (actor.bodyPresence !== "present") return false;
    const { definition: definition2, shapes: shapes2, index, frame, fallBoundary } = context2;
    position(fallBoundary);
    check(
      definition2.locomotion === "grounded" && definition2.gravity > 0 && definition2.terminalVelocity > 0,
      "invalid passive body physics"
    );
    motion(definition2.gravity);
    motion(definition2.terminalVelocity);
    check(
      actor.body.remainderX === 0 && actor.body.remainderY === 0,
      "unsupported passive body remainder"
    );
    const shape = shapes2.get(actor.body.shapeId);
    check(
      shape && (shape.id === definition2.standingShapeId || shape.id === definition2.crouchedShapeId),
      "unknown passive body shape"
    );
    if (actor.body.y > fallBoundary) {
      removeBody(actor);
      return false;
    }
    const support2 = actor.body.vy < 0 ? null : startSupport(actor.body, shape, actor.facing, index, frame, null);
    actor.body.supportId = support2;
    actor.body.grounded = support2 !== null;
    if (support2 !== null) actor.body.vx = 0;
    actor.body.vy = Math.min(definition2.terminalVelocity, actor.body.vy + definition2.gravity);
    const result = stepBody(actor.body, shape, actor.facing, index, { frame });
    if (result.status === "failed") {
      removeBody(actor);
      return false;
    }
    actor.body = result.body;
    if (actor.body.y > fallBoundary) removeBody(actor);
    else {
      actor.locomotion = actor.body.grounded ? "grounded" : "airborne";
      if (actor.body.grounded) actor.body.vx = 0;
    }
    return actor.bodyPresence === "present";
  }
  function damagePlayer(current, tick2, damage, ruleset, cause = "hit") {
    validatePlayerLife(current, tick2, ruleset);
    integer(damage, 1, 65535, "player damage");
    check(cause === "hit" || cause === "fall" || cause === "crush", "unknown damage cause");
    const actor = structuredClone(current);
    if (actor.life !== "alive" || cause === "hit" && actor.invulnerableTicks > 0)
      return { actor, notice: null };
    check(actor.vehicleId === null, "vehicle damage requires the vehicle owner");
    actor.health = cause === "hit" ? Math.max(0, actor.health - damage) : 0;
    if (actor.health > 0) return { actor, notice: null };
    actor.lives--;
    actor.life = "death";
    actor.bodyPresence = "present";
    actor.lifeStartTick = tick2;
    actor.invulnerableTicks = 0;
    clearAction(actor, tick2);
    if (cause !== "hit") removeBody(actor);
    else if (actor.body.grounded) actor.body.vx = 0;
    return { actor, notice: notice(actor, tick2, "death") };
  }
  function entryBody(actor, context2) {
    context2.index.assertFrame(context2.frame);
    position(context2.fallBoundary);
    integer(context2.anchors.length, 1, 16, "checkpoint anchor count");
    check(context2.shape.rect.y + context2.shape.rect.h === 0, "entry shape must use a feet anchor");
    for (const point3 of context2.anchors) {
      if (blockingShapes(point3, context2.shape.rect, actor.facing, context2.index, context2.frame).length)
        continue;
      const body4 = {
        ...actor.body,
        ...point3,
        vx: 0,
        vy: 0,
        remainderX: 0,
        remainderY: 0,
        shapeId: context2.shape.id,
        supportId: null,
        grounded: false,
        contacts: []
      };
      const support2 = startSupport(
        body4,
        context2.shape,
        actor.facing,
        context2.index,
        context2.frame,
        null
      );
      if (support2 === null) continue;
      body4.supportId = support2;
      body4.grounded = true;
      const moved = stepBody(body4, context2.shape, actor.facing, context2.index, {
        frame: context2.frame
      });
      if (moved.status === "complete" && moved.body.grounded && moved.body.y <= context2.fallBoundary)
        return moved.body;
    }
    return null;
  }
  function enterPlayer(current, tick2, ruleset, context2) {
    integer(current.lives, 1, ARCADE.initialLives, "entry lives");
    integer(tick2, current.lifeStartTick, COUNTER_LIMIT - 1, "entry tick");
    check(context2.frame.tick === tick2, "entry collision tick mismatch");
    check(RULE_PRESETS[ruleset], "unknown ruleset");
    check(current.vehicleId === null, "vehicle seat must be released before entry");
    const body4 = entryBody(current, context2);
    if (!body4) return null;
    const actor = structuredClone(current);
    actor.body = body4;
    actor.geometryRevision = context2.frame.geometryRevision;
    actor.life = "respawning";
    actor.bodyPresence = "present";
    actor.lifeStartTick = tick2;
    actor.locomotion = "grounded";
    actor.health = RULE_PRESETS[ruleset].footHealth;
    actor.invulnerableTicks = ARCADE.respawnProtectionTicks;
    actor.weapon = {
      id: "sidearm",
      ammo: 0,
      cooldownTicks: 0,
      shotOrdinal: current.weapon.shotOrdinal,
      lastActionInstanceId: current.weapon.lastActionInstanceId
    };
    actor.grenadeStock = ARCADE.initialGrenades;
    actor.grenadeCooldownTicks = actor.meleeCooldownTicks = actor.reboardCooldownTicks = actor.vehicleSpecialTicks = 0;
    clearAction(actor, tick2);
    return actor;
  }
  function stepPlayerLife(current, tick2, ruleset, context2) {
    validatePlayerLife(current, tick2, ruleset);
    check(context2.frame.tick === tick2, "entry collision tick mismatch");
    context2.index.assertFrame(context2.frame);
    check(
      current.geometryRevision === context2.frame.geometryRevision,
      "life geometry revision mismatch"
    );
    const actor = structuredClone(current);
    actor.invulnerableTicks = Math.max(0, actor.invulnerableTicks - 1);
    actor.reboardCooldownTicks = Math.max(0, actor.reboardCooldownTicks - 1);
    if (actor.life === "death" && tick2 - actor.lifeStartTick >= ARCADE.deathTicks) {
      if (actor.lives === 0) {
        removeBody(actor);
        actor.life = "spectating";
        actor.lifeStartTick = tick2;
        return { actor, notice: notice(actor, tick2, "spectate") };
      }
      const entered = enterPlayer(actor, tick2, ruleset, context2);
      if (entered) return { actor: entered, notice: notice(entered, tick2, "respawn") };
    }
    if (actor.life === "respawning") {
      if (actor.bodyPresence === "removed") {
        const entered = enterPlayer(actor, tick2, ruleset, context2);
        return entered ? { actor: entered, notice: notice(entered, tick2, "respawn") } : { actor, notice: null };
      }
      if (tick2 - actor.lifeStartTick >= ARCADE.respawnEntryTicks) {
        actor.life = "alive";
        actor.lifeStartTick = tick2;
        return { actor, notice: notice(actor, tick2, "ready") };
      }
      if (!stepPassiveBody(actor, context2)) actor.invulnerableTicks = 0;
      return { actor, notice: null };
    }
    if (actor.life === "death") stepPassiveBody(actor, context2);
    return { actor, notice: null };
  }

  // src/shared/protocol/binary.ts
  function bounded2(value, minimum, maximum) {
    if (!Number.isSafeInteger(value) || value < minimum || value > maximum)
      throw new ProtocolError("malformed", `Wire integer outside [${minimum}, ${maximum}]`);
    return value;
  }
  var Writer = class {
    offset = 0;
    bytes;
    view;
    constructor(length2) {
      this.bytes = new Uint8Array(length2);
      this.view = new DataView(this.bytes.buffer);
    }
    u8(value) {
      this.reserve(1);
      this.view.setUint8(this.offset++, bounded2(value, 0, 255));
    }
    u16(value) {
      this.reserve(2);
      this.view.setUint16(this.offset, bounded2(value, 0, 65535), true);
      this.offset += 2;
    }
    u32(value, minimum = 0, maximum = COUNTER_LIMIT - 1) {
      this.reserve(4);
      this.view.setUint32(this.offset, bounded2(value, minimum, maximum), true);
      this.offset += 4;
    }
    i32(value, maximum) {
      this.reserve(4);
      this.view.setInt32(this.offset, bounded2(value, -maximum, maximum), true);
      this.offset += 4;
    }
    bool(value) {
      if (typeof value !== "boolean") throw new ProtocolError("malformed", "Wire boolean required");
      this.u32(value ? 1 : 0);
    }
    optionalId(value) {
      this.u32(value === null ? 0 : value, value === null ? 0 : 1);
    }
    choice(values, value) {
      this.u32(values.indexOf(value), 0, values.length - 1);
    }
    zero(length2) {
      this.reserve(length2);
      this.offset += length2;
    }
    reserve(length2) {
      if (this.offset + length2 > this.bytes.byteLength)
        throw new ProtocolError("malformed", "Wire writer overrun");
    }
  };
  var Reader = class {
    constructor(bytes) {
      this.bytes = bytes;
      this.view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    }
    bytes;
    offset = 0;
    view;
    u8() {
      this.reserve(1);
      return this.view.getUint8(this.offset++);
    }
    u16() {
      this.reserve(2);
      const result = this.view.getUint16(this.offset, true);
      this.offset += 2;
      return result;
    }
    u32(minimum = 0, maximum = COUNTER_LIMIT - 1) {
      this.reserve(4);
      const result = this.view.getUint32(this.offset, true);
      this.offset += 4;
      return bounded2(result, minimum, maximum);
    }
    i32(maximum) {
      this.reserve(4);
      const result = this.view.getInt32(this.offset, true);
      this.offset += 4;
      return bounded2(result, -maximum, maximum);
    }
    bool() {
      return this.u32(0, 1) === 1;
    }
    choice(values) {
      const result = values[this.u32(0, values.length - 1)];
      if (result === void 0) throw new ProtocolError("malformed", "Invalid wire enum");
      return result;
    }
    zero(length2) {
      this.reserve(length2);
      for (let index = 0; index < length2; index++)
        if (this.view.getUint8(this.offset + index) !== 0)
          throw new ProtocolError("malformed", "Nonzero reserved/padding bytes");
      this.offset += length2;
    }
    reserve(length2) {
      if (this.offset + length2 > this.bytes.byteLength)
        throw new ProtocolError("malformed", "Truncated wire record");
    }
  };

  // src/shared/protocol/combat-record.ts
  var COMBAT_HEADER_BYTES = 52;
  var COMBAT_MEMBER_BYTES = 32;
  var AREA_EXPOSURE_BYTES = 48;
  var MAX_AREA_EXPOSURES = 64;
  var DESTRUCTIBLE_BYTES = 24;
  var MAX_DESTRUCTIBLES = 32;
  var MAX_COMBAT_BYTES = 8788 + AREA_EXPOSURE_BYTES * MAX_AREA_EXPOSURES + DESTRUCTIBLE_BYTES * MAX_DESTRUCTIBLES;
  var PHASES = ["active", "complete", "retired", "failed"];
  var STATUSES = ["pending", "alive", "resolved"];
  var RESOLUTIONS = [
    "killed",
    "retreated",
    "crushed",
    "out-of-bounds",
    "ambient-timeout",
    "checkpoint-retired"
  ];
  var FAILURES = ["critical-loss", "forbidden-retreat", "invalid-pose"];
  var CAUSES = [
    "initial-overlap",
    "residual-overlap",
    "contact-limit",
    "unresolved-contact",
    "retreated",
    "crushed",
    "out-of-bounds"
  ];
  function check2(ok, message) {
    if (!ok) throw new ProtocolError("malformed", `Combat baseline: ${message}`);
  }
  function length(members, objectives, kills, volumes, props) {
    check2(Number.isInteger(members) && members >= 0 && members <= 256, "member count");
    check2(Number.isInteger(objectives) && objectives >= 0 && objectives <= 64, "objective count");
    check2(Number.isInteger(kills) && kills >= 1 && kills <= 4, "participant count");
    check2(
      Number.isInteger(volumes) && volumes >= 0 && volumes <= MAX_AREA_EXPOSURES,
      "area volume count"
    );
    check2(Number.isInteger(props) && props >= 0 && props <= MAX_DESTRUCTIBLES, "destructible count");
    return props * DESTRUCTIBLE_BYTES + COMBAT_HEADER_BYTES + members * COMBAT_MEMBER_BYTES + (objectives + kills) * 8 + volumes * AREA_EXPOSURE_BYTES;
  }
  function combatRecordBytes(combat) {
    return combat === null ? 0 : length(
      combat.members.length,
      combat.objectives.length,
      combat.kills.length,
      combat.volumes.length,
      combat.props.length
    );
  }
  function writeTick(w, tick2) {
    w.u32(tick2 === null ? 0 : tick2 + 1, tick2 === null ? 0 : 1);
  }
  function readTick(r) {
    const value = r.u32();
    return value === 0 ? null : value - 1;
  }
  function writeOptional(w, values, value) {
    if (value !== null) check2(values.includes(value), "unknown enum");
    w.u32(value === null ? 0 : values.indexOf(value) + 1, 0, values.length);
  }
  function readOptional(r, values) {
    const index = r.u32(0, values.length);
    return index === 0 ? null : values[index - 1] ?? null;
  }
  function writeCombat(w, combat) {
    w.u16(3);
    w.u16(COMBAT_HEADER_BYTES);
    w.u32(combat.nextEntityId, 1);
    w.u32(combat.nextActionId, 1);
    w.u32(combat.encounterEventCursor, 0, 1024);
    w.u32(combat.encounterId, 1);
    w.choice(PHASES, combat.phase);
    w.u16(combat.members.length);
    w.u16(combat.objectives.length);
    w.u16(combat.kills.length);
    w.u16(combat.volumes.length);
    w.u16(combat.props.length);
    w.zero(2);
    w.optionalId(combat.failure?.id ?? null);
    writeTick(w, combat.failure?.tick ?? null);
    writeOptional(w, FAILURES, combat.failure?.reason ?? null);
    writeOptional(w, CAUSES, combat.failure?.cause ?? null);
    for (const prop of combat.props) {
      w.u32(prop.id, 1);
      w.u32(prop.definitionId, 1);
      w.u32(prop.health, 0, 65535);
      writeTick(w, prop.destroyedTick);
      w.optionalId(prop.destroyerId);
      w.optionalId(prop.destroyActionId);
    }
    for (const member of combat.members) {
      w.u32(member.id, 1);
      for (const flag of [member.required, member.critical, member.retreatAllowed])
        check2(typeof flag === "boolean", "policy flag");
      w.u32(
        Number(member.required) | Number(member.critical) << 1 | Number(member.retreatAllowed) << 2,
        0,
        7
      );
      w.choice(STATUSES, member.status);
      writeTick(w, member.activatedTick);
      writeTick(w, member.resolvedTick);
      writeOptional(w, RESOLUTIONS, member.reason);
      w.optionalId(member.killerId);
      w.zero(4);
    }
    for (const objective of combat.objectives) {
      w.u32(objective.id, 1);
      writeTick(w, objective.completedTick);
    }
    for (const credit of combat.kills) {
      w.u32(credit.playerId, 1);
      w.u32(credit.count, 0, 256);
    }
    for (const volume of combat.volumes) {
      for (const value of [
        volume.id,
        volume.ownerId,
        volume.actionInstanceId,
        volume.definitionId,
        volume.spawnTick,
        volume.endTick
      ])
        w.u32(value, 1);
      w.i32(volume.rect.x, MAX_POSITION);
      w.i32(volume.rect.y, MAX_POSITION);
      w.u32(volume.rect.w, 1, MAX_SHAPE);
      w.u32(volume.rect.h, 1, MAX_SHAPE);
      w.u32(volume.heading, 0, 3);
      w.u16(volume.lobe);
      check2(typeof volume.attached === "boolean", "area attachment flag");
      w.u16(Number(volume.attached));
    }
  }
  function readCombat(r) {
    const start = r.offset;
    check2(r.u16() === 3 && r.u16() === COMBAT_HEADER_BYTES, "section version/header");
    const cursors = {
      nextEntityId: r.u32(1),
      nextActionId: r.u32(1),
      encounterEventCursor: r.u32(0, 1024),
      encounterId: r.u32(1),
      phase: r.choice(PHASES)
    };
    const members = r.u16(), objectives = r.u16(), kills = r.u16(), volumes = r.u16(), props = r.u16();
    r.zero(2);
    check2(
      start + length(members, objectives, kills, volumes, props) === r.bytes.byteLength,
      "section length"
    );
    const id2 = r.u32() || null, tick2 = readTick(r), reason = readOptional(r, FAILURES), cause = readOptional(r, CAUSES);
    check2(
      id2 === null ? tick2 === null && reason === null && cause === null : tick2 !== null && reason !== null && cause !== null,
      "partial failure"
    );
    const combat = {
      ...cursors,
      failure: id2 !== null && tick2 !== null && reason !== null && cause !== null ? { id: id2, tick: tick2, reason, cause } : null,
      props: [],
      members: [],
      objectives: [],
      kills: [],
      volumes: []
    };
    for (let i = 0; i < props; i++)
      combat.props.push({
        id: r.u32(1),
        definitionId: r.u32(1),
        health: r.u32(0, 65535),
        destroyedTick: readTick(r),
        destroyerId: r.u32() || null,
        destroyActionId: r.u32() || null
      });
    for (let i = 0; i < members; i++) {
      const id3 = r.u32(1), flags = r.u32(0, 7);
      combat.members.push({
        id: id3,
        required: Boolean(flags & 1),
        critical: Boolean(flags & 2),
        retreatAllowed: Boolean(flags & 4),
        status: r.choice(STATUSES),
        activatedTick: readTick(r),
        resolvedTick: readTick(r),
        reason: readOptional(r, RESOLUTIONS),
        killerId: r.u32() || null
      });
      r.zero(4);
    }
    for (let i = 0; i < objectives; i++)
      combat.objectives.push({ id: r.u32(1), completedTick: readTick(r) });
    for (let i = 0; i < kills; i++) combat.kills.push({ playerId: r.u32(1), count: r.u32(0, 256) });
    for (let i = 0; i < volumes; i++) {
      const volume = {
        id: r.u32(1),
        ownerId: r.u32(1),
        actionInstanceId: r.u32(1),
        definitionId: r.u32(1),
        spawnTick: r.u32(1),
        endTick: r.u32(1),
        rect: {
          x: r.i32(MAX_POSITION),
          y: r.i32(MAX_POSITION),
          w: r.u32(1, MAX_SHAPE),
          h: r.u32(1, MAX_SHAPE)
        },
        heading: r.u32(0, 3),
        lobe: r.u16(),
        attached: false
      };
      const flag = r.u16();
      check2(flag <= 1, "area attachment flag");
      volume.attached = flag === 1;
      combat.volumes.push(volume);
    }
    return combat;
  }
  function validateCombat(snapshot) {
    const combat = snapshot.combat;
    if (combat === null) return;
    combatRecordBytes(combat);
    check2(combat.encounterId === snapshot.campaign.encounterId, "encounter identity");
    function ordered3(ids2) {
      check2(
        ids2.every(
          (id2, i) => Number.isSafeInteger(id2) && id2 > 0 && id2 < COUNTER_LIMIT && (i === 0 || id2 > (ids2[i - 1] ?? 0))
        ),
        "unordered/duplicate IDs"
      );
    }
    ordered3(combat.props.map((p) => p.id));
    ordered3(combat.members.map((m) => m.id));
    ordered3(combat.objectives.map((o) => o.id));
    ordered3(combat.kills.map((k) => k.playerId));
    const participants = new Set(snapshot.players.map((p) => p.playerId));
    const areaOwners = /* @__PURE__ */ new Map();
    const areaActions = /* @__PURE__ */ new Map();
    for (const [index, volume] of combat.volumes.entries()) {
      const previous = combat.volumes[index - 1];
      check2(
        !previous || volume.id > previous.id || volume.id === previous.id && volume.lobe > previous.lobe,
        "unordered/duplicate area exposures"
      );
      check2(
        participants.has(volume.ownerId) && volume.lobe >= 0 && volume.lobe < 4,
        "area owner/lobe"
      );
      check2(
        volume.spawnTick <= snapshot.tick && snapshot.tick < volume.endTick && volume.endTick - volume.spawnTick <= 120,
        "area lifetime"
      );
      check2(
        Math.abs(volume.rect.x + volume.rect.w) <= MAX_POSITION && Math.abs(volume.rect.y + volume.rect.h) <= MAX_POSITION,
        "area endpoint bounds"
      );
      check2(
        ![
          ...snapshot.players.map((p) => p.body.id),
          ...combat.members.map((m) => m.id),
          ...snapshot.removedIds,
          ...snapshot.enemies.map((e) => e.id),
          ...snapshot.projectiles.map((p) => p.id),
          ...snapshot.vehicles.map((v) => v.body.id),
          ...snapshot.platforms.map((p) => p.id)
        ].includes(volume.id),
        "area entity collision"
      );
      const owner = `${volume.ownerId}/${volume.actionInstanceId}/${volume.definitionId}`;
      check2(
        !areaOwners.has(volume.id) || areaOwners.get(volume.id) === owner,
        "area source ownership"
      );
      areaOwners.set(volume.id, owner);
      check2(
        !areaActions.has(volume.actionInstanceId) || areaActions.get(volume.actionInstanceId) === volume.id,
        "duplicate area action"
      );
      areaActions.set(volume.actionInstanceId, volume.id);
    }
    check2(
      combat.kills.length === participants.size && combat.kills.every((k) => participants.has(k.playerId)),
      "participant roster"
    );
    function time(value) {
      check2(
        value === null || Number.isSafeInteger(value) && value >= 0 && value <= snapshot.tick && value < COUNTER_LIMIT - 1,
        "future/invalid tick"
      );
    }
    const propOwners = /* @__PURE__ */ new Set([...participants, ...combat.members.map((m) => m.id)]);
    for (const prop of combat.props) {
      time(prop.destroyedTick);
      check2(prop.id < combat.nextEntityId, "unallocated prop identity");
      check2(
        Number.isSafeInteger(prop.health) && prop.health >= 0 && prop.health <= 65535,
        "prop health"
      );
      check2(
        Number.isSafeInteger(prop.definitionId) && prop.definitionId > 0 && prop.definitionId < COUNTER_LIMIT,
        "prop definition"
      );
      check2(prop.health === 0 === snapshot.removedIds.includes(prop.id), "prop removal mismatch");
      check2(
        ![
          ...combat.members.map((m) => m.id),
          ...participants,
          ...snapshot.vehicles.map((v) => v.body.id),
          ...snapshot.projectiles.map((p) => p.id),
          ...snapshot.platforms.map((p) => p.id),
          ...combat.volumes.map((v) => v.id)
        ].includes(prop.id),
        "prop identity reused"
      );
      check2(
        prop.health > 0 ? prop.destroyedTick === null && prop.destroyerId === null && prop.destroyActionId === null : prop.destroyedTick !== null && prop.destroyedTick > 0 && prop.destroyerId !== null && propOwners.has(prop.destroyerId) && Number.isSafeInteger(prop.destroyActionId) && (prop.destroyActionId ?? 0) > 0 && (prop.destroyActionId ?? COUNTER_LIMIT) < combat.nextActionId,
        "prop destruction attribution"
      );
    }
    for (const m of combat.members) {
      time(m.activatedTick);
      time(m.resolvedTick);
      check2(!m.critical || m.required && !m.retreatAllowed, "critical policy");
      check2(
        m.status === "resolved" === (m.reason !== null) && m.status === "resolved" === (m.resolvedTick !== null),
        "resolution state"
      );
      check2(m.status !== "pending" || m.activatedTick === null, "pending activation");
      check2(m.status !== "alive" || m.activatedTick !== null, "missing activation");
      check2(
        m.status !== "resolved" || m.reason === "checkpoint-retired" || m.activatedTick !== null,
        "unactivated resolution"
      );
      check2(
        m.activatedTick === null || m.resolvedTick === null || m.activatedTick <= m.resolvedTick,
        "resolution before activation"
      );
      check2(
        m.killerId === null || m.reason === "killed" && participants.has(m.killerId),
        "kill attribution"
      );
      check2(
        m.reason !== "ambient-timeout" || !m.required && !m.critical,
        "required ambient cleanup"
      );
      check2(m.reason !== "checkpoint-retired" || combat.phase === "retired", "retirement phase");
      check2(
        m.status !== "resolved" || !snapshot.enemies.some((e) => e.id === m.id && e.health > 0),
        "resolved enemy still alive"
      );
    }
    for (const o of combat.objectives) time(o.completedTick);
    for (const k of combat.kills)
      check2(
        k.count === combat.members.filter((m) => m.reason === "killed" && m.killerId === k.playerId).length,
        "kill count mismatch"
      );
    const remaining = combat.phase === "retired" ? 0 : combat.members.filter((m) => m.required && m.status !== "resolved").length + combat.objectives.filter((o) => o.completedTick === null).length;
    check2(remaining === snapshot.campaign.remainingEnemies, "remaining count mismatch");
    check2(combat.phase !== "complete" || remaining === 0, "premature completion");
    check2(
      combat.phase !== "retired" || combat.members.every((m) => m.status === "resolved"),
      "incomplete retirement"
    );
    check2(combat.phase === "failed" === (combat.failure !== null), "failure state");
    if (combat.failure !== null) {
      time(combat.failure.tick);
      check2(
        combat.members.some((m) => m.id === combat.failure?.id),
        "unknown failure owner"
      );
    }
    const entityIds = [
      ...snapshot.players.map((p) => p.body.id),
      ...snapshot.vehicles.map((v) => v.body.id),
      ...snapshot.enemies.map((e) => e.id),
      ...snapshot.projectiles.flatMap((p) => [p.id, p.ownerId]),
      ...snapshot.platforms.map((p) => p.id),
      ...snapshot.threats.map((t) => t.sourceId),
      ...snapshot.removedIds,
      ...combat.members.map((m) => m.id),
      ...combat.volumes.map((volume) => volume.id)
    ];
    const actionIds = [
      ...snapshot.players.flatMap((p) => [p.action.actionInstanceId, p.weapon.lastActionInstanceId]),
      ...snapshot.vehicles.flatMap((v) => [v.action.actionInstanceId, v.weapon.lastActionInstanceId]),
      ...snapshot.enemies.map((e) => e.actionInstanceId),
      ...snapshot.projectiles.map((p) => p.actionInstanceId),
      ...snapshot.threats.map((t) => t.actionInstanceId),
      ...combat.volumes.map((volume) => volume.actionInstanceId)
    ];
    check2(combat.nextEntityId > Math.max(0, ...entityIds), "entity allocator reused ID");
    check2(combat.nextActionId > Math.max(0, ...actionIds), "action allocator reused ID");
  }

  // src/shared/protocol/controller-record.ts
  var CONTACTS = ["solid", "one-way", "platform"];
  var ACTIONS = ["ready", "fire", "melee", "grenade", "enter", "exit", "hurt"];
  var WEAPONS = [
    "sidearm",
    "heavy-machine-gun",
    "shotgun",
    "rocket-launcher",
    "flamethrower",
    "laser"
  ];
  var LIFE = ["alive", "death", "respawning", "spectating"];
  var BODY_PRESENCE = ["present", "removed"];
  var LOCOMOTION = ["grounded", "airborne", "crouched", "seated"];
  var VEHICLES = ["tank", "walker", "aircraft"];
  var LIFECYCLE = ["available", "boarding", "occupied", "exiting", "destroying", "wreck"];
  function writeBody(writer, body4) {
    writer.u32(body4.id, 1);
    writer.i32(body4.x, MAX_POSITION);
    writer.i32(body4.y, MAX_POSITION);
    writer.i32(body4.vx, MAX_MOTION);
    writer.i32(body4.vy, MAX_MOTION);
    writer.i32(body4.remainderX, MAX_MOTION * 2 - 1);
    writer.i32(body4.remainderY, MAX_MOTION * 2 - 1);
    writer.u32(body4.shapeId, 1, 65535);
    writer.optionalId(body4.supportId);
    writer.bool(body4.grounded);
    writer.u32(body4.contacts.length, 0, 4);
    for (const contact of body4.contacts) {
      writer.u32(contact.otherId, 1);
      writer.i32(contact.normalX, 1);
      writer.i32(contact.normalY, 1);
      writer.u32(contact.toiNumerator, 0, 2 ** 26);
      writer.u32(contact.toiDenominator, 1, 2 ** 17);
      writer.choice(CONTACTS, contact.kind);
    }
    writer.zero((4 - body4.contacts.length) * 24);
  }
  function readBody(reader) {
    const body4 = {
      id: reader.u32(1),
      x: reader.i32(MAX_POSITION),
      y: reader.i32(MAX_POSITION),
      vx: reader.i32(MAX_MOTION),
      vy: reader.i32(MAX_MOTION),
      remainderX: reader.i32(MAX_MOTION * 2 - 1),
      remainderY: reader.i32(MAX_MOTION * 2 - 1),
      shapeId: reader.u32(1, 65535),
      supportId: reader.u32() || null,
      grounded: reader.bool(),
      contacts: []
    };
    const count = reader.u32(0, 4);
    for (let index = 0; index < count; index++)
      body4.contacts.push({
        otherId: reader.u32(1),
        normalX: reader.i32(1),
        normalY: reader.i32(1),
        toiNumerator: reader.u32(0, 2 ** 26),
        toiDenominator: reader.u32(1, 2 ** 17),
        kind: reader.choice(CONTACTS)
      });
    reader.zero((4 - count) * 24);
    return body4;
  }
  function writeAction(writer, action2) {
    writer.choice(ACTIONS, action2.kind);
    writer.u32(action2.actionInstanceId);
    writer.u32(action2.stateStartTick);
    writer.u32(action2.definitionId, 0, 65535);
    writer.u32(action2.nextMarkerIndex, 0, 128);
  }
  function readAction(reader) {
    return {
      kind: reader.choice(ACTIONS),
      actionInstanceId: reader.u32(),
      stateStartTick: reader.u32(),
      definitionId: reader.u32(0, 65535),
      nextMarkerIndex: reader.u32(0, 128)
    };
  }
  function writeWeapon(writer, weapon2) {
    writer.choice(WEAPONS, weapon2.id);
    writer.u32(weapon2.ammo, 0, 65535);
    writer.u32(weapon2.cooldownTicks, 0, 65535);
    writer.u32(weapon2.shotOrdinal);
    writer.u32(weapon2.lastActionInstanceId);
  }
  function readWeapon(reader) {
    return {
      id: reader.choice(WEAPONS),
      ammo: reader.u32(0, 65535),
      cooldownTicks: reader.u32(0, 65535),
      shotOrdinal: reader.u32(),
      lastActionInstanceId: reader.u32()
    };
  }
  function writePlayer(writer, player2) {
    writeBody(writer, player2.body);
    writer.u32(player2.playerId, 1);
    writer.u32(player2.slot, 0, 3);
    writer.u32(player2.controlEpoch, 1);
    writer.choice(LIFE, player2.life);
    writer.u32(player2.lifeStartTick);
    writer.choice(BODY_PRESENCE, player2.bodyPresence);
    writer.choice(LOCOMOTION, player2.locomotion);
    writeAction(writer, player2.action);
    writer.i32(player2.facing, 1);
    writer.u32(player2.aim, 0, 2);
    writer.i32(player2.firearmAim.pitch, 4);
    writer.u32(player2.firearmAim.nextStepTick);
    writer.u32(player2.jumpBufferTicks, 0, 65535);
    writer.u32(player2.coyoteTicks, 0, 65535);
    writer.optionalId(player2.ignoredSupportId);
    writer.u32(player2.ignoredSupportTicks, 0, 65535);
    writer.u32(player2.invulnerableTicks, 0, 65535);
    writer.u32(player2.reboardCooldownTicks, 0, 65535);
    writer.u32(player2.vehicleSpecialTicks, 0, 65535);
    writer.optionalId(player2.vehicleId);
    writeWeapon(writer, player2.weapon);
    writer.u32(player2.grenadeStock, 0, 65535);
    writer.u32(player2.grenadeCooldownTicks, 0, 65535);
    writer.u32(player2.meleeCooldownTicks, 0, 65535);
    writer.u32(player2.geometryRevision, 1);
    writer.u32(player2.health, 0, 65535);
    writer.u32(player2.lives, 0, 65535);
    writer.u32(player2.lastRallyMission, 0, 65535);
    if (player2.processedEdgeIds.length !== 5)
      throw new ProtocolError("malformed", "Five controller edge cursors required");
    for (const edge of player2.processedEdgeIds) writer.u32(edge);
  }
  function readPlayer(reader) {
    return {
      body: readBody(reader),
      playerId: reader.u32(1),
      slot: reader.u32(0, 3),
      controlEpoch: reader.u32(1),
      life: reader.choice(LIFE),
      lifeStartTick: reader.u32(),
      bodyPresence: reader.choice(BODY_PRESENCE),
      locomotion: reader.choice(LOCOMOTION),
      action: readAction(reader),
      facing: reader.i32(1),
      aim: reader.u32(0, 2),
      firearmAim: { pitch: reader.i32(4), nextStepTick: reader.u32() },
      jumpBufferTicks: reader.u32(0, 65535),
      coyoteTicks: reader.u32(0, 65535),
      ignoredSupportId: reader.u32() || null,
      ignoredSupportTicks: reader.u32(0, 65535),
      invulnerableTicks: reader.u32(0, 65535),
      reboardCooldownTicks: reader.u32(0, 65535),
      vehicleSpecialTicks: reader.u32(0, 65535),
      vehicleId: reader.u32() || null,
      weapon: readWeapon(reader),
      grenadeStock: reader.u32(0, 65535),
      grenadeCooldownTicks: reader.u32(0, 65535),
      meleeCooldownTicks: reader.u32(0, 65535),
      geometryRevision: reader.u32(1),
      health: reader.u32(0, 65535),
      lives: reader.u32(0, 65535),
      lastRallyMission: reader.u32(0, 65535),
      processedEdgeIds: [reader.u32(), reader.u32(), reader.u32(), reader.u32(), reader.u32()]
    };
  }
  function writeVehicle(writer, vehicle) {
    writeBody(writer, vehicle.body);
    writer.u32(vehicle.definitionId, 1, 65535);
    writer.choice(VEHICLES, vehicle.kind);
    writer.choice(LIFECYCLE, vehicle.lifecycle);
    writer.optionalId(vehicle.occupantId);
    writer.optionalId(vehicle.reservedBy);
    writer.u32(vehicle.controlEpoch, 1);
    writer.u32(vehicle.armor, 0, 65535);
    writeAction(writer, vehicle.action);
    writeWeapon(writer, vehicle.weapon);
    writer.u32(vehicle.components.length, 0, 8);
    for (const component of vehicle.components) {
      writer.u32(component.id, 1);
      writer.u32(component.health, 0, 65535);
      writer.bool(component.broken);
    }
    writer.zero((8 - vehicle.components.length) * 12);
    writer.optionalId(vehicle.ownerControlEpoch);
    writer.i32(vehicle.facing, 1);
    writer.u32(vehicle.heading, 0, 7);
    writer.u32(vehicle.invulnerableTicks, 0, 65535);
  }
  function readVehicle(reader) {
    const vehicle = {
      body: readBody(reader),
      definitionId: reader.u32(1, 65535),
      kind: reader.choice(VEHICLES),
      lifecycle: reader.choice(LIFECYCLE),
      occupantId: reader.u32() || null,
      reservedBy: reader.u32() || null,
      controlEpoch: reader.u32(1),
      ownerControlEpoch: null,
      facing: 1,
      heading: 0,
      invulnerableTicks: 0,
      armor: reader.u32(0, 65535),
      action: readAction(reader),
      weapon: readWeapon(reader),
      components: []
    };
    const count = reader.u32(0, 8);
    for (let index = 0; index < count; index++)
      vehicle.components.push({
        id: reader.u32(1),
        health: reader.u32(0, 65535),
        broken: reader.bool()
      });
    reader.zero((8 - count) * 12);
    vehicle.ownerControlEpoch = reader.u32() || null;
    vehicle.facing = reader.i32(1);
    vehicle.heading = reader.u32(0, 7);
    vehicle.invulnerableTicks = reader.u32(0, 65535);
    return vehicle;
  }

  // src/shared/protocol/snapshot-schema.ts
  var ROOM_MODES = [
    "lobby",
    "loading",
    "playing",
    "intermission",
    "paused-empty",
    "recovering",
    "completed",
    "expired"
  ];
  var SNAPSHOT_TYPE = 2;
  var SNAPSHOT_HEADER_BYTES = 64;
  var CAMPAIGN_BYTES = 40;
  var BODY_BYTES = 140;
  var PLAYER_BYTES = 304;
  var VEHICLE_BYTES = 324;
  var ENEMY_BYTES = 64;
  var PROJECTILE_BYTES = 48;
  var PLATFORM_BYTES = 32;
  var THREAT_BYTES = 64;
  var SNAPSHOT_CAPS = {
    players: 4,
    vehicles: 16,
    enemies: 128,
    projectiles: 256,
    platforms: 64,
    threats: 128,
    removedIds: 512
  };
  var MIN_SNAPSHOT_BYTES = 448;
  var MAX_BASE_SNAPSHOT_BYTES = 39432;
  var MAX_SNAPSHOT_BYTES = MAX_BASE_SNAPSHOT_BYTES + MAX_COMBAT_BYTES;

  // src/shared/protocol/snapshot.ts
  var RULESETS = ["classic", "accessible"];
  var PHASES2 = ["playing", "wipe", "intermission", "victory", "defeat"];
  var THREAT_MOTION = ["linear", "locked", "authored"];
  function check3(condition, message) {
    if (!condition) throw new ProtocolError("malformed", message);
  }
  function frameLength(counts) {
    for (const key of Object.keys(SNAPSHOT_CAPS))
      check3(
        Number.isInteger(counts[key]) && counts[key] >= (key === "players" ? 1 : 0) && counts[key] <= SNAPSHOT_CAPS[key],
        `Invalid ${key} snapshot count`
      );
    return SNAPSHOT_HEADER_BYTES + CAMPAIGN_BYTES + counts.players * (PLAYER_BYTES + ACK_BYTES) + counts.vehicles * VEHICLE_BYTES + counts.enemies * ENEMY_BYTES + counts.projectiles * PROJECTILE_BYTES + counts.platforms * PLATFORM_BYTES + counts.threats * THREAT_BYTES + counts.removedIds * 4;
  }
  function ordered(ids2, label) {
    for (let index = 1; index < ids2.length; index++)
      check3((ids2[index] ?? 0) > (ids2[index - 1] ?? 0), `Unordered/duplicate ${label}`);
  }
  function validate2(snapshot, context2) {
    validateCombat(snapshot);
    context2.validateGeometry?.(snapshot);
    if (snapshot.runEpoch !== context2.runEpoch || snapshot.connectionEpoch !== context2.connectionEpoch)
      throw new ProtocolError("identity-mismatch", "Snapshot belongs to another run/socket");
    if (snapshot.geometryRevision !== context2.geometryRevision && !context2.geometryRevisions?.has(snapshot.geometryRevision))
      throw new ProtocolError("resync-required", "Snapshot geometry is not loaded");
    check3(
      snapshot.acknowledgments.length === snapshot.players.length,
      "Missing player acknowledgments"
    );
    const shape = (id2) => {
      if (!context2.shapeIds.has(id2))
        throw new ProtocolError("resync-required", "Snapshot shape is not loaded");
    };
    const ids2 = [];
    const groups = [
      snapshot.players.map((p) => p.body.id),
      snapshot.vehicles.map((v) => v.body.id),
      snapshot.enemies.map((e) => e.id),
      snapshot.projectiles.map((p) => p.id),
      snapshot.platforms.map((p) => p.id),
      snapshot.combat?.props.filter((p) => p.health > 0).map((p) => p.id) ?? []
    ];
    for (const group of groups) {
      ordered(group, "entity IDs");
      ids2.push(...group);
    }
    const liveIds = new Set(ids2);
    check3(liveIds.size === ids2.length, "Entity ID reused across snapshot sections");
    ordered(snapshot.removedIds, "removal IDs");
    check3(
      snapshot.removedIds.every((id2) => !liveIds.has(id2)),
      "Live entity also removed"
    );
    ordered(
      snapshot.threats.map((threat) => threat.actionInstanceId),
      "threat action IDs"
    );
    check3(
      new Set(snapshot.players.map((p) => p.playerId)).size === snapshot.players.length && new Set(snapshot.players.map((p) => p.slot)).size === snapshot.players.length,
      "Duplicate player/slot"
    );
    check3(
      snapshot.players.some((p) => p.playerId === context2.playerId),
      "Local player missing from baseline"
    );
    const removed = new Set(snapshot.removedIds);
    function body4(value) {
      check3(value.contacts.length <= 4, "Contact count limit");
      shape(value.shapeId);
      check3(value.grounded === (value.supportId !== null), "Ground/support mismatch");
      if (value.supportId !== null)
        check3(!removed.has(value.supportId), "Body stands on removed support");
      const keys = /* @__PURE__ */ new Set();
      for (const contact of value.contacts) {
        check3(
          Math.abs(contact.normalX) + Math.abs(contact.normalY) === 1,
          "Noncardinal contact normal"
        );
        check3(contact.toiNumerator <= contact.toiDenominator, "Contact outside tick interval");
        check3(!removed.has(contact.otherId), "Contact with removed geometry");
        const key = `${contact.otherId}:${contact.normalX}:${contact.normalY}`;
        check3(!keys.has(key), "Duplicate contact");
        keys.add(key);
      }
    }
    function action2(value) {
      check3(value.stateStartTick <= snapshot.tick, "Future action state");
      if (value.kind !== "ready")
        check3(value.actionInstanceId > 0 && value.definitionId > 0, "Active action has no identity");
    }
    for (const [index, player2] of snapshot.players.entries()) {
      body4(player2.body);
      action2(player2.action);
      check3(player2.lifeStartTick <= snapshot.tick, "Future life phase");
      check3(validBodyPresence(player2), "Inconsistent body presence");
      check3(
        player2.firearmAim.nextStepTick <= snapshot.tick + 60,
        "Future firearm turn exceeds content bound"
      );
      check3(player2.facing === -1 || player2.facing === 1, "Invalid facing");
      check3(player2.geometryRevision === snapshot.geometryRevision, "Controller geometry mismatch");
      check3(
        player2.locomotion === "seated" === (player2.vehicleId !== null),
        "Controller seat mismatch"
      );
      if (player2.ignoredSupportId !== null)
        check3(!removed.has(player2.ignoredSupportId), "Ignored support has been removed");
      const ack = snapshot.acknowledgments[index];
      check3(
        Boolean(ack && ack.playerId === player2.playerId && ack.controlEpoch === player2.controlEpoch),
        "Controller/acknowledgment identity mismatch"
      );
      if (!ack) throw new ProtocolError("malformed", "Missing acknowledgment");
      if (player2.playerId === context2.playerId && ack.connectionEpoch !== context2.connectionEpoch)
        throw new ProtocolError("identity-mismatch", "Local acknowledgment socket mismatch");
      check3(ack.appliedAtServerTick <= snapshot.tick, "Acknowledgment is in the future");
      check3(
        ack.lastProcessedSequence !== 0 || ack.appliedAtServerTick === 0 && ack.processedEdgeIds.every((value) => value === 0),
        "Unprocessed command has processing cursors"
      );
      check3(
        ack.processedEdgeIds.length === 5 && ack.processedEdgeIds.every((value, edge) => value === player2.processedEdgeIds[edge]),
        "Controller/acknowledgment edge mismatch"
      );
      if (player2.vehicleId !== null) {
        const vehicle = snapshot.vehicles.find((v) => v.body.id === player2.vehicleId);
        check3(
          Boolean(
            vehicle && (vehicle.occupantId ?? vehicle.reservedBy) === player2.body.id && vehicle.ownerControlEpoch === player2.controlEpoch
          ),
          "Unowned controller vehicle"
        );
      }
    }
    const seatClaims = /* @__PURE__ */ new Set();
    for (const vehicle of snapshot.vehicles) {
      check3(vehicle.facing === -1 || vehicle.facing === 1, "Invalid vehicle facing");
      check3(
        vehicle.ownerControlEpoch !== null === (vehicle.occupantId !== null || vehicle.reservedBy !== null),
        "Vehicle owner input generation mismatch"
      );
      check3(vehicle.components.length <= 8, "Vehicle component count limit");
      body4(vehicle.body);
      action2(vehicle.action);
      ordered(
        vehicle.components.map((component) => component.id),
        "vehicle components"
      );
      check3(
        vehicle.occupantId === null || vehicle.reservedBy === null,
        "Occupied seat is also reserved"
      );
      check3(
        vehicle.occupantId === null ? !["occupied", "exiting"].includes(vehicle.lifecycle) : ["occupied", "exiting", "destroying"].includes(vehicle.lifecycle),
        "Vehicle occupancy lifecycle mismatch"
      );
      check3(
        vehicle.lifecycle === "boarding" === (vehicle.reservedBy !== null),
        "Vehicle reservation lifecycle mismatch"
      );
      for (const id2 of [vehicle.occupantId, vehicle.reservedBy]) {
        if (id2 !== null) {
          check3(!seatClaims.has(id2), "Member claims multiple vehicle seats");
          check3(
            snapshot.players.some(
              (p) => p.body.id === id2 && p.life === "alive" && p.vehicleId === vehicle.body.id && p.controlEpoch === vehicle.ownerControlEpoch
            ),
            "Unknown vehicle member"
          );
          seatClaims.add(id2);
        }
      }
      if (vehicle.occupantId !== null)
        check3(
          snapshot.players.some(
            (p) => p.body.id === vehicle.occupantId && p.vehicleId === vehicle.body.id
          ),
          "Vehicle occupant is elsewhere"
        );
    }
    for (const enemy of snapshot.enemies) {
      shape(enemy.shapeId);
      check3(enemy.facing === -1 || enemy.facing === 1, "Invalid enemy facing");
      check3(
        enemy.stateStartTick <= snapshot.tick && enemy.geometryRevision === snapshot.geometryRevision,
        "Enemy state/geometry mismatch"
      );
      if (enemy.supportId !== null)
        check3(!removed.has(enemy.supportId), "Enemy stands on removed geometry");
    }
    for (const projectile of snapshot.projectiles) {
      shape(projectile.shapeId);
      check3(projectile.spawnTick <= snapshot.tick, "Future projectile spawn");
    }
    for (const platform of snapshot.platforms) shape(platform.shapeId);
    for (const threat of snapshot.threats) {
      shape(threat.shapeId);
      check3(
        threat.telegraphTick <= threat.activeTick && threat.activeTick < threat.endTick,
        "Invalid threat activation interval"
      );
    }
  }
  function writeAck(w, ack) {
    w.u32(ack.playerId, 1);
    w.u32(ack.connectionEpoch, 1);
    w.u32(ack.controlEpoch, 1);
    w.u32(ack.lastProcessedSequence);
    w.u32(ack.appliedAtServerTick);
    check3(ack.processedEdgeIds.length === 5, "Five acknowledgment edge cursors required");
    for (const value of ack.processedEdgeIds) w.u32(value);
  }
  function readAck(r) {
    return {
      playerId: r.u32(1),
      connectionEpoch: r.u32(1),
      controlEpoch: r.u32(1),
      lastProcessedSequence: r.u32(),
      appliedAtServerTick: r.u32(),
      processedEdgeIds: [r.u32(), r.u32(), r.u32(), r.u32(), r.u32()]
    };
  }
  function writeEnemy(w, e) {
    w.u32(e.id, 1);
    w.u32(e.definitionId, 1, 65535);
    w.i32(e.x, MAX_POSITION);
    w.i32(e.y, MAX_POSITION);
    w.i32(e.vx, MAX_MOTION);
    w.i32(e.vy, MAX_MOTION);
    w.u32(e.shapeId, 1, 65535);
    w.i32(e.facing, 1);
    w.u32(e.health, 0, 65535);
    w.u32(e.mode, 0, 31);
    w.u32(e.stateStartTick);
    w.u32(e.actionInstanceId);
    w.u32(e.actionDefinitionId, 0, 65535);
    w.u32(e.modeTicks, 0, 65535);
    w.optionalId(e.supportId);
    w.u32(e.geometryRevision, 1);
  }
  function readEnemy(r) {
    return {
      id: r.u32(1),
      definitionId: r.u32(1, 65535),
      x: r.i32(MAX_POSITION),
      y: r.i32(MAX_POSITION),
      vx: r.i32(MAX_MOTION),
      vy: r.i32(MAX_MOTION),
      shapeId: r.u32(1, 65535),
      facing: r.i32(1),
      health: r.u32(0, 65535),
      mode: r.u32(0, 31),
      stateStartTick: r.u32(),
      actionInstanceId: r.u32(),
      actionDefinitionId: r.u32(0, 65535),
      modeTicks: r.u32(0, 65535),
      supportId: r.u32() || null,
      geometryRevision: r.u32(1)
    };
  }
  function writeProjectile(w, p) {
    w.u32(p.id, 1);
    w.u32(p.ownerId, 1);
    w.u32(p.actionInstanceId, 1);
    w.u32(p.definitionId, 1, 65535);
    w.i32(p.x, MAX_POSITION);
    w.i32(p.y, MAX_POSITION);
    w.i32(p.vx, MAX_MOTION);
    w.i32(p.vy, MAX_MOTION);
    w.u32(p.spawnTick);
    w.u32(p.lifetimeTicks, 1, 65535);
    w.u32(p.heading, 0, 255);
    w.u32(p.shapeId, 1, 65535);
  }
  function readProjectile(r) {
    return {
      id: r.u32(1),
      ownerId: r.u32(1),
      actionInstanceId: r.u32(1),
      definitionId: r.u32(1, 65535),
      x: r.i32(MAX_POSITION),
      y: r.i32(MAX_POSITION),
      vx: r.i32(MAX_MOTION),
      vy: r.i32(MAX_MOTION),
      spawnTick: r.u32(),
      lifetimeTicks: r.u32(1, 65535),
      heading: r.u32(0, 255),
      shapeId: r.u32(1, 65535)
    };
  }
  function writePlatform(w, p) {
    w.u32(p.id, 1);
    w.i32(p.x, MAX_POSITION);
    w.i32(p.y, MAX_POSITION);
    w.i32(p.vx, MAX_MOTION);
    w.i32(p.vy, MAX_MOTION);
    w.u32(p.shapeId, 1, 65535);
    w.u32(p.trajectoryId, 0, 65535);
    w.u32(p.trajectoryTick);
  }
  function readPlatform(r) {
    return {
      id: r.u32(1),
      x: r.i32(MAX_POSITION),
      y: r.i32(MAX_POSITION),
      vx: r.i32(MAX_MOTION),
      vy: r.i32(MAX_MOTION),
      shapeId: r.u32(1, 65535),
      trajectoryId: r.u32(0, 65535),
      trajectoryTick: r.u32()
    };
  }
  function writeThreat(w, t) {
    w.u32(t.actionInstanceId, 1);
    w.u32(t.sourceId, 1);
    w.u32(t.definitionId, 1, 65535);
    w.u32(t.telegraphTick);
    w.u32(t.activeTick);
    w.u32(t.endTick);
    w.i32(t.x, MAX_POSITION);
    w.i32(t.y, MAX_POSITION);
    w.i32(t.vx, MAX_MOTION);
    w.i32(t.vy, MAX_MOTION);
    w.u32(t.heading, 0, 255);
    w.optionalId(t.targetId);
    w.choice(THREAT_MOTION, t.motion);
    w.bool(t.cancelled);
    w.u32(t.stateVersion, 1);
    w.u32(t.shapeId, 1, 65535);
  }
  function readThreat(r) {
    return {
      actionInstanceId: r.u32(1),
      sourceId: r.u32(1),
      definitionId: r.u32(1, 65535),
      telegraphTick: r.u32(),
      activeTick: r.u32(),
      endTick: r.u32(),
      x: r.i32(MAX_POSITION),
      y: r.i32(MAX_POSITION),
      vx: r.i32(MAX_MOTION),
      vy: r.i32(MAX_MOTION),
      heading: r.u32(0, 255),
      targetId: r.u32() || null,
      motion: r.choice(THREAT_MOTION),
      cancelled: r.bool(),
      stateVersion: r.u32(1),
      shapeId: r.u32(1, 65535)
    };
  }
  function encodeSnapshot(snapshot, context2) {
    const counts = {
      players: snapshot.players.length,
      vehicles: snapshot.vehicles.length,
      enemies: snapshot.enemies.length,
      projectiles: snapshot.projectiles.length,
      platforms: snapshot.platforms.length,
      threats: snapshot.threats.length,
      removedIds: snapshot.removedIds.length
    };
    const length2 = frameLength(counts) + combatRecordBytes(snapshot.combat);
    validate2(snapshot, context2);
    const w = new Writer(length2);
    w.u16(MAGIC);
    w.u8(PROTOCOL_MAJOR);
    w.u8(PROTOCOL_MINOR);
    w.u8(SNAPSHOT_TYPE);
    w.u8(snapshot.combat === null ? 0 : 1);
    w.u16(length2);
    w.u32(snapshot.runEpoch, 1);
    w.u32(snapshot.connectionEpoch, 1);
    w.u32(snapshot.snapshotId, 1);
    w.u32(snapshot.tick);
    w.u32(snapshot.baselineEventCursor);
    w.u32(snapshot.geometryRevision, 1);
    w.u32(snapshot.stateHash, 0, 4294967295);
    w.u8(counts.players);
    w.u8(counts.vehicles);
    w.u16(counts.enemies);
    w.u16(counts.projectiles);
    w.u16(counts.platforms);
    w.u16(counts.threats);
    w.u16(counts.removedIds);
    w.u8(ROOM_MODES.indexOf(snapshot.roomMode));
    w.zero(15);
    w.i32(snapshot.camera.x, MAX_POSITION);
    w.i32(snapshot.camera.y, MAX_POSITION);
    w.choice(RULESETS, snapshot.campaign.ruleset);
    w.u32(snapshot.campaign.mission, 1, 255);
    w.u32(snapshot.campaign.checkpointId, 1);
    w.u32(snapshot.campaign.continuesRemaining, 0, 65535);
    w.u32(snapshot.campaign.continuesUsed, 0, 65535);
    w.choice(PHASES2, snapshot.campaign.phase);
    w.u32(snapshot.campaign.encounterId, 1);
    w.u32(snapshot.campaign.remainingEnemies, 0, 320);
    for (const ack of snapshot.acknowledgments) writeAck(w, ack);
    for (const player2 of snapshot.players) writePlayer(w, player2);
    for (const vehicle of snapshot.vehicles) writeVehicle(w, vehicle);
    for (const enemy of snapshot.enemies) writeEnemy(w, enemy);
    for (const projectile of snapshot.projectiles) writeProjectile(w, projectile);
    for (const platform of snapshot.platforms) writePlatform(w, platform);
    for (const threat of snapshot.threats) writeThreat(w, threat);
    for (const id2 of snapshot.removedIds) w.u32(id2, 1);
    if (snapshot.combat !== null) writeCombat(w, snapshot.combat);
    check3(w.offset === length2, "Snapshot encoder record size mismatch");
    return w.bytes;
  }
  function decodeSnapshot(bytes, context2) {
    check3(
      bytes.byteLength >= MIN_SNAPSHOT_BYTES && bytes.byteLength <= MAX_SNAPSHOT_BYTES,
      "Snapshot size limit"
    );
    const r = new Reader(bytes);
    check3(
      r.u16() === MAGIC && r.u8() === PROTOCOL_MAJOR && r.u8() === PROTOCOL_MINOR && r.u8() === SNAPSHOT_TYPE,
      "Snapshot frame header"
    );
    const flags = r.u8();
    check3(flags <= 1 && r.u16() === bytes.byteLength, "Snapshot frame header");
    const header = {
      runEpoch: r.u32(1),
      connectionEpoch: r.u32(1),
      snapshotId: r.u32(1),
      tick: r.u32(),
      baselineEventCursor: r.u32(),
      geometryRevision: r.u32(1),
      stateHash: r.u32(0, 4294967295)
    };
    if (header.runEpoch !== context2.runEpoch || header.connectionEpoch !== context2.connectionEpoch)
      throw new ProtocolError("identity-mismatch", "Snapshot belongs to another run/socket");
    if (header.geometryRevision !== context2.geometryRevision && !context2.geometryRevisions?.has(header.geometryRevision))
      throw new ProtocolError("resync-required", "Snapshot geometry is not loaded");
    const counts = {
      players: r.u8(),
      vehicles: r.u8(),
      enemies: r.u16(),
      projectiles: r.u16(),
      platforms: r.u16(),
      threats: r.u16(),
      removedIds: r.u16()
    };
    const baseLength = frameLength(counts);
    check3(
      flags === 0 ? baseLength === bytes.byteLength : baseLength + COMBAT_HEADER_BYTES <= bytes.byteLength,
      "Snapshot section lengths do not match frame"
    );
    const roomMode = ROOM_MODES[r.u8()];
    check3(roomMode !== void 0, "Unknown room mode");
    r.zero(15);
    const snapshot = {
      ...header,
      roomMode,
      camera: { x: r.i32(MAX_POSITION), y: r.i32(MAX_POSITION) },
      campaign: {
        ruleset: r.choice(RULESETS),
        mission: r.u32(1, 255),
        checkpointId: r.u32(1),
        continuesRemaining: r.u32(0, 65535),
        continuesUsed: r.u32(0, 65535),
        phase: r.choice(PHASES2),
        encounterId: r.u32(1),
        remainingEnemies: r.u32(0, 320)
      },
      combat: null,
      acknowledgments: [],
      players: [],
      vehicles: [],
      enemies: [],
      projectiles: [],
      platforms: [],
      threats: [],
      removedIds: []
    };
    for (let index = 0; index < counts.players; index++) snapshot.acknowledgments.push(readAck(r));
    for (let index = 0; index < counts.players; index++) snapshot.players.push(readPlayer(r));
    for (let index = 0; index < counts.vehicles; index++) snapshot.vehicles.push(readVehicle(r));
    for (let index = 0; index < counts.enemies; index++) snapshot.enemies.push(readEnemy(r));
    for (let index = 0; index < counts.projectiles; index++)
      snapshot.projectiles.push(readProjectile(r));
    for (let index = 0; index < counts.platforms; index++) snapshot.platforms.push(readPlatform(r));
    for (let index = 0; index < counts.threats; index++) snapshot.threats.push(readThreat(r));
    for (let index = 0; index < counts.removedIds; index++) snapshot.removedIds.push(r.u32(1));
    if (flags === 1) snapshot.combat = readCombat(r);
    check3(r.offset === bytes.byteLength, "Trailing snapshot bytes");
    validate2(snapshot, context2);
    return snapshot;
  }

  // src/game/content/contract-fixture.ts
  var CONTRACT_FIXTURE = {
    format: 1,
    simulationHz: 60,
    shapes: [
      { id: 1, rect: { x: pixels(-7), y: pixels(-34), w: pixels(14), h: pixels(34) } },
      { id: 2, rect: { x: pixels(-7), y: pixels(-20), w: pixels(14), h: pixels(20) } },
      { id: 3, rect: { x: pixels(-5), y: pixels(-32), w: pixels(10), h: pixels(30) } },
      { id: 4, rect: { x: pixels(-1), y: pixels(-1), w: pixels(2), h: pixels(2) } },
      { id: 5, rect: { x: pixels(-40), y: pixels(-32), w: pixels(80), h: pixels(32) } },
      { id: 6, rect: { x: pixels(-24), y: pixels(-30), w: pixels(48), h: pixels(30) } }
    ],
    poses: [
      {
        id: 1,
        frame: "fixture-operative-idle",
        durationTicks: 6,
        sockets: [
          { name: "muzzle", point: { x: pixels(15), y: pixels(-23) } },
          { name: "hand", point: { x: pixels(10), y: pixels(-20) } }
        ],
        hurtShapeIds: [3]
      },
      {
        id: 2,
        frame: "fixture-tank-idle",
        durationTicks: 12,
        sockets: [
          { name: "seat", point: { x: 0, y: pixels(-20) } },
          { name: "ejection", point: { x: pixels(-40), y: 0 } }
        ],
        hurtShapeIds: [6]
      }
    ],
    timelines: [
      {
        id: 1,
        durationTicks: 6,
        poses: [1],
        markers: [{ tickOffset: 0, kind: "spawn-attack", payloadId: 1, socket: "muzzle" }]
      },
      {
        id: 2,
        durationTicks: 12,
        poses: [2],
        markers: [{ tickOffset: 11, kind: "seat-transfer", payloadId: 1, socket: "seat" }]
      }
    ],
    attacks: [
      {
        id: 1,
        kind: "swept-projectile",
        shapeId: 4,
        damage: 1,
        lifetimeTicks: 30,
        speed: pixels(12),
        maxTargets: 1,
        repeatDamageTicks: 0,
        material: "bullet"
      }
    ],
    weapons: [
      {
        id: "sidearm",
        attackId: 1,
        timelineId: 1,
        cadenceTicks: 10,
        ammoPerAction: 0,
        pickupAmmo: "unlimited",
        aimPolicy: "cardinal",
        visualFamily: "fixture-sidearm",
        audioFamily: "fixture-sidearm"
      }
    ],
    actors: [
      {
        id: 1,
        locomotion: "grounded",
        standingShapeId: 1,
        crouchedShapeId: 2,
        idlePoseId: 1,
        runSpeed: 768,
        jumpVelocity: -1430,
        gravity: 55,
        terminalVelocity: 2048
      },
      {
        id: 2,
        locomotion: "grounded",
        standingShapeId: 6,
        crouchedShapeId: 6,
        idlePoseId: 2,
        runSpeed: 640,
        jumpVelocity: -1200,
        gravity: 60,
        terminalVelocity: 2048
      }
    ],
    vehicles: [
      {
        id: 1,
        kind: "tank",
        actorId: 2,
        armor: 3,
        weaponId: "sidearm",
        seat: {
          socket: { x: 0, y: pixels(-20) },
          ejectionCandidates: [
            { x: pixels(-40), y: 0 },
            { x: pixels(40), y: 0 }
          ],
          boardingSensorShapeId: 5,
          boardingTimelineId: 2
        }
      }
    ],
    terrain: [
      {
        id: 100,
        kind: "solid",
        rect: { x: 0, y: pixels(200), w: pixels(384), h: pixels(16) },
        visibleSurfaceId: "fixture-floor"
      },
      {
        id: 101,
        kind: "one-way",
        rect: { x: pixels(100), y: pixels(145), w: pixels(80), h: pixels(8) },
        visibleSurfaceId: "fixture-platform"
      }
    ],
    encounters: [
      {
        id: 1,
        camera: { x: 0, y: 0, w: pixels(384), h: pixels(216) },
        killBounds: { x: pixels(-64), y: pixels(-64), w: pixels(512), h: pixels(320) },
        checkpoint: { x: pixels(32), y: pixels(200) },
        spawns: [
          {
            id: 102,
            actorId: 1,
            point: { x: pixels(50), y: pixels(200) },
            required: true,
            retreatAllowed: false
          }
        ],
        vehicleSpawns: [{ id: 103, definitionId: 1, point: { x: pixels(250), y: pixels(200) } }]
      }
    ]
  };

  // src/game/labs/foot-fixture.ts
  var FOOT_SHAPES = new Map(CONTRACT_FIXTURE.shapes.map((shape) => [shape.id, shape]));
  var FOOT_DEFINITION = CONTRACT_FIXTURE.actors[0];
  if (!FOOT_DEFINITION) throw new Error("Missing foot fixture definition");
  function footState(x = 0, y = 0) {
    return {
      body: {
        id: 1,
        x: pixels(x),
        y: pixels(y),
        vx: 0,
        vy: 0,
        remainderX: 0,
        remainderY: 0,
        shapeId: 1,
        supportId: 100,
        grounded: true,
        contacts: []
      },
      life: "alive",
      locomotion: "grounded",
      action: {
        kind: "ready",
        actionInstanceId: 0,
        stateStartTick: 0,
        definitionId: 0,
        nextMarkerIndex: 0
      },
      facing: 1,
      aim: 0,
      jumpBufferTicks: 0,
      coyoteTicks: 4,
      ignoredSupportId: null,
      ignoredSupportTicks: 0,
      vehicleId: null,
      geometryRevision: 1
    };
  }
  function footActor(x = 0, y = 0) {
    return {
      ...footState(x, y),
      playerId: 1,
      slot: 0,
      controlEpoch: 1,
      lifeStartTick: 0,
      bodyPresence: "present",
      invulnerableTicks: 0,
      reboardCooldownTicks: 0,
      vehicleSpecialTicks: 0,
      weapon: { id: "sidearm", ammo: 0, cooldownTicks: 0, shotOrdinal: 0, lastActionInstanceId: 0 },
      firearmAim: { pitch: 0, nextStepTick: 0 },
      grenadeStock: 10,
      grenadeCooldownTicks: 0,
      meleeCooldownTicks: 0,
      health: 1,
      lives: 3,
      lastRallyMission: 0,
      processedEdgeIds: [0, 0, 0, 0, 0]
    };
  }
  function footTerrain(id2, x, y, w, h, kind = "solid") {
    return {
      id: id2,
      rect: { x: pixels(x), y: pixels(y), w: pixels(w), h: pixels(h) },
      kind,
      delta: { x: 0, y: 0 }
    };
  }
  var FOOT_FLOOR = footTerrain(100, -200, 0, 400, 16);

  // src/game/combat/projectile.ts
  function sweepProjectile(projectile, definition2, shape, terrain, hurtboxes) {
    if (definition2.id !== projectile.definitionId || definition2.shapeId !== shape.id || definition2.kind !== "swept-projectile" || definition2.maxTargets !== 1 || definition2.material !== "bullet")
      throw new Error("Unsupported ballistic policy");
    return projectileImpact(projectile, shape, definition2.damage, terrain, hurtboxes);
  }
  function projectileImpact(projectile, shape, bodyDamage, terrain, hurtboxes) {
    integer(bodyDamage, 0, 65535, "projectile body damage");
    integer(terrain.length + hurtboxes.length, 0, 4096, "projectile candidate count");
    const bounds = worldRect(projectile.position, shape.rect, 1);
    sweepBounds(bounds, projectile.velocity);
    const candidates = [
      ...terrain.map((target2) => ({
        ...target2,
        entityId: null,
        priority: 0,
        kind: "terrain"
      })),
      ...hurtboxes.filter(
        (target2) => target2.entityId !== projectile.ownerId && (target2.solid || target2.team !== projectile.team)
      ).map((target2) => ({
        ...target2,
        priority: target2.solid ? 0 : target2.kind === "shield" ? 1 : 2
      }))
    ];
    const ids2 = /* @__PURE__ */ new Set();
    let first = null;
    for (const target2 of candidates) {
      integer(target2.id, 1, COUNTER_LIMIT - 1, "projectile collision ID");
      if (ids2.has(target2.id)) throw new Error("Duplicate projectile collision ID");
      ids2.add(target2.id);
      const hit = sweepAabb(bounds, projectile.velocity, target2.rect, target2.delta);
      if (!hit) continue;
      const time2 = hit.kind === "overlap" ? { numerator: 0, denominator: 1 } : hit.time;
      const order = first ? compareContactTime(
        time2.numerator,
        time2.denominator,
        first.time.numerator,
        first.time.denominator
      ) : -1;
      if (order < 0 || order === 0 && first && (target2.priority < first.target.priority || target2.priority === first.target.priority && target2.id < first.target.id))
        first = { target: target2, time: time2 };
    }
    if (!first) return null;
    const { target, time } = first;
    return {
      sourceId: projectile.id,
      definitionId: projectile.definitionId,
      actionInstanceId: projectile.actionInstanceId,
      ownerId: projectile.ownerId,
      colliderId: target.id,
      entityId: target.entityId,
      kind: target.kind,
      damage: target.kind === "body" ? bodyDamage : 0,
      position: {
        x: position(
          projectile.position.x + divide(projectile.velocity.x * time.numerator, time.denominator).quotient
        ),
        y: position(
          projectile.position.y + divide(projectile.velocity.y * time.numerator, time.denominator).quotient
        )
      },
      time
    };
  }
  function muzzleBlocked(hand, muzzle, shape, terrain) {
    const bounds = worldRect(hand, shape.rect, 1);
    const delta = { x: muzzle.x - hand.x, y: muzzle.y - hand.y };
    return terrain.some(
      (target) => sweepAabb(bounds, delta, {
        ...target.rect,
        x: target.rect.x + target.delta.x,
        y: target.rect.y + target.delta.y
      }) !== null
    );
  }

  // src/game/combat/timeline.ts
  function actionPose(catalog, definitionId, age) {
    const timeline = catalog.timelines.get(definitionId);
    if (!timeline) throw new Error("Missing action timeline");
    integer(age, 0, COUNTER_LIMIT - 1, "action age");
    if (age >= timeline.durationTicks) return null;
    let remaining = age;
    for (const id2 of timeline.poses) {
      const pose = catalog.poses.get(id2);
      if (!pose) throw new Error("Missing action pose");
      if (remaining < pose.durationTicks) return pose;
      remaining -= pose.durationTicks;
    }
    throw new Error("Action pose exposures do not cover timeline");
  }
  function stepAction(current, tick2, catalog) {
    integer(tick2, current.stateStartTick, COUNTER_LIMIT - 1, "action tick");
    const definition2 = catalog.timelines.get(current.definitionId);
    if (!definition2) throw new Error("Missing action definition");
    const age = tick2 - current.stateStartTick;
    integer(current.nextMarkerIndex, 0, definition2.markers.length, "action marker cursor");
    if (definition2.markers.slice(0, current.nextMarkerIndex).some((marker) => marker.tickOffset > age))
      throw new Error("Action cursor acknowledges a future marker");
    if ((definition2.markers[current.nextMarkerIndex]?.tickOffset ?? age) < age)
      throw new Error("Action timeline skipped an unprocessed marker");
    const action2 = { ...current };
    const markers = [];
    const pose = actionPose(catalog, current.definitionId, age);
    while (definition2.markers[action2.nextMarkerIndex]?.tickOffset === age) {
      const marker = definition2.markers[action2.nextMarkerIndex];
      if (!marker || !pose) throw new Error("Marker outside active pose");
      markers.push({
        actionInstanceId: action2.actionInstanceId,
        markerIndex: action2.nextMarkerIndex++,
        marker,
        pose
      });
    }
    return { action: action2, markers, pose, finished: age >= definition2.durationTicks };
  }

  // src/game/actors/rifle.ts
  function createRifleState() {
    return {
      action: {
        kind: "ready",
        actionInstanceId: 0,
        stateStartTick: 0,
        definitionId: 0,
        nextMarkerIndex: 0
      },
      targetId: null,
      aim: 0,
      facing: -1
    };
  }
  function cancelRifle(state) {
    state.action.kind = "ready";
    state.targetId = null;
  }
  function rifleMode(state, tick2, profile) {
    if (state.action.kind === "ready") return 0;
    const age = tick2 - state.action.stateStartTick;
    return age < profile.raiseTicks ? 1 : age <= profile.lastReleaseTick ? 2 : 3;
  }
  function validateRifleState(state, enemy, tick2, nextActionId, players, catalog, profile) {
    integer(state.aim, 0, 1, "rifle aim");
    if (state.facing !== -1 && state.facing !== 1) throw new Error("Invalid rifle facing");
    integer(state.action.actionInstanceId, 0, nextActionId - 1, "rifle action allocation");
    integer(state.action.stateStartTick, 0, tick2, "rifle start tick");
    if (state.action.kind !== "ready" && state.action.kind !== "fire")
      throw new Error("Invalid rifle action");
    if (state.action.actionInstanceId === 0) {
      if (state.action.definitionId !== 0 || state.action.nextMarkerIndex !== 0 || state.action.stateStartTick !== 0 || state.aim !== 0 || state.targetId !== null || state.action.kind !== "ready")
        throw new Error("Invalid idle rifle");
      return;
    }
    if (state.action.definitionId !== profile.timelineIds[state.aim])
      throw new Error("Rifle pose/aim mismatch");
    const timeline = catalog.timelines.get(state.action.definitionId);
    if (!timeline) throw new Error("Missing rifle timeline");
    integer(state.action.nextMarkerIndex, 0, timeline.markers.length, "rifle marker cursor");
    const age = tick2 - state.action.stateStartTick;
    if (timeline.markers.slice(0, state.action.nextMarkerIndex).some((marker) => marker.tickOffset > age))
      throw new Error("Future rifle marker");
    if (state.action.kind === "fire") {
      if (enemy.life !== "alive" || enemy.facing !== state.facing || !players.some((player2) => player2.playerId === state.targetId) || age >= timeline.durationTicks || timeline.markers.slice(state.action.nextMarkerIndex).some((marker) => marker.tickOffset <= age))
        throw new Error("Invalid active rifle continuation");
    } else if (state.targetId !== null || enemy.life === "alive" && age < timeline.durationTicks)
      throw new Error("Unexplained rifle cancellation");
  }
  function stepRifleAttack(current, enemy, players, tick2, nextActionId, catalog, profile, bullet, terrain) {
    integer(tick2, 1, COUNTER_LIMIT - 1, "rifle tick");
    const state = structuredClone(current);
    let facing2 = current.action.kind === "fire" ? current.facing : enemy.facing;
    if (enemy.life !== "alive") {
      cancelRifle(state);
      return { state, facing: facing2, nextActionId, markers: [] };
    }
    if (state.action.kind === "ready" && enemy.body.grounded) {
      const candidates = players.filter((player2) => player2.life === "alive" && player2.invulnerableTicks === 0).map((player2) => ({
        player: player2,
        distance: Math.abs(player2.body.x - enemy.body.x) + Math.abs(player2.body.y - enemy.body.y)
      })).filter(({ distance }) => distance <= profile.range).sort((a, b) => a.distance - b.distance || a.player.playerId - b.player.playerId);
      for (const { player: player2 } of candidates) {
        const dx = player2.body.x - enemy.body.x;
        const aim = Math.abs(dx) <= profile.upAlignment && enemy.body.y - player2.body.y >= profile.upHeight ? 1 : 0;
        const direction = dx === 0 ? facing2 : dx < 0 ? -1 : 1;
        const timeline = catalog.timelines.get(profile.timelineIds[aim]);
        const pose = timeline && catalog.poses.get(timeline.poses[0] ?? 0);
        const socket = pose?.sockets.find((socket2) => socket2.name === "muzzle");
        if (!socket) throw new Error("Missing authored rifle raise socket");
        const muzzle = worldSocket(enemy.body, socket.point, direction);
        const end = aim === 1 ? { x: muzzle.x, y: player2.body.y - profile.aimHeight } : { x: player2.body.x, y: muzzle.y };
        if (muzzleBlocked(muzzle, end, bullet, terrain)) continue;
        facing2 = direction;
        state.facing = direction;
        state.aim = aim;
        state.targetId = player2.playerId;
        state.action = {
          kind: "fire",
          actionInstanceId: nextActionId,
          stateStartTick: tick2,
          definitionId: profile.timelineIds[aim],
          nextMarkerIndex: 0
        };
        nextActionId = nextCounter(nextActionId);
        break;
      }
    }
    if (state.action.kind === "ready") return { state, facing: facing2, nextActionId, markers: [] };
    const action2 = stepAction(state.action, tick2, catalog);
    state.action = action2.action;
    if (action2.finished) cancelRifle(state);
    return { state, facing: facing2, nextActionId, markers: action2.markers };
  }

  // src/game/actors/shield.ts
  var SHIELD_PHASES = ["brace", "advance", "turn", "bash", "stunned", "dead"];
  function createShieldState(profile) {
    return {
      phase: "brace",
      integrity: profile.integrity,
      facing: -1,
      turnFacing: -1,
      targetId: null,
      action: { actionInstanceId: 0, stateStartTick: 0, definitionId: 0, nextMarkerIndex: 0 },
      hitIds: []
    };
  }
  function cancelShield(state) {
    state.phase = "dead";
    state.targetId = null;
    state.hitIds = [];
  }
  function shieldProtected(state, tick2, profile) {
    return state.integrity > 0 && (state.phase === "brace" || state.phase === "advance" || state.phase === "bash" && tick2 - state.action.stateStartTick < profile.bashActiveTick);
  }
  function shieldMode(state) {
    return SHIELD_PHASES.indexOf(state.phase) + (state.integrity === 0 ? SHIELD_PHASES.length : 0);
  }
  function begin(state, phase, tick2, nextActionId, profile) {
    state.phase = phase;
    state.hitIds = [];
    state.action = {
      actionInstanceId: nextActionId,
      stateStartTick: tick2,
      definitionId: profile.timelineIds[phase],
      nextMarkerIndex: 0
    };
    return nextCounter(nextActionId);
  }
  function evaluate(state, tick2, nextActionId, catalog, profile) {
    const advanced = stepAction(state.action, tick2, catalog);
    state.action = advanced.action;
    for (const item of advanced.markers)
      if (item.marker.kind === "face") state.facing = state.turnFacing;
    return {
      state,
      nextActionId,
      markers: advanced.markers,
      speed: state.phase === "advance" ? profile.speed : 0
    };
  }
  function stepShield(current, enemy, players, tick2, nextActionId, catalog, profile) {
    integer(tick2, 1, COUNTER_LIMIT - 1, "shield tick");
    const state = structuredClone(current);
    if (enemy.life !== "alive") {
      cancelShield(state);
      return { state, nextActionId, markers: [], speed: 0 };
    }
    const duration = catalog.timelines.get(state.action.definitionId)?.durationTicks ?? 0;
    const finished = tick2 - state.action.stateStartTick >= duration;
    if (["turn", "bash", "stunned"].includes(state.phase) && !finished)
      return evaluate(state, tick2, nextActionId, catalog, profile);
    const target = players.filter((player2) => player2.life === "alive" && player2.invulnerableTicks === 0).map((player2) => ({
      player: player2,
      distance: Math.abs(player2.body.x - enemy.body.x) + Math.abs(player2.body.y - enemy.body.y)
    })).filter(({ distance }) => distance <= profile.sightRange).sort((a, b) => a.distance - b.distance || a.player.playerId - b.player.playerId)[0]?.player;
    const dx = target ? target.body.x - enemy.body.x : 0;
    const direction = dx === 0 ? state.facing : dx < 0 ? -1 : 1;
    if (enemy.body.grounded && target && direction !== state.facing) {
      state.targetId = target.playerId;
      state.turnFacing = direction;
      nextActionId = begin(state, "turn", tick2, nextActionId, profile);
    } else if (enemy.body.grounded && target && Math.abs(dx) <= profile.bashRange && Math.abs(target.body.y - enemy.body.y) <= profile.bashHeight) {
      state.targetId = target.playerId;
      nextActionId = begin(state, "bash", tick2, nextActionId, profile);
    } else if (state.action.actionInstanceId === 0 || finished) {
      const phase = target && enemy.body.grounded && state.phase !== "advance" ? "advance" : "brace";
      state.targetId = target?.playerId ?? null;
      state.turnFacing = state.facing;
      nextActionId = begin(
        state,
        state.action.actionInstanceId === 0 ? "brace" : phase,
        tick2,
        nextActionId,
        profile
      );
    }
    return evaluate(state, tick2, nextActionId, catalog, profile);
  }
  function damageShield(current, attack2, tick2, nextActionId, catalog, profile) {
    const state = structuredClone(current);
    const damage = profile.damageByMaterial[attack2.material];
    integer(damage, 0, 65535, "shield material damage");
    if (state.phase === "dead" || state.integrity === 0 || damage === 0)
      return { state, nextActionId, broken: false, markers: [] };
    state.integrity = Math.max(0, state.integrity - damage);
    if (state.integrity > 0) return { state, nextActionId, broken: false, markers: [] };
    state.targetId = null;
    state.turnFacing = state.facing;
    nextActionId = begin(state, "stunned", tick2, nextActionId, profile);
    return { ...evaluate(state, tick2, nextActionId, catalog, profile), broken: true };
  }
  function validateShield(state, enemy, tick2, nextActionId, players, catalog, profile, additionalHitIds = []) {
    if (!SHIELD_PHASES.includes(state.phase)) throw new Error("Invalid shield phase");
    integer(state.integrity, 0, profile.integrity, "shield integrity");
    if (![state.facing, state.turnFacing].every((value) => value === -1 || value === 1) || state.facing !== enemy.facing)
      throw new Error("Invalid shield facing");
    if (state.phase === "dead" !== (enemy.life === "removed"))
      throw new Error("Shield life mismatch");
    if (state.targetId !== null && !players.some((player2) => player2.playerId === state.targetId))
      throw new Error("Unknown shield target");
    const action2 = state.action;
    integer(action2.actionInstanceId, 0, nextActionId - 1, "shield action allocation");
    integer(action2.stateStartTick, 0, tick2, "shield start tick");
    if (action2.actionInstanceId === 0) {
      if (state.phase !== "brace" || state.integrity !== profile.integrity || action2.definitionId !== 0 || action2.nextMarkerIndex !== 0 || action2.stateStartTick !== 0 || state.targetId !== null || state.hitIds.length !== 0 || state.turnFacing !== state.facing)
        throw new Error("Invalid initial shield");
      return;
    }
    const timeline = catalog.timelines.get(action2.definitionId);
    if (!timeline || !Object.values(profile.timelineIds).includes(action2.definitionId) || state.phase !== "dead" && action2.definitionId !== profile.timelineIds[state.phase])
      throw new Error("Shield phase/timeline mismatch");
    const age = tick2 - action2.stateStartTick;
    integer(action2.nextMarkerIndex, 0, timeline.markers.length, "shield marker cursor");
    if (timeline.markers.slice(0, action2.nextMarkerIndex).some((marker) => marker.tickOffset > age) || state.phase !== "dead" && (age >= timeline.durationTicks || timeline.markers.slice(action2.nextMarkerIndex).some((marker) => marker.tickOffset <= age)))
      throw new Error("Invalid shield marker continuation");
    if (state.phase === "turn") {
      const flipped = timeline.markers.slice(0, action2.nextMarkerIndex).some((marker) => marker.kind === "face");
      if (state.targetId === null || state.facing !== (flipped ? state.turnFacing : -state.turnFacing))
        throw new Error("Invalid committed shield turn");
    }
    if (state.phase === "bash" && state.targetId === null) throw new Error("Missing bash target");
    if (state.phase === "stunned" && (state.integrity !== 0 || state.targetId !== null))
      throw new Error("Invalid broken shield stun");
    integer(state.hitIds.length, 0, 4, "bash hit budget");
    for (const [index, id2] of state.hitIds.entries()) {
      if (state.phase !== "bash" || age < profile.bashActiveTick || index > 0 && id2 <= (state.hitIds[index - 1] ?? 0) || !players.some((player2) => player2.body.id === id2) && !additionalHitIds.includes(id2))
        throw new Error("Invalid bash hit ledger");
    }
  }

  // src/game/combat/volume.ts
  var END2 = { numerator: 1, denominator: 1 };
  function validateQuery(source3, terrain, hurtboxes) {
    for (const id2 of [source3.id, source3.ownerId, source3.actionInstanceId, source3.definitionId])
      integer(id2, 1, COUNTER_LIMIT - 1, "attack identity");
    integer(source3.team, 0, 255, "attack team");
    integer(terrain.length + hurtboxes.length, 0, 4096, "volume candidates");
    const ids2 = /* @__PURE__ */ new Set();
    for (const target of terrain) validateSweepTarget(target);
    for (const target of hurtboxes) {
      integer(target.entityId, 1, COUNTER_LIMIT - 1, "hurt entity");
      integer(target.team, 0, 255, "hurt team");
      if (target.kind !== "body" && target.kind !== "shield") throw new Error("Invalid hurt kind");
      sweepBounds(target.rect, target.delta);
      integer(target.rect.w, 1, 2 ** 24, "hurt width");
      integer(target.rect.h, 1, 2 ** 24, "hurt height");
    }
    for (const target of [...terrain, ...hurtboxes]) {
      integer(target.id, 1, COUNTER_LIMIT - 1, "volume collision ID");
      if (ids2.has(target.id)) throw new Error("Duplicate volume collision ID");
      ids2.add(target.id);
    }
  }
  var at = (origin, delta, time) => ({
    x: origin.x + divide(delta.x * time.numerator, time.denominator).quotient,
    y: origin.y + divide(delta.y * time.numerator, time.denominator).quotient
  });
  function nearest(origin, rect) {
    return {
      x: Math.max(rect.x, Math.min(origin.x, rect.x + rect.w)),
      y: Math.max(rect.y, Math.min(origin.y, rect.y + rect.h))
    };
  }
  function targets(source3, hurtboxes) {
    return hurtboxes.filter(
      (target) => (target.solid || target.team !== source3.team) && target.entityId !== source3.ownerId
    );
  }
  function occluder(from, to, time, terrain, shields) {
    const candidates = [
      ...terrain.filter((target) => target.kind === "solid").map((target) => ({ ...target, entityId: null, kind: "terrain", priority: 0 })),
      ...shields.map((target) => ({ ...target, priority: target.solid ? 0 : 1 }))
    ];
    let first = null;
    for (const target of candidates) {
      const point3 = at(target.rect, target.delta, time);
      const hit = sweepAabb(
        { ...from, w: 0, h: 0 },
        { x: to.x - from.x, y: to.y - from.y },
        { ...target.rect, ...point3 }
      );
      if (!hit) continue;
      const hitTime = hit.kind === "overlap" ? { numerator: 0, denominator: 1 } : hit.time;
      const order = first ? compareContactTime(
        hitTime.numerator,
        hitTime.denominator,
        first.time.numerator,
        first.time.denominator
      ) : -1;
      if (order < 0 || order === 0 && first && (target.priority < first.target.priority || target.priority === first.target.priority && target.id < first.target.id))
        first = { target, time: hitTime };
    }
    return first;
  }
  function impact(source3, target, time, point3, damage) {
    return {
      sourceId: source3.id,
      definitionId: source3.definitionId,
      ownerId: source3.ownerId,
      actionInstanceId: source3.actionInstanceId,
      colliderId: target.id,
      entityId: target.entityId,
      kind: target.kind,
      damage,
      time,
      position: point3
    };
  }
  function ordered2(hits, maximum, excluded, primaryTarget = null) {
    const seen = new Set(excluded);
    return hits.sort(
      (a, b) => compareContactTime(
        a.time.numerator,
        a.time.denominator,
        b.time.numerator,
        b.time.denominator
      ) || (primaryTarget === null ? 0 : Number(b.entityId === primaryTarget) - Number(a.entityId === primaryTarget)) || a.colliderId - b.colliderId
    ).filter((hit) => {
      if (hit.entityId === null || seen.has(hit.entityId) || seen.size >= maximum) return false;
      seen.add(hit.entityId);
      return true;
    });
  }
  function meleeHits(source3, definition2, shape, hand, delta, facing2, occlusionOrigin, terrain, hurtboxes, hitIds = []) {
    if (definition2.kind !== "melee" || definition2.material !== "blade" && definition2.material !== "blunt" || definition2.id !== source3.definitionId || definition2.shapeId !== shape.id)
      throw new Error("Invalid melee policy");
    return rectangularHits(
      source3,
      definition2,
      worldRect(hand, shape.rect, facing2),
      delta,
      occlusionOrigin,
      terrain,
      hurtboxes,
      hitIds
    );
  }
  function rectangularHits(source3, definition2, volume, delta, occlusionOrigin, terrain, hurtboxes, hitIds = []) {
    if (definition2.id !== source3.definitionId || !["melee", "shot-volume", "flame-volumes"].includes(definition2.kind))
      throw new Error("Invalid rectangular attack policy");
    validateQuery(source3, terrain, hurtboxes);
    integer(hitIds.length, 0, definition2.maxTargets, "melee hit budget");
    for (const id2 of hitIds) integer(id2, 1, COUNTER_LIMIT - 1, "melee hit identity");
    if (new Set(hitIds).size !== hitIds.length) throw new Error("Duplicate melee hit identity");
    sweepBounds(volume, delta);
    sweepBounds({ ...occlusionOrigin, w: 0, h: 0 }, delta);
    const enemies = targets(source3, hurtboxes), shields = enemies.filter((target) => target.kind === "shield" || target.solid), hits = [];
    for (const target of enemies.filter(
      (target2) => target2.kind === "body" || definition2.kind !== "melee"
    )) {
      const hit = sweepAabb(volume, delta, target.rect, target.delta);
      if (!hit) continue;
      const time = hit.kind === "overlap" ? { numerator: 0, denominator: 1 } : hit.time;
      const origin = at(occlusionOrigin, delta, time);
      const exposed = { ...target.rect, ...at(target.rect, target.delta, time) };
      const currentVolume = { ...volume, ...at(volume, delta, time) };
      const x = Math.max(exposed.x, currentVolume.x), y = Math.max(exposed.y, currentVolume.y);
      const point3 = nearest(origin, {
        x,
        y,
        w: Math.max(0, Math.min(exposed.x + exposed.w, currentVolume.x + currentVolume.w) - x),
        h: Math.max(0, Math.min(exposed.y + exposed.h, currentVolume.y + currentVolume.h) - y)
      });
      const blocked = occluder(origin, point3, time, terrain, shields);
      if (blocked?.target.kind === "terrain") continue;
      if (blocked && definition2.kind !== "melee") {
        const shield = {
          ...blocked.target.rect,
          ...at(blocked.target.rect, blocked.target.delta, time)
        };
        if (shield.x > currentVolume.x + currentVolume.w || shield.x + shield.w < currentVolume.x || shield.y > currentVolume.y + currentVolume.h || shield.y + shield.h < currentVolume.y)
          continue;
      }
      hits.push(
        blocked ? impact(
          source3,
          blocked.target,
          time,
          at(origin, { x: point3.x - origin.x, y: point3.y - origin.y }, blocked.time),
          blocked.target.kind === "body" ? definition2.damage : 0
        ) : impact(source3, target, time, point3, target.kind === "shield" ? 0 : definition2.damage)
      );
    }
    return ordered2(hits, definition2.maxTargets, hitIds);
  }
  function explosionHits(source3, definition2, center, radius, terrain, hurtboxes, options = {}) {
    const { time = END2, primaryTarget = null } = options;
    if (definition2.id !== source3.definitionId || definition2.kind !== "explosion" || definition2.material !== "explosive")
      throw new Error("Invalid explosion policy");
    integer(radius, 1, 2 ** 16, "blast radius");
    integer(time.denominator, 1, 2 ** 17, "blast contact denominator");
    integer(time.numerator, 0, time.denominator, "blast contact numerator");
    if (primaryTarget !== null) integer(primaryTarget, 1, COUNTER_LIMIT - 1, "blast primary target");
    position(center.x);
    position(center.y);
    validateQuery(source3, terrain, hurtboxes);
    const enemies = targets(source3, hurtboxes), shields = enemies.filter((target) => target.kind === "shield" || target.solid), hits = [];
    for (const target of enemies.filter((target2) => target2.kind === "body")) {
      const point3 = nearest(center, {
        ...target.rect,
        ...at(target.rect, target.delta, time)
      });
      const dx = point3.x - center.x, dy = point3.y - center.y;
      if (dx * dx + dy * dy > radius * radius) continue;
      const blocked = occluder(center, point3, time, terrain, shields);
      if (blocked?.target.kind === "terrain") continue;
      hits.push(
        blocked ? impact(
          source3,
          blocked.target,
          time,
          at(center, { x: point3.x - center.x, y: point3.y - center.y }, blocked.time),
          blocked.target.kind === "body" ? definition2.damage : 0
        ) : impact(source3, target, time, point3, definition2.damage)
      );
    }
    return ordered2(hits, definition2.maxTargets, [], primaryTarget);
  }

  // src/game/combat/area-attack.ts
  var zero = { x: 0, y: 0 };
  function areaEndTick(attack2, profile) {
    return attack2.startTick + (profile.emissionOffsets.at(-1) ?? 0) + profile.frames.length;
  }
  function cardinalRect(origin, rect, heading) {
    if (heading === 0) return { ...rect, x: origin.x + rect.x, y: origin.y + rect.y };
    if (heading === 3) return { ...rect, x: origin.x - rect.x - rect.w, y: origin.y + rect.y };
    if (heading === 1)
      return { x: origin.x + rect.y, y: origin.y - rect.x - rect.w, w: rect.h, h: rect.w };
    return { x: origin.x + rect.y, y: origin.y + rect.x, w: rect.h, h: rect.w };
  }
  function forward(rect, origin, heading) {
    if (heading === 0) return { ...rect, x: rect.x - origin.x, y: rect.y - origin.y };
    if (heading === 3) return { ...rect, x: origin.x - rect.x - rect.w, y: rect.y - origin.y };
    if (heading === 1)
      return { x: origin.y - rect.y - rect.h, y: rect.x - origin.x, w: rect.h, h: rect.w };
    return { x: rect.y - origin.y, y: rect.x - origin.x, w: rect.h, h: rect.w };
  }
  function clippedGeometry(geometry2, lobe, terrain) {
    let reach = lobe.reach;
    let top = geometry2.y, bottom = geometry2.y + geometry2.h;
    for (const wall3 of terrain) {
      if (wall3.kind !== "solid") continue;
      const rect = forward(
        { ...wall3.rect, x: wall3.rect.x + wall3.delta.x, y: wall3.rect.y + wall3.delta.y },
        lobe.origin,
        lobe.heading
      );
      if (rect.y < geometry2.y + geometry2.h && rect.y + rect.h > geometry2.y && rect.x + rect.w > 0 && rect.x <= geometry2.x + geometry2.w) {
        if (rect.y <= 0 && rect.y + rect.h >= 0) reach = Math.min(reach, Math.max(0, rect.x));
        else if (rect.y > 0) bottom = Math.min(bottom, rect.y);
        else top = Math.max(top, rect.y + rect.h);
      }
    }
    const width = Math.min(geometry2.w, reach - geometry2.x);
    return {
      reach,
      rect: width > 0 && bottom > top ? { ...geometry2, y: top, h: bottom - top, w: width } : null
    };
  }
  function geometryAt(attack2, lobe, tick2, profile) {
    const spawnTick = attack2.startTick + (profile.emissionOffsets[lobe.index] ?? -COUNTER_LIMIT);
    const geometry2 = profile.frames[tick2 - spawnTick];
    if (!geometry2) return null;
    const width = Math.min(geometry2.w, lobe.reach - geometry2.x);
    return width > 0 ? { spawnTick, geometry: { ...geometry2, w: width } } : null;
  }
  function areaExposures(attack2, tick2, profile, terrain) {
    return attack2.lobes.flatMap((lobe) => {
      const frame = geometryAt(attack2, lobe, tick2, profile);
      const geometry2 = frame && clippedGeometry(frame.geometry, lobe, terrain).rect;
      return frame && geometry2 ? [
        {
          id: attack2.id,
          ownerId: attack2.ownerId,
          actionInstanceId: attack2.actionInstanceId,
          definitionId: attack2.definitionId,
          lobe: lobe.index,
          spawnTick: frame.spawnTick,
          endTick: frame.spawnTick + profile.frames.length,
          heading: lobe.heading,
          attached: tick2 - frame.spawnTick < profile.attachedTicks,
          rect: cardinalRect(lobe.origin, geometry2, lobe.heading)
        }
      ] : [];
    });
  }
  function emitArea(attack2, tick2, profile, anchor, blocked) {
    const index = profile.emissionOffsets.indexOf(tick2 - attack2.startTick);
    if (index < 0 || index !== attack2.emitted || attack2.cancelledTick !== null)
      throw new Error("Area emission cursor mismatch");
    attack2.emitted++;
    if (!blocked)
      attack2.lobes.push({
        index,
        origin: { ...anchor.origin },
        heading: anchor.heading,
        reach: profile.maximumReach
      });
  }
  function cancelArea(attack2, tick2, profile) {
    if (profile.kind !== "flame-volumes") return;
    attack2.cancelledTick ??= tick2;
    attack2.lobes = attack2.lobes.filter(
      (lobe) => tick2 - attack2.startTick - (profile.emissionOffsets[lobe.index] ?? 0) >= profile.attachedTicks
    );
  }
  function stepArea(current, tick2, definition2, profile, anchor, terrain, hurtboxes) {
    const attack2 = structuredClone(current), impacts = [], candidatesForAction = [];
    if (definition2.kind !== profile.kind || definition2.id !== attack2.definitionId)
      throw new Error("Area definition mismatch");
    if (tick2 >= areaEndTick(attack2, profile)) return { attack: null, impacts };
    if (!anchor) cancelArea(attack2, tick2, profile);
    attack2.lobes = attack2.lobes.filter(
      (lobe) => tick2 - attack2.startTick - (profile.emissionOffsets[lobe.index] ?? 0) < profile.frames.length
    );
    for (const lobe of attack2.lobes) {
      const born = attack2.startTick + (profile.emissionOffsets[lobe.index] ?? 0), age = tick2 - born;
      const frame = profile.frames[age];
      if (!frame) throw new Error("Unknown area exposure");
      const previous = structuredClone(lobe);
      if (age < profile.attachedTicks && anchor) {
        lobe.origin = { ...anchor.origin };
        lobe.heading = anchor.heading;
      }
      const endpoint = age === 0 || previous.heading !== lobe.heading;
      const delta = endpoint ? zero : { x: lobe.origin.x - previous.origin.x, y: lobe.origin.y - previous.origin.y };
      const origin = endpoint ? lobe.origin : previous.origin;
      const clipped = clippedGeometry(frame, lobe, terrain);
      lobe.reach = clipped.reach;
      if (!clipped.rect) continue;
      const excluded = attack2.hits.filter((hit) => definition2.repeatDamageTicks === 0 || tick2 < hit.nextTick).map((hit) => hit.entityId);
      const remaining = definition2.maxTargets - attack2.hits.length;
      const candidates = hurtboxes.filter(
        (hurt) => remaining > 0 || attack2.hits.some((hit) => hit.entityId === hurt.entityId)
      );
      const collisionTerrain = endpoint ? terrain.map((wall3) => ({
        ...wall3,
        rect: { ...wall3.rect, x: wall3.rect.x + wall3.delta.x, y: wall3.rect.y + wall3.delta.y },
        delta: zero
      })) : terrain;
      const hits = rectangularHits(
        attack2,
        definition2,
        cardinalRect(origin, clipped.rect, lobe.heading),
        delta,
        origin,
        collisionTerrain,
        endpoint ? candidates.map((hurt) => ({
          ...hurt,
          rect: { ...hurt.rect, x: hurt.rect.x + hurt.delta.x, y: hurt.rect.y + hurt.delta.y },
          delta: zero
        })) : candidates,
        excluded
      );
      candidatesForAction.push(...hits);
    }
    const granted = /* @__PURE__ */ new Set();
    candidatesForAction.sort(
      (a, b) => compareContactTime(
        a.time.numerator,
        a.time.denominator,
        b.time.numerator,
        b.time.denominator
      ) || a.colliderId - b.colliderId
    );
    for (const hit of candidatesForAction) {
      if (hit.entityId === null) continue;
      if (granted.has(hit.entityId)) continue;
      let receipt = attack2.hits.find((receipt2) => receipt2.entityId === hit.entityId);
      if (!receipt) {
        if (attack2.hits.length >= definition2.maxTargets) continue;
        receipt = { entityId: hit.entityId, nextTick: 0 };
        attack2.hits.push(receipt);
      }
      receipt.nextTick = definition2.repeatDamageTicks === 0 ? areaEndTick(attack2, profile) : tick2 + definition2.repeatDamageTicks;
      granted.add(hit.entityId);
      impacts.push(hit);
    }
    attack2.hits.sort((a, b) => a.entityId - b.entityId);
    return { attack: attack2, impacts };
  }
  function validateAreaProfile(profile, definition2) {
    if (definition2.kind !== profile.kind || !["shot-volume", "flame-volumes"].includes(profile.kind))
      throw new Error("Unknown area profile");
    integer(profile.frames.length, 1, 120, "area frames");
    integer(profile.emissionOffsets.length, 1, 4, "area emissions");
    integer(profile.attachedTicks, 0, profile.frames.length, "area attachment");
    integer(profile.maximumReach, 1, MAX_SHAPE, "area reach");
    for (const [index, offset] of profile.emissionOffsets.entries()) {
      integer(
        offset,
        index === 0 ? 0 : (profile.emissionOffsets[index - 1] ?? 0) + 1,
        120,
        "area emission offset"
      );
      if (index === 0 && offset !== 0) throw new Error("Area must begin at its first emission");
    }
    for (const frame of profile.frames) {
      validateLocalRect(frame);
      if (frame.x < 0 || frame.x + frame.w > profile.maximumReach)
        throw new Error("Area frame exceeds reach");
    }
    if (definition2.lifetimeTicks !== (profile.emissionOffsets.at(-1) ?? 0) + profile.frames.length || profile.kind === "shot-volume" && (definition2.repeatDamageTicks !== 0 || profile.attachedTicks !== 0 || profile.emissionOffsets.length !== 1) || profile.kind === "flame-volumes" && definition2.repeatDamageTicks < 1)
      throw new Error("Area lifetime/damage policy mismatch");
  }
  function validateArea(attack2, tick2, definition2, profile, targetIds) {
    integer(attack2.startTick, 1, tick2, "area start tick");
    if (tick2 >= areaEndTick(attack2, profile)) throw new Error("Expired area attack");
    const through = attack2.cancelledTick ?? tick2;
    if (attack2.cancelledTick !== null)
      integer(attack2.cancelledTick, attack2.startTick, tick2, "area cancellation tick");
    const expected = profile.emissionOffsets.filter(
      (offset) => attack2.startTick + offset <= through
    ).length;
    const minimum = attack2.cancelledTick === null ? expected : profile.emissionOffsets.filter((offset) => attack2.startTick + offset < through).length;
    integer(attack2.emitted, Math.max(1, minimum), expected, "area emission history");
    integer(attack2.lobes.length, 0, attack2.emitted, "area lobe budget");
    for (const [i, lobe] of attack2.lobes.entries()) {
      integer(
        lobe.index,
        i === 0 ? 0 : (attack2.lobes[i - 1]?.index ?? 0) + 1,
        attack2.emitted - 1,
        "area lobe order"
      );
      integer(lobe.heading, 0, 3, "area heading");
      integer(lobe.reach, 0, profile.maximumReach, "area retained reach");
      position(lobe.origin.x);
      position(lobe.origin.y);
      const age = tick2 - attack2.startTick - (profile.emissionOffsets[lobe.index] ?? 0);
      integer(age, 0, profile.frames.length - 1, "area lobe age");
      if (attack2.cancelledTick !== null && attack2.cancelledTick - attack2.startTick - (profile.emissionOffsets[lobe.index] ?? 0) < profile.attachedTicks)
        throw new Error("Cancelled attached flame");
    }
    integer(attack2.hits.length, 0, definition2.maxTargets, "area target budget");
    for (const [index, hit] of attack2.hits.entries()) {
      if (!targetIds.includes(hit.entityId) || index > 0 && hit.entityId <= (attack2.hits[index - 1]?.entityId ?? 0))
        throw new Error("Invalid area hit history");
      integer(
        hit.nextTick,
        attack2.startTick + 1,
        areaEndTick(attack2, profile) + definition2.repeatDamageTicks,
        "area next damage tick"
      );
      if (definition2.repeatDamageTicks === 0 && hit.nextTick !== areaEndTick(attack2, profile))
        throw new Error("Shotgun hit history expires early");
      if (definition2.repeatDamageTicks > 0 && hit.nextTick > tick2 + definition2.repeatDamageTicks)
        throw new Error("Area damage cooldown precedes its hit");
    }
  }

  // src/game/combat/beam.ts
  function beamExposures(beam, profile) {
    return beamSegments(beam.origin, beam.heading, beam.length, profile.width).map((rect, lobe) => ({
      id: beam.id,
      ownerId: beam.ownerId,
      actionInstanceId: beam.actionInstanceId,
      definitionId: beam.definitionId,
      lobe,
      spawnTick: beam.spawnTick,
      endTick: beam.spawnTick + profile.pulseTicks,
      heading: beam.heading,
      attached: true,
      rect
    }));
  }
  function validateBeamProfile(profile) {
    integer(profile.range, 1, MAX_SHAPE * 4, "beam range");
    integer(profile.width, 1, 4096, "beam width");
    integer(profile.pulseTicks, 1, 120, "beam pulse interval");
  }
  function validateBeamPolicy(source3, definition2, profile) {
    validateBeamProfile(profile);
    for (const id2 of [source3.id, source3.ownerId, source3.actionInstanceId, source3.definitionId])
      integer(id2, 1, COUNTER_LIMIT - 1, "beam identity");
    integer(source3.team, 1, 255, "beam team");
    if (source3.definitionId !== definition2.id || definition2.kind !== "beam" || definition2.material !== "energy" || definition2.speed !== 0 || definition2.lifetimeTicks !== profile.pulseTicks || definition2.repeatDamageTicks !== profile.pulseTicks)
      throw new Error("Invalid beam attack policy");
    integer(definition2.damage, 1, 65535, "beam damage");
    integer(definition2.maxTargets, 1, 64, "beam penetration budget");
  }
  function forward2(rect, origin, heading) {
    if (heading === 0) return { ...rect, x: rect.x - origin.x, y: rect.y - origin.y };
    if (heading === 3) return { ...rect, x: origin.x - rect.x - rect.w, y: rect.y - origin.y };
    if (heading === 1)
      return { x: origin.y - rect.y - rect.h, y: rect.x - origin.x, w: rect.h, h: rect.w };
    return { x: rect.y - origin.y, y: rect.x - origin.x, w: rect.h, h: rect.w };
  }
  function beamSegments(origin, heading, length2, width) {
    integer(heading, 0, 3, "beam heading");
    integer(length2, 0, MAX_SHAPE * 4, "beam length");
    integer(width, 1, 4096, "beam width");
    const result = [], y = -divide(width, 2).quotient;
    sweepBounds(cardinalRect(origin, { x: 0, y, w: length2, h: width }, heading));
    for (let x = 0; x < length2; x += MAX_SHAPE)
      result.push(
        cardinalRect(origin, { x, y, w: Math.min(MAX_SHAPE, length2 - x), h: width }, heading)
      );
    return result;
  }
  function castBeam(source3, definition2, profile, origin, heading, terrain, hurtboxes) {
    validateBeamPolicy(source3, definition2, profile);
    beamSegments(origin, heading, profile.range, profile.width);
    integer(terrain.length + hurtboxes.length, 0, 4096, "beam candidate budget");
    const ids2 = /* @__PURE__ */ new Set();
    for (const wall3 of terrain) validateSweepTarget(wall3);
    for (const hurt of hurtboxes) {
      integer(hurt.entityId, 1, COUNTER_LIMIT - 1, "beam target identity");
      integer(hurt.team, 0, 255, "beam target team");
      if (hurt.kind !== "body" && hurt.kind !== "shield" || hurt.solid !== void 0 && typeof hurt.solid !== "boolean")
        throw new Error("Invalid beam target material");
      integer(hurt.rect.w, 1, 2 ** 24, "beam target width");
      integer(hurt.rect.h, 1, 2 ** 24, "beam target height");
      sweepBounds(hurt.rect, hurt.delta);
    }
    for (const candidate of [...terrain, ...hurtboxes]) {
      integer(candidate.id, 1, COUNTER_LIMIT - 1, "beam collider identity");
      if (ids2.has(candidate.id)) throw new Error("Duplicate beam collider identity");
      ids2.add(candidate.id);
    }
    const top = -divide(profile.width, 2).quotient, bottom = top + profile.width;
    const candidates = [
      ...terrain.map((target) => ({
        ...target,
        kind: "terrain",
        entityId: null,
        solid: true,
        priority: 0
      })),
      ...hurtboxes.filter(
        (target) => target.entityId !== source3.ownerId && (target.solid || target.team !== source3.team)
      ).map((target) => ({
        ...target,
        priority: target.kind === "shield" ? 1 : target.solid ? 2 : 3
      }))
    ].flatMap((target) => {
      const rect = forward2(
        { ...target.rect, x: target.rect.x + target.delta.x, y: target.rect.y + target.delta.y },
        origin,
        heading
      );
      if (rect.y >= bottom || rect.y + rect.h <= top || rect.x + rect.w <= 0 || rect.x > profile.range)
        return [];
      return [{ target, rect, distance: Math.max(0, rect.x) }];
    }).sort(
      (a, b) => a.distance - b.distance || a.target.priority - b.target.priority || a.target.id - b.target.id
    );
    const seen = /* @__PURE__ */ new Set(), impacts = [];
    let length2 = profile.range, stoppedBy = null;
    for (const { target, rect, distance } of candidates) {
      const blocking = target.kind === "terrain" || target.kind === "shield" || target.solid;
      if (blocking) {
        length2 = distance;
        stoppedBy = target.kind === "terrain" ? "terrain" : target.kind === "shield" ? "shield" : "solid";
      }
      if (target.entityId === null || !seen.has(target.entityId)) {
        const point3 = cardinalRect(
          origin,
          { x: distance, y: Math.max(rect.y, Math.min(0, rect.y + rect.h)), w: 0, h: 0 },
          heading
        );
        impacts.push({
          sourceId: source3.id,
          definitionId: definition2.id,
          ownerId: source3.ownerId,
          actionInstanceId: source3.actionInstanceId,
          colliderId: target.id,
          entityId: target.entityId,
          kind: target.kind,
          damage: target.kind === "body" ? definition2.damage : 0,
          time: { numerator: 1, denominator: 1 },
          position: { x: position(point3.x), y: position(point3.y) }
        });
        if (target.entityId !== null) seen.add(target.entityId);
      }
      if (blocking) break;
      if (seen.size === definition2.maxTargets) {
        length2 = distance;
        stoppedBy = "penetration";
        break;
      }
    }
    return {
      origin: { ...origin },
      heading,
      length: length2,
      width: profile.width,
      segments: beamSegments(origin, heading, length2, profile.width),
      impacts,
      stoppedBy
    };
  }
  function validateBeamPulse(beam, definition2, profile) {
    validateBeamPolicy(beam, definition2, profile);
    integer(beam.spawnTick, 1, COUNTER_LIMIT - 1 - profile.pulseTicks, "beam birth tick");
    integer(beam.tick, beam.spawnTick, beam.spawnTick + profile.pulseTicks - 1, "beam tick");
    integer(beam.length, 0, profile.range, "beam clipped length");
    beamSegments(beam.origin, beam.heading, profile.range, profile.width);
  }
  function emitBeam(source3, tick2, definition2, profile, anchor, terrain, hurtboxes) {
    const beam = {
      ...source3,
      spawnTick: tick2,
      tick: tick2,
      origin: { ...anchor.origin },
      heading: anchor.heading,
      length: profile.range
    };
    validateBeamPulse(beam, definition2, profile);
    const cast = castBeam(
      source3,
      definition2,
      profile,
      anchor.origin,
      anchor.heading,
      terrain,
      hurtboxes
    );
    beam.length = cast.length;
    return { beam, cast };
  }
  function stepBeam(current, tick2, definition2, profile, anchor, terrain, hurtboxes) {
    validateBeamPulse(current, definition2, profile);
    if (tick2 !== current.tick + 1) throw new Error("Beam requires consecutive ticks");
    if (anchor === null || tick2 === current.spawnTick + profile.pulseTicks)
      return { beam: null, cast: null };
    const cast = castBeam(
      current,
      definition2,
      profile,
      anchor.origin,
      anchor.heading,
      terrain,
      hurtboxes
    );
    return {
      beam: {
        ...current,
        tick: tick2,
        origin: { ...anchor.origin },
        heading: anchor.heading,
        length: cast.length
      },
      // Moving across a target or restoring this state cannot grant another damage pulse.
      cast: { ...cast, impacts: [] }
    };
  }

  // src/game/combat/destructible.ts
  function createDestructible(definition2) {
    return {
      id: definition2.id,
      definitionId: definition2.definitionId,
      health: definition2.health,
      destroyedTick: null,
      destroyerId: null,
      destroyActionId: null
    };
  }
  function destructibleHurtboxes(props, definitions) {
    return props.filter((prop) => prop.health > 0).map((prop) => {
      const definition2 = definitions.find((definition3) => definition3.id === prop.id);
      if (!definition2 || definition2.definitionId !== prop.definitionId)
        throw new Error("Missing destructible geometry");
      return {
        id: prop.id,
        entityId: prop.id,
        team: 0,
        kind: "body",
        solid: true,
        rect: { ...definition2.rect },
        delta: { x: 0, y: 0 }
      };
    });
  }
  function damageDestructible(prop, impact2, attack2, tick2) {
    if (prop.health === 0 || impact2.damage === 0) return false;
    if (impact2.entityId !== prop.id || impact2.kind !== "body" || impact2.definitionId !== attack2.id)
      throw new Error("Destructible damage identity mismatch");
    integer(impact2.damage, 1, attack2.damage, "destructible damage");
    prop.health = Math.max(0, prop.health - impact2.damage);
    if (prop.health > 0) return false;
    prop.destroyedTick = tick2;
    prop.destroyerId = impact2.ownerId;
    prop.destroyActionId = impact2.actionInstanceId;
    return true;
  }
  function detachDestroyedSupport(body4, removed) {
    const detached = body4.supportId !== null && removed.has(body4.supportId);
    if (detached) {
      body4.supportId = null;
      body4.grounded = false;
    }
    body4.contacts = body4.contacts.filter((contact) => !removed.has(contact.otherId));
    return detached;
  }
  function validateDestructibles(props, definitions, tick2, ownerIds, nextActionId) {
    if (props.length !== definitions.length || props.length > 32)
      throw new Error("Destructible roster mismatch");
    for (const [index, prop] of props.entries()) {
      const definition2 = definitions[index];
      if (!definition2 || prop.id !== definition2.id || prop.definitionId !== definition2.definitionId)
        throw new Error("Destructible definition mismatch");
      integer(prop.health, 0, definition2.health, "destructible health");
      if (prop.health > 0) {
        if (prop.destroyedTick !== null || prop.destroyerId !== null || prop.destroyActionId !== null)
          throw new Error("Live prop has destruction attribution");
      } else {
        integer(prop.destroyedTick, 1, tick2, "destruction tick");
        integer(prop.destroyActionId, 1, nextActionId - 1, "destruction action");
        integer(prop.destroyerId, 1, COUNTER_LIMIT - 1, "destruction owner");
        if (!ownerIds.includes(prop.destroyerId))
          throw new Error("Unknown destruction owner");
      }
    }
  }

  // src/game/combat/firearm-aim.ts
  function validateFirearmSweep(profile, catalog) {
    const sweep = profile.sweep;
    if (!sweep) return;
    integer(sweep.stepTicks, 1, 60, "firearm heading exposure");
    const reference = catalog.timelines.get(profile.timelineIds[0]);
    if (!reference || sweep.headings.length !== 9) throw new Error("Incomplete firearm sweep");
    for (const [index, heading] of sweep.headings.entries()) {
      if (heading.pitch !== index - 4)
        throw new Error("Firearm headings must cover -4 through 4 in order");
      const timeline = catalog.timelines.get(heading.timelineId);
      if (!timeline || timeline.durationTicks !== reference.durationTicks || canonical(timeline.markers) !== canonical(reference.markers))
        throw new Error("Firearm sweep marker schedules disagree");
      motion(heading.velocity.x);
      motion(heading.velocity.y);
      if (heading.velocity.x < 0 || Math.sign(heading.velocity.y) !== -Math.sign(heading.pitch) || Math.abs(heading.pitch) === 4 !== (heading.velocity.x === 0) || heading.velocity.x === 0 && heading.velocity.y === 0)
        throw new Error("Invalid authored firearm velocity");
      for (const poseId of timeline.poses) {
        const muzzle = catalog.poses.get(poseId)?.sockets.find((socket) => socket.name === "muzzle");
        if (!muzzle || canonical(muzzle.point) !== canonical(heading.muzzle))
          throw new Error("Firearm sweep socket mismatch");
      }
    }
    for (const [pitch, timelineId] of [
      [0, profile.timelineIds[0]],
      [4, profile.timelineIds[1]],
      [-4, profile.timelineIds[2]]
    ])
      if (sweep.headings.find((heading) => heading.pitch === pitch)?.timelineId !== timelineId)
        throw new Error("Firearm cardinal and sweep poses disagree");
  }
  var cardinalPitch = (actor) => actor.aim === 1 ? 4 : actor.aim === 2 ? -4 : 0;
  var lowered = (actor) => actor.life !== "alive" || actor.vehicleId !== null;
  var crouched = (actor) => actor.aim === 0 && actor.locomotion === "crouched";
  function advanceFirearmAim(actor, tick2, catalog) {
    integer(tick2, 1, COUNTER_LIMIT - 1, "firearm aim tick");
    const profile = catalog.firearms.get(actor.weapon.id);
    if (!profile) throw new Error("Missing firearm aim profile");
    integer(actor.firearmAim.pitch, -4, 4, "firearm pitch");
    integer(
      actor.firearmAim.nextStepTick,
      0,
      tick2 + (profile.sweep?.stepTicks ?? 0),
      "firearm turn tick"
    );
    if (lowered(actor) || crouched(actor)) return { pitch: 0, nextStepTick: 0 };
    const target = cardinalPitch(actor);
    if (!profile.sweep) return { pitch: target, nextStepTick: 0 };
    const aim = { ...actor.firearmAim };
    if (aim.pitch !== target && tick2 >= aim.nextStepTick) {
      aim.pitch += Math.sign(target - aim.pitch);
      aim.nextStepTick = tick2 + profile.sweep.stepTicks;
    }
    return aim;
  }
  function firearmPoseTimeline(actor, catalog) {
    const profile = catalog.firearms.get(actor.weapon.id);
    if (!profile) throw new Error("Missing firearm profile");
    if (profile.sweep && !crouched(actor)) {
      const heading = profile.sweep.headings.find((value) => value.pitch === actor.firearmAim.pitch);
      if (!heading) throw new Error("Missing authored firearm heading");
      return heading.timelineId;
    }
    return profile.timelineIds[crouched(actor) ? 3 : actor.aim];
  }
  function firearmVelocity(actor, speed, catalog) {
    const profile = catalog.firearms.get(actor.weapon.id);
    if (!profile) throw new Error("Missing firearm profile");
    if (profile.sweep) {
      const heading = profile.sweep.headings.find((value) => value.pitch === actor.firearmAim.pitch);
      if (!heading) throw new Error("Missing authored firearm velocity");
      return { x: motion(heading.velocity.x * actor.facing), y: heading.velocity.y };
    }
    return {
      x: actor.aim === 0 ? motion(speed * actor.facing) : 0,
      y: actor.aim === 1 ? -speed : actor.aim === 2 ? speed : 0
    };
  }
  function validateFirearmAim(actor, tick2, catalog) {
    const profile = catalog.firearms.get(actor.weapon.id);
    if (!profile) throw new Error("Missing firearm profile");
    integer(actor.firearmAim.pitch, -4, 4, "firearm pitch");
    integer(
      actor.firearmAim.nextStepTick,
      0,
      tick2 + (profile.sweep?.stepTicks ?? 0),
      "firearm turn tick"
    );
    if (lowered(actor) || crouched(actor)) {
      if (actor.firearmAim.pitch !== 0 || actor.firearmAim.nextStepTick !== 0)
        throw new Error("Lowered firearm must have neutral aim");
    } else if (!profile.sweep && (actor.firearmAim.pitch !== cardinalPitch(actor) || actor.firearmAim.nextStepTick !== 0))
      throw new Error("Cardinal firearm aim mismatch");
    if (actor.action.kind === "fire" && actor.action.definitionId !== firearmPoseTimeline(actor, catalog))
      throw new Error("Firearm pose and heading disagree");
  }

  // src/game/combat/grenade.ts
  function grenadeVelocityBounds(profile) {
    return {
      x: Math.max(profile.standingVelocity.x, profile.crouchedVelocity.x) + profile.inheritedVelocityLimit.x,
      up: Math.max(-profile.standingVelocity.y, -profile.crouchedVelocity.y) + profile.inheritedVelocityLimit.y
    };
  }
  var clamp = (value, limit) => Math.max(-limit, Math.min(limit, value));
  function grenadeLaunchVelocity(actor, profile, index, frame) {
    index.assertFrame(frame);
    const support2 = actor.body.supportId === null ? void 0 : index.get(actor.body.supportId);
    if (actor.body.grounded !== (actor.body.supportId !== null) || actor.body.grounded && !support2)
      throw new Error("Grenade launch requires accepted support");
    if (actor.facing !== 1 && actor.facing !== -1) throw new Error("Grenade launch facing");
    const impulse = actor.locomotion === "crouched" ? profile.crouchedVelocity : profile.standingVelocity;
    return {
      x: motion(
        impulse.x * actor.facing + clamp(motion(actor.body.vx) + (support2?.delta.x ?? 0), profile.inheritedVelocityLimit.x)
      ),
      y: motion(
        Math.min(
          profile.terminalVelocity,
          impulse.y + clamp(motion(actor.body.vy) + (support2?.delta.y ?? 0), profile.inheritedVelocityLimit.y)
        )
      )
    };
  }
  function stepGrenade(current, profile, shape, index, frame) {
    integer(current.spawnTick, 1, frame.tick, "grenade birth");
    integer(current.id, 1, COUNTER_LIMIT - 1, "grenade ID");
    integer(current.bounces, 0, profile.maximumBounces, "grenade bounce count");
    if (shape.id !== profile.bodyShapeId || current.body.id !== current.id)
      throw new Error("Grenade body identity");
    const grenade = structuredClone(current);
    index.assertFrame(frame);
    if (frame.tick === current.spawnTick) return { grenade, status: "active" };
    const vx = grenade.body.vx, vy = motion(Math.min(profile.terminalVelocity, grenade.body.vy + profile.gravity));
    grenade.body.vy = vy;
    const supportId = vy < 0 || !current.body.grounded ? null : startSupport(grenade.body, shape, 1, index, frame, null);
    const carry = supportId === null ? void 0 : index.get(supportId)?.delta;
    const result = stepBody(grenade.body, shape, 1, index, {
      frame,
      carrySupport: current.body.grounded
    });
    if (result.status !== "complete") {
      if (result.reason !== "crushed") throw new Error(`Grenade terrain: ${result.reason}`);
      return {
        status: "crushed",
        position: {
          x: position(result.movement.rect.x - shape.rect.x),
          y: position(result.movement.rect.y - shape.rect.y)
        },
        colliderIds: result.movement.diagnosticIds
      };
    }
    grenade.body = result.body;
    const horizontal = result.movement.contacts.find((contact) => contact.normal.x !== 0);
    const vertical = result.movement.contacts.find((contact) => contact.normal.y !== 0);
    if ((horizontal || vertical) && grenade.bounces < profile.maximumBounces) {
      grenade.bounces++;
      let reboundX = vx + (carry?.x ?? 0), reboundY = vy + (carry?.y ?? 0);
      if (horizontal) {
        const target = index.get(horizontal.otherId);
        if (!target) throw new Error("Missing grenade horizontal contact");
        reboundX = target.delta.x - divide(reboundX - target.delta.x, 2).quotient;
      }
      if (vertical) {
        const target = index.get(vertical.otherId);
        if (!target) throw new Error("Missing grenade vertical contact");
        reboundY = target.delta.y - divide(reboundY - target.delta.y, 2).quotient;
        reboundX = target.delta.x + divide((reboundX - target.delta.x) * 3, 4).quotient;
      }
      const bounds = grenadeVelocityBounds(profile);
      grenade.body.vx = motion(clamp(reboundX, bounds.x));
      grenade.body.vy = motion(Math.max(-bounds.up, Math.min(profile.terminalVelocity, reboundY)));
      grenade.body.grounded = false;
      grenade.body.supportId = null;
    } else if (vertical && grenade.body.grounded)
      grenade.body.vx = divide(grenade.body.vx * 3, 4).quotient;
    return frame.tick - current.spawnTick >= profile.fuseTicks ? { status: "detonated", position: { x: grenade.body.x, y: grenade.body.y } } : { grenade, status: "active" };
  }

  // src/game/combat/rocket.ts
  var QUADRANT = [
    [16384, 0],
    [16069, 3196],
    [15137, 6270],
    [13623, 9102],
    [11585, 11585],
    [9102, 13623],
    [6270, 15137],
    [3196, 16069]
  ];
  var HEADINGS = [0, 1, 2, 3].flatMap(
    (quadrant) => QUADRANT.map(
      ([x, y]) => quadrant === 0 ? [x, y] : quadrant === 1 ? [-y, x] : quadrant === 2 ? [-x, -y] : [y, -x]
    )
  );
  var difference = (from, to) => (to - from + 48) % 32 - 16;
  function velocity(heading, speed) {
    const vector = HEADINGS[integer(heading, 0, 31, "rocket heading")];
    if (!vector || vector[0] === void 0 || vector[1] === void 0)
      throw new Error("Missing rocket heading");
    return {
      x: divide(vector[0] * speed, 16384).quotient,
      y: divide(vector[1] * speed, 16384).quotient
    };
  }
  function headingTo(delta, fallback) {
    if (delta.x === 0 && delta.y === 0) return fallback;
    let best = 0, score = -Infinity;
    for (const [heading, vector] of HEADINGS.entries()) {
      const dot = (vector[0] ?? 0) * delta.x + (vector[1] ?? 0) * delta.y;
      if (dot > score) {
        best = heading;
        score = dot;
      }
    }
    return best;
  }
  function validateRocketProfile(profile) {
    integer(profile.bodyShapeId, 1, COUNTER_LIMIT - 1, "rocket shape");
    integer(profile.launchSpeed, 1, MAX_MOTION, "rocket launch speed");
    integer(profile.maximumSpeed, profile.launchSpeed, MAX_MOTION, "rocket maximum speed");
    integer(profile.acceleration, 1, MAX_MOTION, "rocket acceleration");
    integer(profile.lifetimeTicks, 1, 3600, "rocket lifetime");
    integer(profile.blastRadius, 1, 2 ** 16, "rocket blast radius");
    integer(profile.acquireRange, 1, MAX_MOTION, "rocket acquisition range");
    integer(profile.retainRange, profile.acquireRange, MAX_MOTION, "rocket retention range");
    integer(profile.acquireSteps, 0, 7, "rocket acquisition cone");
    integer(profile.retainSteps, profile.acquireSteps, 7, "rocket retention cone");
    integer(profile.launchLeashSteps, 0, 7, "rocket launch leash");
    integer(profile.acquireIntervalTicks, 1, 60, "rocket acquisition interval");
    integer(profile.turnIntervalTicks, 1, 60, "rocket turn interval");
  }
  function validateRocket(rocket2, profile) {
    for (const id2 of [rocket2.id, rocket2.ownerId, rocket2.actionInstanceId, rocket2.definitionId])
      integer(id2, 1, COUNTER_LIMIT - 1, "rocket identity");
    integer(rocket2.team, 1, 255, "rocket team");
    const tail = profile.lifetimeTicks + Math.max(profile.acquireIntervalTicks, profile.turnIntervalTicks);
    integer(rocket2.spawnTick, 1, COUNTER_LIMIT - 1 - tail, "rocket birth tick");
    integer(
      rocket2.tick,
      rocket2.spawnTick,
      rocket2.spawnTick + profile.lifetimeTicks - 1,
      "rocket tick"
    );
    integer(rocket2.launchHeading, 0, 31, "rocket launch heading");
    integer(rocket2.heading, 0, 31, "rocket heading");
    if (Math.abs(difference(rocket2.launchHeading, rocket2.heading)) > profile.launchLeashSteps)
      throw new Error("Rocket exceeded its launch leash");
    const speed = Math.min(
      profile.maximumSpeed,
      profile.launchSpeed + (rocket2.tick - rocket2.spawnTick) * profile.acceleration
    );
    if (rocket2.speed !== speed) throw new Error("Rocket speed disagrees with its age");
    const expected = velocity(rocket2.heading, speed);
    if (rocket2.velocity.x !== expected.x || rocket2.velocity.y !== expected.y)
      throw new Error("Rocket velocity disagrees with its heading");
    position(rocket2.position.x);
    position(rocket2.position.y);
    if (rocket2.targetId !== null) {
      integer(rocket2.targetId, 1, COUNTER_LIMIT - 1, "rocket target");
      if (rocket2.targetId === rocket2.ownerId) throw new Error("Rocket cannot lock its owner");
    }
    integer(
      rocket2.nextAcquireTick,
      rocket2.tick + 1,
      rocket2.tick + profile.acquireIntervalTicks,
      "rocket acquisition clock"
    );
    integer(
      rocket2.nextTurnTick,
      rocket2.tick + 1,
      rocket2.tick + profile.turnIntervalTicks,
      "rocket turn clock"
    );
    if ((rocket2.nextAcquireTick - rocket2.spawnTick - 1) % profile.acquireIntervalTicks !== 0 || (rocket2.nextTurnTick - rocket2.spawnTick) % profile.turnIntervalTicks !== 0)
      throw new Error("Rocket guidance clock phase disagrees with its birth");
  }
  function createRocket(source3, origin, heading, tick2, profile) {
    validateRocketProfile(profile);
    const rocket2 = {
      ...source3,
      position: { ...origin },
      velocity: velocity(heading, profile.launchSpeed),
      spawnTick: tick2,
      tick: tick2,
      launchHeading: heading,
      heading,
      speed: profile.launchSpeed,
      targetId: null,
      nextAcquireTick: tick2 + 1,
      nextTurnTick: tick2 + profile.turnIntervalTicks
    };
    validateRocket(rocket2, profile);
    return rocket2;
  }
  function validateCandidates(terrain, hurtboxes) {
    integer(terrain.length + hurtboxes.length, 0, 4096, "rocket candidates");
    const ids2 = /* @__PURE__ */ new Set();
    for (const target of terrain) validateSweepTarget(target);
    for (const target of hurtboxes) {
      integer(target.id, 1, COUNTER_LIMIT - 1, "rocket collision ID");
      integer(target.entityId, 1, COUNTER_LIMIT - 1, "rocket hurt entity");
      integer(target.team, 0, 255, "rocket hurt team");
      if (target.kind !== "body" && target.kind !== "shield")
        throw new Error("Invalid rocket hurt kind");
      if (target.solid !== void 0 && typeof target.solid !== "boolean")
        throw new Error("Invalid rocket solid flag");
      sweepBounds(target.rect, target.delta);
      integer(target.rect.w, 1, 2 ** 24, "rocket hurt width");
      integer(target.rect.h, 1, 2 ** 24, "rocket hurt height");
    }
    for (const target of [...terrain, ...hurtboxes]) {
      if (ids2.has(target.id)) throw new Error("Duplicate rocket collision ID");
      ids2.add(target.id);
    }
  }
  function guidanceTargets(rocket2, profile, terrain, hurtboxes, retaining) {
    const range = retaining ? profile.retainRange : profile.acquireRange, steps = retaining ? profile.retainSteps : profile.acquireSteps;
    const candidates = hurtboxes.flatMap((target) => {
      if (target.kind !== "body" || target.solid || target.team === 0 || target.team === rocket2.team || target.entityId === rocket2.ownerId || retaining && target.entityId !== rocket2.targetId)
        return [];
      const center = {
        x: target.rect.x + divide(target.rect.w, 2).quotient,
        y: target.rect.y + divide(target.rect.h, 2).quotient
      }, delta = { x: center.x - rocket2.position.x, y: center.y - rocket2.position.y }, distance = delta.x * delta.x + delta.y * delta.y, heading = headingTo(delta, rocket2.heading);
      if (distance > range * range || Math.abs(difference(rocket2.heading, heading)) > steps || Math.abs(difference(rocket2.launchHeading, heading)) > profile.launchLeashSteps)
        return [];
      return [{ target, delta, distance, heading }];
    }).sort(
      (a, b) => a.distance - b.distance || a.target.entityId - b.target.entityId || a.target.id - b.target.id
    );
    const blockers = [
      ...terrain,
      ...hurtboxes.filter(
        (target) => target.solid || target.kind === "shield" && target.team !== rocket2.team && target.entityId !== rocket2.ownerId
      )
    ];
    for (const candidate of candidates) {
      if (!blockers.some(
        (target) => sweepAabb({ ...rocket2.position, w: 0, h: 0 }, candidate.delta, target.rect)
      ))
        return candidate;
    }
    return null;
  }
  function stepRocket(current, tick2, definition2, shape, profile, terrain, hurtboxes) {
    validateRocketProfile(profile);
    validateRocket(current, profile);
    if (tick2 !== current.tick + 1) throw new Error("Rocket requires consecutive ticks");
    if (definition2.id !== current.definitionId || definition2.kind !== "explosion" || definition2.material !== "explosive" || definition2.lifetimeTicks !== profile.lifetimeTicks || definition2.speed !== profile.launchSpeed || definition2.repeatDamageTicks !== 0 || shape.id !== profile.bodyShapeId)
      throw new Error("Invalid rocket attack policy");
    integer(definition2.damage, 1, 65535, "rocket damage");
    integer(definition2.maxTargets, 1, 64, "rocket blast targets");
    worldRect(current.position, shape.rect, 1);
    const extentX = Math.max(Math.abs(shape.rect.x), Math.abs(shape.rect.x + shape.rect.w)), extentY = Math.max(Math.abs(shape.rect.y), Math.abs(shape.rect.y + shape.rect.h));
    if (extentX * extentX + extentY * extentY > profile.blastRadius * profile.blastRadius)
      throw new Error("Rocket blast must enclose its flight body");
    validateCandidates(terrain, hurtboxes);
    const rocket2 = structuredClone(current);
    let lock = rocket2.targetId === null ? null : guidanceTargets(rocket2, profile, terrain, hurtboxes, true);
    if (!lock) rocket2.targetId = null;
    if (tick2 >= rocket2.nextAcquireTick) {
      if (!lock) lock = guidanceTargets(rocket2, profile, terrain, hurtboxes, false);
      rocket2.nextAcquireTick = tick2 + profile.acquireIntervalTicks;
    }
    rocket2.targetId = lock?.target.entityId ?? null;
    if (tick2 >= rocket2.nextTurnTick) {
      if (lock)
        rocket2.heading = (rocket2.heading + Math.sign(difference(rocket2.heading, lock.heading)) + 32) % 32;
      rocket2.nextTurnTick = tick2 + profile.turnIntervalTicks;
    }
    rocket2.speed = Math.min(profile.maximumSpeed, rocket2.speed + profile.acceleration);
    rocket2.velocity = velocity(rocket2.heading, rocket2.speed);
    const contact = projectileImpact(rocket2, shape, 0, terrain, hurtboxes);
    if (contact)
      return {
        status: "detonated",
        contact,
        // Contact selects the blast origin/time; it never grants a second direct-hit debit.
        impacts: explosionHits(
          rocket2,
          definition2,
          contact.position,
          profile.blastRadius,
          terrain,
          hurtboxes,
          { time: contact.time, primaryTarget: contact.entityId }
        )
      };
    rocket2.position = {
      x: position(rocket2.position.x + motion(rocket2.velocity.x)),
      y: position(rocket2.position.y + motion(rocket2.velocity.y))
    };
    rocket2.tick = tick2;
    return tick2 - rocket2.spawnTick >= profile.lifetimeTicks ? { status: "expired", position: rocket2.position } : { status: "active", rocket: rocket2 };
  }

  // src/game/content/weapons/laser.ts
  var LASER_WEAPON = {
    id: "laser",
    attackId: 18,
    timelineId: 230,
    cadenceTicks: 6,
    ammoPerAction: 1,
    pickupAmmo: 120,
    aimPolicy: "cardinal",
    visualFamily: "fixture-laser",
    audioFamily: "fixture-laser"
  };
  var LASER_PROFILE = { range: pixels(512), width: pixels(4), pulseTicks: 6 };
  var LASER_SHAPE = {
    id: 21,
    rect: { x: 0, y: -pixels(2), w: pixels(256), h: pixels(4) }
  };
  var LASER_ATTACK = {
    id: LASER_WEAPON.attackId,
    kind: "beam",
    shapeId: LASER_SHAPE.id,
    damage: 2,
    lifetimeTicks: 6,
    speed: 0,
    maxTargets: 8,
    repeatDamageTicks: 6,
    material: "energy"
  };
  validateBeamProfile(LASER_PROFILE);

  // src/game/content/weapons/rocket-launcher.ts
  var ROCKET_WEAPON = {
    id: "rocket-launcher",
    attackId: 17,
    timelineId: 220,
    cadenceTicks: 24,
    ammoPerAction: 1,
    pickupAmmo: 20,
    aimPolicy: "cardinal",
    visualFamily: "fixture-rocket",
    audioFamily: "fixture-rocket"
  };
  var ROCKET_SHAPE = {
    id: 19,
    rect: { x: -pixels(2), y: -pixels(2), w: pixels(4), h: pixels(4) }
  };
  var ROCKET_BLAST_SHAPE = {
    id: 20,
    rect: { x: -pixels(48), y: -pixels(48), w: pixels(96), h: pixels(96) }
  };
  var ROCKET_PROFILE = {
    bodyShapeId: ROCKET_SHAPE.id,
    launchSpeed: pixels(2),
    acceleration: 128,
    maximumSpeed: pixels(6),
    lifetimeTicks: 90,
    blastRadius: pixels(48),
    acquireRange: pixels(240),
    retainRange: pixels(256),
    acquireSteps: 2,
    retainSteps: 4,
    launchLeashSteps: 4,
    acquireIntervalTicks: 6,
    turnIntervalTicks: 3
  };
  var ROCKET_ATTACK = {
    id: ROCKET_WEAPON.attackId,
    kind: "explosion",
    shapeId: ROCKET_BLAST_SHAPE.id,
    damage: 4,
    lifetimeTicks: ROCKET_PROFILE.lifetimeTicks,
    speed: ROCKET_PROFILE.launchSpeed,
    maxTargets: 16,
    repeatDamageTicks: 0,
    material: "explosive"
  };
  validateRocketProfile(ROCKET_PROFILE);

  // src/game/encounters/lifecycle.ts
  var POSE_FAULTS = ["initial-overlap", "residual-overlap", "contact-limit", "unresolved-contact"];
  function check4(ok, message) {
    if (!ok) throw new Error(`Encounter: ${message}`);
  }
  function id(value) {
    return integer(value, 1, COUNTER_LIMIT - 1, "encounter ID");
  }
  function tick(value) {
    return integer(value, 0, COUNTER_LIMIT - 2, "encounter tick");
  }
  function unique(values) {
    for (const value of values) id(value);
    check4(new Set(values).size === values.length, "duplicate ID");
  }
  function encounterCounts(state) {
    return {
      pending: state.members.filter((m) => m.status === "pending").length,
      alive: state.members.filter((m) => m.status === "alive").length,
      resolved: state.members.filter((m) => m.status === "resolved").length
    };
  }
  var EncounterLifecycle = class {
    #definition;
    #key;
    constructor(definition2) {
      id(definition2.id);
      integer(definition2.participants.length, 1, 4, "participant count");
      integer(definition2.members.length, 0, 256, "member count");
      integer(definition2.objectives.length, 0, 64, "objective count");
      unique(definition2.participants);
      unique(definition2.members.map((m) => m.id));
      unique(definition2.objectives);
      for (const member of definition2.members) {
        for (const flag of [member.required, member.critical, member.retreatAllowed])
          check4(typeof flag === "boolean", "member flag");
        integer(member.watchdogTicks, 1, 36e3, "watchdog duration");
        check4(
          !member.critical || member.required && !member.retreatAllowed,
          "critical actor policy"
        );
        if (member.ambientCleanupTicks !== null) {
          integer(
            member.ambientCleanupTicks,
            member.watchdogTicks,
            36e3,
            "ambient cleanup duration"
          );
          check4(!member.required && !member.critical, "required actor cannot use ambient cleanup");
        }
      }
      this.#definition = structuredClone(definition2);
      this.#definition.members.sort((a, b) => a.id - b.id);
      this.#definition.participants.sort((a, b) => a - b);
      this.#definition.objectives.sort((a, b) => a - b);
      this.#key = canonical(this.#definition);
      Object.freeze(this);
    }
    begin(startTick = 0) {
      tick(startTick);
      return {
        definitionKey: this.#key,
        tick: startTick,
        phase: "active",
        members: this.#definition.members.map((m) => ({
          id: m.id,
          status: "pending",
          activatedTick: null,
          resolvedTick: null,
          reason: null,
          killerId: null,
          progressKey: null,
          unchangedSince: null,
          unreachableSince: null,
          warnedUnchanged: false,
          warnedUnreachable: false
        })),
        objectives: this.#definition.objectives.map((id2) => ({ id: id2, completedTick: null })),
        kills: this.#definition.participants.map((playerId) => ({ playerId, count: 0 })),
        receipts: [],
        failure: null
      };
    }
    remaining(state) {
      if (state.phase === "retired") return 0;
      return state.members.filter(
        (m, i) => this.#definition.members[i]?.required && m.status !== "resolved"
      ).length + state.objectives.filter((o) => o.completedTick === null).length;
    }
    /** Check a saved continuation without advancing clocks, watchdogs or event receipts. */
    restore(state) {
      this.#validate(state);
      return structuredClone(state);
    }
    step(current, atTick, events, observations, failureMode = "record") {
      this.#validate(current);
      tick(atTick);
      check4(atTick === current.tick + 1, "nonconsecutive tick");
      check4(failureMode === "record" || failureMode === "throw", "failure mode");
      integer(events.length, 0, 1024, "event batch size");
      integer(observations.length, 0, 256, "observation count");
      const state = structuredClone(current);
      state.tick = atTick;
      const notices = [];
      const fail = (memberId, reason, cause) => {
        if (state.failure) return;
        state.failure = { id: memberId, tick: atTick, reason, cause };
        state.phase = "failed";
        notices.push({
          kind: "failed",
          encounterId: this.#definition.id,
          failure: { ...state.failure }
        });
      };
      for (const event of [...events].sort((a, b) => a.sequence - b.sequence)) {
        integer(event.sequence, 1, 1024, "event sequence");
        tick(event.tick);
        const signature = canonical(event);
        if (event.sequence <= state.receipts.length) {
          check4(state.receipts[event.sequence - 1] === signature, "conflicting duplicate event");
          continue;
        }
        check4(event.sequence === state.receipts.length + 1, "event sequence gap");
        check4(event.tick === atTick, "event effective tick mismatch");
        check4(
          state.phase !== "retired" && current.phase !== "failed",
          "event after terminal encounter"
        );
        if (event.kind === "retire") {
          check4(!state.failure, "cannot retire failed encounter");
          check4(Object.keys(event).length === 3, "retire event fields");
          for (const member of state.members)
            if (member.status !== "resolved") {
              member.status = "resolved";
              member.reason = "checkpoint-retired";
              member.resolvedTick = atTick;
            }
          state.phase = "retired";
          notices.push({ kind: "retired", tick: atTick, encounterId: this.#definition.id });
        } else if (event.kind === "objective") {
          check4(Object.keys(event).length === 4, "objective event fields");
          const objective = state.objectives.find((o) => o.id === event.id);
          check4(objective && objective.completedTick === null, "unknown/completed objective");
          objective.completedTick = atTick;
        } else {
          const index = state.members.findIndex((m) => m.id === event.id), member = state.members[index], policy = this.#definition.members[index];
          check4(member && policy, "unknown member");
          if (event.kind === "activate") {
            check4(Object.keys(event).length === 4, "activation fields");
            check4(member.status === "pending", "member already activated/resolved");
            member.status = "alive";
            member.activatedTick = atTick;
          } else if (event.kind === "fault") {
            check4(
              Object.keys(event).length === 5 && POSE_FAULTS.includes(event.reason),
              "pose fault fields"
            );
            check4(member.status === "alive", "fault of nonliving member");
            fail(event.id, policy.critical ? "critical-loss" : "invalid-pose", event.reason);
          } else {
            check4(event.kind === "resolve" && Object.keys(event).length === 6, "resolution fields");
            check4(member.status === "alive", "resolution of nonliving member");
            check4(
              ["killed", "retreated", "crushed", "out-of-bounds"].includes(event.reason),
              "resolution reason"
            );
            check4(
              event.killerId === null || event.reason === "killed" && this.#definition.participants.includes(event.killerId),
              "invalid kill attribution"
            );
            member.status = "resolved";
            member.resolvedTick = atTick;
            member.reason = event.reason;
            member.killerId = event.killerId;
            if (event.killerId !== null) {
              const credit = state.kills.find((k) => k.playerId === event.killerId);
              check4(credit, "unknown participant");
              credit.count++;
            }
            if (policy.critical && event.reason !== "killed")
              fail(event.id, "critical-loss", event.reason);
            else if (event.reason === "retreated" && !policy.retreatAllowed)
              fail(event.id, "forbidden-retreat", event.reason);
          }
        }
        state.receipts.push(signature);
      }
      const observed = /* @__PURE__ */ new Map();
      for (const observation of observations) {
        id(observation.id);
        check4(!observed.has(observation.id), "duplicate observation");
        check4(
          typeof observation.progressKey === "string" && observation.progressKey.length > 0 && observation.progressKey.length <= 256 && typeof observation.unreachable === "boolean",
          "invalid progress observation"
        );
        check4(
          state.members.some((m) => m.id === observation.id),
          "unknown observed member"
        );
        observed.set(observation.id, observation);
      }
      if (state.phase !== "failed" && state.phase !== "retired") {
        for (let i = 0; i < state.members.length; i++) {
          const member = state.members[i], policy = this.#definition.members[i];
          check4(member && policy, "missing member policy");
          if (member.status !== "alive") continue;
          const observation = observed.get(member.id);
          check4(observation, "missing living member observation");
          if (member.progressKey !== observation.progressKey) {
            member.progressKey = observation.progressKey;
            member.unchangedSince = atTick;
            member.warnedUnchanged = false;
          }
          if (!observation.unreachable) {
            member.unreachableSince = null;
            member.warnedUnreachable = false;
          } else if (member.unreachableSince === null) member.unreachableSince = atTick;
          for (const reason of ["unchanged", "unreachable"]) {
            const since = reason === "unchanged" ? member.unchangedSince : member.unreachableSince;
            const warned = reason === "unchanged" ? member.warnedUnchanged : member.warnedUnreachable;
            if (since !== null && atTick - since >= policy.watchdogTicks && !warned) {
              notices.push({
                kind: "watchdog",
                tick: atTick,
                encounterId: this.#definition.id,
                id: member.id,
                sinceTick: since,
                reason,
                progressKey: observation.progressKey
              });
              if (reason === "unchanged") member.warnedUnchanged = true;
              else member.warnedUnreachable = true;
            }
          }
          const stalledSince = member.unreachableSince ?? member.unchangedSince;
          if (policy.ambientCleanupTicks !== null && stalledSince !== null && atTick - stalledSince >= policy.ambientCleanupTicks) {
            member.status = "resolved";
            member.resolvedTick = atTick;
            member.reason = "ambient-timeout";
            notices.push({
              kind: "remove-ambient",
              tick: atTick,
              id: member.id,
              reason: "ambient-timeout"
            });
          }
        }
        if (state.phase === "active" && this.remaining(state) === 0) {
          state.phase = "complete";
          notices.push({ kind: "complete", tick: atTick, encounterId: this.#definition.id });
        }
      }
      if (failureMode === "throw" && state.failure)
        throw new Error(
          `Encounter ${this.#definition.id} ${state.failure.reason}: ${state.failure.id} at ${state.failure.tick}`
        );
      return { state, notices, remaining: this.remaining(state), counts: encounterCounts(state) };
    }
    #validate(state) {
      check4(state.definitionKey === this.#key, "definition mismatch");
      tick(state.tick);
      check4(["active", "complete", "retired", "failed"].includes(state.phase), "phase");
      check4(
        state.members.length === this.#definition.members.length && state.members.every((m, i) => m.id === this.#definition.members[i]?.id),
        "roster mismatch"
      );
      check4(
        state.objectives.length === this.#definition.objectives.length && state.objectives.every((o, i) => o.id === this.#definition.objectives[i]),
        "objective roster mismatch"
      );
      check4(
        state.kills.length === this.#definition.participants.length && state.kills.every((k, i) => k.playerId === this.#definition.participants[i]),
        "participant mismatch"
      );
      integer(state.receipts.length, 0, 1024, "receipt count");
      for (let i = 0; i < state.receipts.length; i++) {
        const receipt = state.receipts[i];
        check4(typeof receipt === "string" && receipt.length <= 512, "receipt length");
        const event = JSON.parse(receipt);
        tick(event.tick);
        check4(
          event.sequence === i + 1 && event.tick <= state.tick && canonical(event) === receipt,
          "receipt continuation"
        );
      }
      for (const member of state.members) {
        check4(["pending", "alive", "resolved"].includes(member.status), "member status");
        for (const value of [
          member.activatedTick,
          member.resolvedTick,
          member.unchangedSince,
          member.unreachableSince
        ])
          if (value !== null) {
            tick(value);
            check4(value <= state.tick, "future member tick");
          }
        check4(
          member.status === "resolved" === (member.reason !== null) && member.status === "resolved" === (member.resolvedTick !== null),
          "resolution state"
        );
        check4(
          member.reason === null || [
            "killed",
            "retreated",
            "crushed",
            "out-of-bounds",
            "ambient-timeout",
            "checkpoint-retired"
          ].includes(member.reason),
          "unknown saved resolution"
        );
        check4(
          member.killerId === null || member.reason === "killed" && this.#definition.participants.includes(member.killerId),
          "saved kill attribution"
        );
        check4(member.status !== "alive" || member.activatedTick !== null, "missing activation");
        check4(
          member.status !== "pending" || member.activatedTick === null && member.progressKey === null && member.unchangedSince === null && member.unreachableSince === null,
          "pending member continuation"
        );
        check4(
          member.progressKey === null || typeof member.progressKey === "string" && member.progressKey.length > 0 && member.progressKey.length <= 256,
          "saved progress key"
        );
        check4(
          typeof member.warnedUnchanged === "boolean" && typeof member.warnedUnreachable === "boolean",
          "saved watchdog flags"
        );
        check4(
          member.progressKey === null === (member.unchangedSince === null),
          "saved progress timer"
        );
      }
      for (const objective of state.objectives)
        if (objective.completedTick !== null) {
          tick(objective.completedTick);
          check4(objective.completedTick <= state.tick, "future objective tick");
        }
      for (const credit of state.kills) {
        integer(credit.count, 0, 256, "kill count");
        check4(
          credit.count === state.members.filter((m) => m.reason === "killed" && m.killerId === credit.playerId).length,
          "kill count mismatch"
        );
      }
      check4(state.phase === "failed" === (state.failure !== null), "failure state");
      if (state.failure) {
        tick(state.failure.tick);
        check4(
          state.failure.tick <= state.tick && state.members.some((m) => m.id === state.failure?.id) && ["critical-loss", "forbidden-retreat", "invalid-pose"].includes(state.failure.reason) && [...POSE_FAULTS, "retreated", "crushed", "out-of-bounds"].includes(state.failure.cause),
          "invalid failure continuation"
        );
      }
      check4(state.phase !== "complete" || this.remaining(state) === 0, "premature completion");
    }
  };

  // src/game/actors/grounded.ts
  function hasLeadingSupport(body4, shape, facing2, speed, supportId, index, frame) {
    index.assertFrame(frame);
    const support2 = index.get(supportId);
    if (!support2) return false;
    const projected = worldRect(
      {
        x: position(body4.x + speed * facing2 + support2.delta.x),
        y: position(body4.y + support2.delta.y)
      },
      shape.rect,
      facing2
    );
    const lead = facing2 === 1 ? projected.x + projected.w - 1 : projected.x;
    const feet = projected.y + projected.h;
    const previousLead = lead - speed * facing2;
    const first = Math.min(previousLead, lead);
    const last = Math.max(previousLead, lead);
    const spans = index.query(sweepBounds({ x: first, y: feet, w: last - first + 1, h: 1 })).filter((target) => {
      if (target.delta.x !== support2.delta.x || target.delta.y !== support2.delta.y) return false;
      const gap = target.rect.y + target.delta.y - feet;
      return gap >= 0 && gap <= (target.id === supportId ? 1 : 0);
    }).map((target) => ({
      start: target.rect.x + target.delta.x,
      end: target.rect.x + target.delta.x + target.rect.w
    })).sort((a, b) => a.start - b.start || a.end - b.end);
    let cursor = first;
    for (const span of spans) {
      if (span.end <= cursor) continue;
      if (span.start > cursor) return false;
      cursor = span.end;
      if (cursor > last) return true;
    }
    return false;
  }
  function stepGroundedEnemy(current, definition2, shape, index, frame) {
    index.assertFrame(frame);
    if (current.geometryRevision !== frame.geometryRevision)
      throw new Error("Enemy geometry revision mismatch");
    integer(current.turns, 0, COUNTER_LIMIT - 2, "enemy turns");
    motion(definition2.speed);
    motion(definition2.gravity);
    motion(definition2.terminalVelocity);
    if (definition2.speed < 0 || definition2.gravity <= 0 || definition2.terminalVelocity <= 0)
      throw new Error("Invalid grounded patrol motion");
    for (const value of [
      definition2.bounds.x,
      definition2.bounds.y,
      definition2.bounds.x + definition2.bounds.w,
      definition2.bounds.y + definition2.bounds.h
    ])
      position(value);
    if (definition2.bounds.w <= 0 || definition2.bounds.h <= 0)
      throw new Error("Invalid patrol bounds");
    if (current.life === "removed")
      return { status: "complete", enemy: current, decision: "removed", physics: null };
    const body4 = { ...current.body, contacts: [...current.body.contacts] };
    if (body4.remainderX !== 0 || body4.remainderY !== 0)
      throw new Error("Patrol requires integral motion");
    const supportId = body4.vy >= 0 ? startSupport(body4, shape, current.facing, index, frame, null) : null;
    body4.supportId = supportId;
    body4.grounded = supportId !== null;
    let facing2 = current.facing;
    let decision = supportId === null ? "fall" : "walk";
    let turns = current.turns;
    if (supportId !== null) {
      const rect = worldRect(body4, shape.rect, facing2);
      const blocked = body4.contacts.some((contact) => {
        const target = index.get(contact.otherId);
        if (target?.kind !== "solid" || contact.normalX !== -facing2) return false;
        const gap = facing2 === 1 ? target.rect.x - rect.x - rect.w : rect.x - target.rect.x - target.rect.w;
        return gap >= 0 && gap <= 1 && rect.y < target.rect.y + target.rect.h && rect.y + rect.h > target.rect.y;
      });
      if (blocked || !hasLeadingSupport(body4, shape, facing2, definition2.speed, supportId, index, frame)) {
        decision = "turn";
        const nextFacing = definition2.turnAtBoundary === false ? facing2 : facing2 === 1 ? -1 : 1;
        const turn = tryBodyShape(body4, shape, shape, facing2, nextFacing, index, frame);
        if (turn.accepted && nextFacing !== facing2) {
          facing2 = nextFacing;
          body4.contacts = [];
          turns++;
        }
        body4.vx = 0;
      } else body4.vx = definition2.speed === 0 ? 0 : definition2.speed * facing2;
      body4.vy = 0;
    }
    body4.vy = motion(Math.min(definition2.terminalVelocity, body4.vy + definition2.gravity));
    const physics = stepBody(body4, shape, facing2, index, { frame });
    if (physics.status === "failed") {
      if (physics.reason !== "crushed") return { status: "failed", physics };
      return {
        status: "complete",
        enemy: { ...current, life: "removed", removalReason: "crushed" },
        decision: "removed",
        physics
      };
    }
    const next = physics.body;
    const bounds = definition2.bounds;
    const outside = next.x < bounds.x || next.x > bounds.x + bounds.w || next.y < bounds.y || next.y > bounds.y + bounds.h;
    return {
      status: "complete",
      enemy: {
        ...current,
        body: next,
        facing: facing2,
        turns,
        life: outside ? "removed" : "alive",
        removalReason: outside ? "out-of-bounds" : null
      },
      decision: outside ? "removed" : decision,
      physics
    };
  }

  // src/game/combat/firearm.ts
  function beginFirearm(current, tick2, nextActionId, catalog) {
    integer(tick2, 1, COUNTER_LIMIT - 1, "firearm tick");
    integer(
      nextActionId,
      current.weapon.lastActionInstanceId + 1,
      COUNTER_LIMIT - 2,
      "firearm allocation"
    );
    if (current.life !== "alive" || current.vehicleId !== null || current.action.kind !== "ready" || current.weapon.cooldownTicks !== 0)
      throw new Error("Firearm action is not ready");
    const actor = structuredClone(current);
    let profile = catalog.firearms.get(actor.weapon.id);
    if (!profile) throw new Error("Missing firearm profile");
    if (actor.weapon.ammo < profile.weapon.ammoPerAction) {
      profile = catalog.firearms.get("sidearm");
      if (profile?.weapon.ammoPerAction !== 0) throw new Error("Missing unlimited sidearm fallback");
      actor.weapon.id = "sidearm";
      actor.weapon.ammo = 0;
      actor.firearmAim = { pitch: actor.aim === 1 ? 4 : actor.aim === 2 ? -4 : 0, nextStepTick: 0 };
    }
    actor.action = {
      kind: "fire",
      actionInstanceId: nextActionId,
      stateStartTick: tick2,
      definitionId: firearmPoseTimeline(actor, catalog),
      nextMarkerIndex: 0
    };
    actor.weapon.ammo -= profile.weapon.ammoPerAction;
    actor.weapon.cooldownTicks = profile.weapon.cadenceTicks;
    actor.weapon.shotOrdinal = nextCounter(actor.weapon.shotOrdinal);
    actor.weapon.lastActionInstanceId = actor.action.actionInstanceId;
    const result = stepAction(actor.action, tick2, catalog);
    actor.action = result.action;
    return { actor, markers: result.markers, nextActionId: nextCounter(nextActionId) };
  }
  function stepFirearm(current, intent, tick2, nextActionId, catalog) {
    integer(tick2, 1, COUNTER_LIMIT - 1, "firearm tick");
    integer(nextActionId, 1, COUNTER_LIMIT - 2, "next action ID");
    integer(intent.held, 0, HELD_MASK, "firearm held mask");
    if (typeof intent.firePressed !== "boolean") throw new Error("Invalid fire edge");
    if (nextActionId <= current.weapon.lastActionInstanceId)
      throw new Error("Action allocator regressed");
    integer(current.weapon.cooldownTicks, 0, 3600, "weapon cooldown");
    integer(current.weapon.ammo, 0, 65535, "weapon ammunition");
    let actor = structuredClone(current);
    actor.firearmAim = advanceFirearmAim(actor, tick2, catalog);
    actor.weapon.cooldownTicks = Math.max(0, actor.weapon.cooldownTicks - 1);
    let outcome = "none";
    const markers = [];
    const requested = intent.firePressed || Boolean(intent.held & Held.Fire);
    const eligible = actor.life === "alive" && actor.vehicleId === null;
    if (!eligible && actor.action.kind === "fire") actor.action.kind = "ready";
    if (eligible && actor.action.kind === "fire") {
      const nextTimeline = firearmPoseTimeline(actor, catalog);
      if (nextTimeline !== actor.action.definitionId) {
        const prior = catalog.timelines.get(actor.action.definitionId);
        const next = catalog.timelines.get(nextTimeline);
        if (!prior || !next || prior.durationTicks !== next.durationTicks || canonical(prior.markers) !== canonical(next.markers))
          throw new Error("Firearm pose variants disagree on action markers");
        actor.action.definitionId = nextTimeline;
      }
      const result = stepAction(actor.action, tick2, catalog);
      actor.action = result.action;
      markers.push(...result.markers);
      if (result.finished) actor.action.kind = "ready";
    }
    if (requested) {
      if (!eligible || actor.action.kind !== "ready" && actor.action.kind !== "fire")
        outcome = "unavailable";
      else if (actor.weapon.cooldownTicks > 0 || actor.action.kind !== "ready") outcome = "cooldown";
      else {
        const result = beginFirearm(actor, tick2, nextActionId, catalog);
        actor = result.actor;
        nextActionId = result.nextActionId;
        markers.push(...result.markers);
        outcome = "applied";
      }
    }
    return { actor, markers, nextActionId, outcome };
  }

  // src/game/combat/foot-actions.ts
  function stepFootCombatAction(current, intent, tick2, nextActionId, catalog, profiles2, closeTarget) {
    integer(intent.held, 0, HELD_MASK, "foot combat held mask");
    if (typeof intent.firePressed !== "boolean" || typeof intent.grenadePressed !== "boolean" || typeof closeTarget !== "boolean")
      throw new Error("Invalid action arbitration");
    const advanced = stepFirearm(
      current,
      { held: 0, firePressed: false },
      tick2,
      nextActionId,
      catalog
    );
    let actor = advanced.actor;
    const markers = advanced.markers;
    for (const field of ["grenadeCooldownTicks", "meleeCooldownTicks"])
      actor[field] = Math.max(0, integer(actor[field], 0, 3600, field) - 1);
    integer(actor.grenadeStock, 0, 65535, "grenade stock");
    const eligible = actor.life === "alive" && actor.vehicleId === null;
    if (actor.action.kind === "melee" || actor.action.kind === "grenade") {
      if (!eligible) actor.action.kind = "ready";
      else {
        const timeline = profiles2[actor.action.kind].timelineIds[actor.locomotion === "crouched" ? 1 : 0];
        const previous = catalog.timelines.get(actor.action.definitionId), next = catalog.timelines.get(timeline);
        if (!previous || !next || previous.durationTicks !== next.durationTicks || canonical(previous.markers) !== canonical(next.markers))
          throw new Error("Foot action pose markers disagree");
        actor.action.definitionId = timeline;
        const result = stepAction(actor.action, tick2, catalog);
        actor.action = result.action;
        markers.push(...result.markers);
        if (result.finished) actor.action.kind = "ready";
      }
    }
    let fire = "none", grenade = "none";
    const requested = intent.firePressed || Boolean(intent.held & Held.Fire);
    const begin2 = (kind) => {
      const profile = profiles2[kind];
      actor.action = {
        kind,
        actionInstanceId: nextActionId,
        definitionId: profile.timelineIds[actor.locomotion === "crouched" ? 1 : 0],
        stateStartTick: tick2,
        nextMarkerIndex: 0
      };
      nextActionId = nextCounter(nextActionId);
      if (kind === "grenade") {
        actor.grenadeStock--;
        actor.grenadeCooldownTicks = profile.cooldownTicks;
      } else actor.meleeCooldownTicks = profile.cooldownTicks;
      const result = stepAction(actor.action, tick2, catalog);
      actor.action = result.action;
      markers.push(...result.markers);
    };
    if (intent.grenadePressed) {
      if (!eligible || actor.grenadeStock === 0) grenade = "unavailable";
      else if (actor.action.kind !== "ready" || actor.grenadeCooldownTicks > 0) grenade = "cooldown";
      else {
        begin2("grenade");
        grenade = "applied";
      }
    }
    if (requested) {
      if (!eligible) fire = "unavailable";
      else if (actor.action.kind !== "ready" || actor.weapon.cooldownTicks > 0) fire = "cooldown";
      else if (closeTarget && actor.aim === 0 && actor.meleeCooldownTicks === 0) {
        begin2("melee");
        fire = "applied";
      } else {
        const result = beginFirearm(actor, tick2, nextActionId, catalog);
        actor = result.actor;
        nextActionId = result.nextActionId;
        markers.push(...result.markers);
        fire = "applied";
      }
    }
    return { actor, markers, nextActionId, fire, grenade };
  }

  // src/game/controller/foot.ts
  function clone(actor) {
    return {
      ...actor,
      body: { ...actor.body, contacts: actor.body.contacts.map((contact) => ({ ...contact })) },
      action: { ...actor.action }
    };
  }
  function required(shapes2, id2) {
    const value = shapes2.get(id2);
    if (!value || value.id !== id2) throw new Error(`Missing controller shape ${id2}`);
    return value;
  }
  function stepFootController(current, intent, definition2, shapes2, index, frame, controlsLocked = false) {
    index.assertFrame(frame);
    integer(intent.held, 0, HELD_MASK, "controller held mask");
    if (typeof intent.jumpPressed !== "boolean") throw new Error("Invalid jump edge intent");
    if (current.geometryRevision !== index.frame.geometryRevision)
      throw new Error("Controller geometry revision mismatch");
    integer(current.jumpBufferTicks, 0, ARCADE.jumpBufferTicks, "jump buffer");
    integer(current.coyoteTicks, 0, ARCADE.coyoteTicks, "coyote timer");
    integer(current.ignoredSupportTicks, 0, ARCADE.dropThroughTicks, "drop timer");
    if (current.ignoredSupportId !== null)
      integer(current.ignoredSupportId, 1, COUNTER_LIMIT - 1, "ignored support ID");
    const actor = clone(current);
    if (actor.life !== "alive" || actor.vehicleId !== null || actor.locomotion === "seated" || actor.action.kind === "enter" || actor.action.kind === "exit")
      return { status: "inactive", actor };
    if (definition2.locomotion !== "grounded" || definition2.gravity <= 0 || definition2.jumpVelocity + definition2.gravity >= 0 || definition2.terminalVelocity <= 0 || definition2.runSpeed < 0)
      throw new Error("Invalid foot controller definition");
    for (const value of [
      definition2.gravity,
      definition2.jumpVelocity,
      definition2.terminalVelocity,
      definition2.runSpeed
    ])
      motion(value);
    const standing = required(shapes2, definition2.standingShapeId);
    const crouched2 = required(shapes2, definition2.crouchedShapeId);
    if (standing.rect.y + standing.rect.h !== 0 || crouched2.rect.y + crouched2.rect.h !== 0 || crouched2.rect.y < standing.rect.y || crouched2.rect.x < standing.rect.x || crouched2.rect.x + crouched2.rect.w > standing.rect.x + standing.rect.w)
      throw new Error("Controller stances must share feet and crouch within standing bounds");
    if (actor.body.shapeId !== standing.id && actor.body.shapeId !== crouched2.id)
      throw new Error("Unknown controller stance");
    if (actor.body.remainderX !== 0 || actor.body.remainderY !== 0)
      throw new Error("Unsupported controller motion remainder");
    let shape = required(shapes2, actor.body.shapeId);
    if (actor.ignoredSupportTicks === 0 || !index.get(actor.ignoredSupportId ?? 0)) {
      actor.ignoredSupportId = null;
      actor.ignoredSupportTicks = 0;
    }
    const touchingSupport = startSupport(
      actor.body,
      shape,
      actor.facing,
      index,
      frame,
      actor.ignoredSupportId
    );
    const support2 = actor.body.vy < 0 ? null : touchingSupport;
    const wasGrounded = current.body.grounded;
    actor.body.supportId = support2;
    actor.body.grounded = support2 !== null;
    const locked = controlsLocked || actor.action.kind === "hurt";
    const held = locked ? 0 : intent.held;
    const direction = directionalIntent(held, actor.facing, support2 !== null);
    if (locked) actor.jumpBufferTicks = 0;
    else if (intent.jumpPressed) actor.jumpBufferTicks = ARCADE.jumpBufferTicks;
    if (support2 !== null) actor.coyoteTicks = ARCADE.coyoteTicks;
    let jumpRequest = intent.jumpPressed ? locked ? "unavailable" : "buffered" : "none";
    const supportTarget = index.get(support2 ?? 0);
    const canJump = !locked && actor.jumpBufferTicks > 0 && (support2 !== null || actor.coyoteTicks > 0);
    let dropping = canJump && direction.vertical > 0 && supportTarget?.kind === "one-way";
    let dropQueuedAtEnd = false;
    let isCrouched = actor.locomotion === "crouched" || crouched2.id !== standing.id && shape.id === crouched2.id;
    const wantsCrouch = locked ? isCrouched : direction.crouch && (!canJump || dropping);
    const desired = wantsCrouch ? crouched2 : standing;
    const nextFacing = locked ? actor.facing : direction.facing;
    let changed = tryBodyShape(actor.body, shape, desired, actor.facing, nextFacing, index, frame);
    if (!changed.accepted && desired.id === standing.id && isCrouched)
      changed = tryBodyShape(actor.body, shape, crouched2, actor.facing, nextFacing, index, frame);
    if (changed.accepted) {
      actor.body = changed.body;
      actor.facing = changed.facing;
      shape = required(shapes2, actor.body.shapeId);
      isCrouched = shape.id === crouched2.id && (standing.id !== crouched2.id || wantsCrouch);
    }
    actor.body.vx = locked ? actor.action.kind === "hurt" ? actor.body.vx : 0 : isCrouched && support2 !== null ? 0 : direction.horizontal * definition2.runSpeed;
    actor.body.vy = Math.min(definition2.terminalVelocity, actor.body.vy + definition2.gravity);
    const events = [];
    let jumped = false;
    if (dropping) {
      actor.ignoredSupportId = support2;
      actor.ignoredSupportTicks = ARCADE.dropThroughTicks;
      actor.body.supportId = null;
      actor.body.grounded = false;
      actor.body.vy = Math.max(definition2.gravity, actor.body.vy);
      actor.jumpBufferTicks = 0;
      actor.coyoteTicks = 0;
      jumpRequest = "consumed";
      events.push({ kind: "drop", tick: frame.tick, supportId: support2 });
    } else if (canJump && !isCrouched) {
      actor.body.vy = definition2.jumpVelocity + definition2.gravity;
      actor.body.supportId = null;
      actor.body.grounded = false;
      actor.jumpBufferTicks = 0;
      actor.coyoteTicks = 0;
      jumped = true;
      jumpRequest = "consumed";
      events.push({ kind: "jump", tick: frame.tick, supportId: support2 });
    }
    const physics = stepBody(actor.body, shape, actor.facing, index, {
      frame,
      ...actor.ignoredSupportId === null ? {} : { ignoredOneWayId: actor.ignoredSupportId }
    });
    if (physics.status !== "complete") return { status: "failed", physics };
    actor.body = physics.body;
    const landed = support2 === null && actor.body.grounded;
    if (landed) events.push({ kind: "land", tick: frame.tick, supportId: actor.body.supportId });
    if ((support2 !== null || wasGrounded) && !actor.body.grounded && !jumped && !dropping)
      events.push({
        kind: "leave-support",
        tick: frame.tick,
        supportId: support2 ?? current.body.supportId
      });
    if (!locked && actor.body.grounded && direction.vertical > 0) {
      const crouchAtEnd = tryBodyShape(
        actor.body,
        shape,
        crouched2,
        actor.facing,
        actor.facing,
        index,
        frame,
        "end"
      );
      if (crouchAtEnd.accepted) {
        actor.body = crouchAtEnd.body;
        shape = crouched2;
        isCrouched = true;
      }
    }
    if (!locked && actor.body.grounded && actor.jumpBufferTicks > 0) {
      const landedOn = actor.body.supportId;
      const landedTarget = index.get(landedOn ?? 0);
      if (direction.vertical > 0 && landedTarget?.kind === "one-way") {
        actor.ignoredSupportId = landedOn;
        actor.ignoredSupportTicks = ARCADE.dropThroughTicks;
        actor.body = { ...actor.body, vy: 0, grounded: false, supportId: null };
        actor.jumpBufferTicks = 0;
        actor.coyoteTicks = 0;
        dropping = true;
        dropQueuedAtEnd = true;
        jumpRequest = "consumed";
        events.push({ kind: "drop", tick: frame.tick, supportId: landedOn });
      } else {
        const standingAtEnd = tryBodyShape(
          actor.body,
          shape,
          standing,
          actor.facing,
          actor.facing,
          index,
          frame,
          "end"
        );
        if (standingAtEnd.accepted) {
          actor.body = {
            ...standingAtEnd.body,
            vy: definition2.jumpVelocity,
            supportId: null,
            grounded: false
          };
          shape = standing;
          isCrouched = false;
          actor.jumpBufferTicks = 0;
          actor.coyoteTicks = 0;
          jumped = true;
          jumpRequest = "consumed";
          events.push({ kind: "jump", tick: frame.tick, supportId: landedOn });
        }
      }
    }
    if (!jumped && !dropping)
      actor.coyoteTicks = actor.body.grounded || support2 !== null ? ARCADE.coyoteTicks : Math.max(0, actor.coyoteTicks - 1);
    actor.jumpBufferTicks = Math.max(0, actor.jumpBufferTicks - 1);
    if (actor.ignoredSupportId !== null) {
      if (!dropQueuedAtEnd) actor.ignoredSupportTicks = Math.max(0, actor.ignoredSupportTicks - 1);
      const ignored = index.get(actor.ignoredSupportId);
      const feet = worldRect(actor.body, shape.rect, actor.facing);
      if (!ignored || actor.ignoredSupportTicks === 0 || feet.y + feet.h > ignored.rect.y + ignored.delta.y + ignored.rect.h) {
        actor.ignoredSupportId = null;
        actor.ignoredSupportTicks = 0;
      }
    }
    actor.locomotion = actor.body.grounded ? isCrouched ? "crouched" : "grounded" : "airborne";
    if (!locked) actor.aim = directionalIntent(held, actor.facing, actor.body.grounded).aim;
    return { status: "complete", actor, events, jumpRequest, physics };
  }

  // src/game/vehicles/tank.ts
  var tankOwner = (tank) => tank.occupantId ?? tank.reservedBy;
  var idleTankAction = (tick2) => ({
    kind: "ready",
    actionInstanceId: 0,
    stateStartTick: tick2,
    definitionId: 0,
    nextMarkerIndex: 0
  });
  var zero2 = { x: 0, y: 0 };
  function createTank(id2, point3, supportId, profile) {
    return {
      body: {
        id: id2,
        ...point3,
        vx: 0,
        vy: 0,
        remainderX: 0,
        remainderY: 0,
        shapeId: profile.locomotion.standingShapeId,
        supportId,
        grounded: supportId !== null,
        contacts: []
      },
      definitionId: profile.definition.id,
      kind: "tank",
      lifecycle: "available",
      occupantId: null,
      reservedBy: null,
      controlEpoch: 1,
      ownerControlEpoch: null,
      facing: 1,
      heading: 0,
      invulnerableTicks: 0,
      armor: profile.definition.armor,
      action: idleTankAction(0),
      components: [],
      weapon: {
        id: profile.definition.weaponId,
        ammo: 0,
        cooldownTicks: 0,
        shotOrdinal: 0,
        lastActionInstanceId: 0
      },
      jumpBufferTicks: 0,
      coyoteTicks: 0,
      turnTicks: 0,
      disconnectedTicks: 0,
      lastGunOwnerId: null,
      lastGunControlEpoch: null
    };
  }
  function attachTankDriver(tank, actor, profile) {
    if (tankOwner(tank) !== actor.playerId) throw new Error("Tank attachment owner mismatch");
    const point3 = worldSocket(tank.body, profile.definition.seat.socket, tank.facing);
    actor.body = {
      ...actor.body,
      ...point3,
      vx: tank.body.vx,
      vy: tank.body.vy,
      remainderX: 0,
      remainderY: 0,
      grounded: false,
      supportId: null,
      contacts: []
    };
    actor.vehicleId = tank.body.id;
    actor.locomotion = "seated";
    actor.facing = tank.facing;
    actor.jumpBufferTicks = actor.coyoteTicks = actor.ignoredSupportTicks = 0;
    actor.ignoredSupportId = null;
  }
  function moveTank(current, intent, profile, shapes2, index, frame) {
    const tank = structuredClone(current);
    if (tank.lifecycle === "wreck" || tank.lifecycle === "destroying")
      return { tank, jumpAccepted: false, fault: null };
    tank.invulnerableTicks = Math.max(0, tank.invulnerableTicks - 1);
    tank.weapon.cooldownTicks = Math.max(0, tank.weapon.cooldownTicks - 1);
    tank.turnTicks = Math.max(0, tank.turnTicks - 1);
    const driving = tank.lifecycle === "occupied";
    const actor = {
      body: tank.body,
      life: "alive",
      locomotion: tank.body.grounded ? "grounded" : "airborne",
      action: idleTankAction(frame.tick),
      facing: tank.facing,
      aim: 0,
      jumpBufferTicks: tank.jumpBufferTicks,
      coyoteTicks: tank.coyoteTicks,
      ignoredSupportId: null,
      ignoredSupportTicks: 0,
      vehicleId: null,
      geometryRevision: frame.geometryRevision
    };
    const result = stepFootController(
      actor,
      {
        held: driving ? intent.held & (Held.Left | Held.Right) : 0,
        jumpPressed: driving && intent.jumpPressed
      },
      profile.locomotion,
      shapes2,
      index,
      frame
    );
    if (result.status === "failed") return { tank, jumpAccepted: false, fault: result.physics };
    tank.body = result.actor.body;
    tank.facing = result.actor.facing;
    tank.jumpBufferTicks = result.actor.jumpBufferTicks;
    tank.coyoteTicks = result.actor.coyoteTicks;
    if (driving && tank.turnTicks === 0) {
      const x = Number(Boolean(intent.held & Held.Right)) - Number(Boolean(intent.held & Held.Left));
      const y = Number(Boolean(intent.held & Held.Down)) - Number(Boolean(intent.held & Held.Up));
      const target = y < 0 ? x > 0 ? 1 : x < 0 ? 3 : 2 : y > 0 ? x > 0 ? 7 : x < 0 ? 5 : 6 : x < 0 ? 4 : x > 0 ? 0 : tank.heading;
      if (target !== tank.heading) {
        const clockwise = (target - tank.heading + 8) % 8;
        tank.heading = (tank.heading + (clockwise <= 4 ? 1 : 7)) % 8;
        tank.turnTicks = profile.turnTicks;
      }
    }
    return {
      tank,
      jumpAccepted: result.status === "complete" && ["consumed", "buffered"].includes(result.jumpRequest),
      fault: null
    };
  }
  function clearPath(actor, point3, shape, index, frame) {
    if (blockingShapes(point3, shape.rect, actor.facing, index, frame, "end").length) return false;
    const start = worldRect(actor.body, shape.rect, actor.facing), delta = { x: point3.x - actor.body.x, y: point3.y - actor.body.y };
    const terrain = index.query(sweepBounds(start, delta)).filter((target) => target.kind === "solid").map((target) => ({
      ...target,
      rect: {
        ...target.rect,
        x: target.rect.x + target.delta.x,
        y: target.rect.y + target.delta.y
      },
      delta: zero2
    }));
    const result = earliestSweep(start, delta, terrain);
    return result.overlaps.length === 0 && result.contacts.every((contact) => contact.time.numerator === contact.time.denominator);
  }
  function tankExitBody(tank, actor, profile, shape, index, frame) {
    const candidates = profile.definition.seat.ejectionCandidates;
    for (const [candidateIndex, offset] of candidates.entries()) {
      const point3 = worldSocket(tank.body, offset, tank.facing);
      if (point3.y > profile.fallBoundary || !clearPath(actor, point3, shape, index, frame)) continue;
      const body4 = {
        ...actor.body,
        ...point3,
        shapeId: shape.id,
        vx: 0,
        vy: 0,
        remainderX: 0,
        remainderY: 0,
        supportId: null,
        grounded: false,
        contacts: []
      };
      const bounds = sweepBounds(worldRect(body4, shape.rect, actor.facing));
      const endTerrain = index.query({
        minX: bounds.minX - 1,
        minY: bounds.minY - 1,
        maxX: bounds.maxX + 1,
        maxY: bounds.maxY + 1
      }).map((target) => ({
        ...target,
        rect: {
          ...target.rect,
          x: target.rect.x + target.delta.x,
          y: target.rect.y + target.delta.y
        },
        delta: zero2
      }));
      const endIndex = new CollisionIndex(new CollisionGrid(endTerrain), [], frame);
      const supportId = startSupport(body4, shape, actor.facing, endIndex, frame, null);
      if (candidateIndex < candidates.length - 1 && supportId === null) continue;
      body4.supportId = supportId;
      body4.grounded = supportId !== null;
      return body4;
    }
    return null;
  }
  function reserveTank(tank, actor, tick2, actionId, profile, shapes2, index, frame) {
    if (actor.life !== "alive" || actor.vehicleId !== null || actor.reboardCooldownTicks > 0 || !["ready", "fire"].includes(actor.action.kind) || !actor.body.grounded || tank.lifecycle !== "available" || tank.armor === 0 || !tank.body.grounded || Math.abs(tank.body.vx) > pixels(1))
      return false;
    const sensor = shapes2.get(profile.definition.seat.boardingSensorShapeId), shape = shapes2.get(actor.body.shapeId);
    if (!sensor || !shape) throw new Error("Missing tank boarding geometry");
    if (sweepAabb(
      worldRect(actor.body, shape.rect, actor.facing),
      zero2,
      worldRect(tank.body, sensor.rect, tank.facing)
    )?.kind !== "overlap")
      return false;
    const seat = worldSocket(tank.body, profile.definition.seat.socket, tank.facing);
    if (!clearPath(actor, seat, shape, index, frame)) return false;
    tank.lifecycle = "boarding";
    tank.reservedBy = actor.playerId;
    tank.controlEpoch = nextCounter(tank.controlEpoch);
    tank.ownerControlEpoch = actor.controlEpoch;
    tank.action = {
      kind: "enter",
      actionInstanceId: actionId,
      stateStartTick: tick2,
      definitionId: profile.definition.seat.boardingTimelineId,
      nextMarkerIndex: 0
    };
    actor.action = { ...tank.action };
    attachTankDriver(tank, actor, profile);
    return true;
  }
  function requestTankExit(tank, actor, tick2, actionId, profile, shape, index, frame) {
    if (tank.lifecycle !== "occupied" || tank.occupantId !== actor.playerId || !tankExitBody(tank, actor, profile, shape, index, frame))
      return false;
    tank.lifecycle = "exiting";
    tank.action = {
      kind: "exit",
      actionInstanceId: actionId,
      stateStartTick: tick2,
      definitionId: profile.exitTimelineId,
      nextMarkerIndex: 0
    };
    actor.action = { ...tank.action };
    return true;
  }
  function releaseTank(tank, actor, tick2, profile, shape, index, frame) {
    if (tankOwner(tank) !== actor.playerId) throw new Error("Tank release owner mismatch");
    const body4 = tankExitBody(tank, actor, profile, shape, index, frame);
    tank.occupantId = tank.reservedBy = null;
    tank.ownerControlEpoch = null;
    tank.controlEpoch = nextCounter(tank.controlEpoch);
    tank.lifecycle = tank.armor > 0 ? "available" : "wreck";
    tank.action = idleTankAction(tick2);
    tank.jumpBufferTicks = tank.coyoteTicks = tank.disconnectedTicks = 0;
    actor.vehicleId = null;
    actor.body = body4 ?? {
      ...actor.body,
      vx: 0,
      vy: 0,
      supportId: null,
      grounded: false,
      contacts: []
    };
    actor.locomotion = actor.body.grounded ? "grounded" : "airborne";
    actor.action = idleTankAction(tick2);
    actor.reboardCooldownTicks = profile.reboardTicks;
    actor.invulnerableTicks = Math.max(actor.invulnerableTicks, profile.exitProtectionTicks);
    return body4 !== null;
  }
  function stepTankTransfer(tank, actor, tick2, profile, catalog, shape, index, frame) {
    if (tank.lifecycle !== "boarding" && tank.lifecycle !== "exiting") return null;
    const step = stepAction(tank.action, tick2, catalog);
    tank.action = step.action;
    actor.action = { ...step.action };
    if (!step.markers.some(({ marker }) => marker.kind === "seat-transfer")) return null;
    if (tank.lifecycle === "boarding") {
      tank.occupantId = tank.reservedBy;
      tank.reservedBy = null;
      tank.lifecycle = "occupied";
      tank.action = actor.action = idleTankAction(tick2);
      return "board";
    }
    if (!tankExitBody(tank, actor, profile, shape, index, frame)) {
      tank.lifecycle = "occupied";
      tank.action = actor.action = idleTankAction(tick2);
      return "exit-blocked";
    }
    releaseTank(tank, actor, tick2, profile, shape, index, frame);
    return "exit";
  }
  function stepTankGun(tank, intent, tick2, nextActionId, profile, catalog) {
    const requested = intent.firePressed || Boolean(intent.held & Held.Fire);
    let outcome = "none";
    const markers = [];
    if (tank.lifecycle !== "occupied" || tank.occupantId === null)
      return { outcome: requested ? "unavailable" : outcome, nextActionId, markers };
    if (tank.action.kind === "fire") {
      const step = stepAction(tank.action, tick2, catalog);
      tank.action = step.finished ? idleTankAction(tick2) : step.action;
      markers.push(...step.markers);
    }
    if (requested) {
      if (tank.action.kind !== "ready" || tank.weapon.cooldownTicks > 0) outcome = "cooldown";
      else {
        integer(
          nextActionId,
          tank.weapon.lastActionInstanceId + 1,
          COUNTER_LIMIT - 2,
          "tank gun allocation"
        );
        const definitionId = profile.fireTimelineIds[tank.heading];
        if (definitionId === void 0) throw new Error("Missing tank gun heading");
        tank.action = {
          kind: "fire",
          actionInstanceId: nextActionId,
          stateStartTick: tick2,
          definitionId,
          nextMarkerIndex: 0
        };
        tank.weapon.cooldownTicks = profile.fireCadenceTicks;
        tank.weapon.shotOrdinal = nextCounter(tank.weapon.shotOrdinal);
        tank.weapon.lastActionInstanceId = nextActionId;
        tank.lastGunOwnerId = tank.occupantId;
        tank.lastGunControlEpoch = tank.ownerControlEpoch;
        nextActionId = nextCounter(nextActionId);
        const step = stepAction(tank.action, tick2, catalog);
        tank.action = step.action;
        markers.push(...step.markers);
        outcome = "applied";
      }
    }
    return { outcome, nextActionId, markers };
  }
  function publicTankState(tank) {
    return structuredClone({
      body: tank.body,
      definitionId: tank.definitionId,
      kind: tank.kind,
      lifecycle: tank.lifecycle,
      occupantId: tank.occupantId,
      reservedBy: tank.reservedBy,
      controlEpoch: tank.controlEpoch,
      ownerControlEpoch: tank.ownerControlEpoch,
      facing: tank.facing,
      heading: tank.heading,
      invulnerableTicks: tank.invulnerableTicks,
      armor: tank.armor,
      action: tank.action,
      components: tank.components,
      weapon: tank.weapon
    });
  }
  function validateTankState(tank, tick2, players, profile, catalog) {
    const check12 = (ok, message) => {
      if (!ok) throw new Error(`Tank state: ${message}`);
    };
    check12(
      tank.kind === "tank" && tank.definitionId === profile.definition.id && tank.body.shapeId === profile.locomotion.standingShapeId && tank.components.length === 0,
      "definition"
    );
    integer(tank.armor, 0, profile.definition.armor, "tank armor");
    check12(tank.armor === 0 === (tank.lifecycle === "wreck"), "wreck armor");
    integer(tank.heading, 0, 7, "tank heading");
    check12(tank.facing === -1 || tank.facing === 1, "facing");
    integer(tank.invulnerableTicks, 0, profile.damageProtectionTicks, "tank protection");
    integer(tank.turnTicks, 0, profile.turnTicks, "tank turn timer");
    integer(tank.jumpBufferTicks, 0, ARCADE.jumpBufferTicks, "tank jump buffer");
    integer(tank.coyoteTicks, 0, ARCADE.coyoteTicks, "tank coyote timer");
    integer(tank.disconnectedTicks, 0, profile.disconnectGraceTicks - 1, "tank disconnect grace");
    check12(tank.weapon.id === profile.definition.weaponId && tank.weapon.ammo === 0, "primary feed");
    integer(tank.weapon.cooldownTicks, 0, profile.fireCadenceTicks, "tank gun cadence");
    const gunOwner = players.find((player2) => player2.playerId === tank.lastGunOwnerId);
    check12(
      tank.weapon.shotOrdinal === 0 ? tank.weapon.lastActionInstanceId === 0 && tank.lastGunOwnerId === null && tank.lastGunControlEpoch === null : gunOwner && tank.lastGunControlEpoch !== null && tank.lastGunControlEpoch > 0 && tank.lastGunControlEpoch <= gunOwner.controlEpoch && tank.weapon.lastActionInstanceId > 0,
      "last gun owner"
    );
    const ownerId = tankOwner(tank), owner = players.find((player2) => player2.playerId === ownerId);
    check12(
      ownerId === null ? tank.ownerControlEpoch === null && tank.disconnectedTicks === 0 : owner?.life === "alive" && owner.vehicleId === tank.body.id && owner.controlEpoch === tank.ownerControlEpoch,
      "seat owner"
    );
    if (owner) {
      const seat = worldSocket(tank.body, profile.definition.seat.socket, tank.facing);
      check12(
        owner.body.x === seat.x && owner.body.y === seat.y && owner.body.vx === tank.body.vx && owner.body.vy === tank.body.vy && !owner.body.grounded && owner.body.supportId === null,
        "seat attachment"
      );
    }
    if (tank.action.kind === "ready") {
      check12(
        ["available", "occupied", "wreck"].includes(tank.lifecycle) && tank.action.actionInstanceId === 0 && tank.action.definitionId === 0 && tank.action.nextMarkerIndex === 0,
        "idle action"
      );
    } else {
      const timeline = catalog.timelines.get(tank.action.definitionId), age = tick2 - tank.action.stateStartTick;
      check12(
        timeline && age >= 0 && age < timeline.durationTicks && tank.action.nextMarkerIndex === timeline.markers.filter((marker) => marker.tickOffset <= age).length,
        "action cursor"
      );
      if (tank.lifecycle === "boarding" || tank.lifecycle === "exiting") {
        check12(
          tank.action.kind === (tank.lifecycle === "boarding" ? "enter" : "exit") && tank.action.definitionId === (tank.lifecycle === "boarding" ? profile.definition.seat.boardingTimelineId : profile.exitTimelineId) && owner && canonical(owner.action) === canonical(tank.action),
          "transfer action"
        );
      } else {
        check12(
          tank.lifecycle === "occupied" && tank.action.kind === "fire" && profile.fireTimelineIds.includes(tank.action.definitionId) && tank.action.actionInstanceId === tank.weapon.lastActionInstanceId && tank.lastGunOwnerId === ownerId,
          "gun action"
        );
      }
    }
  }
  function validateTankProfile(profile, shapes2, catalog) {
    if (profile.definition.kind !== "tank" || profile.definition.actorId !== profile.locomotion.id || profile.locomotion.standingShapeId !== profile.locomotion.crouchedShapeId)
      throw new Error("Invalid tank controller definition");
    integer(profile.headings.length, 8, 8, "tank headings");
    integer(profile.fireTimelineIds.length, 8, 8, "tank fire poses");
    for (const id2 of [
      profile.definition.seat.boardingSensorShapeId,
      profile.locomotion.standingShapeId
    ])
      if (!shapes2.has(id2)) throw new Error("Missing tank shape");
    for (const id2 of [
      profile.definition.seat.boardingTimelineId,
      profile.exitTimelineId,
      ...profile.fireTimelineIds
    ])
      if (!catalog.timelines.has(id2)) throw new Error("Missing tank timeline");
    for (const ticks of [
      profile.fireCadenceTicks,
      profile.turnTicks,
      profile.damageProtectionTicks,
      profile.reboardTicks,
      profile.exitProtectionTicks,
      profile.disconnectGraceTicks
    ])
      integer(ticks, 1, 120, "tank timing");
  }

  // src/game/content/validate.ts
  function check5(condition, message) {
    if (!condition) throw new Error(`Invalid content: ${message}`);
  }
  function unique2(values, label) {
    check5(values.length <= 4096, `${label} count`);
    const table = /* @__PURE__ */ new Map();
    for (const value of values) {
      if (typeof value.id === "number") integer(value.id, 1, COUNTER_LIMIT - 1, label);
      check5(!table.has(value.id), `duplicate ${label} ID ${value.id}`);
      table.set(value.id, value);
    }
    return table;
  }
  function point(value, local = false) {
    const maximum = local ? MAX_SHAPE : 2 ** 24;
    integer(value.x, -maximum, maximum, "point x");
    integer(value.y, -maximum, maximum, "point y");
  }
  function rectangle(rect, local = false) {
    if (local) validateLocalRect(rect);
    point(rect, local);
    integer(rect.w, 1, local ? MAX_SHAPE : 2 ** 24, "rectangle width");
    integer(rect.h, 1, local ? MAX_SHAPE : 2 ** 24, "rectangle height");
    position(rect.x + rect.w);
    position(rect.y + rect.h);
  }
  function validateContent(content) {
    canonical(content);
    check5(content.format === 1 && content.simulationHz === 60, "format/tick rate");
    const shapes2 = unique2(content.shapes, "shape");
    const poses = unique2(content.poses, "pose");
    const timelines = unique2(content.timelines, "timeline");
    const attacks = unique2(content.attacks, "attack");
    const weapons = unique2(content.weapons, "weapon");
    const actors = unique2(content.actors, "actor");
    const vehicles = unique2(content.vehicles, "vehicle");
    const entities = new Set(unique2(content.terrain, "terrain").keys());
    unique2(content.encounters, "encounter");
    for (const shape of content.shapes) rectangle(shape.rect, true);
    for (const pose of content.poses) {
      integer(pose.durationTicks, 1, 3600, "pose duration");
      check5(pose.frame.length > 0, "missing frame identity");
      check5(
        pose.sockets.length <= 8 && new Set(pose.sockets.map((socket) => socket.name)).size === pose.sockets.length,
        "duplicate/excess sockets"
      );
      for (const socket of pose.sockets) point(socket.point, true);
      check5(
        pose.hurtShapeIds.length <= 16 && pose.hurtShapeIds.every((id2) => shapes2.has(id2)),
        "unknown/excess hurt shapes"
      );
    }
    for (const timeline of content.timelines) {
      integer(timeline.durationTicks, 1, 3600, "timeline duration");
      check5(
        timeline.poses.length > 0 && timeline.poses.length <= 256 && timeline.poses.every((id2) => poses.has(id2)),
        "missing/excess timeline poses"
      );
      const duration = timeline.poses.reduce(
        (sum, id2) => sum + (poses.get(id2)?.durationTicks ?? 0),
        0
      );
      check5(duration === timeline.durationTicks, "timeline exposure duration mismatch");
      check5(timeline.markers.length <= 128, "excess markers");
      let previous = -1;
      for (const marker of timeline.markers) {
        integer(marker.tickOffset, 0, timeline.durationTicks - 1, "marker tick");
        check5(marker.tickOffset >= previous, "unordered markers");
        previous = marker.tickOffset;
        let age = marker.tickOffset;
        const pose = timeline.poses.map((id2) => poses.get(id2)).find((candidate) => {
          if (!candidate) return false;
          if (age < candidate.durationTicks) return true;
          age -= candidate.durationTicks;
          return false;
        });
        check5(
          Boolean(pose?.sockets.some((socket) => socket.name === marker.socket)),
          "missing active pose socket"
        );
        if (marker.kind === "spawn-attack" || marker.kind === "activate-hitbox")
          check5(attacks.has(marker.payloadId), "unknown marker attack");
        if (marker.kind === "seat-transfer")
          check5(vehicles.has(marker.payloadId), "unknown marker vehicle");
      }
    }
    for (const attack2 of content.attacks) {
      check5(shapes2.has(attack2.shapeId), "unknown attack shape");
      motion(attack2.speed);
      integer(attack2.damage, 1, 65535, "damage");
      integer(attack2.lifetimeTicks, 1, 3600, "attack lifetime");
      integer(attack2.maxTargets, 1, 256, "attack target limit");
      integer(attack2.repeatDamageTicks, 0, 3600, "damage interval");
    }
    for (const weapon2 of content.weapons) {
      check5(
        attacks.has(weapon2.attackId) && timelines.has(weapon2.timelineId),
        "unknown weapon action"
      );
      integer(weapon2.cadenceTicks, 1, 3600, "weapon cadence");
      integer(weapon2.ammoPerAction, 0, 65535, "ammo cost");
      if (weapon2.pickupAmmo !== "unlimited")
        integer(weapon2.pickupAmmo, 1, 65535, "pickup ammunition");
      check5(
        weapon2.pickupAmmo === "unlimited" ? weapon2.ammoPerAction === 0 : weapon2.ammoPerAction > 0,
        "inconsistent ammo policy"
      );
      check5(
        weapon2.visualFamily.length > 0 && weapon2.audioFamily.length > 0,
        "missing weapon media family"
      );
    }
    for (const actor of content.actors) {
      check5(
        shapes2.has(actor.standingShapeId) && shapes2.has(actor.crouchedShapeId) && poses.has(actor.idlePoseId),
        "unknown actor shape/pose"
      );
      for (const value of [actor.runSpeed, actor.jumpVelocity, actor.gravity, actor.terminalVelocity])
        motion(value);
      check5(
        actor.runSpeed >= 0 && actor.gravity >= 0 && actor.terminalVelocity > 0 && actor.jumpVelocity <= 0,
        "actor movement signs"
      );
    }
    for (const vehicle of content.vehicles) {
      check5(
        actors.has(vehicle.actorId) && weapons.has(vehicle.weaponId) && shapes2.has(vehicle.seat.boardingSensorShapeId) && timelines.has(vehicle.seat.boardingTimelineId),
        "unknown vehicle reference"
      );
      integer(vehicle.armor, 1, 65535, "vehicle armor");
      point(vehicle.seat.socket, true);
      check5(
        vehicle.seat.ejectionCandidates.length > 0 && vehicle.seat.ejectionCandidates.length <= 8,
        "ejection candidates"
      );
      for (const candidate of vehicle.seat.ejectionCandidates) point(candidate, true);
    }
    for (const terrain of content.terrain) {
      rectangle(terrain.rect);
      check5(terrain.visibleSurfaceId.length > 0, "invisible terrain");
    }
    for (const encounter of content.encounters) {
      rectangle(encounter.camera);
      rectangle(encounter.killBounds);
      point(encounter.checkpoint);
      check5(
        encounter.spawns.length <= 256 && encounter.vehicleSpawns.length <= 16,
        "encounter entity budget"
      );
      for (const spawn of [...encounter.spawns, ...encounter.vehicleSpawns]) {
        integer(spawn.id, 1, COUNTER_LIMIT - 1, "spawn ID");
        check5(!entities.has(spawn.id), "reused world entity ID");
        entities.add(spawn.id);
        point(spawn.point);
        if ("actorId" in spawn) check5(actors.has(spawn.actorId), "unknown spawn actor");
        else check5(vehicles.has(spawn.definitionId), "unknown spawn vehicle");
      }
    }
  }

  // src/game/labs/combat-terrain.ts
  var COMBAT_SUPPORT = [
    {
      id: 104,
      definitionId: 1,
      rect: { x: pixels(176), y: pixels(160), w: pixels(152), h: pixels(56) },
      health: 8
    }
  ];
  function combatGeometryRevision(props) {
    return 1 + props.filter((prop) => prop.health === 0).length;
  }
  var COMBAT_ORDNANCE = [
    {
      id: 102,
      shapeId: 17,
      x: pixels(24),
      y: pixels(160),
      w: pixels(240),
      h: pixels(8),
      start: 0,
      end: 50,
      dx: pixels(1),
      dy: 0
    },
    {
      id: 103,
      shapeId: 18,
      x: pixels(190),
      y: pixels(90),
      w: pixels(132),
      h: pixels(10),
      start: 55,
      end: 85,
      dx: 0,
      dy: pixels(2)
    }
  ];
  function ordnancePlatforms(tick2) {
    integer(tick2, 0, 3601, "ordnance trajectory tick");
    return COMBAT_ORDNANCE.map((platform, i) => {
      const age = Math.max(0, Math.min(platform.end, tick2) - platform.start);
      const previous = Math.max(0, Math.min(platform.end, Math.max(0, tick2 - 1)) - platform.start);
      return {
        id: platform.id,
        x: platform.x + age * platform.dx,
        y: platform.y + age * platform.dy,
        vx: (age - previous) * platform.dx,
        vy: (age - previous) * platform.dy,
        shapeId: platform.shapeId,
        trajectoryId: i + 1,
        trajectoryTick: tick2
      };
    });
  }
  function combatTerrain(scenario, tick2 = 0, props = []) {
    if (scenario === "support") {
      if (props.length !== COMBAT_SUPPORT.length) throw new Error("Missing support state");
      return [
        footTerrain(100, 0, 200, 152, 16),
        ...props.filter((prop) => prop.health > 0).map((prop) => {
          const definition2 = COMBAT_SUPPORT.find((definition3) => definition3.id === prop.id);
          if (!definition2) throw new Error("Unknown support geometry");
          return {
            id: prop.id,
            kind: "solid",
            rect: { ...definition2.rect },
            delta: { x: 0, y: 0 }
          };
        }),
        footTerrain(105, 352, 200, 32, 16)
      ];
    }
    const terrain = [
      footTerrain(100, 0, 200, 384, 16),
      ...scenario === "wall" ? [footTerrain(101, 140, 130, 3, 70)] : []
    ];
    if (scenario === "ordnance")
      for (const [i, platform] of ordnancePlatforms(tick2).entries()) {
        const definition2 = COMBAT_ORDNANCE[i];
        if (!definition2) throw new Error("Missing ordnance platform");
        terrain.push({
          id: platform.id,
          kind: "solid",
          rect: {
            x: platform.x - platform.vx,
            y: platform.y - platform.vy,
            w: definition2.w,
            h: definition2.h
          },
          delta: { x: platform.vx, y: platform.vy }
        });
      }
    return terrain;
  }
  function combatEndTerrain(scenario, tick2, props = []) {
    return combatTerrain(scenario, tick2, props).map((target) => ({
      ...target,
      rect: { ...target.rect, x: target.rect.x + target.delta.x, y: target.rect.y + target.delta.y },
      delta: { x: 0, y: 0 }
    }));
  }
  function combatCollisionIndex(scenario, frame, props = [], terrainOverride) {
    const terrain = terrainOverride ?? combatTerrain(scenario, frame.tick, props);
    const moving = (target) => target.delta.x !== 0 || target.delta.y !== 0;
    return new CollisionIndex(
      new CollisionGrid(terrain.filter((target) => !moving(target))),
      terrain.filter(moving),
      frame
    );
  }

  // src/game/labs/combat-content.ts
  var COMBAT_CONTENT = structuredClone(CONTRACT_FIXTURE);
  COMBAT_CONTENT.shapes.push(
    { id: 7, rect: { x: pixels(-5), y: pixels(-18), w: pixels(10), h: pixels(16) } },
    { id: 8, rect: { x: pixels(5), y: pixels(-30), w: pixels(4), h: pixels(28) } },
    { id: 9, rect: { x: pixels(-10), y: pixels(-8), w: pixels(34), h: pixels(16) } },
    { id: 10, rect: { x: pixels(-3), y: pixels(-3), w: pixels(6), h: pixels(6) } },
    { id: 11, rect: { x: pixels(-48), y: pixels(-48), w: pixels(96), h: pixels(96) } },
    { id: 12, rect: { x: 0, y: pixels(-10), w: pixels(30), h: pixels(24) } },
    { id: 13, rect: { x: 0, y: pixels(-3), w: pixels(20), h: pixels(6) } },
    { id: 14, rect: { x: 0, y: pixels(-8), w: pixels(14), h: pixels(8) } },
    structuredClone(ROCKET_SHAPE),
    structuredClone(ROCKET_BLAST_SHAPE),
    structuredClone(LASER_SHAPE)
  );
  var sidearm = COMBAT_CONTENT.weapons[0];
  var attack = COMBAT_CONTENT.attacks[0];
  if (!sidearm || !attack) throw new Error("Missing baseline firearm content");
  sidearm.cadenceTicks = 8;
  var hmg = {
    ...sidearm,
    id: "heavy-machine-gun",
    attackId: 2,
    cadenceTicks: 5,
    ammoPerAction: 1,
    pickupAmmo: 150,
    timelineId: 14,
    visualFamily: "fixture-hmg",
    audioFamily: "fixture-hmg"
  };
  COMBAT_CONTENT.weapons.push(hmg);
  COMBAT_CONTENT.attacks.push({ ...attack, id: 2, speed: pixels(18) });
  var HMG_SWEEP = {
    stepTicks: 2,
    headings: [
      [-4, 16, 2, 0, 0, 4608],
      [-3, 200, 6, -7, 1763, 4257],
      [-2, 201, 11, -12, 3258, 3258],
      [-1, 202, 14, -17, 4257, 1763],
      [0, 14, 15, -23, 4608, 0],
      [1, 203, 14, -29, 4257, -1763],
      [2, 204, 11, -34, 3258, -3258],
      [3, 205, 6, -37, 1763, -4257],
      [4, 15, 2, -38, 0, -4608]
    ].map(([pitch = 0, timelineId = 0, x = 0, y = 0, vx = 0, vy = 0]) => ({
      pitch,
      timelineId,
      muzzle: { x: pixels(x), y: pixels(y) },
      velocity: { x: vx, y: vy }
    }))
  };
  var shotgun = {
    ...sidearm,
    id: "shotgun",
    attackId: 10,
    cadenceTicks: 28,
    ammoPerAction: 1,
    pickupAmmo: 24,
    visualFamily: "fixture-shotgun",
    audioFamily: "fixture-shotgun"
  };
  var flame = {
    ...sidearm,
    id: "flamethrower",
    attackId: 11,
    cadenceTicks: 30,
    ammoPerAction: 1,
    pickupAmmo: 30,
    visualFamily: "fixture-flame",
    audioFamily: "fixture-flame"
  };
  var rocket = structuredClone(ROCKET_WEAPON);
  var laser = structuredClone(LASER_WEAPON);
  COMBAT_CONTENT.weapons.push(shotgun, flame, rocket, laser);
  COMBAT_CONTENT.attacks.push(
    structuredClone(ROCKET_ATTACK),
    structuredClone(LASER_ATTACK),
    {
      id: 10,
      kind: "shot-volume",
      shapeId: 13,
      damage: 4,
      lifetimeTicks: 6,
      speed: 0,
      maxTargets: 16,
      repeatDamageTicks: 0,
      material: "bullet"
    },
    {
      id: 11,
      kind: "flame-volumes",
      shapeId: 14,
      damage: 1,
      lifetimeTicks: 30,
      speed: 0,
      maxTargets: 16,
      repeatDamageTicks: 6,
      material: "heat"
    }
  );
  var AREA_PROFILES = /* @__PURE__ */ new Map([
    [
      10,
      {
        kind: "shot-volume",
        emissionOffsets: [0],
        attachedTicks: 0,
        maximumReach: pixels(110),
        frames: [20, 40, 60, 80, 100, 110].map((length2, age) => ({
          x: 0,
          y: -pixels(3 + age * 2),
          w: pixels(length2),
          h: pixels(6 + age * 4)
        }))
      }
    ],
    [
      11,
      {
        kind: "flame-volumes",
        emissionOffsets: [0, 6, 12],
        attachedTicks: 6,
        maximumReach: pixels(90),
        frames: Array.from({ length: 18 }, (_, age) => {
          const width = age < 6 ? [14, 18, 24, 28, 32, 36][age] ?? 0 : 36;
          const height = age < 6 ? 8 + Math.min(age, 3) * 2 : age < 14 ? 14 : 10;
          return {
            x: age < 6 ? 0 : (age - 5) * (pixels(4) + 128),
            y: pixels((age < 6 ? [-4, -2, 0, 2, 4, 2][age] ?? 0 : 2) - height / 2),
            w: pixels(width),
            h: pixels(height)
          };
        })
      }
    ]
  ]);
  var FOOT_ACTION_PROFILES = {
    melee: { timelineIds: [40, 41], cooldownTicks: 18 },
    grenade: { timelineIds: [50, 51], cooldownTicks: 20 }
  };
  var GRENADE_PROFILE = {
    bodyShapeId: 10,
    fuseTicks: 90,
    gravity: 55,
    terminalVelocity: 2048,
    maximumBounces: 3,
    radius: pixels(48),
    standingVelocity: { x: pixels(2) + 128, y: -pixels(4) - 128 },
    crouchedVelocity: { x: pixels(4), y: -pixels(1) - 128 },
    inheritedVelocityLimit: { x: pixels(8), y: pixels(8) }
  };
  COMBAT_CONTENT.attacks.push(
    {
      id: 4,
      kind: "melee",
      shapeId: 9,
      damage: 1,
      lifetimeTicks: 4,
      speed: 0,
      maxTargets: 4,
      repeatDamageTicks: 0,
      material: "blade"
    },
    {
      id: 5,
      kind: "explosion",
      shapeId: 11,
      damage: 1,
      lifetimeTicks: GRENADE_PROFILE.fuseTicks,
      speed: GRENADE_PROFILE.standingVelocity.x,
      maxTargets: 16,
      repeatDamageTicks: 0,
      material: "explosive"
    }
  );
  for (const kind of ["melee", "grenade"]) {
    const profile = FOOT_ACTION_PROFILES[kind];
    for (const [stance, id2] of profile.timelineIds.entries()) {
      const durations = kind === "melee" ? [5, 4, 9] : [4, 1, 15];
      const poseIds = [id2, id2 + 2, id2 + 4];
      for (const [phase, poseId] of poseIds.entries())
        COMBAT_CONTENT.poses.push({
          id: poseId,
          frame: `engineering-${kind}-${stance}-${phase}`,
          durationTicks: durations[phase] ?? 0,
          sockets: [
            {
              name: "hand",
              point: { x: pixels(10), y: pixels(stance === 1 ? -12 : kind === "melee" ? -20 : -24) }
            }
          ],
          hurtShapeIds: [stance === 1 ? 7 : 3]
        });
      COMBAT_CONTENT.timelines.push({
        id: id2,
        durationTicks: profile.cooldownTicks,
        poses: poseIds,
        markers: [
          {
            tickOffset: durations[0] ?? 0,
            kind: kind === "melee" ? "activate-hitbox" : "spawn-attack",
            payloadId: kind === "melee" ? 4 : 5,
            socket: "hand"
          },
          {
            tickOffset: durations[0] ?? 0,
            kind: "sound",
            payloadId: kind === "melee" ? 4 : 5,
            socket: "hand"
          }
        ]
      });
    }
  }
  var RIFLE_PROFILE = {
    timelineIds: [30, 31],
    raiseTicks: 24,
    lastReleaseTick: 36,
    range: pixels(240),
    upAlignment: pixels(24),
    upHeight: pixels(48),
    aimHeight: pixels(16)
  };
  COMBAT_CONTENT.attacks.push({ ...attack, id: 3, speed: pixels(3), lifetimeTicks: 150 });
  for (const [aim, id2] of RIFLE_PROFILE.timelineIds.entries()) {
    const muzzle = aim === 0 ? { x: pixels(15), y: pixels(-23) } : { x: pixels(2), y: pixels(-36) };
    const poseIds = [id2, id2 + 2, id2 + 4];
    for (const [phase, poseId] of poseIds.entries())
      COMBAT_CONTENT.poses.push({
        id: poseId,
        frame: `engineering-rifle-${aim}-${phase}`,
        durationTicks: [24, 13, 35][phase] ?? 0,
        sockets: [
          { name: "muzzle", point: muzzle },
          { name: "hand", point: { x: 0, y: pixels(-23) } }
        ],
        hurtShapeIds: [3]
      });
    COMBAT_CONTENT.timelines.push({
      id: id2,
      durationTicks: 72,
      poses: poseIds,
      markers: [24, 30, 36].flatMap((tickOffset) => [
        { tickOffset, kind: "spawn-attack", payloadId: 3, socket: "muzzle" },
        { tickOffset, kind: "sound", payloadId: 3, socket: "muzzle" }
      ])
    });
  }
  var SHIELD_PROFILE = {
    timelineIds: { brace: 100, advance: 101, turn: 102, bash: 103, stunned: 104 },
    integrity: 2,
    speed: pixels(1),
    sightRange: pixels(384),
    bashRange: pixels(29),
    bashHeight: pixels(24),
    bashActiveTick: 12,
    bashActiveTicks: 4,
    damageByMaterial: { bullet: 0, explosive: 2, heat: 1, energy: 1, blade: 0, blunt: 1 }
  };
  COMBAT_CONTENT.attacks.push({
    id: 6,
    kind: "melee",
    shapeId: 12,
    damage: 1,
    lifetimeTicks: 4,
    speed: 0,
    maxTargets: 4,
    repeatDamageTicks: 0,
    material: "blunt"
  });
  for (const [index, durationTicks] of [24, 36, 9, 9, 12, 4, 14, 36].entries())
    COMBAT_CONTENT.poses.push({
      id: 100 + index,
      frame: `engineering-shield-${index}`,
      durationTicks,
      sockets: [{ name: "hand", point: { x: 0, y: pixels(-18) } }],
      hurtShapeIds: [3]
    });
  COMBAT_CONTENT.timelines.push(
    { id: 100, durationTicks: 24, poses: [100], markers: [] },
    { id: 101, durationTicks: 36, poses: [101], markers: [] },
    {
      id: 102,
      durationTicks: 18,
      poses: [102, 103],
      markers: [
        { tickOffset: 9, kind: "face", payloadId: 1, socket: "hand" },
        { tickOffset: 9, kind: "sound", payloadId: 8, socket: "hand" }
      ]
    },
    {
      id: 103,
      durationTicks: 30,
      poses: [104, 105, 106],
      markers: [
        { tickOffset: 12, kind: "activate-hitbox", payloadId: 6, socket: "hand" },
        { tickOffset: 12, kind: "sound", payloadId: 6, socket: "hand" }
      ]
    },
    {
      id: 104,
      durationTicks: 36,
      poses: [107],
      markers: [{ tickOffset: 0, kind: "sound", payloadId: 7, socket: "hand" }]
    }
  );
  var profiles = [];
  for (const [index, weapon2] of [sidearm, hmg, shotgun, flame, rocket, laser].entries()) {
    const base = weapon2.id === "laser" ? LASER_WEAPON.timelineId : weapon2.id === "rocket-launcher" ? ROCKET_WEAPON.timelineId : 10 + index * 4;
    const timelineIds = [base, base + 1, base + 2, base + 3];
    weapon2.timelineId = base;
    const duration = weapon2.id === "laser" ? LASER_WEAPON.cadenceTicks : weapon2.id === "flamethrower" ? 30 : weapon2.id === "shotgun" || weapon2.id === "rocket-launcher" ? 12 : 4;
    const emissions = AREA_PROFILES.get(weapon2.attackId)?.emissionOffsets ?? [0];
    for (const [poseIndex, id2] of timelineIds.entries()) {
      const muzzle = (weapon2.id === "heavy-machine-gun" && poseIndex !== 3 ? HMG_SWEEP.headings.find((heading) => heading.timelineId === id2)?.muzzle : void 0) ?? [
        { x: pixels(15), y: pixels(-23) },
        { x: pixels(2), y: pixels(-36) },
        { x: pixels(2), y: 0 },
        { x: pixels(15), y: pixels(-12) }
      ][poseIndex];
      if (!muzzle) throw new Error("Missing firearm socket");
      COMBAT_CONTENT.poses.push({
        id: id2,
        frame: `engineering-${weapon2.id}-${poseIndex}`,
        durationTicks: duration,
        sockets: [
          { name: "muzzle", point: muzzle },
          { name: "hand", point: { x: 0, y: poseIndex === 3 ? pixels(-12) : pixels(-23) } }
        ],
        hurtShapeIds: [poseIndex === 3 ? 7 : 3]
      });
      COMBAT_CONTENT.timelines.push({
        id: id2,
        durationTicks: duration,
        poses: [id2],
        markers: [
          ...emissions.flatMap((tickOffset) => [
            {
              tickOffset,
              kind: "spawn-attack",
              payloadId: weapon2.attackId,
              socket: "muzzle"
            },
            {
              tickOffset,
              kind: "sound",
              payloadId: weapon2.attackId,
              socket: "muzzle"
            }
          ]),
          ...["flamethrower", "laser"].includes(weapon2.id) ? [] : [
            {
              tickOffset: 2,
              kind: "sound",
              payloadId: weapon2.attackId,
              socket: "hand"
            }
          ]
        ]
      });
    }
    profiles.push({
      weapon: weapon2,
      timelineIds,
      ...weapon2.id === "heavy-machine-gun" ? { sweep: HMG_SWEEP } : {}
    });
  }
  for (const heading of HMG_SWEEP.headings.filter((heading2) => heading2.timelineId >= 200)) {
    const reference = COMBAT_CONTENT.timelines.find((timeline) => timeline.id === 14);
    if (!reference) throw new Error("Missing HMG timing");
    COMBAT_CONTENT.poses.push({
      id: heading.timelineId,
      frame: `engineering-heavy-machine-gun-pitch-${heading.pitch}`,
      durationTicks: reference.durationTicks,
      sockets: [
        { name: "muzzle", point: heading.muzzle },
        { name: "hand", point: { x: 0, y: pixels(-23) } }
      ],
      hurtShapeIds: [3]
    });
    COMBAT_CONTENT.timelines.push({
      ...structuredClone(reference),
      id: heading.timelineId,
      poses: [heading.timelineId]
    });
  }
  var tankActor = {
    id: 2,
    locomotion: "grounded",
    standingShapeId: 15,
    crouchedShapeId: 15,
    idlePoseId: 130,
    runSpeed: pixels(3),
    jumpVelocity: -pixels(5),
    gravity: 64,
    terminalVelocity: pixels(8)
  };
  var tankDefinition = {
    id: 1,
    kind: "tank",
    actorId: 2,
    armor: 3,
    weaponId: "heavy-machine-gun",
    seat: {
      socket: { x: 0, y: -pixels(6) },
      ejectionCandidates: [
        { x: pixels(30), y: 0 },
        { x: -pixels(30), y: 0 },
        { x: 0, y: -pixels(38) }
      ],
      boardingSensorShapeId: 16,
      boardingTimelineId: 130
    }
  };
  var TANK_PROFILE = {
    definition: tankDefinition,
    locomotion: tankActor,
    exitTimelineId: 131,
    fireTimelineIds: Array.from({ length: 8 }, (_, i) => 140 + i),
    attackId: 16,
    fireCadenceTicks: 5,
    turnTicks: 3,
    damageProtectionTicks: 30,
    reboardTicks: 30,
    exitProtectionTicks: 12,
    disconnectGraceTicks: 15,
    fallBoundary: pixels(248),
    hardpoint: { x: 0, y: -pixels(24) },
    headings: [
      [26, -24, 20, 0],
      [20, -44, 14, -14],
      [0, -50, 0, -20],
      [-20, -44, -14, -14],
      [-26, -24, -20, 0],
      [-20, -4, -14, 14],
      [0, 2, 0, 20],
      [20, -4, 14, 14]
    ].map(([x = 0, y = 0, vx = 0, vy = 0]) => ({
      muzzle: { x: pixels(x), y: pixels(y) },
      velocity: { x: pixels(vx), y: pixels(vy) }
    }))
  };
  COMBAT_CONTENT.actors = COMBAT_CONTENT.actors.map((actor) => actor.id === 2 ? tankActor : actor);
  COMBAT_CONTENT.vehicles = [tankDefinition];
  COMBAT_CONTENT.shapes.push(
    { id: 15, rect: { x: -pixels(20), y: -pixels(24), w: pixels(40), h: pixels(24) } },
    { id: 16, rect: { x: -pixels(40), y: -pixels(40), w: pixels(80), h: pixels(40) } }
  );
  COMBAT_CONTENT.attacks.push({
    id: 16,
    kind: "swept-projectile",
    shapeId: 4,
    damage: 1,
    lifetimeTicks: 40,
    speed: pixels(20),
    maxTargets: 1,
    repeatDamageTicks: 0,
    material: "bullet"
  });
  for (const [id2, duration] of [
    [130, 12],
    [131, 8]
  ]) {
    COMBAT_CONTENT.poses.push({
      id: id2,
      frame: `engineering-tank-${id2 === 130 ? "board" : "exit"}`,
      durationTicks: duration,
      sockets: [
        { name: "seat", point: tankDefinition.seat.socket },
        { name: "ejection", point: { x: pixels(30), y: 0 } }
      ],
      hurtShapeIds: [15]
    });
    COMBAT_CONTENT.timelines.push({
      id: id2,
      durationTicks: duration,
      poses: [id2],
      markers: [
        {
          tickOffset: duration - 1,
          kind: "seat-transfer",
          payloadId: 1,
          socket: id2 === 130 ? "seat" : "ejection"
        }
      ]
    });
  }
  for (const [heading, exposure] of TANK_PROFILE.headings.entries()) {
    const id2 = 140 + heading;
    COMBAT_CONTENT.poses.push({
      id: id2,
      frame: `engineering-tank-fire-${heading}`,
      durationTicks: 3,
      sockets: [{ name: "muzzle", point: exposure.muzzle }],
      hurtShapeIds: [15]
    });
    COMBAT_CONTENT.timelines.push({
      id: id2,
      durationTicks: 3,
      poses: [id2],
      markers: [
        { tickOffset: 0, kind: "spawn-attack", payloadId: 16, socket: "muzzle" },
        { tickOffset: 0, kind: "sound", payloadId: 16, socket: "muzzle" }
      ]
    });
  }
  for (const platform of COMBAT_ORDNANCE)
    COMBAT_CONTENT.shapes.push({
      id: platform.shapeId,
      rect: { x: 0, y: 0, w: platform.w, h: platform.h }
    });
  validateContent(COMBAT_CONTENT);
  for (const [id2, profile] of AREA_PROFILES) {
    const definition2 = COMBAT_CONTENT.attacks.find((attack2) => attack2.id === id2);
    if (!definition2) throw new Error("Missing area attack definition");
    validateAreaProfile(profile, definition2);
  }
  var COMBAT_CATALOG = {
    firearms: new Map(profiles.map((profile) => [profile.weapon.id, profile])),
    timelines: new Map(COMBAT_CONTENT.timelines.map((timeline) => [timeline.id, timeline])),
    poses: new Map(COMBAT_CONTENT.poses.map((pose) => [pose.id, pose]))
  };
  var COMBAT_SHAPES = new Map(COMBAT_CONTENT.shapes.map((shape) => [shape.id, shape]));
  for (const profile of profiles) validateFirearmSweep(profile, COMBAT_CATALOG);
  validateTankProfile(TANK_PROFILE, COMBAT_SHAPES, COMBAT_CATALOG);
  var COMBAT_ATTACKS = new Map(
    COMBAT_CONTENT.attacks.map((definition2) => [definition2.id, definition2])
  );

  // src/game/labs/combat-tanks.ts
  var neutral = { held: 0, jumpPressed: false, firePressed: false };
  function exitShape() {
    const shape = FOOT_DEFINITION && COMBAT_SHAPES.get(FOOT_DEFINITION.standingShapeId);
    if (!shape) throw new Error("Missing tank ejection shape");
    return shape;
  }
  function releaseCombatTank(world, tank, reason, changes, lifeNotices, index, frame) {
    const id2 = tankOwner(tank);
    if (reason === "destroyed") tank.armor = 0;
    if (id2 === null) {
      if (reason === "destroyed") tank.controlEpoch = nextCounter(tank.controlEpoch);
      tank.lifecycle = tank.armor === 0 ? "wreck" : "available";
      tank.action = idleTankAction(frame.tick);
      if (tank.armor === 0) tank.body.vx = tank.body.vy = tank.invulnerableTicks = 0;
      return;
    }
    const slot = world.players.findIndex((player2) => player2.playerId === id2);
    const actor = world.players[slot];
    if (!actor) throw new Error("Missing tank release owner");
    const safe = releaseTank(tank, actor, frame.tick, TANK_PROFILE, exitShape(), index, frame);
    if (tank.armor === 0) tank.body.vx = tank.body.vy = tank.invulnerableTicks = 0;
    changes.set(id2, reason);
    if (!safe || tank.body.y > TANK_PROFILE.fallBoundary) {
      const death = damagePlayer(actor, frame.tick, 1, "classic", "fall");
      world.players[slot] = death.actor;
      if (death.notice) lifeNotices.push(death.notice);
    }
  }
  function advanceCombatTanks(world, commands, connections, changes, lifeNotices, index, frame) {
    const outcomes = /* @__PURE__ */ new Map();
    for (const player2 of world.players) {
      if (player2.vehicleId !== null && !world.tanks.some(
        (tank) => tank.body.id === player2.vehicleId && tankOwner(tank) === player2.playerId
      ))
        throw new Error("Combat vehicle owner mismatch");
      outcomes.set(player2.playerId, { jumpAccepted: false, interact: "none" });
    }
    for (const [tankIndex, before] of world.tanks.entries()) {
      if (before.lifecycle === "wreck") continue;
      const id2 = tankOwner(before), actor = world.players.find((player2) => player2.playerId === id2), slot = actor?.slot;
      const connected = id2 !== null && connections.connectedPlayerIds.includes(id2);
      const forced = id2 !== null && connections.releasePlayerIds.includes(id2);
      const intent = connected && !forced && slot !== void 0 ? commands[slot] ?? neutral : neutral;
      const moved = moveTank(before, intent, TANK_PROFILE, COMBAT_SHAPES, index, frame);
      const tank = moved.tank;
      world.tanks[tankIndex] = tank;
      if (actor) attachTankDriver(tank, actor, TANK_PROFILE);
      if (moved.fault && moved.fault.reason !== "crushed")
        throw new Error(`Combat tank: ${moved.fault.reason}`);
      if (moved.fault || tank.body.y > TANK_PROFILE.fallBoundary) {
        releaseCombatTank(world, tank, "destroyed", changes, lifeNotices, index, frame);
        continue;
      }
      if (id2 === null || !actor) continue;
      tank.disconnectedTicks = connected ? 0 : tank.disconnectedTicks + 1;
      if (forced || tank.disconnectedTicks >= TANK_PROFILE.disconnectGraceTicks) {
        releaseCombatTank(world, tank, "disconnect", changes, lifeNotices, index, frame);
        continue;
      }
      const outcome = outcomes.get(id2);
      if (outcome) outcome.jumpAccepted = moved.jumpAccepted;
      const transfer = stepTankTransfer(
        tank,
        actor,
        frame.tick,
        TANK_PROFILE,
        COMBAT_CATALOG,
        exitShape(),
        index,
        frame
      );
      if (transfer) changes.set(id2, transfer === "board" ? "board" : "exit");
    }
    for (const actor of [...world.players].sort((a, b) => a.slot - b.slot)) {
      const command2 = commands[actor.slot], outcome = outcomes.get(actor.playerId);
      if (!command2?.interactPressed || !outcome) continue;
      outcome.interact = "unavailable";
      if (changes.has(actor.playerId) || !connections.connectedPlayerIds.includes(actor.playerId))
        continue;
      const owned = world.tanks.find((tank) => tankOwner(tank) === actor.playerId);
      if (owned) {
        if (requestTankExit(
          owned,
          actor,
          frame.tick,
          world.nextActionId,
          TANK_PROFILE,
          exitShape(),
          index,
          frame
        )) {
          changes.set(actor.playerId, "exit");
          world.nextActionId = nextCounter(world.nextActionId);
          outcome.interact = "applied";
        }
      } else {
        const candidates = [...world.tanks].sort(
          (a, b) => Math.abs(a.body.x - actor.body.x) + Math.abs(a.body.y - actor.body.y) - Math.abs(b.body.x - actor.body.x) - Math.abs(b.body.y - actor.body.y) || a.body.id - b.body.id
        );
        for (const tank of candidates) {
          if (!reserveTank(
            tank,
            actor,
            frame.tick,
            world.nextActionId,
            TANK_PROFILE,
            COMBAT_SHAPES,
            index,
            frame
          ))
            continue;
          changes.set(actor.playerId, "board");
          world.nextActionId = nextCounter(world.nextActionId);
          outcome.interact = "applied";
          break;
        }
      }
    }
    return outcomes;
  }
  function fireCombatTanks(world, commands, changes, terrain) {
    const outcomes = /* @__PURE__ */ new Map();
    for (const tank of world.tanks) {
      const ownerId = tank.occupantId;
      if (ownerId === null) continue;
      const actor = world.players.find((player2) => player2.playerId === ownerId), command2 = actor && commands[actor.slot];
      if (!actor || !command2) throw new Error("Missing tank fire owner");
      const changed = changes.has(ownerId);
      const result = stepTankGun(
        tank,
        changed ? neutral : command2,
        world.tick,
        world.nextActionId,
        TANK_PROFILE,
        COMBAT_CATALOG
      );
      world.nextActionId = result.nextActionId;
      outcomes.set(
        ownerId,
        changed && (command2.firePressed || command2.held & Held.Fire) ? "unavailable" : result.outcome
      );
      for (const item of result.markers) {
        const socket = item.pose.sockets.find((socket2) => socket2.name === "muzzle"), definition2 = COMBAT_ATTACKS.get(item.marker.payloadId), heading = TANK_PROFILE.headings[TANK_PROFILE.fireTimelineIds.indexOf(tank.action.definitionId)], shape = definition2 && COMBAT_SHAPES.get(definition2.shapeId);
        if (!socket || !definition2 || !shape || !heading)
          throw new Error("Missing tank release content");
        const point3 = worldSocket(tank.body, socket.point, 1);
        const notice2 = {
          kind: "sound",
          ownerId,
          actionInstanceId: item.actionInstanceId,
          markerIndex: item.markerIndex,
          source: {
            definitionId: definition2.id,
            controlEpoch: actor.controlEpoch,
            shotOrdinal: tank.weapon.shotOrdinal,
            vehicleId: tank.body.id
          },
          position: point3,
          impact: null,
          targetId: null,
          beam: null
        };
        if (item.marker.kind === "spawn-attack") {
          notice2.kind = "shot";
          if (muzzleBlocked(worldSocket(tank.body, TANK_PROFILE.hardpoint, 1), point3, shape, terrain))
            notice2.kind = "muzzle-blocked";
          else {
            if (world.projectiles.length >= 256)
              throw new Error("Tank projectile cap requires recovery");
            world.projectiles.push({
              id: world.nextEntityId,
              ownerId,
              team: 1,
              actionInstanceId: item.actionInstanceId,
              definitionId: definition2.id,
              position: point3,
              velocity: { ...heading.velocity },
              spawnTick: world.tick
            });
            world.nextEntityId = nextCounter(world.nextEntityId);
          }
        } else if (item.marker.kind !== "sound") throw new Error("Unsupported tank gun marker");
        world.events.push(notice2);
      }
    }
    return outcomes;
  }
  function tankCombatHurtboxes(tanks, previous = tanks) {
    return tanks.flatMap((tank, i) => {
      if (tank.armor === 0) return [];
      const before = previous[i], shape = COMBAT_SHAPES.get(tank.body.shapeId);
      if (!before || before.body.id !== tank.body.id || !shape)
        throw new Error("Tank hurtbox identity");
      return [
        {
          id: tank.body.id * 2,
          entityId: tank.body.id,
          team: 1,
          kind: "body",
          rect: worldRect(before.body, shape.rect, tank.facing),
          delta: { x: tank.body.x - before.body.x, y: tank.body.y - before.body.y }
        }
      ];
    });
  }
  function commitCombatSeats(current, world, changes) {
    return [...changes].sort(([a], [b]) => a - b).map(([playerId, reason]) => {
      const before = current.players.find((actor2) => actor2.playerId === playerId), actor = world.players.find((actor2) => actor2.playerId === playerId);
      if (!before || !actor) throw new Error("Missing seat transfer generation");
      actor.controlEpoch = nextCounter(before.controlEpoch);
      const tank = world.tanks.find((tank2) => tankOwner(tank2) === playerId);
      if (tank) tank.ownerControlEpoch = actor.controlEpoch;
      return {
        kind: "seat",
        playerId,
        vehicleId: actor.vehicleId,
        controlEpoch: actor.controlEpoch,
        reason
      };
    });
  }

  // src/game/labs/combat.ts
  var COMBAT_SCENARIOS = [
    "range",
    "wall",
    "shield",
    "rifle",
    "guard",
    "shotgun",
    "flame",
    "tank",
    "ordnance",
    "hmg",
    "support",
    "rocket",
    "laser"
  ];
  var COMBAT_LAB_LIMIT = 3600;
  var COMBAT_ENTRY = {
    firstX: pixels(45),
    slotSpacing: pixels(4),
    y: pixels(200),
    fallBoundary: pixels(248)
  };
  var COMBAT_TANK_DEPOT = {
    firstPlayerX: pixels(36),
    slotSpacing: pixels(56),
    vehicleOffsetX: pixels(24),
    y: pixels(200)
  };
  function combatEntryContext(actor, index, frame, scenario = "range") {
    if (!FOOT_DEFINITION) throw new Error("Missing life physics definition");
    const shape = COMBAT_SHAPES.get(FOOT_DEFINITION.standingShapeId);
    if (!shape) throw new Error("Missing life entry shape");
    const lift = scenario === "ordnance" ? index.get(COMBAT_ORDNANCE[0].id)?.rect : void 0;
    return {
      shape,
      definition: FOOT_DEFINITION,
      shapes: COMBAT_SHAPES,
      fallBoundary: COMBAT_ENTRY.fallBoundary,
      anchors: [
        {
          x: scenario === "tank" ? COMBAT_TANK_DEPOT.firstPlayerX + actor.slot * COMBAT_TANK_DEPOT.slotSpacing : COMBAT_ENTRY.firstX + actor.slot * COMBAT_ENTRY.slotSpacing + (lift ? lift.x - pixels(24) : 0),
          y: lift?.y ?? COMBAT_ENTRY.y
        }
      ],
      index,
      frame
    };
  }
  function combatEncounterDefinition(world) {
    return {
      id: 1,
      participants: world.players.map((player2) => player2.playerId),
      members: world.targets.map(({ enemy }) => ({
        id: enemy.body.id,
        required: true,
        critical: false,
        retreatAllowed: false,
        watchdogTicks: 600,
        ambientCleanupTicks: null
      })),
      objectives: []
    };
  }
  function lifecycle(world) {
    return new EncounterLifecycle(combatEncounterDefinition(world));
  }
  function createCombatLab(scenario, count = 1) {
    if (!COMBAT_SCENARIOS.includes(scenario)) throw new Error("Unknown combat scenario");
    integer(count, 1, 4, "combat players");
    const players = Array.from({ length: count }, (_, slot) => {
      const actor = footActor(
        scenario === "tank" ? (COMBAT_TANK_DEPOT.firstPlayerX + slot * COMBAT_TANK_DEPOT.slotSpacing) / 256 : 45 + slot * 4,
        scenario === "ordnance" ? 160 : 200
      );
      actor.playerId = actor.body.id = slot + 1;
      actor.slot = slot;
      if (scenario === "ordnance") actor.body.supportId = 102;
      if (slot === 1) actor.weapon = { ...actor.weapon, id: "heavy-machine-gun", ammo: 150 };
      if (scenario === "hmg") actor.weapon = { ...actor.weapon, id: "heavy-machine-gun", ammo: 150 };
      if (scenario === "shotgun") actor.weapon = { ...actor.weapon, id: "shotgun", ammo: 24 };
      if (scenario === "flame") actor.weapon = { ...actor.weapon, id: "flamethrower", ammo: 30 };
      if (scenario === "rocket") actor.weapon = { ...actor.weapon, id: "rocket-launcher", ammo: 20 };
      if (scenario === "laser") actor.weapon = { ...actor.weapon, id: "laser", ammo: 120 };
      return actor;
    });
    const props = scenario === "support" ? COMBAT_SUPPORT.map(createDestructible) : [];
    const targets2 = Array.from({ length: 2 }, (_, index) => ({
      enemy: {
        body: {
          ...footActor(
            scenario === "support" ? 220 + index * 60 : scenario === "ordnance" ? 340 + index * 26 : scenario === "tank" ? 300 + index * 40 : scenario === "shotgun" ? 140 + index * 30 : (scenario === "guard" || scenario === "flame") && index === 0 ? 140 : scenario === "flame" ? 220 : 220 + index * 60,
            scenario === "support" ? 160 : 200
          ).body,
          ...scenario === "support" ? { supportId: 104 } : {},
          id: 20 + index
        },
        facing: -1,
        geometryRevision: 1,
        life: "alive",
        removalReason: null,
        turns: 0
      },
      health: 1,
      shield: scenario === "shield" && index === 0,
      rifle: scenario === "tank" || scenario === "rifle" || (scenario === "guard" || scenario === "flame" || scenario === "support") && index === 1 ? createRifleState() : null,
      guard: (scenario === "guard" || scenario === "flame" || scenario === "support") && index === 0 ? createShieldState(SHIELD_PROFILE) : null
    }));
    return {
      format: 11,
      scenario,
      tick: 0,
      nextActionId: 1,
      nextEntityId: 1e3,
      eventSequence: 0,
      players,
      tanks: scenario === "tank" ? players.map(
        (actor) => createTank(
          30 + actor.slot,
          {
            x: COMBAT_TANK_DEPOT.firstPlayerX + actor.slot * COMBAT_TANK_DEPOT.slotSpacing + COMBAT_TANK_DEPOT.vehicleOffsetX,
            y: COMBAT_TANK_DEPOT.y
          },
          100,
          TANK_PROFILE
        )
      ) : [],
      targets: targets2,
      props,
      projectiles: [],
      rockets: [],
      beams: [],
      strikes: [],
      grenades: [],
      areas: [],
      encounter: lifecycle({ players, targets: targets2 }).begin(),
      events: []
    };
  }
  function combatAreaAnchor(world, area) {
    const actor = world.players.find((actor2) => actor2.playerId === area.ownerId);
    if (actor?.life !== "alive" || actor.vehicleId !== null || actor.action.kind !== "fire" || actor.action.actionInstanceId !== area.actionInstanceId)
      return null;
    const pose = actionPose(
      COMBAT_CATALOG,
      actor.action.definitionId,
      world.tick - actor.action.stateStartTick
    );
    const socket = pose?.sockets.find((socket2) => socket2.name === "muzzle");
    if (!socket) throw new Error("Missing attached volume socket");
    return {
      origin: worldSocket(actor.body, socket.point, actor.facing),
      heading: actor.aim === 1 ? 1 : actor.aim === 2 ? 2 : actor.facing === 1 ? 0 : 3
    };
  }
  function actionHand(actor, tick2) {
    const pose = actionPose(
      COMBAT_CATALOG,
      actor.action.definitionId,
      tick2 - actor.action.stateStartTick
    );
    const socket = pose?.sockets.find((socket2) => socket2.name === "hand");
    if (!socket) throw new Error("Missing combat hand socket");
    return socket.point;
  }
  function appendShieldMarkers(world, target, markers) {
    const guard = target.guard;
    if (!guard || target.health === 0) return;
    for (const item of markers) {
      if (item.marker.kind === "face") continue;
      if (item.marker.kind !== "sound" && item.marker.kind !== "activate-hitbox")
        throw new Error("Unsupported shield marker");
      const socket = item.pose.sockets.find((socket2) => socket2.name === item.marker.socket);
      if (!socket) throw new Error("Missing shield marker socket");
      world.events.push({
        kind: item.marker.kind === "sound" ? "action-sound" : "melee",
        ownerId: target.enemy.body.id,
        actionInstanceId: item.actionInstanceId,
        markerIndex: item.markerIndex,
        source: {
          definitionId: item.marker.payloadId,
          timelineId: guard.action.definitionId,
          stateStartTick: guard.action.stateStartTick
        },
        position: worldSocket(target.enemy.body, socket.point, target.enemy.facing),
        impact: null,
        targetId: null,
        beam: null
      });
    }
  }
  function meleeEligible(actor, targets2, terrain, tick2, props, definitions, extraHurtboxes) {
    const definition2 = COMBAT_ATTACKS.get(4), shape = COMBAT_SHAPES.get(9);
    if (!definition2 || !shape) throw new Error("Missing contextual melee content");
    const pose = COMBAT_CATALOG.poses.get(
      FOOT_ACTION_PROFILES.melee.timelineIds[actor.locomotion === "crouched" ? 1 : 0]
    );
    const socket = pose?.sockets.find((socket2) => socket2.name === "hand");
    if (!socket) throw new Error("Missing melee ready socket");
    const hand = worldSocket(actor.body, socket.point, actor.facing);
    return actor.aim === 0 && meleeHits(
      { id: actor.body.id, ownerId: actor.playerId, team: 1, actionInstanceId: 1, definitionId: 4 },
      definition2,
      shape,
      hand,
      { x: 0, y: 0 },
      actor.facing,
      { x: actor.body.x, y: hand.y },
      terrain,
      [
        ...combatHurtboxes(targets2, tick2),
        ...destructibleHurtboxes(props, definitions),
        ...extraHurtboxes
      ]
    ).some((hit) => hit.damage > 0);
  }
  function combatHurtboxes(targets2, tick2, previous = targets2) {
    return targets2.flatMap((target, index) => {
      if (target.health === 0 || target.enemy.life !== "alive") return [];
      const body4 = target.enemy.body, before = previous[index]?.enemy.body;
      if (!before || before.id !== body4.id) throw new Error("Target motion identity mismatch");
      const protectedBody = target.shield || target.guard !== null && shieldProtected(target.guard, tick2, SHIELD_PROFILE);
      const kinds = protectedBody ? ["body", "shield"] : ["body"];
      return kinds.map((kind) => {
        const shape = COMBAT_SHAPES.get(kind === "body" ? 3 : 8);
        if (!shape) throw new Error("Missing target hurt shape");
        return {
          id: body4.id * 2 + (kind === "shield" ? 1 : 0),
          entityId: body4.id,
          team: 2,
          kind,
          rect: worldRect(before, shape.rect, target.enemy.facing),
          delta: { x: body4.x - before.x, y: body4.y - before.y }
        };
      });
    });
  }
  function playerCombatHurtboxes(players, previous = players) {
    return players.flatMap((player2, slot) => {
      if (player2.life !== "alive" || player2.invulnerableTicks > 0 || player2.vehicleId !== null)
        return [];
      const before = previous[slot];
      const shape = COMBAT_SHAPES.get(
        player2.body.shapeId === FOOT_DEFINITION?.crouchedShapeId ? 7 : 3
      );
      if (!before || before.body.id !== player2.body.id || !shape)
        throw new Error("Player hurtbox identity");
      return [
        {
          id: player2.body.id * 2,
          entityId: player2.body.id,
          team: 1,
          kind: "body",
          rect: worldRect(before.body, shape.rect, player2.facing),
          delta: { x: player2.body.x - before.body.x, y: player2.body.y - before.body.y }
        }
      ];
    });
  }
  function stepCombatLab(current, commands) {
    return advanceCombatLab(current, commands).state;
  }
  function advanceCombatLab(current, commands, connections = {
    connectedPlayerIds: current.players.map((p) => p.playerId),
    releasePlayerIds: []
  }, stage) {
    integer(current.tick, 0, COMBAT_LAB_LIMIT - 1, "combat tick");
    if (commands.length !== current.players.length) throw new Error("Missing combat input owner");
    for (const command2 of commands) {
      integer(command2.held, 0, HELD_MASK, "combat held mask");
      if (typeof command2.firePressed !== "boolean" || typeof command2.jumpPressed !== "boolean" || typeof command2.grenadePressed !== "boolean" || typeof command2.interactPressed !== "boolean")
        throw new Error("Invalid combat edges");
    }
    const world = structuredClone(current);
    const tick2 = ++world.tick;
    world.events = [];
    const physicalTerrain = stage?.terrain ?? combatTerrain(world.scenario, tick2, world.props);
    const active = (target) => !stage || stage.activeEnemyIds.has(target.enemy.body.id);
    const destructibles = stage?.destructibles ?? COMBAT_SUPPORT;
    const terrain = physicalTerrain.filter(
      (target) => !world.props.some((prop) => prop.id === target.id)
    );
    const frame = { tick: tick2, geometryRevision: combatGeometryRevision(world.props) };
    const index = combatCollisionIndex(world.scenario, frame, world.props, physicalTerrain);
    const encounterEvents = [];
    const activatedIds = /* @__PURE__ */ new Set();
    const activateTarget = (id2) => {
      if (!activatedIds.has(id2) && world.encounter.members.some((member) => member.id === id2 && member.status === "pending")) {
        activatedIds.add(id2);
        encounterEvents.push({ kind: "activate", id: id2, sequence: ++world.eventSequence, tick: tick2 });
      }
    };
    const lifeNotices = [];
    const seatChanges = /* @__PURE__ */ new Map();
    const outcomes = [];
    for (const [slot, actor] of world.players.entries()) {
      const command2 = commands[slot];
      if (!command2 || !FOOT_DEFINITION) throw new Error("Missing combat controller");
      const life = stepPlayerLife(actor, tick2, "classic", {
        ...combatEntryContext(actor, index, frame, world.scenario),
        ...stage ? {
          fallBoundary: stage.fallBoundary,
          anchors: [{ x: stage.entry.x + actor.slot * pixels(24), y: stage.entry.y }]
        } : {}
      });
      if (life.notice) lifeNotices.push(life.notice);
      const result = stepFootController(
        life.actor,
        command2,
        FOOT_DEFINITION,
        COMBAT_SHAPES,
        index,
        frame
      );
      if (result.status === "failed") {
        if (result.physics.reason !== "crushed")
          throw new Error(`Combat body: ${result.physics.reason}`);
        const killed = damagePlayer(life.actor, tick2, 1, "classic", "crush");
        world.players[slot] = killed.actor;
        if (killed.notice) lifeNotices.push(killed.notice);
      } else world.players[slot] = result.actor;
      outcomes.push({
        playerId: actor.playerId,
        jumpAccepted: result.status === "complete" && (result.jumpRequest === "consumed" || result.jumpRequest === "buffered"),
        fire: "none",
        grenade: "none",
        interact: "none"
      });
    }
    const tankOutcomes = advanceCombatTanks(
      world,
      commands,
      connections,
      seatChanges,
      lifeNotices,
      index,
      frame
    );
    for (const outcome of outcomes) {
      const tank = tankOutcomes.get(outcome.playerId);
      if (!tank) throw new Error("Missing tank input outcome");
      outcome.jumpAccepted ||= tank.jumpAccepted;
      outcome.interact = tank.interact;
    }
    for (const target of world.targets) {
      if (!active(target)) continue;
      activateTarget(target.enemy.body.id);
      if (target.health === 0) continue;
      const shieldStep = target.guard && stepShield(
        target.guard,
        target.enemy,
        world.players,
        tick2,
        world.nextActionId,
        COMBAT_CATALOG,
        SHIELD_PROFILE
      );
      if (shieldStep) {
        target.guard = shieldStep.state;
        target.enemy.facing = shieldStep.state.facing;
        world.nextActionId = shieldStep.nextActionId;
      }
      const shape = COMBAT_SHAPES.get(target.enemy.body.shapeId);
      if (!shape) throw new Error("Missing enemy body");
      const result = stepGroundedEnemy(
        target.enemy,
        {
          speed: shieldStep ? shieldStep.speed : target.rifle?.action.kind === "fire" ? 0 : 64,
          turnAtBoundary: !target.guard && target.rifle?.action.kind !== "fire",
          gravity: 55,
          terminalVelocity: 2048,
          bounds: stage?.enemyBounds ?? { x: 0, y: 0, w: pixels(384), h: pixels(220) }
        },
        shape,
        index,
        frame
      );
      if (result.status === "failed") throw new Error(`Combat enemy: ${result.physics.reason}`);
      target.enemy = result.enemy;
      if (target.enemy.removalReason) {
        target.health = 0;
        if (target.rifle) cancelRifle(target.rifle);
        if (target.guard) cancelShield(target.guard);
        encounterEvents.push({
          kind: "resolve",
          id: target.enemy.body.id,
          reason: target.enemy.removalReason,
          killerId: null,
          sequence: ++world.eventSequence,
          tick: tick2
        });
      }
      if (shieldStep) appendShieldMarkers(world, target, shieldStep.markers);
    }
    for (const [slot, actor] of world.players.entries()) {
      const command2 = commands[slot];
      if (!command2) throw new Error("Missing firearm input");
      const result = stepFootCombatAction(
        actor,
        seatChanges.has(actor.playerId) ? { held: 0, firePressed: false, grenadePressed: false } : command2,
        tick2,
        world.nextActionId,
        COMBAT_CATALOG,
        FOOT_ACTION_PROFILES,
        meleeEligible(
          actor,
          world.targets,
          terrain,
          tick2,
          world.props,
          destructibles,
          stage?.extraHurtboxes ?? []
        )
      );
      world.players[slot] = result.actor;
      world.nextActionId = result.nextActionId;
      const outcome = outcomes.find((item) => item.playerId === actor.playerId);
      if (!outcome) throw new Error("Missing combat action owner");
      outcome.fire = result.fire;
      outcome.grenade = result.grenade;
      for (const item of result.markers) {
        const local = item.pose.sockets.find((socket) => socket.name === item.marker.socket)?.point;
        if (!local) throw new Error("Missing marker socket");
        const position2 = worldSocket(actor.body, local, actor.facing);
        if (item.marker.payloadId === 4 || item.marker.payloadId === 5) {
          const notice3 = {
            kind: "action-sound",
            ownerId: actor.playerId,
            actionInstanceId: item.actionInstanceId,
            markerIndex: item.markerIndex,
            source: {
              definitionId: item.marker.payloadId,
              timelineId: result.actor.action.definitionId,
              stateStartTick: result.actor.action.stateStartTick
            },
            position: position2,
            impact: null,
            targetId: null,
            beam: null
          };
          if (item.marker.kind === "activate-hitbox") {
            notice3.kind = "melee";
            world.strikes.push({
              id: world.nextEntityId,
              ownerId: actor.playerId,
              team: 1,
              actionInstanceId: item.actionInstanceId,
              definitionId: 4,
              spawnTick: tick2,
              endTick: tick2 + (COMBAT_ATTACKS.get(4)?.lifetimeTicks ?? 0),
              hitIds: []
            });
            world.nextEntityId = nextCounter(world.nextEntityId);
          } else if (item.marker.kind === "spawn-attack") {
            notice3.kind = "throw";
            const shape = COMBAT_SHAPES.get(GRENADE_PROFILE.bodyShapeId);
            if (!shape) throw new Error("Missing grenade body");
            const handRoot = { x: actor.body.x, y: position2.y };
            const delta = { x: position2.x - handRoot.x, y: 0 };
            const blocking = earliestSweep(
              worldRect(handRoot, shape.rect, 1),
              delta,
              physicalTerrain.map((target) => ({
                ...target,
                rect: {
                  ...target.rect,
                  x: target.rect.x + target.delta.x,
                  y: target.rect.y + target.delta.y
                },
                delta: { x: 0, y: 0 }
              }))
            );
            if (blocking.overlaps.length) throw new Error("Grenade hand starts inside terrain");
            const contact = blocking.contacts[0];
            const releaseDelta = contact ? displacementAtContact(delta, contact.time) : delta;
            const release = { x: handRoot.x + releaseDelta.x, y: handRoot.y + releaseDelta.y };
            notice3.position = release;
            const velocity2 = grenadeLaunchVelocity(actor, GRENADE_PROFILE, index, frame);
            world.grenades.push({
              id: world.nextEntityId,
              ownerId: actor.playerId,
              team: 1,
              actionInstanceId: item.actionInstanceId,
              definitionId: 5,
              spawnTick: tick2,
              bounces: 0,
              body: {
                id: world.nextEntityId,
                x: release.x,
                y: release.y,
                vx: velocity2.x,
                vy: velocity2.y,
                remainderX: 0,
                remainderY: 0,
                shapeId: shape.id,
                grounded: false,
                supportId: null,
                contacts: []
              }
            });
            world.nextEntityId = nextCounter(world.nextEntityId);
          } else if (item.marker.kind !== "sound") throw new Error("Unsupported foot action marker");
          world.events.push(notice3);
          continue;
        }
        const notice2 = {
          kind: "sound",
          ownerId: actor.playerId,
          actionInstanceId: item.actionInstanceId,
          markerIndex: item.markerIndex,
          source: {
            definitionId: item.marker.payloadId,
            controlEpoch: result.actor.controlEpoch,
            shotOrdinal: result.actor.weapon.shotOrdinal
          },
          position: position2,
          impact: null,
          targetId: null,
          beam: null
        };
        if (item.marker.kind === "spawn-attack") {
          const definition2 = COMBAT_ATTACKS.get(item.marker.payloadId);
          const shape = definition2 && COMBAT_SHAPES.get(definition2.shapeId);
          const hand = item.pose.sockets.find((socket) => socket.name === "hand")?.point;
          if (!definition2 || !shape || !hand) throw new Error("Missing release definition");
          notice2.kind = "shot";
          const areaProfile = AREA_PROFILES.get(definition2.id);
          const rocket2 = definition2.id === ROCKET_ATTACK.id;
          const laser2 = definition2.id === LASER_ATTACK.id;
          const clearance = rocket2 ? ROCKET_SHAPE : areaProfile || laser2 ? COMBAT_SHAPES.get(4) : shape;
          if (!clearance) throw new Error("Missing muzzle clearance shape");
          const blocked = muzzleBlocked(
            worldSocket(actor.body, hand, actor.facing),
            position2,
            clearance,
            physicalTerrain
          );
          if (areaProfile) {
            let area = world.areas.find((area2) => area2.actionInstanceId === item.actionInstanceId);
            if (!area) {
              if (world.areas.length >= 16) throw new Error("Area attack cap requires recovery");
              area = {
                id: world.nextEntityId,
                ownerId: actor.playerId,
                team: 1,
                actionInstanceId: item.actionInstanceId,
                definitionId: definition2.id,
                startTick: result.actor.action.stateStartTick,
                emitted: 0,
                cancelledTick: null,
                lobes: [],
                hits: []
              };
              world.areas.push(area);
              world.nextEntityId = nextCounter(world.nextEntityId);
            }
            emitArea(
              area,
              tick2,
              areaProfile,
              {
                origin: position2,
                heading: actor.aim === 1 ? 1 : actor.aim === 2 ? 2 : actor.facing === 1 ? 0 : 3
              },
              blocked
            );
            if (blocked) notice2.kind = "muzzle-blocked";
          } else if (blocked) notice2.kind = "muzzle-blocked";
          else if (laser2) {
            if (world.beams.length >= 8) throw new Error("Beam cap requires recovery");
            world.beams.push({
              id: world.nextEntityId,
              ownerId: actor.playerId,
              team: 1,
              actionInstanceId: item.actionInstanceId,
              definitionId: definition2.id,
              spawnTick: tick2,
              tick: tick2,
              origin: { ...position2 },
              heading: actor.aim === 1 ? 1 : actor.aim === 2 ? 2 : actor.facing === 1 ? 0 : 3,
              length: LASER_PROFILE.range
            });
            world.nextEntityId = nextCounter(world.nextEntityId);
          } else if (rocket2) {
            if (world.rockets.length >= 32) throw new Error("Rocket cap requires recovery");
            world.rockets.push(
              createRocket(
                {
                  id: world.nextEntityId,
                  ownerId: actor.playerId,
                  team: 1,
                  actionInstanceId: item.actionInstanceId,
                  definitionId: definition2.id
                },
                position2,
                actor.aim === 1 ? 24 : actor.aim === 2 ? 8 : actor.facing === 1 ? 0 : 16,
                tick2,
                ROCKET_PROFILE
              )
            );
            world.nextEntityId = nextCounter(world.nextEntityId);
          } else {
            if (world.projectiles.length >= 256) throw new Error("Projectile cap requires recovery");
            world.projectiles.push({
              id: world.nextEntityId,
              ownerId: actor.playerId,
              team: 1,
              actionInstanceId: item.actionInstanceId,
              definitionId: definition2.id,
              position: position2,
              velocity: firearmVelocity(result.actor, definition2.speed, COMBAT_CATALOG),
              spawnTick: tick2
            });
            world.nextEntityId = nextCounter(world.nextEntityId);
          }
        } else if (item.marker.kind !== "sound") throw new Error("Unsupported firearm marker");
        world.events.push(notice2);
      }
    }
    const tankFire = fireCombatTanks(world, commands, seatChanges, physicalTerrain);
    for (const outcome of outcomes) {
      const fire = tankFire.get(outcome.playerId);
      if (fire !== void 0) outcome.fire = fire;
    }
    for (const target of world.targets) {
      if (!active(target) || !target.rifle || target.health === 0) continue;
      const shape = COMBAT_SHAPES.get(4);
      if (!shape) throw new Error("Missing rifle projectile shape");
      const result = stepRifleAttack(
        target.rifle,
        target.enemy,
        world.players,
        tick2,
        world.nextActionId,
        COMBAT_CATALOG,
        RIFLE_PROFILE,
        shape,
        physicalTerrain
      );
      target.rifle = result.state;
      target.enemy.facing = result.facing;
      world.nextActionId = result.nextActionId;
      for (const item of result.markers) {
        const muzzle = item.pose.sockets.find((socket) => socket.name === "muzzle")?.point;
        const hand = item.pose.sockets.find((socket) => socket.name === "hand")?.point;
        const definition2 = COMBAT_ATTACKS.get(item.marker.payloadId);
        if (!muzzle || !hand || !definition2) throw new Error("Missing rifle release content");
        const position2 = worldSocket(target.enemy.body, muzzle, target.enemy.facing);
        const notice2 = {
          kind: "sound",
          ownerId: target.enemy.body.id,
          actionInstanceId: item.actionInstanceId,
          markerIndex: item.markerIndex,
          source: {
            definitionId: definition2.id,
            timelineId: target.rifle.action.definitionId,
            stateStartTick: target.rifle.action.stateStartTick
          },
          position: position2,
          impact: null,
          targetId: null,
          beam: null
        };
        if (item.marker.kind === "spawn-attack") {
          notice2.kind = "shot";
          if (muzzleBlocked(
            worldSocket(target.enemy.body, hand, target.enemy.facing),
            position2,
            shape,
            physicalTerrain
          ))
            notice2.kind = "muzzle-blocked";
          else {
            if (world.projectiles.length >= 256) throw new Error("Projectile cap requires recovery");
            world.projectiles.push({
              id: world.nextEntityId,
              ownerId: target.enemy.body.id,
              team: 2,
              actionInstanceId: item.actionInstanceId,
              definitionId: definition2.id,
              position: position2,
              velocity: {
                x: target.rifle.aim === 0 ? definition2.speed * target.enemy.facing : 0,
                y: target.rifle.aim === 1 ? -definition2.speed : 0
              },
              spawnTick: tick2
            });
            world.nextEntityId = nextCounter(world.nextEntityId);
          }
        } else if (item.marker.kind !== "sound") throw new Error("Unsupported rifle marker");
        world.events.push(notice2);
      }
    }
    const hurtboxes = [
      // Authored actors remain material before AI activation. A long-range round must
      // meet an intact shield before it can enter the body behind it.
      ...combatHurtboxes(world.targets, tick2, current.targets),
      ...playerCombatHurtboxes(world.players, current.players),
      ...tankCombatHurtboxes(world.tanks, current.tanks),
      ...destructibleHurtboxes(world.props, destructibles),
      ...stage?.extraHurtboxes ?? []
    ];
    const impacts = [];
    world.beams = world.beams.flatMap((beam) => {
      const index2 = world.players.findIndex((player2) => player2.playerId === beam.ownerId);
      let anchor = index2 >= 0 && ((commands[index2]?.held ?? 0) & Held.Fire) !== 0 ? combatAreaAnchor(world, beam) : null;
      if (anchor) {
        const actor = world.players[index2], clearance = COMBAT_SHAPES.get(4);
        if (!actor || !clearance) throw new Error("Missing beam muzzle clearance");
        if (muzzleBlocked(
          worldSocket(actor.body, actionHand(actor, tick2), actor.facing),
          anchor.origin,
          clearance,
          physicalTerrain
        ))
          anchor = null;
      }
      const result = beam.spawnTick === tick2 ? emitBeam(
        beam,
        tick2,
        LASER_ATTACK,
        LASER_PROFILE,
        { origin: beam.origin, heading: beam.heading },
        terrain,
        hurtboxes
      ) : stepBeam(beam, tick2, LASER_ATTACK, LASER_PROFILE, anchor, terrain, hurtboxes);
      if (result.cast) {
        impacts.push(...result.cast.impacts);
        if (beam.spawnTick === tick2) {
          const notice2 = world.events.find(
            (event) => event.kind === "shot" && event.actionInstanceId === beam.actionInstanceId
          );
          if (!notice2) throw new Error("Missing laser birth event");
          notice2.beam = {
            heading: result.cast.heading,
            length: result.cast.length,
            width: result.cast.width
          };
        }
      }
      return result.beam ? [result.beam] : [];
    });
    world.rockets = world.rockets.flatMap((rocket2) => {
      if (rocket2.spawnTick === tick2) return [rocket2];
      const result = stepRocket(
        rocket2,
        tick2,
        ROCKET_ATTACK,
        ROCKET_SHAPE,
        ROCKET_PROFILE,
        terrain,
        hurtboxes
      );
      if (result.status === "active") return [result.rocket];
      if (result.status === "detonated") {
        world.events.push({
          kind: "explosion",
          ownerId: rocket2.ownerId,
          actionInstanceId: rocket2.actionInstanceId,
          markerIndex: 0,
          source: {
            definitionId: rocket2.definitionId,
            spawnTick: rocket2.spawnTick,
            sourceId: rocket2.id
          },
          position: result.contact.position,
          impact: null,
          targetId: null,
          beam: null
        });
        impacts.push(...result.impacts);
      }
      return [];
    });
    world.areas = world.areas.flatMap((area) => {
      const definition2 = COMBAT_ATTACKS.get(area.definitionId), profile = AREA_PROFILES.get(area.definitionId);
      if (!definition2 || !profile) throw new Error("Missing area policy");
      const result = stepArea(
        area,
        tick2,
        definition2,
        profile,
        combatAreaAnchor(world, area),
        terrain,
        hurtboxes
      );
      impacts.push(...result.impacts);
      return result.attack ? [result.attack] : [];
    });
    for (const target of world.targets) {
      const guard = target.guard;
      if (!active(target) || !guard || target.health === 0 || guard.phase !== "bash") continue;
      const age = tick2 - guard.action.stateStartTick;
      if (age < SHIELD_PROFILE.bashActiveTick || age >= SHIELD_PROFILE.bashActiveTick + SHIELD_PROFILE.bashActiveTicks)
        continue;
      const pose = actionPose(COMBAT_CATALOG, guard.action.definitionId, age);
      const socket = pose?.sockets.find((socket2) => socket2.name === "hand");
      const definition2 = COMBAT_ATTACKS.get(6), shape = COMBAT_SHAPES.get(12);
      const previous = current.targets.find(
        (candidate) => candidate.enemy.body.id === target.enemy.body.id
      );
      if (!socket || !definition2 || !shape || !previous) throw new Error("Missing bash volume");
      const moving = age > SHIELD_PROFILE.bashActiveTick;
      const body4 = moving ? previous.enemy.body : target.enemy.body;
      const hand = worldSocket(body4, socket.point, guard.facing);
      const delta = moving ? { x: target.enemy.body.x - body4.x, y: target.enemy.body.y - body4.y } : { x: 0, y: 0 };
      const candidates = moving ? hurtboxes : hurtboxes.map((hurt) => ({
        ...hurt,
        rect: { ...hurt.rect, x: hurt.rect.x + hurt.delta.x, y: hurt.rect.y + hurt.delta.y },
        delta: { x: 0, y: 0 }
      }));
      const hits = meleeHits(
        {
          id: target.enemy.body.id,
          ownerId: target.enemy.body.id,
          team: 2,
          actionInstanceId: guard.action.actionInstanceId,
          definitionId: 6
        },
        definition2,
        shape,
        hand,
        delta,
        guard.facing,
        { x: body4.x, y: hand.y },
        terrain,
        candidates,
        guard.hitIds
      );
      for (const hit of hits) if (hit.entityId !== null) guard.hitIds.push(hit.entityId);
      guard.hitIds.sort((a, b) => a - b);
      impacts.push(...hits);
    }
    world.strikes = world.strikes.filter((strike) => {
      const owner = world.players.find((player2) => player2.playerId === strike.ownerId);
      const before = current.players.find((player2) => player2.playerId === strike.ownerId);
      if (!owner || !before) throw new Error("Missing melee owner");
      if (tick2 >= strike.endTick || owner.life !== "alive" || owner.action.actionInstanceId !== strike.actionInstanceId || owner.action.kind !== "melee")
        return false;
      const definition2 = COMBAT_ATTACKS.get(strike.definitionId), shape = definition2 && COMBAT_SHAPES.get(definition2.shapeId);
      if (!definition2 || !shape) throw new Error("Missing melee volume");
      const hand = actionHand(owner, tick2);
      const sameFacing = owner.facing === before.facing && strike.spawnTick !== tick2;
      const start = worldSocket(sameFacing ? before.body : owner.body, hand, owner.facing);
      const delta = sameFacing ? { x: owner.body.x - before.body.x, y: owner.body.y - before.body.y } : { x: 0, y: 0 };
      const candidates = sameFacing ? hurtboxes : hurtboxes.map((target) => ({
        ...target,
        rect: {
          ...target.rect,
          x: target.rect.x + target.delta.x,
          y: target.rect.y + target.delta.y
        },
        delta: { x: 0, y: 0 }
      }));
      const hits = meleeHits(
        strike,
        definition2,
        shape,
        start,
        delta,
        owner.facing,
        { x: sameFacing ? before.body.x : owner.body.x, y: start.y },
        terrain,
        candidates,
        strike.hitIds
      );
      for (const hit of hits) if (hit.entityId !== null) strike.hitIds.push(hit.entityId);
      strike.hitIds.sort((a, b) => a - b);
      impacts.push(...hits);
      return true;
    });
    world.grenades = world.grenades.filter((grenade) => {
      const shape = COMBAT_SHAPES.get(GRENADE_PROFILE.bodyShapeId), definition2 = COMBAT_ATTACKS.get(grenade.definitionId);
      if (!shape || !definition2) throw new Error("Missing grenade policy");
      const result = stepGrenade(grenade, GRENADE_PROFILE, shape, index, frame);
      if (result.status === "active") {
        Object.assign(grenade, result.grenade);
        return true;
      }
      const position2 = result.position;
      if (result.status === "crushed") {
        const colliderId = result.colliderIds[0];
        if (colliderId === void 0) throw new Error("Grenade crush lacks a terrain witness");
        world.events.push({
          kind: "impact",
          ownerId: grenade.ownerId,
          actionInstanceId: grenade.actionInstanceId,
          markerIndex: 0,
          source: null,
          position: position2,
          targetId: null,
          beam: null,
          impact: {
            sourceId: grenade.id,
            definitionId: grenade.definitionId,
            actionInstanceId: grenade.actionInstanceId,
            ownerId: grenade.ownerId,
            colliderId,
            entityId: null,
            kind: "terrain",
            damage: 0,
            position: position2,
            time: { numerator: 1, denominator: 1 }
          }
        });
        return false;
      }
      world.events.push({
        kind: "explosion",
        ownerId: grenade.ownerId,
        actionInstanceId: grenade.actionInstanceId,
        markerIndex: 0,
        source: {
          definitionId: grenade.definitionId,
          spawnTick: grenade.spawnTick,
          sourceId: grenade.id
        },
        position: position2,
        impact: null,
        targetId: null,
        beam: null
      });
      impacts.push(
        ...explosionHits(grenade, definition2, position2, GRENADE_PROFILE.radius, terrain, hurtboxes)
      );
      return false;
    });
    if (world.projectiles.length + world.rockets.length + world.beams.length + world.areas.length + world.grenades.length + world.strikes.length > 256)
      throw new Error("Attack entity budget requires recovery");
    world.projectiles = world.projectiles.filter((projectile) => {
      const definition2 = COMBAT_ATTACKS.get(projectile.definitionId);
      const shape = definition2 && COMBAT_SHAPES.get(definition2.shapeId);
      if (!definition2 || !shape) throw new Error("Missing projectile definition");
      if (tick2 - projectile.spawnTick > definition2.lifetimeTicks) return false;
      if (projectile.spawnTick === tick2) return true;
      const impact2 = sweepProjectile(projectile, definition2, shape, terrain, hurtboxes);
      if (impact2) {
        impacts.push(impact2);
        return false;
      }
      projectile.position = {
        x: position(projectile.position.x + projectile.velocity.x),
        y: position(projectile.position.y + projectile.velocity.y)
      };
      return tick2 - projectile.spawnTick < definition2.lifetimeTicks;
    });
    impacts.sort(
      (a, b) => compareContactTime(
        a.time.numerator,
        a.time.denominator,
        b.time.numerator,
        b.time.denominator
      ) || a.actionInstanceId - b.actionInstanceId || a.sourceId - b.sourceId || a.colliderId - b.colliderId
    );
    for (const impact2 of impacts) {
      const notice2 = {
        kind: "impact",
        ownerId: impact2.ownerId,
        actionInstanceId: impact2.actionInstanceId,
        markerIndex: 0,
        source: null,
        position: impact2.position,
        impact: impact2,
        targetId: impact2.entityId,
        beam: null
      };
      world.events.push(notice2);
      const prop = world.props.find((prop2) => prop2.id === impact2.entityId);
      if (prop) {
        const attack2 = COMBAT_ATTACKS.get(impact2.definitionId);
        if (!attack2) throw new Error("Missing prop attack definition");
        if (damageDestructible(prop, impact2, attack2, tick2))
          world.events.push({ ...notice2, kind: "prop-destroyed" });
        continue;
      }
      const tank = world.tanks.find((tank2) => tank2.body.id === impact2.entityId);
      if (tank) {
        if (impact2.damage > 0 && tank.armor > 0 && tank.invulnerableTicks === 0) {
          tank.armor--;
          tank.invulnerableTicks = TANK_PROFILE.damageProtectionTicks;
          if (tank.armor === 0) {
            releaseCombatTank(world, tank, "destroyed", seatChanges, lifeNotices, index, frame);
            world.events.push({ ...notice2, kind: "killed" });
          }
        }
        continue;
      }
      const slot = world.players.findIndex((player3) => player3.body.id === impact2.entityId);
      const player2 = world.players[slot];
      if (player2 && impact2.damage > 0) {
        const damage = damagePlayer(player2, tick2, impact2.damage, "classic");
        world.players[slot] = damage.actor;
        if (damage.notice) {
          lifeNotices.push(damage.notice);
          world.events.push({ ...notice2, kind: "killed" });
        }
        continue;
      }
      const target = world.targets.find((candidate) => candidate.enemy.body.id === impact2.entityId);
      if (target && target.health > 0) activateTarget(target.enemy.body.id);
      if (target?.guard && target.health > 0 && impact2.kind === "shield") {
        const definition2 = COMBAT_ATTACKS.get(impact2.definitionId);
        if (!definition2) throw new Error("Unknown shield damage definition");
        const damage = damageShield(
          target.guard,
          definition2,
          tick2,
          world.nextActionId,
          COMBAT_CATALOG,
          SHIELD_PROFILE
        );
        target.guard = damage.state;
        world.nextActionId = damage.nextActionId;
        if (damage.broken) world.events.push({ ...notice2, kind: "shield-break" });
        appendShieldMarkers(world, target, damage.markers);
      }
      if (!target || target.health === 0 || impact2.damage === 0) continue;
      target.health = Math.max(0, target.health - impact2.damage);
      if (target.health === 0) {
        target.enemy.life = "removed";
        if (target.rifle) cancelRifle(target.rifle);
        if (target.guard) cancelShield(target.guard);
        world.events.push({ ...notice2, kind: "killed" });
        encounterEvents.push({
          kind: "resolve",
          id: target.enemy.body.id,
          reason: "killed",
          killerId: impact2.ownerId,
          sequence: ++world.eventSequence,
          tick: tick2
        });
      }
    }
    const geometryRevision = combatGeometryRevision(world.props);
    if (geometryRevision !== frame.geometryRevision) {
      const removed = new Set(world.props.filter((prop) => prop.health === 0).map((prop) => prop.id));
      for (const actor of world.players) {
        const detached = detachDestroyedSupport(actor.body, removed);
        actor.geometryRevision = geometryRevision;
        if (detached && actor.locomotion !== "seated") actor.locomotion = "airborne";
        if (actor.ignoredSupportId !== null && removed.has(actor.ignoredSupportId)) {
          actor.ignoredSupportId = null;
          actor.ignoredSupportTicks = 0;
        }
      }
      for (const { enemy } of world.targets) {
        detachDestroyedSupport(enemy.body, removed);
        enemy.geometryRevision = geometryRevision;
      }
      for (const tank of world.tanks) detachDestroyedSupport(tank.body, removed);
      for (const grenade of world.grenades) detachDestroyedSupport(grenade.body, removed);
    }
    for (const [slot, actor] of world.players.entries()) {
      if (actor.life !== "alive" || actor.body.y <= (stage?.fallBoundary ?? COMBAT_ENTRY.fallBoundary))
        continue;
      const death = damagePlayer(actor, tick2, 1, "classic", "fall");
      world.players[slot] = death.actor;
      if (death.notice) lifeNotices.push(death.notice);
    }
    world.strikes = world.strikes.filter(
      (strike) => world.players.some(
        (player2) => player2.playerId === strike.ownerId && player2.life === "alive" && player2.action.actionInstanceId === strike.actionInstanceId
      )
    );
    for (const area of world.areas) {
      const profile = AREA_PROFILES.get(area.definitionId);
      if (!profile) throw new Error("Missing area cancellation policy");
      if (!combatAreaAnchor(world, area)) cancelArea(area, tick2, profile);
    }
    world.beams = world.beams.filter((beam) => combatAreaAnchor(world, beam) !== null);
    world.encounter = lifecycle(world).step(
      world.encounter,
      tick2,
      encounterEvents,
      world.targets.filter(
        (target) => target.health > 0 && (active(target) || activatedIds.has(target.enemy.body.id))
      ).map((target) => ({
        id: target.enemy.body.id,
        progressKey: canonical([
          target.enemy.body.x,
          target.enemy.body.y,
          target.enemy.body.vx,
          target.enemy.body.vy,
          target.enemy.body.supportId,
          target.enemy.facing
        ]),
        unreachable: false
      })),
      "throw"
    ).state;
    const seatEvents = commitCombatSeats(current, world, seatChanges);
    return { state: world, outcomes, lifeNotices, seatEvents, impacts };
  }

  // src/game/campaign/lifecycle.ts
  function check6(ok, reason) {
    if (!ok) throw new Error(`Campaign: ${reason}`);
  }
  function ids(values, label) {
    integer(values.length, 0, 320, `${label} count`);
    let previous = 0;
    for (const id2 of values) {
      integer(id2, previous + 1, COUNTER_LIMIT - 1, label);
      previous = id2;
    }
  }
  function validate3(state) {
    const rules = RULE_PRESETS[state.ruleset];
    check6(rules, "unknown ruleset");
    integer(state.mission, 1, 255, "mission number");
    integer(state.checkpointId, 1, COUNTER_LIMIT - 1, "checkpoint ID");
    integer(state.encounterId, 1, COUNTER_LIMIT - 1, "encounter ID");
    integer(state.continuesRemaining, 0, rules.sharedContinues, "remaining continues");
    integer(state.continuesUsed, 0, rules.sharedContinues, "used continues");
    check6(
      state.continuesRemaining + state.continuesUsed === rules.sharedContinues,
      "continue accounting"
    );
    check6(
      ["playing", "wipe", "intermission", "victory", "defeat"].includes(state.phase),
      "unknown phase"
    );
    ids(state.requiredEntities, "required entities");
    ids(
      state.resolvedEntities.map((entity) => entity.id),
      "resolved entities"
    );
    for (const entity of state.resolvedEntities)
      check6(["killed", "retreated", "out-of-bounds"].includes(entity.reason), "resolution reason");
  }
  function party(state, players, tick2) {
    validate3(state);
    integer(players.length, 1, ARCADE.maxPlayers, "party size");
    ids(
      players.map((player2) => player2.playerId),
      "player IDs"
    );
    check6(new Set(players.map((player2) => player2.slot)).size === players.length, "duplicate slot");
    for (const player2 of players) {
      integer(player2.slot, 0, ARCADE.maxPlayers - 1, "party slot");
      integer(player2.lastRallyMission, 0, 255, "rally mission");
      validatePlayerLife(player2, tick2, state.ruleset);
    }
  }
  function createCampaign(ruleset, checkpointId, encounterId) {
    check6(RULE_PRESETS[ruleset], "unknown ruleset");
    const state = {
      ruleset,
      mission: 1,
      checkpointId,
      encounterId,
      continuesRemaining: RULE_PRESETS[ruleset].sharedContinues,
      continuesUsed: 0,
      phase: "playing",
      requiredEntities: [],
      resolvedEntities: []
    };
    validate3(state);
    return state;
  }
  function evaluatePartyWipe(current, players, connected, tick2) {
    party(current, players, tick2);
    ids(connected, "connected players");
    check6(
      connected.every((id2) => players.some((player2) => player2.playerId === id2)),
      "unknown connected player"
    );
    const state = structuredClone(current);
    if (state.phase !== "playing" || connected.length === 0) return state;
    if (players.some((player2) => connected.includes(player2.playerId) && player2.lives > 0))
      return state;
    state.phase = state.continuesRemaining > 0 ? "wipe" : "defeat";
    return state;
  }
  function finishMission(current, players, connected, tick2, finish) {
    const state = evaluatePartyWipe(current, players, connected, tick2);
    integer(finish.missionCount, 1, 255, "campaign mission count");
    check6(
      finish.mission === state.mission && state.mission <= finish.missionCount,
      "mission identity"
    );
    check6(finish.finalEncounter.id === state.encounterId, "final encounter identity");
    const encounter = new EncounterLifecycle(finish.finalEncounter).restore(finish.encounter);
    check6(encounter.tick === tick2, "encounter boundary");
    if (state.phase !== "playing" || connected.length === 0 || encounter.phase !== "complete")
      return state;
    if (!players.some((player2) => connected.includes(player2.playerId) && player2.life === "alive"))
      return state;
    position(finish.exit.x);
    position(finish.exit.y);
    integer(finish.exit.w, 1, MAX_POSITION * 2, "exit width");
    integer(finish.exit.h, 1, MAX_POSITION * 2, "exit height");
    position(finish.exit.x + finish.exit.w);
    position(finish.exit.y + finish.exit.h);
    for (const player2 of players) {
      if (!connected.includes(player2.playerId) || player2.life === "death" || player2.life === "spectating")
        continue;
      const shape = finish.shapes.get(player2.body.shapeId);
      check6(shape, "missing exit body shape");
      const body4 = worldRect(player2.body, shape.rect, player2.facing);
      if (body4.x < finish.exit.x || body4.y < finish.exit.y || body4.x + body4.w > finish.exit.x + finish.exit.w || body4.y + body4.h > finish.exit.y + finish.exit.h)
        return state;
    }
    state.phase = state.mission === finish.missionCount ? "victory" : "intermission";
    return state;
  }
  function checkpoint(current, entry, mission) {
    check6(entry.mission === mission, "checkpoint mission mismatch");
    integer(entry.id, 1, COUNTER_LIMIT - 1, "checkpoint ID");
    integer(entry.encounterId, 1, COUNTER_LIMIT - 1, "checkpoint encounter ID");
    ids(entry.requiredEntities, "checkpoint entities");
    return {
      ...structuredClone(current),
      mission,
      checkpointId: entry.id,
      encounterId: entry.encounterId,
      requiredEntities: [...entry.requiredEntities],
      resolvedEntities: [],
      phase: "playing"
    };
  }
  function enter(player2, state, tick2, entry) {
    const context2 = entry.entries.get(player2.playerId);
    check6(context2, "missing checkpoint player anchor");
    const next = enterPlayer(player2, tick2, state.ruleset, context2);
    check6(next, "checkpoint player anchor is blocked");
    return next;
  }
  function stageContinue(current, players, tick2, entry) {
    party(current, players, tick2);
    check6(current.phase === "wipe" && current.continuesRemaining > 0, "continue unavailable");
    check6(entry.id === current.checkpointId, "continue checkpoint mismatch");
    const state = checkpoint(current, entry, current.mission);
    const reset = players.map(
      (player2) => enter({ ...player2, lives: ARCADE.initialLives }, state, tick2, entry)
    );
    state.continuesRemaining--;
    state.continuesUsed++;
    return {
      state,
      players: reset,
      boundary: {
        kind: "continue",
        tick: tick2,
        mission: state.mission,
        checkpointId: state.checkpointId,
        continueOrdinal: state.continuesUsed
      }
    };
  }
  function stageNextMission(current, players, tick2, entry) {
    party(current, players, tick2);
    check6(
      current.phase === "intermission" && current.mission < 255,
      "mission transition unavailable"
    );
    const state = checkpoint(current, entry, current.mission + 1);
    const rallied = [];
    const reset = players.map((currentPlayer) => {
      const player2 = structuredClone(currentPlayer);
      check6(player2.lastRallyMission <= state.mission, "future rally grant");
      if (player2.lives === 0) {
        if (player2.lastRallyMission === state.mission) return player2;
        player2.lives = 1;
        player2.lastRallyMission = state.mission;
        rallied.push(player2.playerId);
      }
      const next = enter(player2, state, tick2, entry);
      if (currentPlayer.life === "alive") {
        next.weapon = { ...currentPlayer.weapon, cooldownTicks: 0 };
        next.grenadeStock = currentPlayer.grenadeStock;
        next.health = currentPlayer.health;
      }
      return next;
    });
    return {
      state,
      players: reset,
      boundary: { kind: "next-mission", tick: tick2, mission: state.mission, rallied }
    };
  }

  // src/game/labs/combat-campaign.ts
  var check7 = (ok, reason) => {
    if (!ok) throw new Error(`Combat campaign: ${reason}`);
  };
  var resolvedEntities = (combat) => combat.encounter.members.flatMap(
    (member) => member.reason === "killed" || member.reason === "retreated" || member.reason === "out-of-bounds" ? [{ id: member.id, reason: member.reason }] : []
  );
  function createCombatCampaign(combat) {
    const state = createCampaign("classic", 1, combatEncounterDefinition(combat).id);
    state.requiredEntities = combat.targets.map((target) => target.enemy.body.id);
    return { state, continues: [] };
  }
  function validateCombatCampaign(campaign, combat, runEpoch) {
    integer(runEpoch, 1, COUNTER_LIMIT - 1, "campaign epoch");
    const state = campaign.state;
    check7(
      state.ruleset === "classic" && state.mission === 1 && state.checkpointId === 1 && state.encounterId === 1,
      "diagnostic checkpoint identity"
    );
    evaluatePartyWipe(state, combat.players, [], combat.tick);
    check7(["playing", "wipe", "defeat"].includes(state.phase), "unsupported diagnostic phase");
    check7(state.phase !== "wipe" || state.continuesRemaining > 0, "wipe credit budget");
    check7(state.phase !== "defeat" || state.continuesRemaining === 0, "defeat credit budget");
    check7(
      canonical(state.resolvedEntities) === canonical(resolvedEntities(combat)),
      "campaign resolution ledger"
    );
    const initial = createCombatLab(combat.scenario, combat.players.length);
    const initialVehicles = initial.tanks.map((tank) => tank.body.id);
    const initialIds = initial.targets.map((target) => target.enemy.body.id);
    check7(campaign.continues.length === state.continuesUsed, "continue decision count");
    integer(
      campaign.continues.length,
      0,
      RULE_PRESETS[state.ruleset].sharedContinues,
      "continue history length"
    );
    let lastTick = -1, lastEpoch = 0;
    const allocated = /* @__PURE__ */ new Set();
    for (const [index, decision] of campaign.continues.entries()) {
      check7(
        decision.ordinal === index + 1 && decision.checkpointId === state.checkpointId,
        "continue decision identity"
      );
      integer(decision.tick, lastTick + 1, combat.tick, "continue tick");
      integer(decision.fromRunEpoch, lastEpoch || 1, runEpoch - 1, "continue source epoch");
      check7(decision.runEpoch === decision.fromRunEpoch + 1, "continue generation");
      integer(
        decision.nextEntityIdBefore,
        Math.max(
          ...campaign.continues[index - 1]?.spawnedEntityIds ?? initialIds,
          ...campaign.continues[index - 1]?.spawnedVehicleIds ?? initialVehicles
        ) + 1,
        combat.nextEntityId - 1,
        "continue allocation boundary"
      );
      check7(
        [...decision.spawnedEntityIds, ...decision.spawnedVehicleIds].every(
          (id2, i) => id2 === decision.nextEntityIdBefore + i
        ),
        "checkpoint allocation sequence"
      );
      for (const ids2 of [decision.retiredVehicleIds, decision.spawnedVehicleIds]) {
        check7(ids2.length === initialVehicles.length, "checkpoint vehicle count");
        for (const [i, id2] of ids2.entries())
          integer(
            id2,
            i ? (ids2[i - 1] ?? 0) + 1 : 1,
            combat.nextEntityId - 1,
            "checkpoint vehicle ID"
          );
      }
      check7(
        canonical(decision.retiredVehicleIds) === canonical(campaign.continues[index - 1]?.spawnedVehicleIds ?? initialVehicles),
        "checkpoint vehicle retirement prefix"
      );
      for (const ids2 of [decision.retiredEntityIds, decision.spawnedEntityIds]) {
        check7(ids2.length === combat.targets.length, "checkpoint entity count");
        for (const [i, id2] of ids2.entries())
          integer(id2, i ? (ids2[i - 1] ?? 0) + 1 : 1, combat.nextEntityId - 1, "checkpoint entity ID");
      }
      check7(
        canonical(decision.retiredEntityIds) === canonical(campaign.continues[index - 1]?.spawnedEntityIds ?? initialIds),
        "checkpoint retirement prefix"
      );
      if (index === 0)
        for (const id2 of [...decision.retiredEntityIds, ...decision.retiredVehicleIds])
          allocated.add(id2);
      for (const id2 of [...decision.spawnedEntityIds, ...decision.spawnedVehicleIds]) {
        check7(!allocated.has(id2), "reused checkpoint entity");
        allocated.add(id2);
      }
      check7(decision.kills.length === combat.players.length, "checkpoint kill roster");
      for (const [i, credit] of decision.kills.entries()) {
        check7(credit.playerId === combat.players[i]?.playerId, "checkpoint kill owner");
        integer(credit.count, 0, combat.targets.length, "checkpoint kills");
      }
      check7(
        decision.kills.reduce((sum, credit) => sum + credit.count, 0) <= combat.targets.length,
        "checkpoint kill total"
      );
      lastTick = decision.tick;
      lastEpoch = decision.runEpoch;
    }
    const expectedIds = campaign.continues.at(-1)?.spawnedEntityIds ?? initialIds;
    check7(
      canonical(combat.tanks.map((tank) => tank.body.id)) === canonical(campaign.continues.at(-1)?.spawnedVehicleIds ?? initialVehicles),
      "current checkpoint vehicle roster"
    );
    check7(
      canonical(combat.targets.map((target) => target.enemy.body.id)) === canonical(expectedIds),
      "current checkpoint entity roster"
    );
    check7(
      canonical(state.requiredEntities) === canonical(expectedIds),
      "campaign requirement roster"
    );
  }
  function advanceCombatCampaign(current, combat, connected) {
    const campaign = structuredClone(current);
    campaign.state.resolvedEntities = resolvedEntities(combat);
    if (connected.length && connected.every(
      (id2) => combat.players.some((player2) => player2.playerId === id2 && player2.life === "spectating")
    ))
      campaign.state = evaluatePartyWipe(campaign.state, combat.players, connected, combat.tick);
    return campaign;
  }
  function continueCombatCheckpoint(current, campaign, runEpoch) {
    validateCombatCampaign(campaign, current, runEpoch);
    const world = structuredClone(current);
    const template = createCombatLab(current.scenario, current.players.length);
    world.targets = template.targets.map((target) => {
      const id2 = world.nextEntityId;
      world.nextEntityId = nextCounter(world.nextEntityId);
      return { ...target, enemy: { ...target.enemy, body: { ...target.enemy.body, id: id2 } } };
    });
    world.tanks = template.tanks.map((tank) => {
      const id2 = world.nextEntityId;
      world.nextEntityId = nextCounter(world.nextEntityId);
      tank.body.id = id2;
      tank.action.stateStartTick = world.tick;
      return tank;
    });
    world.props = structuredClone(template.props);
    for (const player2 of world.players) player2.geometryRevision = 1;
    world.projectiles = [];
    world.rockets = [];
    world.beams = [];
    world.strikes = [];
    world.grenades = [];
    world.areas = [];
    world.events = [];
    world.eventSequence = 0;
    world.encounter = new EncounterLifecycle(combatEncounterDefinition(world)).begin(world.tick);
    const frame = { tick: world.tick, geometryRevision: 1 };
    const index = new CollisionIndex(
      new CollisionGrid(combatEndTerrain(world.scenario, world.tick, world.props)),
      [],
      frame
    );
    const entry = stageContinue(campaign.state, world.players, world.tick, {
      mission: 1,
      id: 1,
      encounterId: 1,
      requiredEntities: world.targets.map((target) => target.enemy.body.id),
      entries: new Map(
        world.players.map((player2) => [
          player2.playerId,
          combatEntryContext(player2, index, frame, world.scenario)
        ])
      )
    });
    world.players = entry.players;
    const decision = {
      ordinal: entry.boundary.continueOrdinal,
      tick: world.tick,
      checkpointId: 1,
      fromRunEpoch: runEpoch,
      runEpoch: nextCounter(runEpoch),
      nextEntityIdBefore: current.nextEntityId,
      retiredEntityIds: current.targets.map((target) => target.enemy.body.id),
      spawnedEntityIds: world.targets.map((target) => target.enemy.body.id),
      retiredVehicleIds: current.tanks.map((tank) => tank.body.id),
      spawnedVehicleIds: world.tanks.map((tank) => tank.body.id),
      kills: structuredClone(current.encounter.kills)
    };
    return {
      combat: world,
      campaign: { state: entry.state, continues: [...structuredClone(campaign.continues), decision] }
    };
  }

  // src/shared/protocol/events.ts
  var EVENT_TYPE = 3;
  var EVENT_HEADER_BYTES = 32;
  var EVENT_RECORD_BYTES = 76;
  var MAX_EVENT_BATCH = 64;
  var MAX_EVENT_HISTORY = 512;
  var EVENT_HISTORY_TICKS = 120;
  var EVENT_KINDS = [
    "shot",
    "sound",
    "muzzle-blocked",
    "impact",
    "killed",
    "melee",
    "throw",
    "action-sound",
    "explosion",
    "shield-break",
    "prop-destroyed"
  ];
  var EVENT_MATERIALS = ["none", "terrain", "shield", "body"];
  var EVENT_ORIGINS = ["player", "enemy"];
  function eventCounter(value, zero4 = false) {
    return integer(value, zero4 ? 0 : 1, COUNTER_LIMIT - 1, "event counter");
  }
  function eventRequire(condition, message) {
    if (!condition) throw new ProtocolError("malformed", message);
  }
  function identity(value, expected) {
    eventCounter(value.runEpoch);
    eventCounter(value.connectionEpoch);
    if (value.runEpoch !== expected.runEpoch || value.connectionEpoch !== expected.connectionEpoch)
      throw new ProtocolError("identity-mismatch", "Event session mismatch");
  }
  function validateGameplayEvent(event, context2) {
    eventRequire(
      Object.keys(event).sort().join() === "actionInstanceId,beam,confirmation,definitionId,kind,markerIndex,material,origin,ownerId,targetId,x,y",
      "Unexpected gameplay event fields"
    );
    eventRequire(EVENT_KINDS.includes(event.kind), "Unknown gameplay event kind");
    eventRequire(EVENT_ORIGINS.includes(event.origin), "Unknown event origin");
    eventRequire(EVENT_MATERIALS.includes(event.material), "Unknown impact material");
    eventCounter(event.ownerId);
    eventCounter(event.actionInstanceId);
    integer(event.markerIndex, 0, MAX_EVENT_HISTORY - 1, "event marker");
    eventCounter(event.definitionId);
    eventRequire(
      (["sound", "action-sound"].includes(event.kind) ? context2.soundIds : context2.attackIds).has(
        event.definitionId
      ),
      "Unknown event content definition"
    );
    integer(event.x, -MAX_POSITION, MAX_POSITION, "event x");
    integer(event.y, -MAX_POSITION, MAX_POSITION, "event y");
    const beamProfile = context2.beamProfiles.get(event.definitionId);
    eventRequire(
      event.beam !== null === (event.kind === "shot" && beamProfile !== void 0),
      "Invalid beam event geometry presence"
    );
    if (event.beam !== null) {
      eventRequire(
        event.beam.width === beamProfile?.width && event.beam.length <= beamProfile.range,
        "Beam event disagrees with content profile"
      );
      eventRequire(
        Object.keys(event.beam).sort().join() === "heading,length,width",
        "Unexpected beam geometry fields"
      );
      beamSegments(
        { x: event.x, y: event.y },
        event.beam.heading,
        event.beam.length,
        event.beam.width
      );
    }
    if (event.targetId !== null) eventCounter(event.targetId);
    const firearm = ["shot", "sound", "muzzle-blocked"].includes(event.kind);
    if (firearm) {
      if (event.origin === "player") {
        eventRequire(event.confirmation !== null, "Missing firearm confirmation identity");
        eventRequire(
          Object.keys(event.confirmation).sort().join() === "controlEpoch,playerId,shotOrdinal",
          "Unexpected confirmation fields"
        );
        eventCounter(event.confirmation.playerId);
        eventCounter(event.confirmation.controlEpoch);
        eventCounter(event.confirmation.shotOrdinal);
        eventRequire(event.confirmation.playerId === event.ownerId, "Confirmation owner mismatch");
      } else eventRequire(event.confirmation === null, "Enemy event has player confirmation");
      eventRequire(event.targetId === null, "Unexpected firearm target");
      eventRequire(
        event.material === (event.kind === "muzzle-blocked" ? "terrain" : "none"),
        "Invalid firearm material"
      );
    } else if (["melee", "throw", "action-sound", "explosion"].includes(event.kind)) {
      eventRequire(
        event.confirmation === null && event.targetId === null && event.material === "none",
        "Invalid foot action event"
      );
    } else {
      eventRequire(
        event.confirmation === null && event.material !== "none",
        "Invalid impact confirmation/material"
      );
      eventRequire(
        event.material === "terrain" ? event.targetId === null : event.targetId !== null,
        "Invalid impact target"
      );
      if (event.kind === "killed") eventRequire(event.material === "body", "Invalid kill material");
      if (event.kind === "prop-destroyed")
        eventRequire(event.material === "body", "Invalid prop destruction material");
      if (event.kind === "shield-break")
        eventRequire(event.material === "shield", "Invalid shield break material");
    }
  }
  function followsEvent(previous, next) {
    return next.cursor === previous.cursor + 1 && (next.tick === previous.tick && next.counter === previous.counter + 1 || next.tick > previous.tick && next.counter === 0);
  }
  function validateEventBatch(batch, context2) {
    identity(batch, context2);
    eventCounter(batch.throughTick, true);
    eventRequire(
      Array.isArray(batch.events) && batch.events.length > 0 && batch.events.length <= MAX_EVENT_BATCH,
      "Invalid event batch count"
    );
    let previous;
    for (const envelope of batch.events) {
      eventCounter(envelope.cursor);
      eventCounter(envelope.tick, true);
      integer(envelope.counter, 0, MAX_EVENT_HISTORY - 1, "event identity counter");
      eventRequire(envelope.tick <= batch.throughTick, "Event beyond committed boundary");
      if (previous)
        eventRequire(followsEvent(previous, envelope), "Noncontiguous event identities/cursors");
      validateGameplayEvent(envelope.event, context2);
      previous = envelope;
    }
  }
  function encodeEventBatch(batch, context2) {
    validateEventBatch(batch, context2);
    const length2 = EVENT_HEADER_BYTES + batch.events.length * EVENT_RECORD_BYTES;
    const w = new Writer(length2);
    w.u16(MAGIC);
    w.u8(PROTOCOL_MAJOR);
    w.u8(PROTOCOL_MINOR);
    w.u8(EVENT_TYPE);
    w.zero(1);
    w.u16(length2);
    w.u32(batch.runEpoch);
    w.u32(batch.connectionEpoch);
    w.u32(batch.throughTick);
    w.u32(batch.events[0]?.cursor ?? 0);
    w.u16(batch.events.length);
    w.u16(EVENT_RECORD_BYTES);
    w.zero(4);
    for (const { cursor, tick: tick2, counter: counter3, event } of batch.events) {
      w.u32(cursor);
      w.u32(tick2);
      w.u32(counter3);
      w.choice(EVENT_KINDS, event.kind);
      w.choice(EVENT_ORIGINS, event.origin);
      w.u32(event.ownerId);
      w.u32(event.actionInstanceId);
      w.u32(event.markerIndex);
      w.u32(event.definitionId);
      w.i32(event.x, MAX_POSITION);
      w.i32(event.y, MAX_POSITION);
      w.optionalId(event.targetId);
      w.choice(EVENT_MATERIALS, event.material);
      w.u32(event.confirmation?.playerId ?? 0);
      w.u32(event.confirmation?.controlEpoch ?? 0);
      w.u32(event.confirmation?.shotOrdinal ?? 0);
      w.u32(event.beam?.length ?? 0);
      w.u32(event.beam?.width ?? 0);
      w.u32(event.beam?.heading ?? 0);
    }
    eventRequire(w.offset === length2, "Event writer size mismatch");
    return w.bytes;
  }
  function decodeEventBatch(bytes, context2) {
    eventRequire(
      bytes.byteLength >= EVENT_HEADER_BYTES + EVENT_RECORD_BYTES && bytes.byteLength <= EVENT_HEADER_BYTES + MAX_EVENT_BATCH * EVENT_RECORD_BYTES,
      "Invalid event frame length"
    );
    const r = new Reader(bytes);
    eventRequire(
      r.u16() === MAGIC && r.u8() === PROTOCOL_MAJOR && r.u8() === PROTOCOL_MINOR && r.u8() === EVENT_TYPE,
      "Invalid event header"
    );
    r.zero(1);
    eventRequire(r.u16() === bytes.byteLength, "Event length mismatch");
    const batch = {
      runEpoch: r.u32(1),
      connectionEpoch: r.u32(1),
      throughTick: r.u32(),
      events: []
    };
    const firstCursor = r.u32(1), count = r.u16();
    eventRequire(
      count > 0 && count <= MAX_EVENT_BATCH && r.u16() === EVENT_RECORD_BYTES && bytes.byteLength === EVENT_HEADER_BYTES + count * EVENT_RECORD_BYTES,
      "Invalid event record layout"
    );
    r.zero(4);
    for (let index = 0; index < count; index++) {
      const cursor = r.u32(1), tick2 = r.u32(), counter3 = r.u32(0, MAX_EVENT_HISTORY - 1);
      const event = {
        kind: r.choice(EVENT_KINDS),
        origin: r.choice(EVENT_ORIGINS),
        ownerId: r.u32(1),
        actionInstanceId: r.u32(1),
        markerIndex: r.u32(0, MAX_EVENT_HISTORY - 1),
        definitionId: r.u32(1),
        x: r.i32(MAX_POSITION),
        y: r.i32(MAX_POSITION),
        targetId: r.u32() || null,
        material: r.choice(EVENT_MATERIALS),
        confirmation: null,
        beam: null
      };
      const playerId = r.u32(), controlEpoch = r.u32(), shotOrdinal = r.u32();
      eventRequire(
        Boolean(playerId) === Boolean(controlEpoch) && Boolean(playerId) === Boolean(shotOrdinal),
        "Partial confirmation identity"
      );
      if (playerId) event.confirmation = { playerId, controlEpoch, shotOrdinal };
      const length2 = r.u32(), width = r.u32(), heading = r.u32(0, 3);
      eventRequire(width !== 0 || length2 === 0 && heading === 0, "Partial beam geometry");
      if (width) event.beam = { length: length2, width, heading };
      batch.events.push({ cursor, tick: tick2, counter: counter3, event });
    }
    eventRequire(batch.events[0]?.cursor === firstCursor, "Event prefix mismatch");
    validateEventBatch(batch, context2);
    return batch;
  }
  function controlObject(raw, fields3) {
    eventRequire(new TextEncoder().encode(raw).byteLength <= 512, "Event control too large");
    const data = JSON.parse(raw);
    eventRequire(
      Boolean(data) && typeof data === "object" && !Array.isArray(data),
      "Invalid event control"
    );
    eventRequire(
      Object.keys(data).sort().join() === fields3.sort().join(),
      "Unexpected event control fields"
    );
    return data;
  }
  function decodeEventBaseline(raw, context2) {
    const data = controlObject(raw, [
      "type",
      "scope",
      "reason",
      "runEpoch",
      "connectionEpoch",
      "snapshotId",
      "tick",
      "baselineEventCursor"
    ]);
    identity(data, context2);
    eventCounter(data.snapshotId);
    eventCounter(data.tick, true);
    eventCounter(data.baselineEventCursor, true);
    eventRequire(
      data.type === "resync-required" && data.scope === "events" && ["history-expired", "client-gap"].includes(data.reason),
      "Invalid event baseline control"
    );
    return data;
  }

  // src/shared/session/room-phase.ts
  function isPausableRoom(mode) {
    return ["lobby", "loading", "playing", "intermission"].includes(mode);
  }

  // src/shared/diagnostics/combat-events.ts
  function combatEventContext(identity3) {
    return {
      ...identity3,
      attackIds: new Set(COMBAT_CONTENT.attacks.map((value) => value.id)),
      beamProfiles: /* @__PURE__ */ new Map([[LASER_ATTACK.id, LASER_PROFILE]]),
      soundIds: new Set(
        COMBAT_CONTENT.timelines.flatMap(
          (timeline) => timeline.markers.filter((marker) => marker.kind === "sound").map((marker) => marker.payloadId)
        )
      )
    };
  }
  function combatGameplayEvents(previous, next) {
    if (next.tick !== previous.tick + 1) throw new Error("Combat event boundary mismatch");
    return next.events.map((notice2) => {
      const event = {
        kind: notice2.kind,
        origin: previous.players.some((player2) => player2.playerId === notice2.ownerId) ? "player" : "enemy",
        ownerId: notice2.ownerId,
        actionInstanceId: notice2.actionInstanceId,
        markerIndex: notice2.markerIndex,
        definitionId: 0,
        x: notice2.position.x,
        y: notice2.position.y,
        targetId: notice2.targetId,
        material: notice2.impact?.kind ?? (notice2.kind === "muzzle-blocked" ? "terrain" : "none"),
        confirmation: null,
        beam: notice2.beam
      };
      if (notice2.impact) {
        if (notice2.impact.actionInstanceId !== notice2.actionInstanceId)
          throw new Error("Missing impact attack identity");
        event.definitionId = notice2.impact.definitionId;
      } else {
        const source3 = notice2.source;
        if (!source3) throw new Error("Missing firearm confirmation source");
        event.definitionId = source3.definitionId;
        if ("controlEpoch" in source3)
          event.confirmation = {
            playerId: notice2.ownerId,
            controlEpoch: source3.controlEpoch,
            shotOrdinal: source3.shotOrdinal
          };
      }
      return event;
    });
  }

  // src/shared/protocol/event-stream.ts
  function createEventHistory(runEpoch) {
    eventCounter(runEpoch);
    return { runEpoch, tick: 0, cursor: 0, entries: [], capEvictions: 0, ageEvictions: 0 };
  }
  function stageEventTick(current, tick2, events, context2) {
    eventCounter(tick2);
    eventRequire(
      tick2 === current.tick + 1 && current.runEpoch === context2.runEpoch,
      "Event history boundary mismatch"
    );
    eventRequire(
      events.length <= MAX_EVENT_HISTORY,
      "Event tick exceeds the retained stream capacity"
    );
    for (const event of events) validateGameplayEvent(event, context2);
    const entries = current.entries.filter((item) => item.tick > tick2 - EVENT_HISTORY_TICKS);
    const ageEvictions = current.ageEvictions + current.entries.length - entries.length;
    let cursor = current.cursor;
    for (const [counter3, event] of events.entries()) {
      cursor = nextCounter(cursor);
      entries.push({ cursor, tick: tick2, counter: counter3, event: structuredClone(event) });
    }
    const overflow = Math.max(0, entries.length - MAX_EVENT_HISTORY);
    return {
      runEpoch: current.runEpoch,
      tick: tick2,
      cursor,
      entries: entries.slice(overflow),
      ageEvictions,
      capEvictions: current.capEvictions + overflow
    };
  }
  function eventBatches(history, acknowledged, connectionEpoch) {
    eventCounter(acknowledged, true);
    eventCounter(connectionEpoch);
    eventRequire(acknowledged <= history.cursor, "Event acknowledgment beyond world cursor");
    const oldest = history.entries[0]?.cursor ?? history.cursor + 1;
    if (acknowledged < oldest - 1) return null;
    const entries = history.entries.filter((item) => item.cursor > acknowledged);
    const batches = [];
    for (let offset = 0; offset < entries.length; offset += MAX_EVENT_BATCH)
      batches.push({
        runEpoch: history.runEpoch,
        connectionEpoch,
        throughTick: history.tick,
        events: structuredClone(entries.slice(offset, offset + MAX_EVENT_BATCH))
      });
    return batches;
  }
  function acceptsEventBaseline(pending, snapshotAck, eventAck, previouslySentCursor) {
    if (!pending) return false;
    eventCounter(snapshotAck, true);
    eventCounter(eventAck, true);
    if (snapshotAck < pending.snapshotId && eventAck <= previouslySentCursor) return false;
    eventRequire(
      snapshotAck === pending.snapshotId && eventAck === pending.baselineEventCursor,
      "Event baseline acknowledgment must accept its exact snapshot and cursor together"
    );
    return true;
  }
  var EventReceiver = class {
    constructor(context2, baseline) {
      this.context = context2;
      this.validateBoundary(baseline);
      this.cursorValue = this.floor = baseline.baselineEventCursor;
      this.floorTick = baseline.tick;
      this.snapshotId = baseline.snapshotId;
    }
    context;
    fingerprints = /* @__PURE__ */ new Map();
    cursorValue;
    floor;
    floorTick;
    last = null;
    stopped = false;
    snapshotId;
    consumed = 0;
    duplicateCount = 0;
    resetCount = 0;
    omitted = 0;
    get cursor() {
      return this.cursorValue;
    }
    get requiresBaseline() {
      return this.stopped;
    }
    get status() {
      return {
        cursor: this.cursorValue,
        baselineCursor: this.floor,
        baselineTick: this.floorTick,
        consumed: this.consumed,
        duplicates: this.duplicateCount,
        baselines: this.resetCount,
        omittedByBaseline: this.omitted,
        requiresBaseline: this.stopped
      };
    }
    validateBoundary(snapshot) {
      eventCounter(snapshot.snapshotId);
      eventCounter(snapshot.tick, true);
      eventCounter(snapshot.baselineEventCursor, true);
      if (snapshot.runEpoch !== this.context.runEpoch || snapshot.connectionEpoch !== this.context.connectionEpoch)
        throw new ProtocolError("identity-mismatch", "Event baseline session mismatch");
    }
    installBaseline(snapshot, promise) {
      this.validateBoundary(snapshot);
      eventRequire(
        promise.runEpoch === snapshot.runEpoch && promise.connectionEpoch === snapshot.connectionEpoch && promise.snapshotId === snapshot.snapshotId && promise.tick === snapshot.tick && promise.baselineEventCursor === snapshot.baselineEventCursor,
        "Event baseline does not match its promised full snapshot"
      );
      eventRequire(
        snapshot.snapshotId > this.snapshotId && snapshot.baselineEventCursor >= this.cursorValue && snapshot.tick >= (this.last?.tick ?? this.floorTick),
        "Event baseline regressed"
      );
      this.omitted += snapshot.baselineEventCursor - this.cursorValue;
      this.cursorValue = this.floor = snapshot.baselineEventCursor;
      this.floorTick = snapshot.tick;
      this.snapshotId = snapshot.snapshotId;
      this.last = null;
      this.fingerprints.clear();
      this.stopped = false;
      this.resetCount++;
    }
    consume(batch) {
      if (this.stopped) throw new ProtocolError("resync-required", "Event baseline required");
      try {
        validateEventBatch(batch, this.context);
        const fresh = [];
        let cursor = this.cursorValue, last = this.last, duplicates = 0;
        for (const item of batch.events) {
          if (item.cursor <= this.floor) {
            duplicates++;
            continue;
          }
          if (item.cursor <= cursor) {
            if (this.fingerprints.get(item.cursor) !== canonical(item))
              throw new ProtocolError("resync-required", "Changed or expired duplicate event");
            duplicates++;
            continue;
          }
          if (item.cursor !== cursor + 1 || (last ? !followsEvent(last, item) : item.tick <= this.floorTick || item.counter !== 0))
            throw new ProtocolError("resync-required", "Missing contiguous event prefix");
          fresh.push(structuredClone(item));
          cursor = item.cursor;
          last = item;
        }
        for (const item of fresh) this.fingerprints.set(item.cursor, canonical(item));
        while (this.fingerprints.size > MAX_EVENT_HISTORY) {
          const first = this.fingerprints.keys().next().value;
          if (first !== void 0) this.fingerprints.delete(first);
        }
        this.cursorValue = cursor;
        this.last = last ? structuredClone(last) : null;
        this.consumed += fresh.length;
        this.duplicateCount += duplicates;
        return fresh;
      } catch (error) {
        this.stopped = true;
        throw error;
      }
    }
  };

  // src/shared/diagnostics/room-workload.ts
  var PROBE_IDENTITY = {
    simulationVersion: 1,
    simulationBuild: "1".repeat(64),
    contentFormat: 1,
    contentHash: "2".repeat(64),
    presentationBuild: "3".repeat(64)
  };
  var PROBE_SHAPES = /* @__PURE__ */ new Set([1, 2, 3, 4]);
  function probeContext(slot) {
    return {
      runEpoch: 1,
      connectionEpoch: slot + 1,
      playerId: slot + 1,
      geometryRevision: 1,
      shapeIds: PROBE_SHAPES
    };
  }
  function body(id2, shapeId) {
    return {
      id: id2,
      x: id2 % 300 * 256,
      y: 180 * 256,
      vx: 0,
      vy: 0,
      remainderX: 0,
      remainderY: 0,
      shapeId,
      supportId: 1e4,
      grounded: true,
      contacts: [
        {
          otherId: 1e4,
          normalX: 0,
          normalY: -1,
          toiNumerator: 0,
          toiDenominator: 1,
          kind: "solid"
        }
      ]
    };
  }
  function action() {
    return {
      kind: "ready",
      actionInstanceId: 0,
      stateStartTick: 0,
      definitionId: 0,
      nextMarkerIndex: 0
    };
  }
  function weapon() {
    return {
      id: "sidearm",
      ammo: 0,
      cooldownTicks: 0,
      shotOrdinal: 0,
      lastActionInstanceId: 0
    };
  }
  function probeAck(slot) {
    return {
      playerId: slot + 1,
      connectionEpoch: slot + 1,
      controlEpoch: 1,
      lastProcessedSequence: 0,
      appliedAtServerTick: 0,
      processedEdgeIds: [0, 0, 0, 0, 0]
    };
  }
  function player(slot) {
    return {
      body: body(slot + 1, 1),
      playerId: slot + 1,
      slot,
      controlEpoch: 1,
      life: "alive",
      locomotion: "grounded",
      action: action(),
      facing: 1,
      aim: 0,
      jumpBufferTicks: 0,
      coyoteTicks: 0,
      ignoredSupportId: null,
      ignoredSupportTicks: 0,
      invulnerableTicks: 0,
      reboardCooldownTicks: 0,
      vehicleSpecialTicks: 0,
      vehicleId: null,
      weapon: weapon(),
      firearmAim: { pitch: 0, nextStepTick: 0 },
      grenadeStock: 5,
      grenadeCooldownTicks: 0,
      meleeCooldownTicks: 0,
      geometryRevision: 1,
      health: 1,
      lives: 3,
      lastRallyMission: 1,
      lifeStartTick: 0,
      bodyPresence: "present",
      processedEdgeIds: [0, 0, 0, 0, 0]
    };
  }
  function createRoomWorkload(multiplier) {
    if (multiplier !== 1 && multiplier !== 2) throw new RangeError("Unknown diagnostic workload");
    return {
      runEpoch: 1,
      connectionEpoch: 1,
      snapshotId: 1,
      tick: 0,
      baselineEventCursor: 0,
      geometryRevision: 1,
      stateHash: 0,
      roomMode: "loading",
      combat: null,
      camera: { x: 0, y: 0 },
      campaign: {
        ruleset: "classic",
        mission: 1,
        checkpointId: 1,
        continuesRemaining: 3,
        continuesUsed: 0,
        phase: "playing",
        encounterId: 1,
        remainingEnemies: 32 * multiplier
      },
      players: Array.from({ length: 4 }, (_, slot) => player(slot)),
      acknowledgments: Array.from({ length: 4 }, (_, slot) => probeAck(slot)),
      vehicles: Array.from({ length: 4 * multiplier }, (_, index) => ({
        body: body(100 + index, 2),
        definitionId: 1,
        kind: "tank",
        lifecycle: "available",
        occupantId: null,
        reservedBy: null,
        controlEpoch: 1,
        ownerControlEpoch: null,
        facing: 1,
        heading: 0,
        invulnerableTicks: 0,
        armor: 100,
        action: action(),
        components: [{ id: 1, health: 100, broken: false }],
        weapon: weapon()
      })),
      enemies: Array.from({ length: 32 * multiplier }, (_, index) => ({
        id: 200 + index,
        definitionId: 1,
        x: index * 256,
        y: 180 * 256,
        vx: index % 2 ? 128 : -128,
        vy: 0,
        shapeId: 1,
        facing: 1,
        health: 3,
        mode: 0,
        stateStartTick: 0,
        actionInstanceId: 0,
        actionDefinitionId: 0,
        modeTicks: 0,
        supportId: 1e4,
        geometryRevision: 1
      })),
      projectiles: Array.from({ length: 96 * multiplier }, (_, index) => ({
        id: 400 + index,
        ownerId: 1,
        actionInstanceId: index + 1,
        definitionId: 1,
        x: index * 256,
        y: 100 * 256,
        vx: 1024,
        vy: 0,
        spawnTick: 0,
        lifetimeTicks: 65535,
        heading: 0,
        shapeId: 3
      })),
      platforms: Array.from({ length: 16 * multiplier }, (_, index) => ({
        id: 800 + index,
        x: index * 256,
        y: 100 * 256,
        vx: 64,
        vy: 0,
        shapeId: 4,
        trajectoryId: 1,
        trajectoryTick: 0
      })),
      threats: Array.from({ length: 24 * multiplier }, (_, index) => ({
        actionInstanceId: 1e3 + index,
        sourceId: 200 + index,
        definitionId: 1,
        telegraphTick: 0,
        activeTick: 30,
        endTick: 65535,
        x: index * 256,
        y: 100 * 256,
        vx: 0,
        vy: 0,
        heading: 0,
        targetId: index % 4 + 1,
        motion: "linear",
        cancelled: false,
        stateVersion: 1,
        shapeId: 3
      })),
      removedIds: []
    };
  }
  function roomWorkloadHash(world) {
    const { connectionEpoch: _connection, snapshotId: _snapshot, stateHash: _hash, ...state } = world;
    return Number.parseInt(stateHash(state), 16);
  }

  // src/shared/diagnostics/controller-recovery.ts
  function renewControllerGenerations(current) {
    if (current.players.some((actor) => actor.vehicleId !== null) || current.vehicles.some(
      (vehicle) => vehicle.occupantId !== null || vehicle.reservedBy !== null || vehicle.ownerControlEpoch !== null
    ))
      throw new Error("Controller generations require settled vehicle ownership");
    const next = structuredClone(current);
    next.runEpoch = nextCounter(current.runEpoch);
    next.roomMode = "loading";
    for (const actor of next.players) {
      const ack = next.acknowledgments.find((value) => value.playerId === actor.playerId);
      if (!ack) throw new Error("Missing recovery acknowledgment");
      actor.controlEpoch = nextCounter(actor.controlEpoch);
      actor.jumpBufferTicks = 0;
      actor.processedEdgeIds = [0, 0, 0, 0, 0];
      ack.connectionEpoch = nextCounter(ack.connectionEpoch);
      ack.controlEpoch = actor.controlEpoch;
      ack.lastProcessedSequence = 0;
      ack.appliedAtServerTick = 0;
      ack.processedEdgeIds = [0, 0, 0, 0, 0];
    }
    next.stateHash = roomWorkloadHash(next);
    return next;
  }
  function controllerPeerContext(world, slot) {
    const actor = world.players.find((value) => value.slot === slot);
    const ack = world.acknowledgments.find((value) => value.playerId === actor?.playerId);
    if (!actor || !ack) throw new Error("Missing controller session");
    return {
      ...probeContext(slot),
      runEpoch: world.runEpoch,
      connectionEpoch: ack.connectionEpoch,
      playerId: actor.playerId,
      geometryRevision: world.geometryRevision
    };
  }

  // src/shared/diagnostics/combat-workload.ts
  var COMBAT_TERRAIN = combatTerrain("range");
  var COMBAT_SHAPE_IDS = new Set(COMBAT_SHAPES.keys());
  function combatPeerContext(world, slot) {
    return {
      ...controllerPeerContext(world, slot),
      shapeIds: COMBAT_SHAPE_IDS,
      ...combatGeometryContext()
    };
  }
  function combatGeometryContext() {
    return {
      geometryRevisions: /* @__PURE__ */ new Set([1, 2]),
      validateGeometry: (snapshot) => {
        const combat = snapshot.combat;
        if (!combat) throw new Error("Missing combat geometry baseline");
        validateDestructibles(
          combat.props,
          combat.props.length ? COMBAT_SUPPORT : [],
          snapshot.tick,
          [...snapshot.players.map((p) => p.playerId), ...combat.members.map((m) => m.id)],
          combat.nextActionId
        );
        if (snapshot.geometryRevision !== combatGeometryRevision(combat.props))
          throw new Error("Destructible geometry revision mismatch");
      }
    };
  }
  async function combatIdentity() {
    const bytes = new TextEncoder().encode(
      canonical({
        content: COMBAT_CONTENT,
        campaignFormat: 2,
        rifle: RIFLE_PROFILE,
        shield: SHIELD_PROFILE,
        areas: [...AREA_PROFILES],
        footActions: FOOT_ACTION_PROFILES,
        grenade: GRENADE_PROFILE,
        rocket: ROCKET_PROFILE,
        tank: TANK_PROFILE,
        tankDepot: COMBAT_TANK_DEPOT,
        ordnance: COMBAT_ORDNANCE,
        laser: LASER_PROFILE,
        support: COMBAT_SUPPORT,
        life: {
          rules: RULE_PRESETS,
          deathTicks: ARCADE.deathTicks,
          entryTicks: ARCADE.respawnEntryTicks,
          protectionTicks: ARCADE.respawnProtectionTicks,
          checkpoint: COMBAT_ENTRY
        },
        profiles: [...COMBAT_CATALOG.firearms].map(([id2, profile]) => ({
          id: id2,
          timelineIds: profile.timelineIds,
          sweep: profile.sweep ?? null
        }))
      })
    );
    const digest2 = await crypto.subtle.digest("SHA-256", bytes);
    return {
      ...PROBE_IDENTITY,
      contentHash: Array.from(
        new Uint8Array(digest2),
        (byte) => byte.toString(16).padStart(2, "0")
      ).join("")
    };
  }
  function projectCombatCampaign(snapshot, campaign) {
    const { ruleset, mission, checkpointId, continuesRemaining, continuesUsed, phase, encounterId } = campaign.state;
    Object.assign(snapshot.campaign, {
      ruleset,
      mission,
      checkpointId,
      continuesRemaining,
      continuesUsed,
      phase,
      encounterId
    });
  }
  function combatSnapshot(combat, previous = createRoomWorkload(1), campaign) {
    const snapshot = structuredClone(previous);
    snapshot.tick = combat.tick;
    snapshot.geometryRevision = combatGeometryRevision(combat.props);
    snapshot.players = structuredClone(combat.players);
    snapshot.vehicles = combat.tanks.map(publicTankState);
    snapshot.platforms = combat.scenario === "ordnance" ? ordnancePlatforms(combat.tick) : [];
    snapshot.threats = combat.targets.flatMap(({ enemy, health, rifle }) => {
      if (!rifle || health === 0 || rifle.action.kind !== "fire" || combat.tick - rifle.action.stateStartTick > RIFLE_PROFILE.lastReleaseTick)
        return [];
      const pose = actionPose(
        COMBAT_CATALOG,
        rifle.action.definitionId,
        combat.tick - rifle.action.stateStartTick
      );
      const socket = pose?.sockets.find((socket2) => socket2.name === "muzzle");
      const attack2 = COMBAT_CONTENT.attacks.find((attack3) => attack3.id === 3);
      if (!socket || !attack2) throw new Error("Missing rifle threat content");
      const point3 = worldSocket(enemy.body, socket.point, enemy.facing);
      return [
        {
          actionInstanceId: rifle.action.actionInstanceId,
          sourceId: enemy.body.id,
          definitionId: attack2.id,
          telegraphTick: rifle.action.stateStartTick,
          activeTick: rifle.action.stateStartTick + RIFLE_PROFILE.raiseTicks,
          endTick: rifle.action.stateStartTick + RIFLE_PROFILE.lastReleaseTick,
          x: point3.x,
          y: point3.y,
          vx: rifle.aim === 0 ? attack2.speed * enemy.facing : 0,
          vy: rifle.aim === 1 ? -attack2.speed : 0,
          heading: rifle.aim === 1 ? 1 : enemy.facing === -1 ? 3 : 0,
          targetId: rifle.targetId,
          motion: "locked",
          cancelled: false,
          stateVersion: 1,
          shapeId: attack2.shapeId
        }
      ];
    });
    for (const player2 of combat.players) {
      if (player2.life !== "alive" || player2.action.kind !== "melee") continue;
      const marker = COMBAT_CATALOG.timelines.get(player2.action.definitionId)?.markers.find((marker2) => marker2.kind === "activate-hitbox");
      const definition3 = marker && COMBAT_CONTENT.attacks.find((attack2) => attack2.id === marker.payloadId);
      if (!marker || !definition3) throw new Error("Missing melee threat window");
      const activeTick = player2.action.stateStartTick + marker.tickOffset;
      const endTick = activeTick + definition3.lifetimeTicks;
      if (combat.tick >= endTick) continue;
      const pose = actionPose(
        COMBAT_CATALOG,
        player2.action.definitionId,
        combat.tick - player2.action.stateStartTick
      );
      const socket = pose?.sockets.find((socket2) => socket2.name === "hand");
      if (!socket) throw new Error("Missing melee threat socket");
      const hand = worldSocket(player2.body, socket.point, player2.facing);
      snapshot.threats.push({
        actionInstanceId: player2.action.actionInstanceId,
        sourceId: player2.playerId,
        definitionId: 4,
        telegraphTick: player2.action.stateStartTick,
        activeTick,
        endTick,
        x: hand.x,
        y: hand.y,
        vx: 0,
        vy: 0,
        heading: player2.facing === 1 ? 0 : 3,
        targetId: null,
        motion: "authored",
        cancelled: false,
        stateVersion: 1,
        shapeId: 9
      });
    }
    for (const target of combat.targets) {
      const guard = target.guard;
      if (!guard || target.health === 0 || guard.phase !== "bash" || combat.tick - guard.action.stateStartTick >= SHIELD_PROFILE.bashActiveTick + SHIELD_PROFILE.bashActiveTicks)
        continue;
      const pose = actionPose(
        COMBAT_CATALOG,
        guard.action.definitionId,
        combat.tick - guard.action.stateStartTick
      );
      const socket = pose?.sockets.find((socket2) => socket2.name === "hand");
      if (!socket) throw new Error("Missing bash telegraph socket");
      const point3 = worldSocket(target.enemy.body, socket.point, guard.facing);
      snapshot.threats.push({
        actionInstanceId: guard.action.actionInstanceId,
        sourceId: target.enemy.body.id,
        definitionId: 6,
        telegraphTick: guard.action.stateStartTick,
        activeTick: guard.action.stateStartTick + SHIELD_PROFILE.bashActiveTick,
        endTick: guard.action.stateStartTick + SHIELD_PROFILE.bashActiveTick + SHIELD_PROFILE.bashActiveTicks,
        ...point3,
        vx: 0,
        vy: 0,
        heading: guard.facing === 1 ? 0 : 3,
        targetId: guard.targetId,
        motion: "authored",
        cancelled: false,
        stateVersion: 1,
        shapeId: 12
      });
    }
    snapshot.threats.sort((a, b) => a.actionInstanceId - b.actionInstanceId);
    snapshot.enemies = combat.targets.filter((target) => target.health > 0).map(({ enemy, health, shield, rifle, guard }) => ({
      id: enemy.body.id,
      definitionId: guard ? 4 : rifle ? 3 : shield ? 2 : 1,
      x: enemy.body.x,
      y: enemy.body.y,
      vx: enemy.body.vx,
      vy: enemy.body.vy,
      shapeId: enemy.body.shapeId,
      facing: enemy.facing,
      health,
      mode: guard ? shieldMode(guard) : rifle ? rifleMode(rifle, combat.tick, RIFLE_PROFILE) : 0,
      stateStartTick: guard?.action.stateStartTick ?? rifle?.action.stateStartTick ?? 0,
      actionInstanceId: guard?.action.actionInstanceId ?? (rifle?.action.kind === "fire" ? rifle.action.actionInstanceId : 0),
      actionDefinitionId: guard?.action.definitionId ?? (rifle?.action.kind === "fire" ? rifle.action.definitionId : 0),
      modeTicks: guard?.action.actionInstanceId ? combat.tick - guard.action.stateStartTick : rifle?.action.kind === "fire" ? combat.tick - rifle.action.stateStartTick : 0,
      supportId: enemy.body.supportId,
      geometryRevision: snapshot.geometryRevision
    }));
    snapshot.projectiles = combat.projectiles.map((projectile) => ({
      id: projectile.id,
      ownerId: projectile.ownerId,
      actionInstanceId: projectile.actionInstanceId,
      definitionId: projectile.definitionId,
      x: projectile.position.x,
      y: projectile.position.y,
      vx: projectile.velocity.x,
      vy: projectile.velocity.y,
      spawnTick: projectile.spawnTick,
      lifetimeTicks: COMBAT_CONTENT.attacks.find((attack2) => attack2.id === projectile.definitionId)?.lifetimeTicks ?? 0,
      heading: projectile.definitionId === TANK_PROFILE.attackId ? TANK_PROFILE.headings.findIndex(
        ({ velocity: velocity2 }) => velocity2.x === projectile.velocity.x && velocity2.y === projectile.velocity.y
      ) : projectile.velocity.y < 0 ? 1 : projectile.velocity.y > 0 ? 2 : projectile.velocity.x < 0 ? 3 : 0,
      shapeId: 4
    }));
    for (const grenade of combat.grenades)
      snapshot.projectiles.push({
        id: grenade.id,
        ownerId: grenade.ownerId,
        actionInstanceId: grenade.actionInstanceId,
        definitionId: grenade.definitionId,
        x: grenade.body.x,
        y: grenade.body.y,
        vx: grenade.body.vx,
        vy: grenade.body.vy,
        spawnTick: grenade.spawnTick,
        lifetimeTicks: GRENADE_PROFILE.fuseTicks,
        heading: grenade.body.vy < 0 ? 1 : grenade.body.vy > 0 ? 2 : grenade.body.vx < 0 ? 3 : 0,
        shapeId: grenade.body.shapeId
      });
    for (const rocket2 of combat.rockets)
      snapshot.projectiles.push({
        id: rocket2.id,
        ownerId: rocket2.ownerId,
        actionInstanceId: rocket2.actionInstanceId,
        definitionId: rocket2.definitionId,
        x: rocket2.position.x,
        y: rocket2.position.y,
        vx: rocket2.velocity.x,
        vy: rocket2.velocity.y,
        spawnTick: rocket2.spawnTick,
        lifetimeTicks: ROCKET_PROFILE.lifetimeTicks,
        heading: rocket2.heading,
        shapeId: ROCKET_PROFILE.bodyShapeId
      });
    snapshot.projectiles.sort((a, b) => a.id - b.id);
    snapshot.removedIds = combat.targets.filter((target) => target.health === 0).map((target) => target.enemy.body.id).concat(combat.props.filter((prop) => prop.health === 0).map((prop) => prop.id)).sort((a, b) => a - b);
    snapshot.campaign.remainingEnemies = combat.targets.filter((target) => target.health > 0).length;
    snapshot.campaign.encounterId = 1;
    const definition2 = combatEncounterDefinition(combat);
    snapshot.combat = {
      props: structuredClone(combat.props),
      volumes: combat.areas.flatMap((area) => {
        const profile = AREA_PROFILES.get(area.definitionId);
        if (!profile) throw new Error("Missing area snapshot profile");
        return areaExposures(
          area,
          combat.tick,
          profile,
          combatTerrain(combat.scenario, combat.tick, combat.props)
        );
      }).concat(combat.beams.flatMap((beam) => beamExposures(beam, LASER_PROFILE))).sort((a, b) => a.id - b.id || a.lobe - b.lobe),
      nextEntityId: combat.nextEntityId,
      nextActionId: combat.nextActionId,
      encounterEventCursor: combat.eventSequence,
      encounterId: definition2.id,
      phase: combat.encounter.phase,
      members: combat.encounter.members.map((member, index) => {
        const policy = definition2.members[index];
        if (!policy || policy.id !== member.id) throw new Error("Combat roster mismatch");
        return {
          id: member.id,
          required: policy.required,
          critical: policy.critical,
          retreatAllowed: policy.retreatAllowed,
          status: member.status,
          activatedTick: member.activatedTick,
          resolvedTick: member.resolvedTick,
          reason: member.reason,
          killerId: member.killerId
        };
      }),
      objectives: structuredClone(combat.encounter.objectives),
      kills: structuredClone(combat.encounter.kills),
      failure: structuredClone(combat.encounter.failure)
    };
    if (campaign) projectCombatCampaign(snapshot, campaign);
    snapshot.stateHash = roomWorkloadHash(snapshot);
    return snapshot;
  }
  function createCombatWorkload(scenario = "range") {
    const combat = createCombatLab(scenario, 4);
    return { combat, snapshot: combatSnapshot(combat) };
  }
  function evaluateCombatTick(current, previous, prepared, releasePlayerIds = []) {
    if (current.tick !== previous.tick) throw new Error("Combat/snapshot boundary mismatch");
    const commands = current.players.map((actor) => {
      const item = prepared.find(({ input }) => input.playerId === actor.playerId);
      if (item && item.input.serverTick !== current.tick + 1)
        throw new Error("Combat input tick mismatch");
      return {
        held: item?.input.command.held ?? 0,
        jumpPressed: item?.input.command.edges.some((edge) => edge.kind === Edge.Jump) ?? false,
        firePressed: item?.input.command.edges.some((edge) => edge.kind === Edge.FireOnset) ?? false,
        grenadePressed: item?.input.command.edges.some((edge) => edge.kind === Edge.Grenade) ?? false,
        interactPressed: item?.input.command.edges.some((edge) => edge.kind === Edge.Interact) ?? false
      };
    });
    const result = advanceCombatLab(current, commands, {
      connectedPlayerIds: prepared.map((item) => item.input.playerId),
      releasePlayerIds
    });
    const outcomes = prepared.map((item) => {
      const actor = result.state.players.find((player2) => player2.playerId === item.input.playerId);
      const outcome = result.outcomes.find((value) => value.playerId === item.input.playerId);
      if (!actor || !outcome) throw new Error("Unknown combat input owner");
      actor.processedEdgeIds = [...item.acknowledgment.processedEdgeIds];
      let jump = false, grenade = false, fire = false, interact = false;
      return {
        playerId: actor.playerId,
        ...actor.controlEpoch !== item.acknowledgment.controlEpoch ? { controlEpoch: actor.controlEpoch } : {},
        edgeResults: item.input.command.edges.map((edge) => {
          let accepted = "unavailable";
          if (edge.kind === Edge.Jump && !jump) {
            accepted = outcome.jumpAccepted ? "applied" : "unavailable";
            jump = true;
          }
          if (edge.kind === Edge.Grenade && !grenade) {
            accepted = outcome.grenade === "none" ? "unavailable" : outcome.grenade;
            grenade = true;
          } else if (edge.kind === Edge.Grenade) accepted = "cooldown";
          if (edge.kind === Edge.FireOnset && !fire) {
            accepted = outcome.fire === "none" ? "unavailable" : outcome.fire;
            fire = true;
          } else if (edge.kind === Edge.FireOnset) accepted = "cooldown";
          if (edge.kind === Edge.Interact && !interact) {
            accepted = outcome.interact === "none" ? "unavailable" : outcome.interact;
            interact = true;
          } else if (edge.kind === Edge.Interact) accepted = "cooldown";
          return { ...edge, outcome: accepted };
        })
      };
    });
    const snapshot = combatSnapshot(result.state, previous);
    for (const item of prepared) {
      const index = snapshot.acknowledgments.findIndex((ack) => ack.playerId === item.input.playerId);
      if (index < 0) throw new Error("Missing combat acknowledgment");
      snapshot.acknowledgments[index] = structuredClone(item.acknowledgment);
    }
    for (const ack of snapshot.acknowledgments) {
      const actor = result.state.players.find((player2) => player2.playerId === ack.playerId);
      if (!actor) throw new Error("Missing combat ownership acknowledgment");
      ack.controlEpoch = actor.controlEpoch;
    }
    snapshot.stateHash = roomWorkloadHash(snapshot);
    return { state: { combat: result.state, snapshot }, outcomes, seatEvents: result.seatEvents };
  }
  function predictCombatMovement(actor, command2, tick2, scenario = "range", props = []) {
    if (!FOOT_DEFINITION) throw new Error("Missing combat foot definition");
    const frame = { tick: tick2, geometryRevision: combatGeometryRevision(props) };
    const index = combatCollisionIndex(scenario, frame, props);
    const life = stepPlayerLife(
      actor,
      tick2,
      "classic",
      combatEntryContext(actor, index, frame, scenario)
    );
    const result = stepFootController(
      life.actor,
      { held: command2.held, jumpPressed: command2.edges.some((edge) => edge.kind === Edge.Jump) },
      FOOT_DEFINITION,
      COMBAT_SHAPES,
      index,
      frame
    );
    if (result.status === "failed") {
      if (result.physics.reason === "crushed")
        return damagePlayer(life.actor, tick2, 1, "classic", "crush").actor;
      throw new Error(`Combat prediction: ${result.physics.reason}`);
    }
    result.actor.firearmAim = advanceFirearmAim(result.actor, tick2, COMBAT_CATALOG);
    return result.actor.life === "alive" && result.actor.body.y > COMBAT_ENTRY.fallBoundary ? damagePlayer(result.actor, tick2, 1, "classic", "fall").actor : result.actor;
  }

  // src/shared/diagnostics/combat-runtime.ts
  function createCombatRuntime(scenario = "range") {
    const state = createCombatWorkload(scenario);
    const campaign = createCombatCampaign(state.combat);
    projectCombatCampaign(state.snapshot, campaign);
    state.snapshot.roomMode = "playing";
    state.snapshot.stateHash = roomWorkloadHash(state.snapshot);
    return {
      ...state,
      history: createEventHistory(state.snapshot.runEpoch),
      connectedPlayerIds: state.combat.players.map((p) => p.playerId),
      pausedFrom: null,
      campaign
    };
  }
  function combatRuntimeHash(state) {
    const {
      connectionEpoch: _connection,
      snapshotId: _snapshot,
      stateHash: _hash,
      ...snapshot
    } = state.snapshot;
    return stateHash({
      combat: state.combat,
      snapshot,
      history: state.history,
      connectedPlayerIds: state.connectedPlayerIds,
      pausedFrom: state.pausedFrom,
      campaign: state.campaign
    });
  }
  function check8(ok, message) {
    if (!ok) throw new Error(`Combat journal: ${message}`);
  }
  function command(value, allowZero) {
    integer(value.sequence, allowZero ? 0 : 1, COUNTER_LIMIT - 1, "journal command sequence");
    integer(value.clientTick, 0, COUNTER_LIMIT - 1, "journal client tick");
    integer(value.controlEpoch, 1, COUNTER_LIMIT - 1, "journal control epoch");
    integer(value.held, 0, HELD_MASK, "journal held mask");
    integer(value.aim, 0, 2, "journal aim");
    integer(value.edges.length, 0, 8, "journal edge count");
    let kind = 0, id2 = 0;
    for (const edge of value.edges) {
      check8(
        EDGE_KINDS.includes(edge.kind) && (edge.kind > kind || edge.kind === kind && edge.id > id2),
        "edge order"
      );
      integer(edge.id, 1, COUNTER_LIMIT - 1, "journal edge ID");
      kind = edge.kind;
      id2 = edge.id;
    }
  }
  function validatePrepared(current, prepared) {
    integer(prepared.length, 0, 4, "journal owner count");
    let previousId = 0;
    for (const item of prepared) {
      const { input, acknowledgment } = item;
      const previous = current.snapshot.acknowledgments.find((a) => a.playerId === input.playerId);
      check8(previous && input.playerId > previousId, "unknown/duplicate/unordered input owner");
      previousId = input.playerId;
      check8(input.serverTick === current.combat.tick + 1, "nonconsecutive applied input");
      check8(["applied", "stale", "old-control"].includes(input.outcome), "input admission outcome");
      check8(
        typeof item.neutralized === "boolean" && (!item.neutralized || input.outcome === "stale"),
        "neutralization decision"
      );
      check8(input.repeatedHeld === (input.submittedCommand === null), "held-repeat decision");
      command(input.command, input.submittedCommand === null);
      check8(!input.repeatedHeld || input.command.edges.length === 0, "repeated action edge");
      check8(
        input.outcome === "applied" || input.command.held === 0 && input.command.aim === 0 && input.command.edges.length === 0,
        "rejected input not neutral"
      );
      if (input.outcome === "applied")
        check8(input.command.controlEpoch === previous.controlEpoch, "applied old control");
      const expected = structuredClone(previous);
      if (input.submittedCommand !== null) {
        const submitted = input.submittedCommand;
        command(submitted, false);
        check8(submitted.sequence > previous.lastProcessedSequence, "sequence reuse");
        check8(
          input.outcome === "old-control" ? submitted.controlEpoch !== previous.controlEpoch : submitted.controlEpoch === previous.controlEpoch,
          "control rejection mismatch"
        );
        const normalized = structuredClone(submitted);
        if (input.outcome !== "applied") {
          normalized.held = 0;
          normalized.aim = 0;
          normalized.edges = [];
        }
        check8(canonical(input.command) === canonical(normalized), "submitted/applied mismatch");
        expected.lastProcessedSequence = submitted.sequence;
        expected.appliedAtServerTick = input.serverTick;
        for (const edge of submitted.edges) {
          check8(edge.id > (expected.processedEdgeIds[edge.kind - 1] ?? 0), "edge cursor reuse");
          expected.processedEdgeIds[edge.kind - 1] = edge.id;
        }
      }
      check8(canonical(expected) === canonical(acknowledgment), "acknowledgment continuation");
    }
  }
  function stageCombatRuntime(current, prepared, connections = []) {
    check8(
      current.snapshot.roomMode === "playing" && current.pausedFrom === null,
      "combat requires playing phase"
    );
    integer(connections.length, 0, 4, "combat connection changes");
    const baseline = connections.length ? structuredClone(current) : current;
    let previousConnectionPlayer = 0;
    for (const connection of connections) {
      const actor = baseline.combat.players.find((p) => p.playerId === connection.playerId);
      const ack = baseline.snapshot.acknowledgments.find((a) => a.playerId === connection.playerId);
      const input = prepared.find((p) => p.input.playerId === connection.playerId);
      check8(
        actor && ack && input && connection.playerId > previousConnectionPlayer,
        "connection owner/order"
      );
      integer(connection.connectionEpoch, 1, COUNTER_LIMIT - 1, "connection epoch");
      check8(
        connection.connectionEpoch === ack.connectionEpoch + 1,
        "connection generation must advance once"
      );
      check8(input.input.submittedCommand === null, "new connection must begin with a fresh baseline");
      const fresh = input.input.command;
      check8(
        fresh.sequence === 0 && fresh.clientTick === 0 && fresh.held === 0 && fresh.aim === 0 && fresh.edges.length === 0,
        "new connection must discard prior intent"
      );
      previousConnectionPlayer = connection.playerId;
      actor.jumpBufferTicks = 0;
      actor.processedEdgeIds = [0, 0, 0, 0, 0];
      ack.connectionEpoch = connection.connectionEpoch;
      ack.lastProcessedSequence = 0;
      ack.appliedAtServerTick = 0;
      ack.processedEdgeIds = [0, 0, 0, 0, 0];
    }
    if (connections.length) baseline.snapshot.players = structuredClone(baseline.combat.players);
    validatePrepared(baseline, prepared);
    const result = evaluateCombatTick(
      baseline.combat,
      baseline.snapshot,
      prepared,
      connections.map((value) => value.playerId)
    );
    if (!result.state.snapshot.acknowledgments.some(
      (a) => a.connectionEpoch === result.state.snapshot.connectionEpoch
    )) {
      const recipient = result.state.snapshot.acknowledgments[0];
      if (!recipient) throw new Error("Missing snapshot recipient");
      result.state.snapshot.connectionEpoch = recipient.connectionEpoch;
    }
    const history = stageEventTick(
      current.history,
      result.state.combat.tick,
      combatGameplayEvents(current.combat, result.state.combat),
      combatEventContext(current.snapshot)
    );
    result.state.snapshot.baselineEventCursor = history.cursor;
    result.state.snapshot.stateHash = roomWorkloadHash(result.state.snapshot);
    const connectedPlayerIds = prepared.map((p) => p.input.playerId);
    const campaign = advanceCombatCampaign(current.campaign, result.state.combat, connectedPlayerIds);
    projectCombatCampaign(result.state.snapshot, campaign);
    if (campaign.state.phase === "wipe" || campaign.state.phase === "defeat")
      result.state.snapshot.roomMode = "intermission";
    result.state.snapshot.stateHash = roomWorkloadHash(result.state.snapshot);
    const state = {
      ...result.state,
      history,
      connectedPlayerIds,
      pausedFrom: null,
      campaign
    };
    const boundary = [];
    for (const player2 of current.combat.players) {
      const was = current.connectedPlayerIds.includes(player2.playerId), connected = connectedPlayerIds.includes(player2.playerId);
      const replacement = connections.find((value) => value.playerId === player2.playerId);
      if (replacement) {
        boundary.push({ kind: "neutralize", playerId: player2.playerId, reason: "disconnect" });
        boundary.push({
          kind: "connection",
          playerId: player2.playerId,
          connectionEpoch: replacement.connectionEpoch,
          connected: true
        });
      } else if (was !== connected) {
        const ack = state.snapshot.acknowledgments.find((a) => a.playerId === player2.playerId);
        if (!ack) throw new Error("Missing combat connection owner");
        boundary.push({
          kind: "connection",
          playerId: player2.playerId,
          connectionEpoch: ack.connectionEpoch,
          connected
        });
        if (!connected)
          boundary.push({ kind: "neutralize", playerId: player2.playerId, reason: "disconnect" });
      }
    }
    for (const item of prepared)
      if (item.neutralized)
        boundary.push({ kind: "neutralize", playerId: item.input.playerId, reason: "stale" });
    boundary.push(...result.seatEvents);
    const journal = {
      tick: state.combat.tick,
      runEpoch: state.snapshot.runEpoch,
      inputs: prepared.map((item, index) => ({
        input: structuredClone(item.input),
        edgeResults: item.input.outcome === "applied" ? structuredClone([...result.outcomes[index]?.edgeResults ?? []]) : (item.input.submittedCommand?.edges ?? []).map((edge) => ({
          ...edge,
          outcome: item.input.outcome
        }))
      })),
      acknowledgments: prepared.map((p) => structuredClone(p.acknowledgment)),
      boundaryEvents: boundary.map((event, order) => ({ order, event })),
      beforeHash: combatRuntimeHash(current),
      assertions: [{ kind: "state-hash", value: combatRuntimeHash(state) }]
    };
    return { state, outcomes: result.outcomes, journal };
  }
  function replayCombatTick(current, journal) {
    check8(
      journal.runEpoch === current.snapshot.runEpoch && journal.tick === current.combat.tick + 1 && journal.beforeHash === combatRuntimeHash(current),
      "missing/changed journal prefix"
    );
    integer(journal.inputs.length, 0, 4, "journal input count");
    integer(journal.boundaryEvents.length, 0, 16, "journal boundary count");
    check8(journal.acknowledgments.length === journal.inputs.length, "journal acknowledgment count");
    const prepared = journal.inputs.map(({ input }, index) => {
      const acknowledgment = journal.acknowledgments[index];
      if (!acknowledgment) throw new Error("Missing journal acknowledgment");
      return {
        input,
        acknowledgment,
        neutralized: journal.boundaryEvents.some(
          ({ event }) => event.kind === "neutralize" && event.playerId === input.playerId && event.reason === "stale"
        )
      };
    });
    const connections = journal.boundaryEvents.flatMap(({ event }) => {
      if (event.kind !== "connection" || !event.connected) return [];
      const before = current.snapshot.acknowledgments.find((a) => a.playerId === event.playerId);
      return before && event.connectionEpoch !== before.connectionEpoch ? [{ playerId: event.playerId, connectionEpoch: event.connectionEpoch }] : [];
    });
    const result = stageCombatRuntime(current, prepared, connections);
    check8(canonical(result.journal) === canonical(journal), "journal outcome/boundary/hash mismatch");
    return result.state;
  }

  // src/shared/diagnostics/combat-checkpoint.ts
  var COMBAT_ARCHIVE_MAX_BYTES = 1024 * 1024;
  var COMBAT_SEGMENT_TICKS = 15;
  function check9(ok, message) {
    if (!ok) throw new Error(`Combat checkpoint: ${message}`);
  }
  function fields(value, names) {
    check9(
      value !== null && !Array.isArray(value) && Object.keys(value).sort().join(",") === names.split(" ").sort().join(","),
      "unexpected/missing fields"
    );
  }
  function identity2(value) {
    fields(value, "simulationVersion simulationBuild contentFormat contentHash runId");
    integer(value.simulationVersion, 1, COUNTER_LIMIT - 1, "simulation version");
    integer(value.contentFormat, 1, COUNTER_LIMIT - 1, "content format");
    for (const digest2 of [value.simulationBuild, value.contentHash])
      check9(typeof digest2 === "string" && /^[a-f0-9]{64}$/u.test(digest2), "identity digest");
    check9(typeof value.runId === "string" && /^[a-z0-9-]{8,80}$/u.test(value.runId), "run identity");
  }
  function validateCombatCheckpoint(state) {
    fields(state, "combat snapshot history connectedPlayerIds pausedFrom campaign");
    const { combat, snapshot, history } = state;
    fields(state.campaign, "state continues");
    fields(
      state.campaign.state,
      "ruleset mission checkpointId encounterId continuesRemaining continuesUsed phase requiredEntities resolvedEntities"
    );
    for (const decision of state.campaign.continues) {
      fields(
        decision,
        "ordinal tick checkpointId fromRunEpoch runEpoch nextEntityIdBefore retiredEntityIds spawnedEntityIds retiredVehicleIds spawnedVehicleIds kills"
      );
      for (const kill of decision.kills) fields(kill, "playerId count");
    }
    validateCombatCampaign(state.campaign, combat, snapshot.runEpoch);
    check9(
      snapshot.roomMode === "paused-empty" ? state.pausedFrom !== null && isPausableRoom(state.pausedFrom) : state.pausedFrom === null,
      "paused room origin"
    );
    fields(
      combat,
      "format scenario tick nextActionId nextEntityId eventSequence players tanks targets props projectiles rockets beams strikes grenades areas encounter events"
    );
    check9(combat.format === 11, "simulation format");
    integer(combat.tick, 0, COMBAT_LAB_LIMIT, "combat checkpoint tick");
    integer(combat.players.length, 1, 4, "combat checkpoint players");
    integer(combat.projectiles.length, 0, 256, "combat checkpoint projectiles");
    integer(combat.rockets.length, 0, 32, "combat checkpoint rockets");
    integer(combat.beams.length, 0, 4, "combat checkpoint beams");
    integer(combat.strikes.length, 0, 4, "combat checkpoint strikes");
    integer(combat.grenades.length, 0, 32, "combat checkpoint grenades");
    integer(combat.areas.length, 0, 16, "combat area budget");
    integer(
      combat.projectiles.length + combat.rockets.length + combat.beams.length + combat.strikes.length + combat.grenades.length + combat.areas.length,
      0,
      256,
      "attack entity budget"
    );
    integer(combat.events.length, 0, MAX_EVENT_HISTORY, "combat checkpoint notices");
    const initial = createCombatLab(combat.scenario, combat.players.length);
    validateDestructibles(
      combat.props,
      combat.scenario === "support" ? COMBAT_SUPPORT : [],
      combat.tick,
      [...combat.players.map((p) => p.playerId), ...combat.targets.map((t) => t.enemy.body.id)],
      combat.nextActionId
    );
    check9(
      snapshot.geometryRevision === combatGeometryRevision(combat.props),
      "committed geometry revision"
    );
    for (const prop of combat.props)
      fields(prop, "id definitionId health destroyedTick destroyerId destroyActionId");
    const actionOwners = /* @__PURE__ */ new Map();
    const ownAction = (actionId, ownerId) => {
      integer(actionId, 0, combat.nextActionId - 1, "action allocation");
      if (actionId === 0) return;
      const owner = actionOwners.get(actionId);
      check9(owner === void 0 || owner === ownerId, "action owner collision");
      actionOwners.set(actionId, ownerId);
    };
    for (const prop of combat.props)
      if (prop.destroyActionId !== null && prop.destroyerId !== null)
        ownAction(prop.destroyActionId, prop.destroyerId);
    check9(combat.targets.length === initial.targets.length, "target roster");
    const lifecycle2 = new EncounterLifecycle(combatEncounterDefinition(combat));
    lifecycle2.restore(combat.encounter);
    check9(
      combat.encounter.tick === combat.tick && combat.eventSequence === combat.encounter.receipts.length,
      "ledger boundary"
    );
    for (const [index, actor] of combat.players.entries()) {
      ownAction(actor.action.actionInstanceId, actor.playerId);
      ownAction(actor.weapon.lastActionInstanceId, actor.playerId);
      const original = initial.players[index];
      check9(
        original && actor.playerId === original.playerId && actor.body.id === original.body.id && actor.slot === original.slot,
        "player roster"
      );
      check9(COMBAT_CATALOG.firearms.has(actor.weapon.id), "unsupported weapon");
      fields(actor.firearmAim, "pitch nextStepTick");
      validateFirearmAim(actor, combat.tick, COMBAT_CATALOG);
      validatePlayerLife(actor, combat.tick, snapshot.campaign.ruleset);
      if (actor.action.kind !== "ready") {
        const timeline = COMBAT_CATALOG.timelines.get(actor.action.definitionId);
        const age = combat.tick - actor.action.stateStartTick;
        check9(
          ["fire", "melee", "grenade", "enter", "exit"].includes(actor.action.kind) && timeline && age >= 0 && age < timeline.durationTicks && actor.action.nextMarkerIndex === timeline.markers.filter((marker) => marker.tickOffset <= age).length,
          "action marker cursor"
        );
        if (actor.action.kind === "melee" || actor.action.kind === "grenade")
          check9(
            FOOT_ACTION_PROFILES[actor.action.kind].timelineIds.includes(actor.action.definitionId),
            "foot action timeline"
          );
        if (actor.action.kind === "enter" || actor.action.kind === "exit")
          check9(actor.vehicleId !== null, "transfer requires seat owner");
      }
    }
    check9(combat.tanks.length === initial.tanks.length, "tank roster");
    for (const tank of combat.tanks) {
      fields(
        tank,
        "body definitionId kind lifecycle occupantId reservedBy controlEpoch ownerControlEpoch facing heading invulnerableTicks armor action components weapon jumpBufferTicks coyoteTicks turnTicks disconnectedTicks lastGunOwnerId lastGunControlEpoch"
      );
      fields(tank.action, "kind actionInstanceId stateStartTick definitionId nextMarkerIndex");
      fields(tank.weapon, "id ammo cooldownTicks shotOrdinal lastActionInstanceId");
      validateTankState(tank, combat.tick, combat.players, TANK_PROFILE, COMBAT_CATALOG);
      ownAction(tank.action.actionInstanceId, tankOwner(tank) ?? tank.lastGunOwnerId ?? 0);
      ownAction(tank.weapon.lastActionInstanceId, tank.lastGunOwnerId ?? 0);
    }
    for (const [index, target] of combat.targets.entries()) {
      fields(target, "enemy health shield rifle guard");
      fields(target.enemy, "body facing geometryRevision life removalReason turns");
      const original = initial.targets[index], member = combat.encounter.members[index], body4 = target.enemy.body;
      check9(
        original && member && body4.id === member.id && target.shield === original.shield,
        "target identity"
      );
      integer(target.health, 0, 1, "target health");
      check9(
        target.rifle !== null === (original.rifle !== null) && target.guard !== null === (original.guard !== null),
        "enemy attack policy"
      );
      if (target.guard) {
        const guard = target.guard;
        fields(guard, "phase integrity facing turnFacing targetId action hitIds");
        fields(guard.action, "actionInstanceId stateStartTick definitionId nextMarkerIndex");
        check9(
          guard.action.actionInstanceId !== 0 || member.status === "pending",
          "unstarted shield action"
        );
        ownAction(guard.action.actionInstanceId, body4.id);
        validateShield(
          guard,
          target.enemy,
          combat.tick,
          combat.nextActionId,
          combat.players,
          COMBAT_CATALOG,
          SHIELD_PROFILE,
          [...combat.props.map((prop) => prop.id), ...combat.tanks.map((tank) => tank.body.id)]
        );
      }
      if (target.rifle) {
        ownAction(target.rifle.action.actionInstanceId, target.enemy.body.id);
        fields(target.rifle, "action targetId aim facing");
        fields(
          target.rifle.action,
          "kind actionInstanceId stateStartTick definitionId nextMarkerIndex"
        );
        validateRifleState(
          target.rifle,
          target.enemy,
          combat.tick,
          combat.nextActionId,
          combat.players,
          COMBAT_CATALOG,
          RIFLE_PROFILE
        );
      }
      integer(target.enemy.turns, 0, combat.tick, "enemy turn cursor");
      check9(
        target.health === 0 === (target.enemy.life === "removed") && ["alive", "removed"].includes(target.enemy.life),
        "enemy life"
      );
      check9(target.health === 0 === (member.status === "resolved"), "enemy ledger resolution");
      check9(
        target.enemy.removalReason === null || target.health === 0 && ["crushed", "out-of-bounds"].includes(target.enemy.removalReason) && member.reason === target.enemy.removalReason,
        "enemy removal cause"
      );
      check9(
        target.enemy.geometryRevision === snapshot.geometryRevision && [-1, 1].includes(target.enemy.facing),
        "enemy geometry/facing"
      );
      const writer = new Writer(BODY_BYTES);
      writeBody(writer, body4);
      check9(canonical(readBody(new Reader(writer.bytes))) === canonical(body4), "body schema");
      check9(
        COMBAT_SHAPES.has(body4.shapeId) && body4.grounded === (body4.supportId !== null),
        "enemy support/shape"
      );
      const contacts = /* @__PURE__ */ new Set();
      for (const contact of body4.contacts) {
        const key = `${contact.otherId}:${contact.normalX}:${contact.normalY}`;
        check9(
          Math.abs(contact.normalX) + Math.abs(contact.normalY) === 1 && contact.toiNumerator <= contact.toiDenominator && !contacts.has(key),
          "enemy contacts"
        );
        contacts.add(key);
      }
    }
    for (const projectile of combat.projectiles) {
      ownAction(projectile.actionInstanceId, projectile.ownerId);
      fields(projectile, "id ownerId team actionInstanceId definitionId position velocity spawnTick");
      fields(projectile.position, "x y");
      fields(projectile.velocity, "x y");
      const attack2 = COMBAT_ATTACKS.get(projectile.definitionId);
      check9(
        attack2 && attack2.kind === "swept-projectile" && attack2.material === "bullet" && (projectile.team === 1 && combat.players.some((p) => p.playerId === projectile.ownerId) && projectile.definitionId !== 3 || projectile.team === 2 && projectile.definitionId === 3 && combat.targets.some((t) => t.rifle && t.enemy.body.id === projectile.ownerId)),
        "projectile owner/definition"
      );
      check9(
        projectile.spawnTick > 0 && projectile.spawnTick <= combat.tick && combat.tick - projectile.spawnTick < attack2.lifetimeTicks,
        "projectile lifetime"
      );
      check9(
        attack2.id === TANK_PROFILE.attackId ? TANK_PROFILE.headings.some(
          ({ velocity: velocity2 }) => velocity2.x === projectile.velocity.x && velocity2.y === projectile.velocity.y
        ) : attack2.id === 2 ? COMBAT_CATALOG.firearms.get("heavy-machine-gun")?.sweep?.headings.some(
          ({ velocity: velocity2 }) => Math.abs(projectile.velocity.x) === velocity2.x && projectile.velocity.y === velocity2.y
        ) : Math.abs(projectile.velocity.x) + Math.abs(projectile.velocity.y) === attack2.speed,
        "projectile motion"
      );
    }
    const attackIds = new Set(combat.projectiles.map((projectile) => projectile.id));
    const ownAttack = (source3) => {
      integer(source3.id, 1, combat.nextEntityId - 1, "attack entity allocation");
      check9(
        !attackIds.has(source3.id) && !combat.targets.some((target) => target.enemy.body.id === source3.id) && !combat.tanks.some((tank) => tank.body.id === source3.id) && !combat.players.some((player2) => player2.body.id === source3.id),
        "attack entity collision"
      );
      attackIds.add(source3.id);
      check9(
        source3.team === 1 && combat.players.some((player2) => player2.playerId === source3.ownerId),
        "foot attack ownership"
      );
      ownAction(source3.actionInstanceId, source3.ownerId);
    };
    const rocketActions = /* @__PURE__ */ new Set();
    const beamOwners = /* @__PURE__ */ new Set();
    for (const beam of combat.beams) {
      fields(
        beam,
        "id ownerId team actionInstanceId definitionId spawnTick tick origin heading length"
      );
      fields(beam.origin, "x y");
      ownAttack(beam);
      check9(!beamOwners.has(beam.ownerId), "duplicate beam owner");
      beamOwners.add(beam.ownerId);
      validateBeamPulse(beam, LASER_ATTACK, LASER_PROFILE);
      const actor = combat.players.find((player2) => player2.playerId === beam.ownerId);
      const anchor = combatAreaAnchor(combat, beam);
      check9(
        beam.tick === combat.tick && actor?.weapon.id === "laser" && actor.action.stateStartTick === beam.spawnTick && anchor !== null && canonical(anchor.origin) === canonical(beam.origin) && anchor.heading === beam.heading,
        "beam owner/clock/muzzle"
      );
    }
    for (const rocket2 of combat.rockets) {
      fields(
        rocket2,
        "id ownerId team actionInstanceId definitionId position velocity spawnTick tick launchHeading heading speed targetId nextAcquireTick nextTurnTick"
      );
      fields(rocket2.position, "x y");
      fields(rocket2.velocity, "x y");
      ownAttack(rocket2);
      check9(!rocketActions.has(rocket2.actionInstanceId), "duplicate rocket action");
      rocketActions.add(rocket2.actionInstanceId);
      check9(
        rocket2.definitionId === ROCKET_ATTACK.id && rocket2.tick === combat.tick,
        "rocket definition/tick"
      );
      check9(
        rocket2.targetId === null || combat.targets.some((target) => target.enemy.body.id === rocket2.targetId),
        "rocket target roster"
      );
      validateRocket(rocket2, ROCKET_PROFILE);
      sweepBounds(worldRect(rocket2.position, ROCKET_SHAPE.rect, 1), { x: 0, y: 0 });
    }
    for (const strike of combat.strikes) {
      fields(strike, "id ownerId team actionInstanceId definitionId spawnTick endTick hitIds");
      ownAttack(strike);
      const owner = combat.players.find((player2) => player2.playerId === strike.ownerId);
      check9(
        owner?.life === "alive" && owner.action.kind === "melee" && owner.action.actionInstanceId === strike.actionInstanceId && strike.definitionId === 4 && strike.spawnTick === owner.action.stateStartTick + (COMBAT_CATALOG.timelines.get(owner.action.definitionId)?.markers.find((marker) => marker.kind === "activate-hitbox")?.tickOffset ?? -1) && strike.spawnTick <= combat.tick && strike.endTick === strike.spawnTick + (COMBAT_ATTACKS.get(4)?.lifetimeTicks ?? 0) && combat.tick < strike.endTick,
        "active melee continuation"
      );
      integer(strike.hitIds.length, 0, COMBAT_ATTACKS.get(4)?.maxTargets ?? 0, "melee hit budget");
      for (const [index, id2] of strike.hitIds.entries())
        check9(
          (index === 0 || id2 > (strike.hitIds[index - 1] ?? 0)) && (combat.targets.some((target) => target.enemy.body.id === id2) || combat.props.some((prop) => prop.id === id2)),
          "melee hit ledger"
        );
    }
    const areaActions = /* @__PURE__ */ new Set();
    for (const area of combat.areas) {
      fields(
        area,
        "id ownerId team actionInstanceId definitionId startTick emitted cancelledTick lobes hits"
      );
      ownAttack(area);
      check9(!areaActions.has(area.actionInstanceId), "duplicate area action");
      areaActions.add(area.actionInstanceId);
      const definition2 = COMBAT_ATTACKS.get(area.definitionId), profile = AREA_PROFILES.get(area.definitionId);
      check9(definition2 && profile, "area attack definition");
      for (const lobe of area.lobes) {
        fields(lobe, "index origin heading reach");
        fields(lobe.origin, "x y");
      }
      for (const hit of area.hits) fields(hit, "entityId nextTick");
      validateArea(area, combat.tick, definition2, profile, [
        ...combat.targets.map((target) => target.enemy.body.id),
        ...combat.props.map((prop) => prop.id)
      ]);
      const anchor = combatAreaAnchor(combat, area);
      if (anchor) {
        const owner = combat.players.find((player2) => player2.playerId === area.ownerId);
        check9(owner?.action.stateStartTick === area.startTick, "area action start");
        check9(
          COMBAT_CATALOG.timelines.get(owner.action.definitionId)?.markers.some(
            (marker) => marker.kind === "spawn-attack" && marker.payloadId === area.definitionId
          ),
          "area action definition"
        );
      }
      if (profile.kind === "flame-volumes") {
        check9(anchor === null === (area.cancelledTick !== null), "flame action cancellation");
        for (const lobe of area.lobes) {
          const age = combat.tick - area.startTick - (profile.emissionOffsets[lobe.index] ?? 0);
          if (age < profile.attachedTicks)
            check9(
              anchor && canonical(lobe.origin) === canonical(anchor.origin) && lobe.heading === anchor.heading,
              "attached flame anchor"
            );
        }
      } else check9(area.cancelledTick === null, "released shotgun cancellation");
    }
    for (const grenade of combat.grenades) {
      const bounds = grenadeVelocityBounds(GRENADE_PROFILE);
      fields(grenade, "id ownerId team actionInstanceId definitionId body spawnTick bounces");
      ownAttack(grenade);
      check9(
        grenade.definitionId === 5 && grenade.body.id === grenade.id && grenade.body.shapeId === GRENADE_PROFILE.bodyShapeId,
        "grenade body/definition"
      );
      integer(
        grenade.spawnTick,
        Math.max(1, combat.tick - GRENADE_PROFILE.fuseTicks + 1),
        combat.tick,
        "grenade fuse continuation"
      );
      integer(grenade.bounces, 0, GRENADE_PROFILE.maximumBounces, "grenade bounce count");
      const writer = new Writer(BODY_BYTES);
      writeBody(writer, grenade.body);
      check9(
        canonical(readBody(new Reader(writer.bytes))) === canonical(grenade.body),
        "grenade body schema"
      );
      integer(grenade.body.vx, -bounds.x, bounds.x, "grenade horizontal motion");
      integer(
        grenade.body.vy,
        -bounds.up,
        GRENADE_PROFILE.terminalVelocity,
        "grenade vertical motion"
      );
    }
    for (const notice2 of combat.events) {
      ownAction(notice2.actionInstanceId, notice2.ownerId);
      fields(
        notice2,
        "kind ownerId actionInstanceId markerIndex source position impact targetId beam"
      );
      fields(notice2.position, "x y");
      check9(
        notice2.beam !== null === (notice2.kind === "shot" && notice2.source?.definitionId === LASER_ATTACK.id),
        "beam notice presence"
      );
      if (notice2.beam !== null) {
        fields(notice2.beam, "heading length width");
        check9(
          notice2.beam.width === LASER_PROFILE.width && notice2.beam.length <= LASER_PROFILE.range,
          "beam notice profile"
        );
        beamSegments(notice2.position, notice2.beam.heading, notice2.beam.length, notice2.beam.width);
      }
      check9(
        [
          "shot",
          "sound",
          "muzzle-blocked",
          "impact",
          "killed",
          "melee",
          "throw",
          "action-sound",
          "explosion",
          "shield-break",
          "prop-destroyed"
        ].includes(notice2.kind),
        "notice kind"
      );
      check9(
        combat.players.some((p) => p.playerId === notice2.ownerId) || combat.targets.some((t) => (t.rifle || t.guard) && t.enemy.body.id === notice2.ownerId),
        "notice owner"
      );
      integer(notice2.actionInstanceId, 1, combat.nextActionId - 1, "notice action");
      integer(notice2.markerIndex, 0, 127, "notice marker");
      integer(notice2.position.x, -MAX_POSITION, MAX_POSITION, "notice x");
      integer(notice2.position.y, -MAX_POSITION, MAX_POSITION, "notice y");
      check9(
        notice2.targetId === null || combat.props.some((prop) => prop.id === notice2.targetId) || combat.tanks.some((tank) => tank.body.id === notice2.targetId) || combat.targets.some((t) => t.enemy.body.id === notice2.targetId) || combat.players.some((p) => p.body.id === notice2.targetId),
        "notice target"
      );
      check9(
        ["impact", "killed", "shield-break", "prop-destroyed"].includes(notice2.kind) === (notice2.impact !== null),
        "notice impact"
      );
      check9(notice2.impact === null === (notice2.source !== null), "notice source kind");
      if (notice2.source !== null) {
        if ("controlEpoch" in notice2.source) {
          const source3 = notice2.source;
          fields(
            source3,
            "vehicleId" in source3 ? "definitionId controlEpoch shotOrdinal vehicleId" : "definitionId controlEpoch shotOrdinal"
          );
          const owner = combat.players.find((player2) => player2.playerId === notice2.ownerId);
          const tank = "vehicleId" in source3 ? combat.tanks.find((tank2) => tank2.body.id === source3.vehicleId) : null;
          const weapon2 = "vehicleId" in source3 ? tank?.weapon : owner?.weapon;
          check9(
            owner && weapon2?.lastActionInstanceId === notice2.actionInstanceId && weapon2.shotOrdinal === source3.shotOrdinal && ("vehicleId" in source3 ? tank?.lastGunOwnerId === owner.playerId && tank.lastGunControlEpoch === source3.controlEpoch && source3.definitionId === TANK_PROFILE.attackId : owner.controlEpoch === source3.controlEpoch && source3.definitionId !== TANK_PROFILE.attackId),
            "notice confirmation identity"
          );
          integer(notice2.source.shotOrdinal, 1, COUNTER_LIMIT - 1, "notice shot ordinal");
        } else if ("timelineId" in notice2.source) {
          fields(notice2.source, "definitionId timelineId stateStartTick");
          const enemy = combat.targets.find((target) => target.enemy.body.id === notice2.ownerId);
          const player2 = combat.players.find((player3) => player3.playerId === notice2.ownerId);
          check9(
            enemy?.rifle ? enemy.rifle.action.actionInstanceId === notice2.actionInstanceId && enemy.rifle.action.definitionId === notice2.source.timelineId && notice2.source.definitionId === 3 : enemy?.guard ? enemy.guard.action.actionInstanceId === notice2.actionInstanceId && enemy.guard.action.definitionId === notice2.source.timelineId && enemy.guard.action.stateStartTick === notice2.source.stateStartTick : player2 && [4, 5].includes(notice2.source.definitionId) && (player2.life === "death" || player2.action.actionInstanceId === notice2.actionInstanceId),
            "timeline notice owner"
          );
          const marker = COMBAT_CATALOG.timelines.get(notice2.source.timelineId)?.markers[notice2.markerIndex];
          check9(
            marker && marker.tickOffset === combat.tick - notice2.source.stateStartTick && marker.payloadId === notice2.source.definitionId && marker.kind === (["sound", "action-sound"].includes(notice2.kind) ? "sound" : notice2.kind === "melee" ? "activate-hitbox" : "spawn-attack"),
            "timeline notice marker"
          );
        } else {
          fields(notice2.source, "definitionId spawnTick sourceId");
          check9(
            notice2.kind === "explosion" && (notice2.source.definitionId === 5 && notice2.source.spawnTick === combat.tick - GRENADE_PROFILE.fuseTicks || notice2.source.definitionId === ROCKET_ATTACK.id && notice2.source.spawnTick < combat.tick && combat.tick - notice2.source.spawnTick <= ROCKET_PROFILE.lifetimeTicks),
            "detonation lifetime boundary"
          );
          integer(notice2.source.spawnTick, 1, combat.tick - 1, "detonation birth tick");
          integer(notice2.source.sourceId, 1, combat.nextEntityId - 1, "detonation source");
        }
        if (!("spawnTick" in notice2.source))
          check9(
            [...COMBAT_CATALOG.timelines.values()].some((timeline) => {
              const marker = timeline.markers[notice2.markerIndex];
              return marker?.payloadId === notice2.source?.definitionId && marker?.kind === (["sound", "action-sound"].includes(notice2.kind) ? "sound" : notice2.kind === "melee" ? "activate-hitbox" : "spawn-attack");
            }),
            "notice marker payload"
          );
      }
      if (notice2.impact !== null) {
        const impact2 = notice2.impact;
        fields(
          impact2,
          "sourceId definitionId actionInstanceId ownerId colliderId entityId kind damage position time"
        );
        fields(impact2.time, "numerator denominator");
        fields(impact2.position, "x y");
        integer(impact2.sourceId, 1, combat.nextEntityId - 1, "impact projectile");
        check9(COMBAT_ATTACKS.has(impact2.definitionId), "impact definition");
        integer(impact2.colliderId, 1, COUNTER_LIMIT - 1, "impact collider");
        integer(impact2.damage, 0, 65535, "impact damage");
        integer(impact2.time.denominator, 1, 2 ** 17, "impact denominator");
        integer(impact2.time.numerator, 0, impact2.time.denominator, "impact numerator");
        check9(
          impact2.actionInstanceId === notice2.actionInstanceId && impact2.ownerId === notice2.ownerId && impact2.entityId === notice2.targetId && canonical(impact2.position) === canonical(notice2.position),
          "impact attribution"
        );
        check9(
          ["terrain", "shield", "body"].includes(impact2.kind) && impact2.kind === "terrain" === (impact2.entityId === null),
          "impact material"
        );
        check9(notice2.kind !== "killed" || impact2.kind === "body", "kill material");
        if (notice2.kind === "prop-destroyed") {
          const prop = combat.props.find((prop2) => prop2.id === notice2.targetId);
          check9(
            impact2.kind === "body" && prop?.health === 0 && prop.destroyedTick === combat.tick && prop.destroyerId === notice2.ownerId && prop.destroyActionId === notice2.actionInstanceId,
            "prop destruction attribution"
          );
        }
        if (notice2.kind === "shield-break") {
          const broken = combat.targets.find(
            (target) => target.enemy.body.id === notice2.targetId
          )?.guard;
          check9(
            impact2.kind === "shield" && broken?.integrity === 0 && broken.action.stateStartTick === combat.tick,
            "shield break attribution"
          );
        }
      }
    }
    const local = snapshot.acknowledgments.find(
      (a) => a.connectionEpoch === snapshot.connectionEpoch
    );
    check9(local, "checkpoint snapshot recipient");
    const context2 = {
      runEpoch: snapshot.runEpoch,
      connectionEpoch: snapshot.connectionEpoch,
      playerId: local.playerId,
      geometryRevision: snapshot.geometryRevision,
      shapeIds: new Set(COMBAT_SHAPES.keys())
    };
    const restored = decodeSnapshot(encodeSnapshot(snapshot, context2), context2);
    check9(
      canonical(restored) === canonical(snapshot) && snapshot.stateHash === roomWorkloadHash(snapshot),
      "snapshot schema/hash"
    );
    check9(
      canonical(combatSnapshot(combat, snapshot, state.campaign)) === canonical(snapshot),
      "combat/snapshot mismatch"
    );
    integer(state.connectedPlayerIds.length, 0, combat.players.length, "connected roster size");
    check9(
      state.connectedPlayerIds.every(
        (id2, i) => combat.players.some((p) => p.playerId === id2) && (i === 0 || id2 > (state.connectedPlayerIds[i - 1] ?? 0))
      ),
      "connected roster"
    );
    fields(history, "runEpoch tick cursor entries capEvictions ageEvictions");
    check9(
      history.runEpoch === snapshot.runEpoch && history.tick === combat.tick && history.cursor === snapshot.baselineEventCursor,
      "event history boundary"
    );
    eventCounter(history.cursor, true);
    integer(history.entries.length, 0, MAX_EVENT_HISTORY, "retained event count");
    integer(history.capEvictions, 0, history.cursor, "event cap evictions");
    integer(history.ageEvictions, 0, history.cursor, "event age evictions");
    check9(
      history.capEvictions + history.ageEvictions + history.entries.length === history.cursor,
      "event retention accounting"
    );
    for (const [index, envelope] of history.entries.entries()) {
      fields(envelope, "cursor tick counter event");
      eventCounter(envelope.cursor);
      integer(
        envelope.tick,
        Math.max(1, combat.tick - EVENT_HISTORY_TICKS + 1),
        combat.tick,
        "retained event tick"
      );
      integer(envelope.counter, 0, MAX_EVENT_HISTORY - 1, "retained event counter");
      check9(
        envelope.cursor === history.cursor - history.entries.length + index + 1,
        "retained cursor gap"
      );
      const previous = history.entries[index - 1];
      check9(!previous || followsEvent(previous, envelope), "event identity gap");
      validateGameplayEvent(envelope.event, combatEventContext(snapshot));
      const event = envelope.event;
      check9(
        event.origin === "player" ? combat.players.some((player2) => player2.playerId === event.ownerId) : combat.targets.some(
          (target) => (target.rifle || target.guard) && target.enemy.body.id === event.ownerId
        ),
        "retained event owner/origin"
      );
      ownAction(event.actionInstanceId, event.ownerId);
      check9(envelope.event.actionInstanceId < combat.nextActionId, "future retained action");
    }
  }
  async function digest(payload) {
    const hash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(payload));
    return Array.from(new Uint8Array(hash), (b) => b.toString(16).padStart(2, "0")).join("");
  }
  async function seal(kind, value, expected) {
    identity2(expected);
    const payload = canonical(value);
    check9(
      new TextEncoder().encode(payload).byteLength < COMBAT_ARCHIVE_MAX_BYTES / 2,
      "payload size limit"
    );
    return canonical({
      format: 14,
      protocolMajor: PROTOCOL_MAJOR,
      protocolMinor: PROTOCOL_MINOR,
      kind,
      identity: expected,
      payload,
      sha256: await digest(payload)
    });
  }
  async function unseal(raw, kind, expected) {
    identity2(expected);
    check9(
      typeof raw === "string" && raw.length <= COMBAT_ARCHIVE_MAX_BYTES && new TextEncoder().encode(raw).byteLength <= COMBAT_ARCHIVE_MAX_BYTES,
      "archive size limit"
    );
    const envelope = JSON.parse(raw);
    fields(envelope, "format protocolMajor protocolMinor kind identity payload sha256");
    check9(
      envelope.format === 14 && envelope.kind === kind && envelope.protocolMajor === PROTOCOL_MAJOR && envelope.protocolMinor === PROTOCOL_MINOR,
      "archive version/kind"
    );
    check9(canonical(envelope.identity) === canonical(expected), "archive identity mismatch");
    check9(
      typeof envelope.payload === "string" && envelope.payload.length < COMBAT_ARCHIVE_MAX_BYTES / 2 && await digest(envelope.payload) === envelope.sha256,
      "archive checksum mismatch"
    );
    const value = JSON.parse(envelope.payload);
    check9(canonical(value) === envelope.payload, "noncanonical payload");
    return value;
  }
  async function encodeCombatCheckpoint(current, expected) {
    const state = structuredClone(current);
    validateCombatCheckpoint(state);
    return seal("checkpoint", state, { ...expected });
  }
  async function decodeCombatCheckpoint(raw, expected) {
    const state = await unseal(raw, "checkpoint", expected);
    validateCombatCheckpoint(state);
    return state;
  }
  async function encodeCombatJournalSegment(start, entries, expected) {
    const saved = structuredClone([...entries]);
    integer(saved.length, 1, COMBAT_SEGMENT_TICKS, "journal segment ticks");
    let state = start;
    for (const entry of saved) state = replayCombatTick(state, entry);
    return encodeAcceptedCombatJournalSegment(start, saved, state, expected);
  }
  async function encodeAcceptedCombatJournalSegment(start, entries, accepted, expected) {
    const saved = structuredClone([...entries]);
    integer(saved.length, 1, COMBAT_SEGMENT_TICKS, "journal segment ticks");
    let hash = combatRuntimeHash(start);
    for (const [index, entry] of saved.entries()) {
      check9(
        entry.runEpoch === start.snapshot.runEpoch && entry.tick === start.combat.tick + index + 1 && entry.beforeHash === hash && entry.assertions.length === 1 && entry.assertions[0]?.kind === "state-hash" && /^[a-f0-9]{8}$/u.test(entry.assertions[0].value),
        "accepted journal prefix"
      );
      hash = entry.assertions[0].value;
    }
    validateCombatCheckpoint(accepted);
    check9(
      accepted.snapshot.runEpoch === start.snapshot.runEpoch && accepted.combat.tick === start.combat.tick + saved.length && combatRuntimeHash(accepted) === hash,
      "accepted journal boundary"
    );
    const segment = {
      runEpoch: start.snapshot.runEpoch,
      fromTick: start.combat.tick + 1,
      throughTick: accepted.combat.tick,
      entries: saved
    };
    return seal("journal", segment, { ...expected });
  }
  async function restoreCombatJournalSegment(start, raw, expected) {
    const segment = await unseal(raw, "journal", expected);
    fields(segment, "runEpoch fromTick throughTick entries");
    integer(segment.entries.length, 1, COMBAT_SEGMENT_TICKS, "journal segment ticks");
    check9(
      segment.runEpoch === start.snapshot.runEpoch && segment.fromTick === start.combat.tick + 1 && segment.throughTick === start.combat.tick + segment.entries.length,
      "journal segment gap/epoch"
    );
    let state = start;
    for (const entry of segment.entries) state = replayCombatTick(state, entry);
    validateCombatCheckpoint(state);
    return state;
  }

  // src/shared/protocol/input-mapping.ts
  var fields2 = [
    "type",
    "runEpoch",
    "connectionEpoch",
    "playerId",
    "snapshotId",
    "snapshotTick",
    "nextSequence",
    "nextCommandTick"
  ].sort().join(",");
  function validateInputMapping(value) {
    if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).sort().join(",") !== fields2)
      throw new ProtocolError("malformed", "Invalid input mapping fields");
    const record2 = value;
    if (record2.type !== "input-mapping")
      throw new ProtocolError("malformed", "Invalid input mapping type");
    for (const key of [
      "runEpoch",
      "connectionEpoch",
      "playerId",
      "snapshotId",
      "snapshotTick",
      "nextSequence",
      "nextCommandTick"
    ]) {
      const n = record2[key];
      if (typeof n !== "number" || !Number.isSafeInteger(n) || n < (key === "snapshotTick" ? 0 : 1) || n >= COUNTER_LIMIT)
        throw new ProtocolError("malformed", "Invalid input mapping counter");
    }
    if (record2.nextCommandTick !== Number(record2.snapshotTick) + 1)
      throw new ProtocolError("malformed", "Mapping must start after its snapshot boundary");
    return { ...record2 };
  }
  function decodeInputMapping(raw) {
    if (raw.length > 512 || new TextEncoder().encode(raw).byteLength > 512)
      throw new ProtocolError("malformed", "Input mapping too large");
    try {
      return validateInputMapping(JSON.parse(raw));
    } catch (error) {
      if (error instanceof ProtocolError) throw error;
      throw new ProtocolError("malformed", "Invalid input mapping JSON");
    }
  }
  function mappingForSnapshot(snapshot, playerId) {
    const ack = snapshot.acknowledgments.find((value) => value.playerId === playerId);
    if (!ack || ack.connectionEpoch !== snapshot.connectionEpoch)
      throw new ProtocolError("malformed", "Missing mapping owner");
    return validateInputMapping({
      type: "input-mapping",
      runEpoch: snapshot.runEpoch,
      connectionEpoch: snapshot.connectionEpoch,
      playerId,
      snapshotId: snapshot.snapshotId,
      snapshotTick: snapshot.tick,
      nextSequence: ack.lastProcessedSequence + 1,
      nextCommandTick: snapshot.tick + 1
    });
  }

  // src/shared/prediction/controller.ts
  var ControllerPrediction = class {
    #initial;
    #step;
    #actor;
    #tick;
    #baselineTick;
    #lastSequence = 0;
    #lastClientTick = -1;
    #lastAck = 0;
    #lastAckTick = 0;
    #sentEdges = [0, 0, 0, 0, 0];
    #ackedEdges = [0, 0, 0, 0, 0];
    #pending = [];
    #history = /* @__PURE__ */ new Map();
    #stopped = false;
    #usesMappings;
    #loadedGeometry;
    #mapping = null;
    constructor(baseline, step, mapping, loadedGeometry) {
      for (const value of [baseline.runEpoch, baseline.connectionEpoch])
        integer(value, 1, COUNTER_LIMIT - 1, "prediction epoch");
      integer(baseline.tick, 0, COUNTER_LIMIT - 2, "prediction baseline tick");
      if (baseline.acknowledgment.lastProcessedSequence !== 0 || baseline.acknowledgment.appliedAtServerTick !== 0 || baseline.acknowledgment.processedEdgeIds.some((id2) => id2 !== 0))
        throw new Error("Prediction needs a fresh server input baseline");
      this.#initial = structuredClone(baseline);
      this.#usesMappings = mapping !== void 0;
      this.#step = step;
      this.#loadedGeometry = loadedGeometry;
      this.#actor = structuredClone(baseline.actor);
      this.#tick = baseline.tick;
      this.#baselineTick = baseline.tick;
      this.#history.set(baseline.tick, structuredClone(baseline.actor));
      this.#checkIdentity(baseline);
      if (mapping) this.#mapping = this.#checkMapping(baseline, mapping);
    }
    #checkMapping(baseline, value) {
      let mapping;
      try {
        mapping = validateInputMapping(value);
      } catch {
        this.#reject("Invalid authoritative input mapping");
      }
      const offset = mapping.nextCommandTick - mapping.nextSequence;
      const previousOffset = this.#mapping ? this.#mapping.nextCommandTick - this.#mapping.nextSequence : this.#initial.tick;
      if (mapping.runEpoch !== baseline.runEpoch || mapping.connectionEpoch !== baseline.connectionEpoch || mapping.playerId !== baseline.actor.playerId || mapping.snapshotId !== baseline.snapshotId || mapping.snapshotTick !== baseline.tick || mapping.nextSequence !== baseline.acknowledgment.lastProcessedSequence + 1 || offset < previousOffset || offset - this.#initial.tick > MAX_CLIENT_LEAD_TICKS && this.#pending.some(
        (command2) => command2.sequence > baseline.acknowledgment.lastProcessedSequence
      ))
        this.#reject("Authoritative mapping needs a fresh baseline");
      return mapping;
    }
    #target(command2, mapping = this.#mapping) {
      return mapping ? mapping.nextCommandTick + command2.sequence - mapping.nextSequence : this.#initial.tick + command2.clientTick + 1;
    }
    get actor() {
      return structuredClone(this.#actor);
    }
    get tick() {
      return this.#tick;
    }
    get pending() {
      return this.#pending.length;
    }
    get requiresResync() {
      return this.#stopped;
    }
    #reject(message) {
      this.#stopped = true;
      throw new ProtocolError("resync-required", message);
    }
    #guard() {
      if (this.#stopped) this.#reject("Prediction requires a fresh baseline");
    }
    #checkIdentity(baseline) {
      const original = this.#initial, ack = baseline.acknowledgment;
      if (baseline.runEpoch !== original.runEpoch || baseline.connectionEpoch !== original.connectionEpoch || baseline.actor.playerId !== original.actor.playerId || baseline.actor.body.id !== original.actor.body.id || baseline.actor.controlEpoch < this.#actor.controlEpoch || baseline.actor.geometryRevision !== (this.#loadedGeometry?.() ?? original.actor.geometryRevision) || baseline.actor.geometryRevision < this.#actor.geometryRevision || baseline.actor.controlEpoch === this.#actor.controlEpoch && baseline.actor.vehicleId !== this.#actor.vehicleId || ack.playerId !== baseline.actor.playerId || ack.connectionEpoch !== baseline.connectionEpoch || ack.controlEpoch !== baseline.actor.controlEpoch)
        this.#reject("Prediction identity/ownership changed");
    }
    submit(command2) {
      this.#guard();
      if (this.#mapping && this.#mapping.nextCommandTick - this.#mapping.nextSequence - this.#initial.tick > MAX_CLIENT_LEAD_TICKS)
        this.#reject("Input mapping drift needs a fresh baseline");
      validateInputBatch({
        runEpoch: this.#initial.runEpoch,
        connectionEpoch: this.#initial.connectionEpoch,
        packetSequence: 1,
        snapshotAck: 0,
        eventAck: 0,
        commands: [command2]
      });
      if (command2.sequence !== this.#lastSequence + 1 || command2.clientTick !== this.#lastClientTick + 1 || command2.controlEpoch !== this.#actor.controlEpoch)
        this.#reject("Prediction command sequence/mapping gap");
      const edges = [...this.#sentEdges];
      for (const edge of command2.edges) {
        const previous = edges[edge.kind - 1] ?? 0;
        if (edge.id <= previous || edge.id - previous > 256)
          this.#reject("Prediction edge identity reused");
        edges[edge.kind - 1] = edge.id;
      }
      const target = this.#target(command2);
      if (target !== this.#tick + 1 || target <= this.#baselineTick)
        this.#reject("Pending command maps into an authoritative or missing tick");
      if (this.#pending.length >= MAX_QUEUED_COMMANDS || target - this.#baselineTick > MAX_PREDICTION_TICKS)
        this.#reject("Prediction history limit");
      let actor;
      try {
        actor = this.#step(structuredClone(this.#actor), structuredClone(command2), target);
      } catch {
        this.#reject("Prediction physics failed");
      }
      this.#sentEdges = edges;
      this.#pending.push(structuredClone(command2));
      this.#actor = actor;
      this.#tick = target;
      this.#lastSequence = command2.sequence;
      this.#lastClientTick = command2.clientTick;
      this.#history.set(target, structuredClone(actor));
    }
    reconcile(baseline, mapping) {
      this.#guard();
      this.#checkIdentity(baseline);
      integer(baseline.tick, 0, COUNTER_LIMIT - 2, "snapshot tick");
      const ack = baseline.acknowledgment;
      let nextMapping = this.#mapping;
      if (this.#usesMappings) {
        if (!mapping) this.#reject("Missing authoritative input mapping");
        nextMapping = this.#checkMapping(baseline, mapping);
      } else if (mapping) this.#reject("Input mapping capability was not negotiated");
      encodeAcknowledgment(ack);
      if (baseline.tick < this.#baselineTick || ack.lastProcessedSequence < this.#lastAck || ack.lastProcessedSequence > this.#lastSequence || ack.appliedAtServerTick > baseline.tick)
        this.#reject("Snapshot/ack regression or unsent command");
      if (ack.lastProcessedSequence === this.#lastAck && ack.appliedAtServerTick !== this.#lastAckTick || ack.lastProcessedSequence > this.#lastAck && ack.appliedAtServerTick < this.#initial.tick + ack.lastProcessedSequence)
        this.#reject("Acknowledged command tick is inconsistent");
      const consumedEdges = [...this.#ackedEdges];
      for (const command2 of this.#pending.filter((c) => c.sequence <= ack.lastProcessedSequence))
        for (const edge of command2.edges) consumedEdges[edge.kind - 1] = edge.id;
      if (canonical(consumedEdges) !== canonical(ack.processedEdgeIds))
        this.#reject("Acknowledged edge was not consumed");
      const pending = this.#pending.filter((c) => c.sequence > ack.lastProcessedSequence);
      if (pending.some((c) => this.#target(c, nextMapping) <= baseline.tick))
        this.#reject("Unacknowledged command overlaps restored snapshot");
      const prior = this.#history.get(baseline.tick);
      const correction = prior ? {
        x: baseline.actor.body.x - prior.body.x,
        y: baseline.actor.body.y - prior.body.y,
        changed: canonical(prior) !== canonical(baseline.actor)
      } : null;
      const history = /* @__PURE__ */ new Map();
      let actor = structuredClone(baseline.actor), tick2 = baseline.tick;
      history.set(tick2, structuredClone(actor));
      try {
        for (const command2 of pending) {
          const target = this.#target(command2, nextMapping);
          if (target !== tick2 + 1) this.#reject("Pending mapping needs a new baseline");
          const applied = structuredClone(command2);
          if (applied.controlEpoch < actor.controlEpoch) {
            applied.controlEpoch = actor.controlEpoch;
            applied.held = 0;
            applied.aim = 0;
            applied.edges = [];
          }
          actor = this.#step(actor, applied, target);
          tick2 = target;
          history.set(tick2, structuredClone(actor));
        }
      } catch {
        this.#reject("Reconciliation replay failed");
      }
      this.#pending = pending;
      this.#actor = actor;
      this.#tick = tick2;
      this.#baselineTick = baseline.tick;
      this.#lastAck = ack.lastProcessedSequence;
      this.#lastAckTick = ack.appliedAtServerTick;
      this.#ackedEdges = consumedEdges;
      this.#history = history;
      this.#mapping = nextMapping;
      return { correction, replayed: pending.length, tick: tick2 };
    }
  };

  // test/fixtures/combat-input-driver.ts
  function recordCombatInputs(initial, ticks, input = Held.Right | Held.Fire, options = {}) {
    let state = structuredClone(initial);
    const initialTick = initial.combat.tick;
    const states = [structuredClone(state)], entries = [];
    const streams = state.combat.players.map(
      (actor) => new InputStream({
        ...combatPeerContext(initial.snapshot, actor.slot),
        controlEpoch: actor.controlEpoch,
        baselineServerTick: initialTick
      })
    );
    const baseline = (current, slot) => {
      const actor = current.snapshot.players[slot], acknowledgment = current.snapshot.acknowledgments[slot];
      if (!actor || !acknowledgment) throw new Error("Missing prediction baseline");
      return {
        runEpoch: current.snapshot.runEpoch,
        connectionEpoch: acknowledgment.connectionEpoch,
        tick: current.combat.tick,
        actor,
        acknowledgment
      };
    };
    let predictionProps = state.combat.props, loadedGeometryRevision = state.snapshot.geometryRevision;
    const reconcilers = state.combat.players.map(
      (actor) => new ControllerPrediction(
        baseline(state, actor.slot),
        (a, c, t) => predictCombatMovement(a, c, t, initial.combat.scenario, predictionProps),
        void 0,
        () => loadedGeometryRevision
      )
    );
    const edgeIds = streams.map(() => /* @__PURE__ */ new Map());
    let reconciliations = 0, duplicates = 0;
    for (let tick2 = initialTick + 1; tick2 <= initialTick + ticks; tick2++) {
      const sequence = tick2 - initialTick;
      const predictions = [];
      for (const [slot, stream] of streams.entries()) {
        const intent = typeof input === "function" ? input(tick2, slot) : {
          held: input,
          edges: sequence === 1 && input & Held.Fire ? [Edge.FireOnset] : []
        };
        const cursors = edgeIds[slot];
        if (!cursors) throw new Error("Missing edge cursors");
        const command2 = {
          sequence,
          clientTick: sequence - 1,
          controlEpoch: initial.combat.players[slot]?.controlEpoch ?? 0,
          held: intent.held,
          aim: 0,
          edges: (intent.edges ?? []).map((kind) => {
            const id2 = (cursors.get(kind) ?? 0) + 1;
            cursors.set(kind, id2);
            return { kind, id: id2 };
          })
        };
        const packet = encodeInputBatch({
          ...combatPeerContext(initial.snapshot, slot),
          packetSequence: sequence,
          snapshotAck: 0,
          eventAck: 0,
          commands: [command2]
        });
        stream.receive(packet, tick2 * 16, tick2 - 1);
        if (options.duplicatePackets) {
          const duplicate = stream.receive(packet, tick2 * 16, tick2 - 1);
          if (!duplicate.duplicate || duplicate.admitted !== 0 || duplicate.renewed)
            throw new Error("Combat duplicate packet changed admission");
          duplicates++;
        }
        const player2 = state.combat.players[slot];
        if (!player2) throw new Error("Missing life recovery player");
        predictions.push(
          predictCombatMovement(player2, command2, tick2, initial.combat.scenario, state.combat.props)
        );
        reconcilers[slot]?.submit(command2);
      }
      let journal;
      const committed = InputStream.processWorldTick(streams, tick2, tick2 * 16, (prepared) => {
        const candidate = stageCombatRuntime(state, prepared);
        journal = candidate.journal;
        return candidate;
      });
      state = committed.state;
      if (sequence % 3 === 0 || state.snapshot.roomMode !== "playing") {
        predictionProps = state.combat.props;
        loadedGeometryRevision = state.snapshot.geometryRevision;
        for (const [slot, reconciler] of reconcilers.entries())
          reconciler.reconcile(baseline(state, slot));
        reconciliations++;
      }
      if (!journal) throw new Error("Missing life journal");
      for (const [slot, player2] of state.combat.players.entries()) {
        let prediction = predictions[slot];
        if (prediction)
          for (const notice2 of state.combat.events) {
            if (notice2.kind === "impact" && notice2.targetId === player2.body.id && notice2.impact && notice2.impact.damage > 0)
              prediction = damagePlayer(prediction, tick2, notice2.impact.damage, "classic").actor;
          }
        if (!prediction || canonical([
          prediction.body,
          prediction.life,
          prediction.lifeStartTick,
          prediction.bodyPresence,
          prediction.lives,
          prediction.invulnerableTicks
        ]) !== canonical([
          player2.body,
          player2.life,
          player2.lifeStartTick,
          player2.bodyPresence,
          player2.lives,
          player2.invulnerableTicks
        ]))
          throw new Error(`Life movement prediction mismatch at ${tick2}/${slot}`);
      }
      entries.push(journal);
      states.push(structuredClone(state));
      if (state.snapshot.roomMode !== "playing") break;
    }
    return { states, entries, state, reconciliations, duplicates };
  }

  // test/fixtures/combat-recovery-proof.ts
  async function combatArchiveIdentity() {
    const { simulationVersion, simulationBuild, contentFormat, contentHash } = await combatIdentity();
    return {
      simulationVersion,
      simulationBuild,
      contentFormat,
      contentHash,
      runId: "combat-recovery-proof"
    };
  }
  function recordCombatRecovery() {
    let state = createCombatRuntime();
    const states = [structuredClone(state)];
    const entries = [];
    const streams = state.combat.players.map(
      (actor) => new InputStream({ ...probeContext(actor.slot), controlEpoch: 1, baselineServerTick: 0 })
    );
    for (let tick2 = 1; tick2 <= 119; tick2++) {
      const active = streams.filter((_, slot) => slot !== 3 || tick2 < 67);
      for (const [slot, stream] of active.entries()) {
        if (slot === 2 && tick2 >= 62) continue;
        stream.receive(
          encodeInputBatch({
            ...probeContext(slot),
            packetSequence: tick2,
            snapshotAck: 0,
            eventAck: 0,
            commands: [
              {
                sequence: tick2,
                clientTick: tick2 - 1,
                controlEpoch: 1,
                held: Held.Fire,
                aim: 0,
                edges: tick2 === 1 ? [{ kind: Edge.FireOnset, id: 1 }] : tick2 === 63 && slot === 0 ? [{ kind: Edge.Jump, id: 1 }] : []
              }
            ]
          }),
          tick2 * 16,
          tick2 - 1
        );
      }
      let entry;
      const committed = InputStream.processWorldTick(active, tick2, tick2 * 16, (prepared) => {
        const candidate = stageCombatRuntime(state, prepared);
        entry = candidate.journal;
        return candidate;
      });
      state = committed.state;
      if (!entry || canonical(entry.inputs) !== canonical(committed.processed.map(({ input, edgeResults }) => ({ input, edgeResults }))))
        throw new Error("Journal differs from committed applied inputs");
      entries.push(entry);
      states.push(structuredClone(state));
    }
    return { states, entries };
  }
  async function combatRecoveryProof() {
    const identity3 = await combatArchiveIdentity();
    const { states, entries } = recordCombatRecovery();
    const captured = states[60], durable = states[105], live = states[119];
    if (!captured || !durable || !live) throw new Error("Missing checkpoint fixture");
    const raw = await encodeCombatCheckpoint(captured, identity3);
    let restored = await decodeCombatCheckpoint(raw, identity3);
    const bytes = [];
    for (let start = 60; start < 105; start += 15) {
      const source3 = states[start];
      if (!source3) throw new Error("Missing segment boundary");
      const segment = await encodeCombatJournalSegment(
        source3,
        entries.slice(start, start + 15),
        identity3
      );
      bytes.push(new TextEncoder().encode(segment).byteLength);
      restored = await restoreCombatJournalSegment(restored, segment, identity3);
    }
    if (canonical(restored) !== canonical(durable))
      throw new Error("Committed combat reconstruction diverged");
    const baseline = decodeSnapshot(
      encodeSnapshot(restored.snapshot, probeContext(0)),
      probeContext(0)
    );
    if (baseline.combat?.phase !== "complete" || baseline.combat.kills[1]?.count !== 2)
      throw new Error("Recovery baseline lost encounter accounting");
    const boundaries = entries.slice(60, 105).flatMap(
      (entry) => entry.boundaryEvents.map((boundary) => ({ tick: entry.tick, ...boundary }))
    );
    if (!boundaries.some((b) => b.event.kind === "neutralize" && b.event.reason === "stale") || !boundaries.some((b) => b.event.kind === "connection" && !b.event.connected))
      throw new Error("Missing external recovery decisions");
    return {
      checkpointTick: 60,
      committedTick: restored.combat.tick,
      observedTick: live.combat.tick,
      uncommittedTicks: live.combat.tick - restored.combat.tick,
      checkpointBytes: new TextEncoder().encode(raw).byteLength,
      segmentBytes: bytes,
      connectedPlayerIds: restored.connectedPlayerIds,
      shots: restored.combat.players.map((p) => p.weapon.shotOrdinal),
      nextEntityId: restored.combat.nextEntityId,
      nextActionId: restored.combat.nextActionId,
      kills: baseline.combat.kills,
      eventCursor: restored.history.cursor,
      boundaries,
      stateHash: combatRuntimeHash(restored),
      journalHash: stateHash(entries.slice(60, 105))
    };
  }

  // test/fixtures/airborne-death-recovery-proof.ts
  function recordAirborneDeath(kind) {
    const rising = kind === "rising";
    const fixture = recordCombatInputs(
      createCombatRuntime("rifle"),
      145,
      (tick2) => ({
        held: rising ? Held.Right : 0,
        edges: tick2 === (rising ? 35 : 31) ? [Edge.Jump] : []
      }),
      { duplicatePackets: true }
    );
    const deathTick = rising ? 37 : 77, slot = rising ? 3 : 0;
    const killed = fixture.states[deathTick]?.combat.players[slot];
    if (killed?.life !== "death" || killed.body.grounded || killed.lifeStartTick !== deathTick || killed.bodyPresence !== "present" || killed.body.vy < 0 !== rising)
      throw new Error("Missing real airborne rifle kill");
    return { ...fixture, deathTick, slot };
  }
  async function airborneDeathRecoveryProof() {
    const identity3 = await combatArchiveIdentity();
    const cases3 = [];
    for (const kind of ["rising", "falling"]) {
      const fixture = recordAirborneDeath(kind), { states, entries, deathTick, slot } = fixture;
      const killed = states[deathTick]?.combat.players[slot], next = states[deathTick + 1]?.combat.players[slot];
      if (!killed || !next || !FOOT_DEFINITION || next.body.vy !== killed.body.vy + FOOT_DEFINITION.gravity || next.body.x !== killed.body.x + killed.body.vx || next.body.y !== killed.body.y + next.body.vy)
        throw new Error("Hostile hit stopped airborne integration");
      const landedTick = states.find(
        (state) => state.combat.tick > deathTick && state.combat.players[slot]?.life === "death" && state.combat.players[slot]?.body.grounded
      )?.combat.tick ?? null;
      if (kind === "falling" && (landedTick === null || landedTick >= deathTick + 30))
        throw new Error("Falling hit did not settle before respawn");
      const checkpoints = [];
      for (const tick2 of [
        deathTick - 1,
        deathTick,
        deathTick + 6,
        deathTick + 29,
        deathTick + 30,
        deathTick + 42
      ]) {
        const original = states[tick2], accepted = states[tick2 + 15];
        if (!original || !accepted) throw new Error("Missing airborne death boundary");
        const raw = await encodeCombatCheckpoint(original, identity3);
        const checkpoint2 = await decodeCombatCheckpoint(raw, identity3);
        const resumed = await restoreCombatJournalSegment(
          checkpoint2,
          await encodeCombatJournalSegment(original, entries.slice(tick2, tick2 + 15), identity3),
          identity3
        );
        if (canonical(checkpoint2) !== canonical(original) || canonical(resumed) !== canonical(accepted))
          throw new Error("Airborne death replay mismatch");
        const context2 = combatPeerContext(checkpoint2.snapshot, slot);
        const baseline = decodeSnapshot(
          encodeSnapshot(
            { ...checkpoint2.snapshot, connectionEpoch: context2.connectionEpoch },
            context2
          ),
          context2
        );
        if (canonical(baseline.players) !== canonical(checkpoint2.combat.players))
          throw new Error("Airborne body lost in baseline");
        checkpoints.push({
          tick: tick2,
          through: resumed.combat.tick,
          player: baseline.players[slot],
          hash: combatRuntimeHash(resumed)
        });
      }
      const entry = states[deathTick + 30]?.combat.players[slot], ready3 = states[deathTick + 42]?.combat.players[slot];
      if (entry?.life !== "respawning" || entry.bodyPresence !== "present" || ready3?.life !== "alive" || ready3.bodyPresence !== "present" || ready3.lives !== 2)
        throw new Error("Airborne corpse changed life deadline/accounting");
      cases3.push({
        kind,
        deathTick,
        slot,
        killed,
        landedTick,
        checkpoints,
        duplicates: fixture.duplicates,
        reconciliations: fixture.reconciliations,
        hash: stateHash(states.map(combatRuntimeHash))
      });
    }
    return { cases: cases3, hash: stateHash(cases3) };
  }

  // test/fixtures/area-proof.ts
  var AREA_BOUNDARIES = {
    shotgun: [1, 4, 5, 6, 7],
    flame: [6, 7, 12, 13, 15, 18, 19, 25, 30, 31]
  };
  function recordAreaCombat(mode) {
    return recordCombatInputs(
      createCombatRuntime(mode),
      120,
      (tick2) => ({
        held: Held.Down | (tick2 <= 18 ? Held.Fire : 0),
        edges: tick2 === 1 ? [Edge.FireOnset] : []
      }),
      { duplicatePackets: true }
    );
  }
  async function areaCombatProof() {
    const identity3 = await combatArchiveIdentity(), scenarios = [];
    for (const mode of ["shotgun", "flame"]) {
      const fixture = recordAreaCombat(mode), checkpoints = [];
      for (const tick2 of AREA_BOUNDARIES[mode]) {
        const original = fixture.states[tick2], accepted = fixture.states[tick2 + 15];
        if (!original || !accepted) throw new Error("Missing area boundary");
        const raw = await encodeCombatCheckpoint(original, identity3);
        const restored = await decodeCombatCheckpoint(raw, identity3);
        const segment = await encodeCombatJournalSegment(
          original,
          fixture.entries.slice(tick2, tick2 + 15),
          identity3
        );
        const resumed = await restoreCombatJournalSegment(restored, segment, identity3);
        if (canonical(restored) !== canonical(original) || canonical(resumed) !== canonical(accepted))
          throw new Error("Area attack continuation diverged");
        const context2 = combatPeerContext(original.snapshot, 0), bytes = encodeSnapshot(original.snapshot, context2);
        if (canonical(decodeSnapshot(bytes, context2)) !== canonical(original.snapshot))
          throw new Error("Area exposure wire diverged");
        checkpoints.push({
          tick: tick2,
          checkpointBytes: new TextEncoder().encode(raw).byteLength,
          snapshotBytes: bytes.byteLength,
          volumes: original.snapshot.combat?.volumes,
          areas: original.combat.areas,
          hash: combatRuntimeHash(original),
          resumedTick: resumed.combat.tick,
          resumedHash: combatRuntimeHash(resumed)
        });
      }
      const events = fixture.states.flatMap(
        (state) => state.combat.events.filter((event) => ["shot", "impact", "shield-break", "killed"].includes(event.kind)).map((event) => ({
          tick: state.combat.tick,
          kind: event.kind,
          ownerId: event.ownerId,
          targetId: event.targetId,
          actionInstanceId: event.actionInstanceId,
          impact: event.impact
        }))
      );
      if (fixture.state.combat.players.some(
        (player2) => player2.lives !== 3 || player2.weapon.ammo !== (mode === "shotgun" ? 23 : 29) || player2.weapon.shotOrdinal !== 1
      ))
        throw new Error("Area charge/life accounting diverged");
      if (events.filter((event) => event.kind === "shot" && event.ownerId <= 4).length !== (mode === "shotgun" ? 4 : 12))
        throw new Error("Area emission count diverged");
      if (mode === "shotgun" && fixture.states[5]?.combat.encounter.phase !== "complete")
        throw new Error("Shotgun failed its expansion gate");
      if (mode === "flame" && (fixture.states[13]?.combat.targets[0]?.health !== 1 || fixture.states[13]?.combat.targets[0]?.guard?.integrity !== 0 || fixture.states[15]?.combat.targets[0]?.health !== 0))
        throw new Error("Flame break/body separation diverged");
      scenarios.push({
        mode,
        ticks: 120,
        duplicates: fixture.duplicates,
        checkpoints,
        events,
        finalHash: combatRuntimeHash(fixture.state),
        traceHash: stateHash(fixture.states.map(combatRuntimeHash)),
        encounter: fixture.state.combat.encounter.phase
      });
    }
    return {
      scenarios,
      scope: "Four admitted input streams and exact area rectangles, emission cursors, hit cooldowns and wall reach across archive recovery; engineering targets, no final media or deployed timing acceptance"
    };
  }

  // test/fixtures/beam-proof.ts
  var zero3 = { x: 0, y: 0 };
  var source = {
    id: 1e3,
    ownerId: 1,
    team: 1,
    actionInstanceId: 7,
    definitionId: LASER_ATTACK.id
  };
  var body2 = (entityId, x, y = -4) => ({
    id: entityId * 10,
    entityId,
    team: 2,
    kind: "body",
    rect: { x: pixels(x), y: pixels(y), w: pixels(8), h: pixels(8) },
    delta: zero3
  });
  var wall = (x, y = -20) => ({
    id: 900,
    kind: "solid",
    rect: { x: pixels(x), y: pixels(y), w: pixels(1), h: pixels(40) },
    delta: zero3
  });
  var cases = [
    { name: "empty-long-range", hit: [] },
    { name: "long-range-target", targets: [body2(20, 400)], hit: [20] },
    { name: "range-endpoint", targets: [body2(20, 512), body2(21, 513)], hit: [20] },
    {
      name: "width-edges",
      targets: [body2(20, 40, 2), body2(21, 40, -10), body2(22, 40, 1)],
      hit: [22]
    },
    {
      name: "thin-cover",
      terrain: [wall(300)],
      targets: [body2(20, 400)],
      hit: [null],
      length: 300,
      stop: "terrain"
    },
    {
      name: "partial-cover",
      terrain: [wall(40, 1)],
      targets: [body2(20, 80)],
      hit: [null],
      length: 40,
      stop: "terrain"
    },
    {
      name: "one-way-cover",
      terrain: [{ ...wall(40), kind: "one-way" }],
      targets: [body2(20, 80)],
      hit: [null],
      length: 40,
      stop: "terrain"
    },
    {
      name: "muzzle-overlap",
      terrain: [wall(0)],
      targets: [body2(20, 80)],
      hit: [null],
      length: 0,
      stop: "terrain"
    },
    {
      name: "cover-arriving",
      terrain: [{ ...wall(40, -60), delta: { x: 0, y: pixels(40) } }],
      targets: [body2(20, 80)],
      hit: [null],
      length: 40,
      stop: "terrain"
    },
    {
      name: "cover-departing",
      terrain: [{ ...wall(40), delta: { x: 0, y: pixels(40) } }],
      targets: [body2(20, 80)],
      hit: [20]
    },
    {
      name: "body-arriving",
      targets: [{ ...body2(20, 40, -24), delta: { x: 0, y: pixels(24) } }],
      hit: [20]
    },
    {
      name: "body-crossing-between-samples",
      targets: [{ ...body2(20, 40, -24), delta: { x: 0, y: pixels(48) } }],
      hit: []
    },
    {
      name: "component-deduplication",
      maxTargets: 2,
      targets: [body2(20, 20), { ...body2(20, 22), id: 201 }, body2(21, 30), body2(22, 40)],
      hit: [20, 21],
      length: 30,
      stop: "penetration"
    },
    {
      name: "coincident-order",
      maxTargets: 2,
      targets: [body2(22, 40), body2(21, 40), body2(20, 40)],
      hit: [20, 21],
      length: 40,
      stop: "penetration"
    },
    {
      name: "shield-before-body",
      targets: [body2(20, 40), { ...body2(20, 40), id: 201, kind: "shield" }, body2(21, 60)],
      hit: [20],
      length: 40,
      stop: "shield"
    },
    {
      name: "terrain-before-shield",
      terrain: [wall(40)],
      targets: [body2(20, 40), { ...body2(20, 40), id: 201, kind: "shield" }],
      hit: [null],
      length: 40,
      stop: "terrain"
    },
    {
      name: "exposed-component-before-shield",
      targets: [body2(20, 30), { ...body2(20, 40), id: 201, kind: "shield" }, body2(21, 60)],
      hit: [20],
      length: 40,
      stop: "shield"
    },
    {
      name: "allied-solid",
      targets: [{ ...body2(20, 40), team: 1, solid: true }, body2(21, 60)],
      hit: [20],
      length: 40,
      stop: "solid"
    },
    {
      name: "owner-and-allies",
      targets: [body2(1, 10), { ...body2(20, 20), team: 1 }, body2(21, 60)],
      hit: [21]
    },
    { name: "up", heading: 1, targets: [body2(20, -4, -48)], hit: [20] },
    { name: "down", heading: 2, targets: [body2(20, -4, 40)], hit: [20] },
    { name: "left", heading: 3, targets: [body2(20, -48)], hit: [20] }
  ];
  var charges = [
    {
      name: "held-moving-muzzle",
      anchor: (tick2) => ({ origin: { x: pixels(tick2), y: 0 }, heading: 0 }),
      frame: () => ({ terrain: [], targets: [body2(20, 100)] })
    },
    {
      name: "held-turning-muzzle",
      anchor: (tick2) => ({ origin: zero3, heading: tick2 % 4 }),
      frame: () => ({
        terrain: [],
        targets: [body2(20, 100), body2(21, -4, -108), body2(22, -4, 100), body2(23, -108)]
      })
    },
    {
      name: "short-tap",
      anchor: (tick2) => tick2 === 1 ? { origin: zero3, heading: 0 } : null,
      frame: () => ({ terrain: [], targets: [body2(20, 100)] })
    },
    {
      name: "interrupted-owner",
      anchor: (tick2) => tick2 < 4 ? { origin: zero3, heading: 0 } : null,
      frame: () => ({ terrain: [], targets: [body2(20, 100)] })
    },
    {
      name: "moving-cover-and-target",
      anchor: () => ({ origin: zero3, heading: 0 }),
      frame: (tick2) => ({
        terrain: tick2 === 3 || tick2 === 4 ? [wall(40)] : [],
        targets: [body2(20 + tick2, 100)]
      })
    }
  ];
  function runCharge(study, restored) {
    let beam;
    const frames = [], states = [];
    if (restored) beam = restored;
    else {
      const anchor = study.anchor(1), frame = study.frame(1);
      if (!anchor) throw new Error("Missing charge birth");
      const result = emitBeam(
        source,
        1,
        LASER_ATTACK,
        LASER_PROFILE,
        anchor,
        frame.terrain,
        frame.targets
      );
      beam = result.beam;
      frames.push({ tick: 1, ...result });
    }
    states.push(beam);
    while (beam.tick <= LASER_PROFILE.pulseTicks) {
      const tick2 = beam.tick + 1, frame = study.frame(tick2), before = stateHash(beam);
      const result = stepBeam(
        beam,
        tick2,
        LASER_ATTACK,
        LASER_PROFILE,
        study.anchor(tick2),
        frame.terrain,
        frame.targets
      );
      if (stateHash(beam) !== before) throw new Error(`Mutated prior charge: ${study.name}`);
      frames.push({ tick: tick2, ...result });
      if (!result.beam) return { frames, states, terminalTick: tick2 };
      beam = result.beam;
      states.push(beam);
    }
    throw new Error("Charge outlived its paid pulse interval");
  }
  function beamProof() {
    return {
      scope: "Instantaneous energy-beam geometry and prepaid charge continuation in a deterministic fixture; no room input/ammo, event delivery, durable archive, media or production claim.",
      cases: cases.map((study) => {
        const definition2 = {
          ...LASER_ATTACK,
          maxTargets: study.maxTargets ?? LASER_ATTACK.maxTargets
        };
        const query = (reverse) => castBeam(
          source,
          definition2,
          LASER_PROFILE,
          zero3,
          study.heading ?? 0,
          reverse ? [...study.terrain ?? []].reverse() : study.terrain ?? [],
          reverse ? [...study.targets ?? []].reverse() : study.targets ?? []
        );
        const cast = query(false), hash = stateHash(cast);
        if (stateHash(query(true)) !== hash) throw new Error(`Beam order dependence: ${study.name}`);
        if (stateHash(cast.impacts.map((impact2) => impact2.entityId)) !== stateHash(study.hit) || cast.length !== pixels(study.length ?? 512) || cast.stoppedBy !== (study.stop ?? null))
          throw new Error(`Beam behavioral control failed: ${study.name}`);
        return { name: study.name, hash, cast };
      }),
      charges: charges.map((study) => {
        const result = runCharge(study), restoredTicks = [];
        for (const state of result.states) {
          const restored = JSON.parse(JSON.stringify(state));
          if (stateHash(runCharge(study, restored).frames) !== stateHash(result.frames.filter((frame) => frame.tick > state.tick)))
            throw new Error(`Beam continuation changed: ${study.name}:${state.tick}`);
          restoredTicks.push(state.tick);
        }
        const followupDamage = result.frames.filter((frame) => frame.tick > 1).flatMap((frame) => frame.cast?.impacts ?? []).reduce((sum, impact2) => sum + impact2.damage, 0);
        if (followupDamage !== 0) throw new Error(`Repeated charge damage: ${study.name}`);
        return {
          name: study.name,
          hash: stateHash(result.frames),
          visibleTicks: result.states.length,
          terminalTick: result.terminalTick,
          restoredTicks,
          followupDamage,
          frames: result.frames
        };
      })
    };
  }

  // test/fixtures/campaign-proof.ts
  function required2(value) {
    if (value === void 0) throw new Error("Missing campaign fixture entry");
    return value;
  }
  function campaignPlayers() {
    return [
      footActor(),
      { ...footActor(30), playerId: 2, slot: 1, body: { ...footActor(30).body, id: 2 } }
    ];
  }
  function campaignSpectator(player2) {
    return {
      ...player2,
      life: "spectating",
      health: 0,
      lives: 0,
      bodyPresence: "removed",
      locomotion: "airborne",
      body: {
        ...player2.body,
        vx: 0,
        vy: 0,
        remainderX: 0,
        remainderY: 0,
        grounded: false,
        supportId: null,
        contacts: []
      }
    };
  }
  function campaignCheckpoint(tick2, mission = 1) {
    const shape = FOOT_SHAPES.get(1);
    if (!shape) throw new Error("Missing campaign shape");
    const frame = { tick: tick2, geometryRevision: 1 };
    const index = new CollisionIndex(new CollisionGrid([FOOT_FLOOR]), [], frame);
    return {
      mission,
      id: 1e3 + mission,
      encounterId: 100 + mission,
      requiredEntities: [2e3 + mission],
      entries: new Map(
        [1, 2].map((playerId) => [
          playerId,
          {
            shape,
            index,
            frame,
            fallBoundary: pixels(300),
            anchors: [{ x: pixels((playerId - 1) * 30), y: 0 }]
          }
        ])
      )
    };
  }
  function campaignFinish(tick2, mission = 1, complete = true) {
    const finalEncounter = {
      id: 100 + mission,
      participants: [1, 2],
      members: [
        {
          id: 2e3 + mission,
          required: true,
          critical: true,
          retreatAllowed: false,
          watchdogTicks: 600,
          ambientCleanupTicks: null
        }
      ],
      objectives: [3e3 + mission]
    };
    const lifecycle2 = new EncounterLifecycle(finalEncounter);
    const result = lifecycle2.step(
      lifecycle2.begin(tick2 - 1),
      tick2,
      [
        { sequence: 1, tick: tick2, kind: "activate", id: 2e3 + mission },
        { sequence: 2, tick: tick2, kind: "resolve", id: 2e3 + mission, reason: "killed", killerId: 1 },
        ...complete ? [{ sequence: 3, tick: tick2, kind: "objective", id: 3e3 + mission }] : []
      ],
      []
    );
    return {
      mission,
      missionCount: 3,
      finalEncounter,
      encounter: result.state,
      exit: { x: pixels(-200), y: pixels(-50), w: pixels(400), h: pixels(50) },
      shapes: FOOT_SHAPES
    };
  }
  function campaignProof() {
    let players = campaignPlayers(), state = createCampaign("classic", 1001, 101), tick2 = 1;
    players[1] = campaignSpectator(required2(players[1]));
    const boundaries = [], hashes = [];
    for (let mission = 1; mission <= 3; mission++) {
      state = finishMission(state, players, [1, 2], tick2, campaignFinish(tick2, mission));
      if (state.phase !== (mission === 3 ? "victory" : "intermission"))
        throw new Error("Missing mission boundary");
      hashes.push(stateHash({ state, players, tick: tick2 }));
      if (mission === 3) break;
      const entry = campaignCheckpoint(tick2, mission + 1);
      const transition = stageNextMission(state, players, tick2, entry);
      state = transition.state;
      players = JSON.parse(JSON.stringify(transition.players));
      boundaries.push(transition.boundary);
      for (let step = 0; step < 12; step++) {
        tick2++;
        players = players.map(
          (player2) => stepPlayerLife(player2, tick2, "classic", {
            ...required2(campaignCheckpoint(tick2, mission + 1).entries.get(player2.playerId)),
            definition: required2(FOOT_DEFINITION),
            shapes: FOOT_SHAPES,
            fallBoundary: pixels(300)
          }).actor
        );
      }
      if (mission === 1) {
        players[1] = damagePlayer(required2(players[1]), tick2, 1, "classic", "fall").actor;
        for (let step = 0; step < 30; step++) {
          tick2++;
          players = players.map(
            (player2) => stepPlayerLife(player2, tick2, "classic", {
              ...required2(campaignCheckpoint(tick2, mission + 1).entries.get(player2.playerId)),
              definition: required2(FOOT_DEFINITION),
              shapes: FOOT_SHAPES,
              fallBoundary: pixels(300)
            }).actor
          );
        }
      }
      tick2++;
    }
    return {
      tick: tick2,
      state,
      players,
      boundaries,
      traceHash: stateHash(hashes),
      scope: "Synthetic campaign reducer boundaries; no authored mission traversal or world reset"
    };
  }

  // test/fixtures/collision-proof.ts
  function collisionProof() {
    const samples = Array.from({ length: 256 }, (_, index) => {
      let rng = index + 1;
      const next = (range) => {
        rng = randomStep(rng);
        return rng % range;
      };
      const a = { x: next(80) - 40, y: next(80) - 40, w: next(16) + 1, h: next(16) + 1 };
      const b = { x: next(80) - 40, y: next(80) - 40, w: next(16) + 1, h: next(16) + 1 };
      const da = { x: next(128) - 64, y: next(128) - 64 };
      const db = { x: next(128) - 64, y: next(128) - 64 };
      return { seed: index + 1, solid: sweepAabb(a, da, b, db), oneWay: sweepOneWay(a, da, b, db) };
    });
    const body4 = { x: 0, y: 0, w: 10, h: 10 };
    const ties = earliestSweep(body4, { x: 20, y: 20 }, [
      { id: 9, rect: { x: 20, y: 20, w: 10, h: 10 }, delta: { x: 0, y: 0 }, kind: "solid" },
      { id: 2, rect: { x: 20, y: -10, w: 10, h: 100 }, delta: { x: 0, y: 0 }, kind: "solid" }
    ]);
    return { samples, ties };
  }

  // test/fixtures/combat-proof.ts
  function combatProof() {
    return COMBAT_SCENARIOS.map((scenario) => {
      let world = createCombatLab(scenario, 4), restored = structuredClone(world);
      const hashes = [], shots = [], kills = [];
      let impacts = 0;
      for (let tick2 = 1; tick2 <= 120; tick2++) {
        const inputs = world.players.map(() => ({
          held: tick2 <= 100 ? Held.Fire : 0,
          interactPressed: false,
          grenadePressed: false,
          firePressed: tick2 === 1,
          jumpPressed: false
        }));
        world = stepCombatLab(world, inputs);
        restored = stepCombatLab(restored, inputs);
        if (stateHash(world) !== stateHash(restored))
          throw new Error(`Combat restore mismatch at ${scenario}:${tick2}`);
        if ([1, 13, 37].includes(tick2)) restored = JSON.parse(JSON.stringify(restored));
        hashes.push(stateHash(world));
        shots.push(world.events.filter((event) => event.kind === "shot").length);
        impacts += world.events.filter((event) => event.kind === "impact").length;
        for (const event of world.events)
          if (event.kind === "killed")
            kills.push({ tick: tick2, ownerId: event.ownerId, targetId: event.targetId });
      }
      return {
        scenario,
        ticks: world.tick,
        phase: world.encounter.phase,
        ammo: world.players.map((player2) => player2.weapon.ammo),
        shots: shots.reduce((sum, count) => sum + count, 0),
        impacts,
        kills,
        traceHash: stateHash(hashes),
        finalHash: stateHash(world)
      };
    });
  }

  // test/fixtures/combat-reconnect-proof.ts
  function recordCombatReconnect(reconnectingSlot = 0) {
    let state = createCombatRuntime();
    const states = [structuredClone(state)], entries = [];
    const streams = state.combat.players.map(
      (p) => new InputStream({ ...probeContext(p.slot), controlEpoch: 1, baselineServerTick: 0 })
    );
    for (let tick2 = 1; tick2 <= 45; tick2++) {
      if (tick2 === 3)
        streams[reconnectingSlot] = new InputStream({
          ...probeContext(reconnectingSlot),
          connectionEpoch: reconnectingSlot + 2,
          controlEpoch: 1,
          baselineServerTick: 2
        });
      for (const [slot, stream] of streams.entries()) {
        if (tick2 === 3 && slot === reconnectingSlot) continue;
        const sequence = slot === reconnectingSlot && tick2 > 3 ? tick2 - 3 : tick2;
        stream.receive(
          encodeInputBatch({
            ...probeContext(slot),
            connectionEpoch: stream.acknowledgment.connectionEpoch,
            packetSequence: sequence,
            snapshotAck: 0,
            eventAck: 0,
            commands: [
              {
                sequence,
                clientTick: sequence - 1,
                controlEpoch: 1,
                held: Held.Fire,
                aim: 0,
                edges: []
              }
            ]
          }),
          tick2 * 16,
          tick2 - 1
        );
      }
      let entry;
      const committed = InputStream.processWorldTick(streams, tick2, tick2 * 16, (prepared) => {
        const candidate = stageCombatRuntime(
          state,
          prepared,
          tick2 === 3 ? [{ playerId: reconnectingSlot + 1, connectionEpoch: reconnectingSlot + 2 }] : []
        );
        entry = candidate.journal;
        return candidate;
      });
      if (!entry) throw new Error("Missing reconnect journal");
      if (canonical(replayCombatTick(state, entry)) !== canonical(committed.state))
        throw new Error("Reconnect replay changed accepted continuation");
      state = committed.state;
      entries.push(entry);
      states.push(structuredClone(state));
      if (tick2 === 3)
        streams[reconnectingSlot] = new InputStream({
          ...probeContext(reconnectingSlot),
          connectionEpoch: reconnectingSlot + 2,
          controlEpoch: 1,
          baselineServerTick: 3
        });
    }
    return { states, entries };
  }
  function combatReconnectProof() {
    const { states, entries } = recordCombatReconnect();
    const before = states[2], after = states[3], last = states[45];
    if (!before || !after || !last) throw new Error("Missing reconnect boundaries");
    if (before.combat.players[0]?.action.kind !== "fire" || before.combat.players[0]?.action.actionInstanceId !== after.combat.players[0]?.action.actionInstanceId)
      throw new Error("Reconnect restarted an active action");
    return {
      transitionTick: 3,
      beforeActor: before.combat.players[0],
      afterActor: after.combat.players[0],
      acknowledgments: after.snapshot.acknowledgments,
      boundaryEvents: entries[2]?.boundaryEvents,
      continuedTick: last.combat.tick,
      finalHash: combatRuntimeHash(last),
      journalHash: stateHash(entries)
    };
  }

  // src/game/content/compiled/navigation.json
  var navigation_default = {
    format: 1,
    compiler: "edgefall-ldtk-1",
    editorSchema: "1.5.3",
    contentHash: "a6434f8f6468122005419e4c88336a3e6dbf29547ca01ed1057b818514c2dbb6",
    graphicsHash: "8523df73611d93e17ef71e49e31839cfac6fb97ba022b330e87793f6b447b47a",
    gameplay: {
      format: 1,
      simulationHz: 60,
      dimensions: {
        w: 128e3,
        h: 102400
      },
      definitions: {
        format: 1,
        simulationHz: 60,
        shapes: [
          {
            id: 1,
            rect: {
              x: -1792,
              y: -8704,
              w: 3584,
              h: 8704
            }
          },
          {
            id: 2,
            rect: {
              x: -1792,
              y: -5120,
              w: 3584,
              h: 5120
            }
          },
          {
            id: 3,
            rect: {
              x: -1280,
              y: -8192,
              w: 2560,
              h: 7680
            }
          },
          {
            id: 4,
            rect: {
              x: -256,
              y: -256,
              w: 512,
              h: 512
            }
          },
          {
            id: 5,
            rect: {
              x: -10240,
              y: -8192,
              w: 20480,
              h: 8192
            }
          },
          {
            id: 6,
            rect: {
              x: -6144,
              y: -7680,
              w: 12288,
              h: 7680
            }
          }
        ],
        poses: [
          {
            id: 1,
            frame: "fixture-operative-idle",
            durationTicks: 6,
            sockets: [
              {
                name: "muzzle",
                point: {
                  x: 3840,
                  y: -5888
                }
              },
              {
                name: "hand",
                point: {
                  x: 2560,
                  y: -5120
                }
              }
            ],
            hurtShapeIds: [
              3
            ]
          },
          {
            id: 2,
            frame: "fixture-tank-idle",
            durationTicks: 12,
            sockets: [
              {
                name: "seat",
                point: {
                  x: 0,
                  y: -5120
                }
              },
              {
                name: "ejection",
                point: {
                  x: -10240,
                  y: 0
                }
              }
            ],
            hurtShapeIds: [
              6
            ]
          }
        ],
        timelines: [
          {
            id: 1,
            durationTicks: 6,
            poses: [
              1
            ],
            markers: [
              {
                tickOffset: 0,
                kind: "spawn-attack",
                payloadId: 1,
                socket: "muzzle"
              }
            ]
          },
          {
            id: 2,
            durationTicks: 12,
            poses: [
              2
            ],
            markers: [
              {
                tickOffset: 11,
                kind: "seat-transfer",
                payloadId: 1,
                socket: "seat"
              }
            ]
          }
        ],
        attacks: [
          {
            id: 1,
            kind: "swept-projectile",
            shapeId: 4,
            damage: 1,
            lifetimeTicks: 30,
            speed: 3072,
            maxTargets: 1,
            repeatDamageTicks: 0,
            material: "bullet"
          }
        ],
        weapons: [
          {
            id: "sidearm",
            attackId: 1,
            timelineId: 1,
            cadenceTicks: 10,
            ammoPerAction: 0,
            pickupAmmo: "unlimited",
            aimPolicy: "cardinal",
            visualFamily: "fixture-sidearm",
            audioFamily: "fixture-sidearm"
          }
        ],
        actors: [
          {
            id: 1,
            locomotion: "grounded",
            standingShapeId: 1,
            crouchedShapeId: 2,
            idlePoseId: 1,
            runSpeed: 768,
            jumpVelocity: -1430,
            gravity: 55,
            terminalVelocity: 2048
          },
          {
            id: 2,
            locomotion: "grounded",
            standingShapeId: 6,
            crouchedShapeId: 6,
            idlePoseId: 2,
            runSpeed: 640,
            jumpVelocity: -1200,
            gravity: 60,
            terminalVelocity: 2048
          }
        ],
        vehicles: [
          {
            id: 1,
            kind: "tank",
            actorId: 2,
            armor: 3,
            weaponId: "sidearm",
            seat: {
              socket: {
                x: 0,
                y: -5120
              },
              ejectionCandidates: [
                {
                  x: -10240,
                  y: 0
                },
                {
                  x: 10240,
                  y: 0
                }
              ],
              boardingSensorShapeId: 5,
              boardingTimelineId: 2
            }
          }
        ]
      },
      terrain: [
        {
          id: 1501,
          kind: "solid",
          rect: {
            x: 0,
            y: 76800,
            w: 25600,
            h: 10240
          },
          delta: {
            x: 0,
            y: 0
          }
        },
        {
          id: 1514,
          kind: "solid",
          rect: {
            x: 33280,
            y: 76800,
            w: 30720,
            h: 10240
          },
          delta: {
            x: 0,
            y: 0
          }
        },
        {
          id: 1529,
          kind: "solid",
          rect: {
            x: 71680,
            y: 76800,
            w: 56320,
            h: 10240
          },
          delta: {
            x: 0,
            y: 0
          }
        }
      ],
      camera: {
        x: 0,
        y: 0,
        w: 128e3,
        h: 92160
      },
      killBounds: {
        x: 0,
        y: 0,
        w: 128e3,
        h: 102400
      },
      exit: {
        x: 94720,
        y: 66560,
        w: 5120,
        h: 10240
      },
      entry: {
        actorId: 1,
        actor: {
          body: {
            id: 1e6,
            x: 12800,
            y: 76800,
            vx: 0,
            vy: 0,
            remainderX: 0,
            remainderY: 0,
            shapeId: 1,
            supportId: 1501,
            grounded: true,
            contacts: []
          },
          life: "alive",
          locomotion: "grounded",
          action: {
            kind: "ready",
            actionInstanceId: 0,
            stateStartTick: 0,
            definitionId: 0,
            nextMarkerIndex: 0
          },
          facing: 1,
          aim: 0,
          jumpBufferTicks: 0,
          coyoteTicks: 4,
          ignoredSupportId: null,
          ignoredSupportTicks: 0,
          vehicleId: null,
          geometryRevision: 1
        }
      },
      checkpoint: {
        x: 97280,
        y: 76800,
        facing: 1
      },
      spawns: [
        {
          actorId: 1,
          actor: {
            body: {
              id: 1000007,
              x: 20480,
              y: 76800,
              vx: 0,
              vy: 0,
              remainderX: 0,
              remainderY: 0,
              shapeId: 1,
              supportId: 1501,
              grounded: true,
              contacts: []
            },
            life: "alive",
            locomotion: "grounded",
            action: {
              kind: "ready",
              actionInstanceId: 0,
              stateStartTick: 0,
              definitionId: 0,
              nextMarkerIndex: 0
            },
            facing: 1,
            aim: 0,
            jumpBufferTicks: 0,
            coyoteTicks: 4,
            ignoredSupportId: null,
            ignoredSupportTicks: 0,
            vehicleId: null,
            geometryRevision: 1
          }
        }
      ],
      links: [
        {
          actorId: 1,
          actor: {
            body: {
              id: 1000005,
              x: 12800,
              y: 76800,
              vx: 0,
              vy: 0,
              remainderX: 0,
              remainderY: 0,
              shapeId: 1,
              supportId: 1501,
              grounded: true,
              contacts: []
            },
            life: "alive",
            locomotion: "grounded",
            action: {
              kind: "ready",
              actionInstanceId: 0,
              stateStartTick: 0,
              definitionId: 0,
              nextMarkerIndex: 0
            },
            facing: 1,
            aim: 0,
            jumpBufferTicks: 0,
            coyoteTicks: 4,
            ignoredSupportId: null,
            ignoredSupportTicks: 0,
            vehicleId: null,
            geometryRevision: 1
          },
          definition: {
            id: 1000005,
            kind: "jump",
            sourceSpanId: 4,
            sourceX: 12800,
            destinationSpanId: 5,
            destinationMinX: 51968,
            destinationMaxX: 51968,
            direction: 1,
            maxTicks: 90
          }
        },
        {
          actorId: 1,
          actor: {
            body: {
              id: 1000006,
              x: 51200,
              y: 76800,
              vx: 0,
              vy: 0,
              remainderX: 0,
              remainderY: 0,
              shapeId: 1,
              supportId: 1514,
              grounded: true,
              contacts: []
            },
            life: "alive",
            locomotion: "grounded",
            action: {
              kind: "ready",
              actionInstanceId: 0,
              stateStartTick: 0,
              definitionId: 0,
              nextMarkerIndex: 0
            },
            facing: 1,
            aim: 0,
            jumpBufferTicks: 0,
            coyoteTicks: 4,
            ignoredSupportId: null,
            ignoredSupportTicks: 0,
            vehicleId: null,
            geometryRevision: 1
          },
          definition: {
            id: 1000006,
            kind: "jump",
            sourceSpanId: 5,
            sourceX: 51200,
            destinationSpanId: 6,
            destinationMinX: 90368,
            destinationMaxX: 90368,
            direction: 1,
            maxTicks: 90
          }
        }
      ],
      route: {
        status: "route",
        geometryRevision: 1,
        from: {
          x: 12800,
          y: 76800,
          facing: 1
        },
        destination: {
          x: 97280,
          y: 76800,
          facing: 1
        },
        shapeId: 1,
        costTicks: 117,
        linkIds: [
          1000005,
          1000006
        ],
        legs: [
          {
            kind: "settle",
            ticks: 1
          },
          {
            kind: "traverse",
            linkId: 1000005,
            ticks: 51
          },
          {
            kind: "walk",
            direction: -1,
            ticks: 1
          },
          {
            kind: "walk",
            direction: -1,
            ticks: 1
          },
          {
            kind: "walk",
            direction: 1,
            ticks: 1
          },
          {
            kind: "settle",
            ticks: 1
          },
          {
            kind: "traverse",
            linkId: 1000006,
            ticks: 51
          },
          {
            kind: "walk",
            direction: 1,
            ticks: 9
          },
          {
            kind: "settle",
            ticks: 1
          }
        ]
      }
    },
    presentation: {
      format: 1,
      tileset: {
        id: 20,
        path: "terrain.png",
        width: 10,
        height: 10,
        cell: 10
      },
      tiles: [
        {
          x: 0,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 10,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 20,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 30,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 40,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 50,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 60,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 70,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 80,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 90,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 130,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 140,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 150,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 160,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 170,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 180,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 190,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 200,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 210,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 220,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 230,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 240,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 280,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 290,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 300,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 310,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 320,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 330,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 340,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 350,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 360,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 370,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 380,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 390,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 400,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 410,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 420,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 430,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 440,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 450,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 460,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 470,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 480,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 490,
          y: 300,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 0,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 10,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 20,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 30,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 40,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 50,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 60,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 70,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 80,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 90,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 130,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 140,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 150,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 160,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 170,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 180,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 190,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 200,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 210,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 220,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 230,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 240,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 280,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 290,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 300,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 310,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 320,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 330,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 340,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 350,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 360,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 370,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 380,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 390,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 400,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 410,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 420,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 430,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 440,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 450,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 460,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 470,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 480,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 490,
          y: 310,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 0,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 10,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 20,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 30,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 40,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 50,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 60,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 70,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 80,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 90,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 130,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 140,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 150,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 160,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 170,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 180,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 190,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 200,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 210,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 220,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 230,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 240,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 280,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 290,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 300,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 310,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 320,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 330,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 340,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 350,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 360,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 370,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 380,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 390,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 400,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 410,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 420,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 430,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 440,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 450,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 460,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 470,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 480,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 490,
          y: 320,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 0,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 10,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 20,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 30,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 40,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 50,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 60,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 70,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 80,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 90,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 130,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 140,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 150,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 160,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 170,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 180,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 190,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 200,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 210,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 220,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 230,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 240,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 280,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 290,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 300,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 310,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 320,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 330,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 340,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 350,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 360,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 370,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 380,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 390,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 400,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 410,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 420,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 430,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 440,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 450,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 460,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 470,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 480,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        },
        {
          x: 490,
          y: 330,
          sx: 0,
          sy: 0,
          flip: 0,
          tile: 0
        }
      ],
      assetSha256: "db04ec948db7f056562d9e8bef0c029dd98bf630f9d1a60708cebcdea764e627"
    },
    buildHash: "e7042cbe2114695b232b5958580c5e3bd881da7f5adbe528f7e38ff3f7ae9688"
  };

  // src/game/navigation/follower.ts
  function point2(actor) {
    return { x: actor.body.x, y: actor.body.y, facing: actor.facing };
  }
  function same(a, b) {
    return a.x === b.x && a.y === b.y && a.facing === b.facing;
  }
  function ready(actor) {
    return actor.life === "alive" && actor.vehicleId === null && actor.action.kind === "ready";
  }
  var RouteFollower = class {
    geometryRevision;
    poses;
    #graph;
    #legs;
    #offsets;
    #shapes;
    constructor(graph, route, shapes2) {
      graph.surface.assertRevision(route.geometryRevision);
      if (route.shapeId !== graph.surface.shapeId || !shapes2.has(route.shapeId))
        throw new Error("Route shape mismatch");
      integer(route.legs.length, 1, 3600, "route leg count");
      integer(shapes2.size, 1, 4096, "route shape count");
      integer(route.costTicks, 1, 3600, "route duration");
      this.geometryRevision = route.geometryRevision;
      this.#graph = graph;
      this.#legs = Object.freeze(route.legs.map((leg) => Object.freeze({ ...leg })));
      this.#shapes = new Map(
        [...shapes2].map(([id2, shape]) => [
          id2,
          Object.freeze({ ...shape, rect: Object.freeze({ ...shape.rect }) })
        ])
      );
      const poses = [Object.freeze({ x: route.from.x, y: route.from.y, facing: route.from.facing })];
      const offsets = [];
      for (const leg of this.#legs) {
        integer(leg.ticks, 1, 3600, "route leg duration");
        offsets.push(poses.length - 1);
        const from = poses.at(-1);
        if (!from) throw new Error("Missing route source");
        if (leg.kind === "traverse") {
          const link = graph.link(leg.linkId);
          const launch = link?.poses[0];
          if (!link || !launch || !same(from, launch) || leg.ticks !== link.commands.length)
            throw new Error("Route link mismatch");
          for (const pose of link.poses.slice(1))
            poses.push(Object.freeze({ x: pose.x, y: pose.y, facing: pose.facing }));
        } else {
          if (leg.kind !== "walk" && leg.kind !== "settle") throw new Error("Invalid route leg");
          if (leg.kind === "settle" && leg.ticks !== 1) throw new Error("Invalid settle duration");
          const facing2 = leg.kind === "walk" ? leg.direction : from.facing;
          if (facing2 !== -1 && facing2 !== 1) throw new Error("Invalid route direction");
          const x = position(
            from.x + (leg.kind === "walk" ? leg.direction * graph.actorDefinition.runSpeed * leg.ticks : 0)
          );
          const span = graph.surface.locate(from.x, from.y, facing2, this.geometryRevision);
          if (!span || x < span.minX || x > span.maxX)
            throw new Error("Route walk lacks continuous clearance");
          for (let i = 1; i <= leg.ticks; i++)
            poses.push(
              Object.freeze({
                x: position(
                  from.x + (leg.kind === "walk" ? i * leg.direction * graph.actorDefinition.runSpeed : 0)
                ),
                y: from.y,
                facing: facing2
              })
            );
        }
        if (poses.length > 3601) throw new Error("Route proof exceeds duration bound");
      }
      const last = poses.at(-1);
      if (!last || !same(last, route.destination) || poses.length !== route.costTicks + 1)
        throw new Error("Route destination/duration mismatch");
      this.#offsets = Object.freeze(offsets);
      this.poses = Object.freeze(poses);
      Object.freeze(this);
    }
    begin(actor, startTick) {
      integer(startTick, 0, COUNTER_LIMIT - 3602, "route start tick");
      const source3 = this.poses[0];
      if (!source3 || !ready(actor) || !actor.body.grounded || actor.body.vx !== 0 || actor.body.vy !== 0 || actor.body.shapeId !== this.#graph.surface.shapeId || actor.geometryRevision !== this.geometryRevision || !same(point2(actor), source3))
        throw new Error("Route source mismatch");
      return { startTick, elapsed: 0, legIndex: 0, legElapsed: 0, traversal: null };
    }
    step(actor, cursor, index, frame) {
      index.assertFrame(frame);
      integer(cursor.startTick, 0, COUNTER_LIMIT - 3602, "route start tick");
      integer(cursor.elapsed, 0, this.poses.length - 2, "route elapsed");
      integer(cursor.legIndex, 0, this.#legs.length - 1, "route leg index");
      const leg = this.#legs[cursor.legIndex];
      if (!leg) throw new Error("Missing route leg");
      integer(cursor.legElapsed, 0, leg.ticks - 1, "route leg elapsed");
      if (frame.tick !== cursor.startTick + cursor.elapsed + 1 || cursor.elapsed !== (this.#offsets[cursor.legIndex] ?? -1) + cursor.legElapsed || leg.kind !== "traverse" && cursor.traversal !== null)
        throw new Error("Route tick/cursor mismatch");
      const expected = this.poses[cursor.elapsed];
      let reason = frame.geometryRevision !== this.geometryRevision || actor.geometryRevision !== frame.geometryRevision ? "geometry" : !expected || !same(point2(actor), expected) || !ready(actor) ? "state" : null;
      let result;
      let traversal = cursor.traversal;
      if (!reason && leg.kind === "traverse") {
        const link = this.#graph.link(leg.linkId);
        if (!link) throw new Error("Missing route link");
        if (!traversal) {
          if (cursor.legElapsed !== 0) throw new Error("Missing active link cursor");
          try {
            traversal = link.begin(actor, frame.tick - 1);
          } catch {
            reason = "launch";
          }
        } else if (traversal.elapsed !== cursor.legElapsed || traversal.startTick !== cursor.startTick + (this.#offsets[cursor.legIndex] ?? -1))
          throw new Error("Route/link cursor mismatch");
        if (traversal && !reason) {
          const progress = link.step(actor, traversal, index, frame);
          result = progress.result;
          traversal = progress.status === "failed" ? null : progress.cursor;
          if (progress.status === "cancelled") reason = progress.reason;
        } else result = this.#neutral(actor, index, frame);
      } else {
        result = reason ? this.#neutral(actor, index, frame) : stepFootController(
          actor,
          {
            held: leg.kind === "walk" ? leg.direction === 1 ? Held.Right : Held.Left : 0,
            jumpPressed: false
          },
          this.#graph.actorDefinition,
          this.#shapes,
          index,
          frame
        );
      }
      if (result.status === "failed") return { status: "failed", result };
      const after = this.poses[cursor.elapsed + 1];
      if (!reason && (!after || !same(point2(result.actor), after))) reason = "trajectory";
      if (reason || result.status !== "complete")
        return {
          status: "cancelled",
          reason: reason ?? "state",
          actor: result.actor,
          cursor: null,
          result
        };
      const elapsed = cursor.elapsed + 1;
      const nextLeg = cursor.legElapsed + 1 === leg.ticks;
      const done = elapsed === this.poses.length - 1;
      return {
        status: done ? "arrived" : "active",
        actor: result.actor,
        cursor: done ? null : {
          ...cursor,
          elapsed,
          legIndex: cursor.legIndex + Number(nextLeg),
          legElapsed: nextLeg ? 0 : cursor.legElapsed + 1,
          traversal
        },
        result
      };
    }
    #neutral(actor, index, frame) {
      return stepFootController(
        { ...actor, geometryRevision: frame.geometryRevision, jumpBufferTicks: 0 },
        { held: 0, jumpPressed: false },
        this.#graph.actorDefinition,
        this.#shapes,
        index,
        frame
      );
    }
  };

  // src/game/navigation/graph.ts
  function compare2(a, b) {
    if (a.cost !== b.cost) return a.cost - b.cost;
    for (let i = 0; i < Math.min(a.ids.length, b.ids.length); i++) {
      const ai = a.ids[i], bi = b.ids[i];
      if (ai !== void 0 && bi !== void 0 && ai !== bi) return ai - bi;
    }
    return a.ids.length - b.ids.length;
  }
  function validate4(point3) {
    position(point3.x);
    position(point3.y);
    if (point3.facing !== -1 && point3.facing !== 1) throw new Error("Invalid route facing");
  }
  var NavigationGraph = class {
    constructor(surface, definition2, links) {
      this.surface = surface;
      if (definition2.locomotion !== "grounded")
        throw new Error("Navigation requires grounded locomotion");
      this.actorDefinition = Object.freeze({ ...definition2 });
      integer(links.length, 0, 256, "navigation link count");
      this.#speed = integer(definition2.runSpeed, 1, 2 ** 16, "navigation run speed");
      if (surface.shapeId !== definition2.standingShapeId)
        throw new Error("Graph actor shape mismatch");
      if (new Set(links.map((link) => link.id)).size !== links.length)
        throw new Error("Duplicate navigation link ID");
      const policy = canonical(definition2);
      for (const link of links) {
        if (link.surface !== surface || link.geometryRevision !== surface.geometryRevision || canonical(link.actorDefinition) !== policy)
          throw new Error("Link belongs to a different compiled surface or movement policy");
      }
      this.#links = Object.freeze([...links].sort((a, b) => a.id - b.id));
      const buckets = /* @__PURE__ */ new Map();
      for (const span of surface.spans) {
        const key = `${span.y}:${span.facing}`;
        const bucket = buckets.get(key) ?? [];
        bucket.push(span);
        buckets.set(key, bucket);
      }
      for (const [key, bucket] of buckets)
        this.#planes.set(key, Object.freeze(bucket.sort((a, b) => a.minX - b.minX)));
      Object.freeze(this);
    }
    surface;
    #planes = /* @__PURE__ */ new Map();
    #links;
    #speed;
    actorDefinition;
    link(id2) {
      return this.#links.find((link) => link.id === id2);
    }
    #span(point3) {
      const spans = this.#planes.get(`${point3.y}:${point3.facing}`) ?? [];
      let low = 0, high = spans.length;
      while (low < high) {
        const mid = Math.floor((low + high) / 2);
        const span2 = spans[mid];
        if (span2 && span2.minX <= point3.x) low = mid + 1;
        else high = mid;
      }
      const span = spans[low - 1];
      return span && point3.x <= span.maxX ? span : null;
    }
    #walk(from, x, direction) {
      const span = this.#span({ ...from, facing: direction });
      if (!span || x < span.minX || x > span.maxX) return null;
      const distance = Math.abs(x - from.x);
      if (distance % this.#speed !== 0) return null;
      return { kind: "walk", direction, ticks: distance / this.#speed };
    }
    #approach(from, to) {
      if (from.y !== to.y || !this.#span(to)) return null;
      const legs = [];
      let point3 = { ...from };
      if (point3.x !== to.x) {
        const direction = point3.x < to.x ? 1 : -1;
        const walk = this.#walk(point3, to.x, direction);
        if (!walk) return null;
        legs.push(walk);
        point3 = { ...to, facing: direction };
      }
      if (point3.facing !== to.facing) {
        const away = -to.facing;
        const x = to.x + away * this.#speed;
        const outward = this.#walk(point3, x, away);
        const inward = this.#walk({ ...point3, x, facing: away }, to.x, to.facing);
        if (!outward || !inward) return null;
        legs.push(outward, inward);
      }
      legs.push({ kind: "settle", ticks: 1 });
      return legs;
    }
    route(from, destination, revision, maxTicks = 3600) {
      this.surface.assertRevision(revision);
      validate4(from);
      validate4(destination);
      integer(maxTicks, 1, 3600, "route tick budget");
      if (!this.#span(from) || !this.#span(destination))
        return { status: "unreachable", reason: "outside-surface" };
      const initial = { node: 0, point: from, cost: 0, ids: [], legs: [] };
      const best = /* @__PURE__ */ new Map([[0, initial]]);
      const queue = /* @__PURE__ */ new Map([[0, initial]]);
      const settled = /* @__PURE__ */ new Set();
      let finish = null;
      const spans = new Map(this.surface.spans.map((span) => [span.id, span]));
      while (queue.size) {
        const current = [...queue.values()].sort((a, b) => compare2(a, b) || a.node - b.node)[0];
        if (!current) break;
        queue.delete(current.node);
        settled.add(current.node);
        if (!current || best.get(current.node) !== current || finish && current.cost > finish.cost)
          continue;
        const end = this.#approach(current.point, destination);
        if (end) {
          const candidate = {
            ...current,
            point: destination,
            cost: current.cost + end.reduce((sum, leg) => sum + leg.ticks, 0),
            legs: [...current.legs, ...end]
          };
          if (candidate.cost <= maxTicks && (!finish || compare2(candidate, finish) < 0))
            finish = candidate;
        }
        for (const link of this.#links) {
          if (settled.has(link.id)) continue;
          const source3 = spans.get(link.definition.sourceSpanId);
          const landing = link.poses.at(-1);
          if (!source3 || !landing) throw new Error("Missing compiled route endpoint");
          const approach = this.#approach(current.point, {
            x: link.definition.sourceX,
            y: source3.y,
            facing: source3.facing
          });
          if (!approach) continue;
          const cost = current.cost + approach.reduce((sum, leg) => sum + leg.ticks, 0) + link.commands.length;
          if (cost > maxTicks) continue;
          const candidate = {
            node: link.id,
            point: landing,
            cost,
            ids: [...current.ids, link.id],
            legs: [
              ...current.legs,
              ...approach,
              { kind: "traverse", linkId: link.id, ticks: link.commands.length }
            ]
          };
          const previous = best.get(link.id);
          if (!previous || compare2(candidate, previous) < 0) {
            best.set(link.id, candidate);
            queue.set(link.id, candidate);
          }
        }
      }
      return finish ? {
        status: "route",
        geometryRevision: revision,
        from: { ...from },
        destination: { ...destination },
        shapeId: this.surface.shapeId,
        costTicks: finish.cost,
        linkIds: finish.ids,
        legs: finish.legs
      } : { status: "unreachable", reason: "no-route" };
    }
  };

  // src/game/navigation/spans.ts
  var MAX_SPANS = 8192;
  var MAX_CLEARANCE_CHECKS = 1e6;
  var WalkSurface = class {
    spans;
    shapeId;
    geometryRevision;
    constructor(targets2, shape, geometryRevision) {
      integer(geometryRevision, 1, COUNTER_LIMIT - 1, "navigation revision");
      integer(shape.id, 1, COUNTER_LIMIT - 1, "navigation shape");
      validateLocalRect(shape.rect);
      if (shape.rect.y + shape.rect.h !== 0)
        throw new Error("Navigation requires a feet-anchored collider");
      const grid2 = new CollisionGrid(targets2);
      if (grid2.hasMotion) throw new Error("Static navigation cannot compile moving terrain");
      this.shapeId = shape.id;
      this.geometryRevision = geometryRevision;
      const planes = /* @__PURE__ */ new Map();
      for (const target of grid2.targets) {
        const plane = planes.get(target.rect.y) ?? [];
        plane.push(target);
        planes.set(target.rect.y, plane);
      }
      const spans = [];
      let checks = 0;
      for (const [y, plane] of [...planes].sort(([a], [b]) => a - b)) {
        const unions = [];
        for (const target of plane.sort((a, b) => a.rect.x - b.rect.x || a.id - b.id)) {
          const last = unions.at(-1);
          if (last && target.rect.x <= last.end) {
            last.end = Math.max(last.end, target.rect.x + target.rect.w);
            last.targets.push(target);
          } else
            unions.push({
              start: target.rect.x,
              end: target.rect.x + target.rect.w,
              targets: [target]
            });
        }
        for (const facing2 of [-1, 1]) {
          const localX = facing2 === 1 ? shape.rect.x : -shape.rect.x - shape.rect.w;
          if (y + shape.rect.y < -MAX_POSITION) continue;
          for (const union of unions) {
            let intervals = [
              {
                start: Math.max(union.start - localX, -MAX_POSITION),
                end: Math.min(union.end - localX - shape.rect.w, MAX_POSITION)
              }
            ];
            const range = intervals[0];
            if (!range || range.start > range.end) continue;
            const obstacles = grid2.query({
              minX: union.start,
              maxX: union.end,
              minY: y + shape.rect.y,
              maxY: y
            });
            for (const obstacle of obstacles) {
              checks += Math.max(1, intervals.length);
              if (checks > MAX_CLEARANCE_CHECKS)
                throw new Error("Navigation clearance work exceeds bound");
              if (obstacle.kind !== "solid" || obstacle.rect.y >= y || obstacle.rect.y + obstacle.rect.h <= y + shape.rect.y)
                continue;
              const firstBlocked = obstacle.rect.x - localX - shape.rect.w + 1;
              const lastBlocked = obstacle.rect.x + obstacle.rect.w - localX - 1;
              intervals = intervals.flatMap((interval) => {
                if (lastBlocked < interval.start || firstBlocked > interval.end) return [interval];
                const kept = [];
                if (interval.start < firstBlocked)
                  kept.push({ start: interval.start, end: firstBlocked - 1 });
                if (interval.end > lastBlocked)
                  kept.push({ start: lastBlocked + 1, end: interval.end });
                return kept;
              });
            }
            for (const interval of intervals) {
              if (spans.length >= MAX_SPANS) throw new Error("Navigation span count exceeds bound");
              checks += union.targets.length;
              if (checks > MAX_CLEARANCE_CHECKS)
                throw new Error("Navigation provenance work exceeds bound");
              const supportIds = union.targets.filter(
                (target) => target.rect.x < interval.end + localX + shape.rect.w && target.rect.x + target.rect.w > interval.start + localX
              ).map((target) => target.id).sort((a, b) => a - b);
              spans.push(
                Object.freeze({
                  id: spans.length + 1,
                  facing: facing2,
                  y,
                  minX: interval.start,
                  maxX: interval.end,
                  supportIds: Object.freeze(supportIds)
                })
              );
            }
          }
        }
      }
      this.spans = Object.freeze(spans);
      Object.freeze(this);
    }
    assertRevision(revision) {
      if (revision !== this.geometryRevision) throw new Error("Stale navigation geometry revision");
    }
    locate(x, y, facing2, revision) {
      this.assertRevision(revision);
      position(x);
      position(y);
      if (facing2 !== -1 && facing2 !== 1) throw new Error("Invalid navigation facing");
      return this.spans.find(
        (span) => span.facing === facing2 && span.y === y && x >= span.minX && x <= span.maxX
      ) ?? null;
    }
  };

  // src/game/navigation/links.ts
  function continuation(actor) {
    const { id: _id, contacts: _contacts, ...body4 } = actor.body;
    return canonical({
      body: body4,
      facing: actor.facing,
      aim: actor.aim,
      locomotion: actor.locomotion,
      jumpBufferTicks: actor.jumpBufferTicks,
      coyoteTicks: actor.coyoteTicks,
      ignoredSupportId: actor.ignoredSupportId,
      ignoredSupportTicks: actor.ignoredSupportTicks
    });
  }
  function ready2(actor) {
    return actor.life === "alive" && actor.vehicleId === null && actor.action.kind === "ready";
  }
  var CompiledTraversal = class {
    id;
    geometryRevision;
    definition;
    commands;
    poses;
    #samples;
    actorDefinition;
    surface;
    #shapes;
    constructor(authored, sourceActor, actorDefinition, shapes2, targets2, surface) {
      for (const id2 of [authored.id, authored.sourceSpanId, authored.destinationSpanId])
        integer(id2, 1, COUNTER_LIMIT - 1, "traversal ID");
      integer(shapes2.size, 1, 4096, "traversal shape count");
      integer(authored.maxTicks, 1, 180, "traversal duration");
      integer(authored.direction, -1, 1, "traversal direction");
      if (authored.kind !== "jump" && authored.kind !== "drop")
        throw new Error("Unknown traversal kind");
      for (const x of [authored.sourceX, authored.destinationMinX, authored.destinationMaxX])
        position(x);
      surface.assertRevision(sourceActor.geometryRevision);
      const standing = shapes2.get(actorDefinition.standingShapeId);
      if (!standing || surface.shapeId !== standing.id) throw new Error("Traversal shape mismatch");
      const grid2 = new CollisionGrid(targets2);
      if (grid2.hasMotion) throw new Error("Static traversal cannot compile moving terrain");
      if (canonical(new WalkSurface(targets2, standing, surface.geometryRevision).spans) !== canonical(surface.spans))
        throw new Error("Traversal surface/geometry mismatch");
      const from = surface.locate(
        sourceActor.body.x,
        sourceActor.body.y,
        sourceActor.facing,
        surface.geometryRevision
      );
      const destination = surface.spans.find((span) => span.id === authored.destinationSpanId);
      const facing2 = authored.direction === 0 ? sourceActor.facing : authored.direction;
      if (!from || from.id !== authored.sourceSpanId || sourceActor.body.x !== authored.sourceX || !destination || destination.facing !== facing2 || authored.destinationMinX < destination.minX || authored.destinationMaxX > destination.maxX || authored.destinationMinX > authored.destinationMaxX)
        throw new Error("Invalid traversal endpoints");
      const initialFrame = { tick: 0, geometryRevision: surface.geometryRevision };
      const initialIndex = new CollisionIndex(grid2, [], initialFrame);
      if (!ready2(sourceActor) || sourceActor.locomotion !== "grounded" || sourceActor.body.shapeId !== standing.id || !sourceActor.body.grounded || sourceActor.body.vx !== 0 || sourceActor.body.vy !== 0 || sourceActor.body.remainderX !== 0 || sourceActor.body.remainderY !== 0 || sourceActor.jumpBufferTicks !== 0 || sourceActor.ignoredSupportId !== null || sourceActor.ignoredSupportTicks !== 0 || sourceActor.body.supportId === null || startSupport(
        sourceActor.body,
        standing,
        sourceActor.facing,
        initialIndex,
        initialFrame,
        null
      ) !== sourceActor.body.supportId)
        throw new Error("Traversal source is not a neutral supported actor");
      if (authored.kind === "drop" && (initialIndex.get(sourceActor.body.supportId)?.kind !== "one-way" || destination.y <= from.y))
        throw new Error("Drop requires a one-way source and lower destination");
      this.surface = surface;
      this.id = authored.id;
      this.geometryRevision = surface.geometryRevision;
      this.definition = Object.freeze({ ...authored });
      this.actorDefinition = Object.freeze({ ...actorDefinition });
      this.#shapes = new Map(
        [...shapes2].map(([id2, shape]) => [
          id2,
          Object.freeze({ ...shape, rect: Object.freeze({ ...shape.rect }) })
        ])
      );
      let actor = sourceActor;
      const samples = [continuation(actor)];
      const poses = [
        Object.freeze({
          x: actor.body.x,
          y: actor.body.y,
          shapeId: actor.body.shapeId,
          facing: actor.facing
        })
      ];
      const commands = [];
      let landed = false;
      for (let tick2 = 1; tick2 <= authored.maxTicks; tick2++) {
        const command2 = Object.freeze({
          held: (authored.direction < 0 ? Held.Left : authored.direction > 0 ? Held.Right : 0) | (authored.kind === "drop" && tick2 === 1 ? Held.Down : 0),
          jumpPressed: tick2 === 1
        });
        const frame = { tick: tick2, geometryRevision: this.geometryRevision };
        const result = stepFootController(
          actor,
          command2,
          this.actorDefinition,
          this.#shapes,
          new CollisionIndex(grid2, [], frame),
          frame
        );
        if (result.status !== "complete") throw new Error("Traversal controller failed");
        if (tick2 === 1 && !result.events.some((event) => event.kind === authored.kind))
          throw new Error("Traversal launch was not consumed");
        if (result.physics.movement.contacts.some(
          (contact) => contact.normal.x !== 0 || contact.normal.y === 1
        ))
          throw new Error("Traversal trajectory lacks clearance");
        actor = result.actor;
        commands.push(command2);
        samples.push(continuation(actor));
        poses.push(
          Object.freeze({
            x: actor.body.x,
            y: actor.body.y,
            shapeId: actor.body.shapeId,
            facing: actor.facing
          })
        );
        if (actor.body.grounded) {
          const arrival = surface.locate(
            actor.body.x,
            actor.body.y,
            actor.facing,
            this.geometryRevision
          );
          if (arrival?.id !== destination.id || actor.body.x < authored.destinationMinX || actor.body.x > authored.destinationMaxX)
            throw new Error("Traversal first landing misses destination");
          landed = true;
          break;
        }
      }
      if (!landed) throw new Error("Traversal does not land within its duration");
      this.commands = Object.freeze(commands);
      this.poses = Object.freeze(poses);
      this.#samples = Object.freeze(samples);
      Object.freeze(this);
    }
    begin(actor, startTick) {
      integer(startTick, 0, COUNTER_LIMIT - 182, "traversal start tick");
      if (!ready2(actor) || actor.geometryRevision !== this.geometryRevision || continuation(actor) !== this.#samples[0])
        throw new Error("Traversal source state mismatch");
      return { linkId: this.id, startTick, elapsed: 0 };
    }
    step(actor, cursor, index, frame) {
      index.assertFrame(frame);
      integer(cursor.startTick, 0, COUNTER_LIMIT - 182, "traversal start tick");
      integer(cursor.elapsed, 0, this.commands.length - 1, "traversal cursor");
      if (cursor.linkId !== this.id || frame.tick !== cursor.startTick + cursor.elapsed + 1)
        throw new Error("Traversal tick/cursor mismatch");
      const reason = frame.geometryRevision !== this.geometryRevision || actor.geometryRevision !== frame.geometryRevision ? "geometry" : !ready2(actor) || continuation(actor) !== this.#samples[cursor.elapsed] ? "state" : null;
      const command2 = reason ? { held: 0, jumpPressed: false } : this.commands[cursor.elapsed];
      if (!command2) throw new Error("Missing traversal command");
      const result = stepFootController(
        {
          ...actor,
          geometryRevision: frame.geometryRevision,
          ...reason ? { jumpBufferTicks: 0 } : {}
        },
        command2,
        this.actorDefinition,
        this.#shapes,
        index,
        frame
      );
      if (result.status === "failed") return { status: "failed", result };
      if (reason || result.status !== "complete")
        return {
          status: "cancelled",
          reason: reason ?? "state",
          actor: result.actor,
          cursor: null,
          result
        };
      if (continuation(result.actor) !== this.#samples[cursor.elapsed + 1])
        return {
          status: "cancelled",
          reason: "trajectory",
          actor: result.actor,
          cursor: null,
          result
        };
      const elapsed = cursor.elapsed + 1;
      return {
        status: elapsed === this.commands.length ? "landed" : "active",
        actor: result.actor,
        cursor: elapsed === this.commands.length ? null : { ...cursor, elapsed },
        result
      };
    }
  };

  // src/game/labs/compiled.ts
  var compiledPresentation = navigation_default.presentation;
  function compiledLevelFixture() {
    const level = navigation_default.gameplay;
    const definitions = level.definitions.actors;
    const definition2 = definitions.find((d) => d.id === level.entry.actorId);
    const shapes2 = new Map(level.definitions.shapes.map((s) => [s.id, s]));
    const shape = definition2 && shapes2.get(definition2.standingShapeId);
    if (!definition2 || !shape) throw new Error("Compiled actor missing");
    const targets2 = level.terrain;
    const surface = new WalkSurface(targets2, shape, 1);
    const links = level.links.filter((l) => l.actorId === definition2.id).map(
      (l) => new CompiledTraversal(
        l.definition,
        l.actor,
        definition2,
        shapes2,
        targets2,
        surface
      )
    );
    const graph = new NavigationGraph(surface, definition2, links);
    const actor = { ...footActor(), ...structuredClone(level.entry.actor) };
    const destination = level.checkpoint;
    const route = graph.route(
      { x: actor.body.x, y: actor.body.y, facing: actor.facing },
      destination,
      1
    );
    if (route.status !== "route" || canonical(route) !== canonical(level.route))
      throw new Error("Compiled checkpoint route mismatch");
    const follower = new RouteFollower(graph, route, shapes2);
    return {
      actor,
      definition: definition2,
      shapes: shapes2,
      targets: targets2,
      surface,
      links,
      graph,
      destination,
      route,
      follower,
      contentHash: navigation_default.contentHash,
      buildHash: navigation_default.buildHash
    };
  }

  // test/fixtures/compiled-level-proof.ts
  function compiledLevelProof() {
    const fixture = compiledLevelFixture();
    let actor = fixture.actor;
    let cursor = fixture.follower.begin(actor, 0);
    let traceHash = "00000000";
    const grid2 = new CollisionGrid(fixture.targets);
    for (let tick2 = 1; tick2 <= fixture.route.costTicks; tick2++) {
      if (!cursor) throw new Error("Early compiled arrival");
      const frame = { tick: tick2, geometryRevision: 1 };
      const result = fixture.follower.step(
        actor,
        cursor,
        new CollisionIndex(grid2, [], frame),
        frame
      );
      if (result.status !== "active" && result.status !== "arrived")
        throw new Error("Compiled route failed");
      actor = result.actor;
      cursor = result.cursor;
      traceHash = stateHash({ traceHash, tick: tick2, actor, cursor });
    }
    if (cursor || actor.body.x !== fixture.destination.x || actor.body.y !== fixture.destination.y)
      throw new Error("Wrong compiled destination");
    return {
      contentHash: fixture.contentHash,
      buildHash: fixture.buildHash,
      ticks: fixture.route.costTicks,
      traceHash,
      actor
    };
  }

  // test/fixtures/controller-proof.ts
  function controllerProof(restoreAfterTick) {
    if (!FOOT_DEFINITION) throw new Error("Missing controller definition");
    let actor = footActor(-10, -30);
    actor.body.supportId = 101;
    const fixed = new CollisionGrid([
      FOOT_FLOOR,
      footTerrain(102, -210, -180, 10, 196),
      footTerrain(103, 200, -180, 10, 196),
      footTerrain(104, -40, -130, 80, 8)
    ]);
    const platform = footTerrain(101, -60, -30, 120, 8, "one-way");
    let traceHash = "00000000";
    let encodedBytes = 0;
    let jumpEdges = 0;
    const counts = { jump: 0, drop: 0, land: 0, "leave-support": 0 };
    const checkpoints = [];
    for (let tick2 = 1; tick2 <= 1200; tick2++) {
      const geometryRevision = tick2 < 900 ? 1 : 2;
      actor.geometryRevision = geometryRevision;
      platform.delta.x = pixels(Math.floor((tick2 - 1) / 60) % 2 === 0 ? 1 : -1);
      const index = new CollisionIndex(fixed, tick2 < 900 ? [platform] : [], {
        tick: tick2,
        geometryRevision
      });
      const phase = tick2 % 240;
      const held = tick2 < 60 ? 0 : tick2 < 100 ? Held.Down : phase < 100 ? Held.Right : phase < 200 ? Held.Left : Held.Down;
      const jumpPressed = tick2 === 60 || tick2 >= 100 && tick2 % 45 === 10;
      const result = stepFootController(
        actor,
        { held, jumpPressed },
        FOOT_DEFINITION,
        FOOT_SHAPES,
        index,
        { tick: tick2, geometryRevision }
      );
      if (result.status !== "complete")
        throw new Error(`Controller proof tick ${tick2}: ${JSON.stringify(result)}`);
      actor = result.actor;
      if (jumpPressed) actor.processedEdgeIds[0] = ++jumpEdges;
      for (const event of result.events) counts[event.kind]++;
      platform.rect.x += platform.delta.x;
      const snapshot = {
        runEpoch: 1,
        connectionEpoch: 2,
        snapshotId: tick2,
        tick: tick2,
        baselineEventCursor: 0,
        geometryRevision,
        stateHash: Number.parseInt(stateHash({ actor, geometryRevision, tick: tick2 }), 16),
        roomMode: "playing",
        combat: null,
        camera: { x: 0, y: 0 },
        campaign: {
          ruleset: "classic",
          mission: 1,
          checkpointId: 1,
          continuesRemaining: 3,
          continuesUsed: 0,
          phase: "playing",
          encounterId: 1,
          remainingEnemies: 0
        },
        acknowledgments: [
          {
            playerId: 1,
            connectionEpoch: 2,
            controlEpoch: 1,
            lastProcessedSequence: tick2,
            appliedAtServerTick: tick2,
            processedEdgeIds: [...actor.processedEdgeIds]
          }
        ],
        players: [actor],
        vehicles: [],
        enemies: [],
        projectiles: [],
        threats: [],
        platforms: tick2 < 900 ? [
          {
            id: 101,
            x: platform.rect.x,
            y: platform.rect.y,
            vx: platform.delta.x,
            vy: 0,
            shapeId: 7,
            trajectoryId: 1,
            trajectoryTick: tick2
          }
        ] : [],
        removedIds: tick2 < 900 ? [] : [101]
      };
      const context2 = {
        runEpoch: 1,
        connectionEpoch: 2,
        playerId: 1,
        geometryRevision,
        shapeIds: /* @__PURE__ */ new Set([1, 2, 3, 4, 5, 6, 7])
      };
      const encoded = encodeSnapshot(snapshot, context2);
      const decoded = decodeSnapshot(encoded, context2);
      const restored = decoded.players[0];
      if (!restored || canonical(restored) !== canonical(actor))
        throw new Error(`Controller snapshot mismatch at ${tick2}`);
      encodedBytes += encoded.byteLength;
      traceHash = stateHash({ previous: traceHash, snapshot: decoded, events: result.events });
      if (tick2 % 60 === 0 || [599, 601, 899, 901].includes(tick2))
        checkpoints.push({
          tick: tick2,
          hash: traceHash,
          x: actor.body.x,
          y: actor.body.y,
          shapeId: actor.body.shapeId,
          supportId: actor.body.supportId,
          geometryRevision
        });
      if (tick2 === restoreAfterTick) {
        actor = restored;
        jumpEdges = actor.processedEdgeIds[0];
      }
    }
    return { ticks: 1200, traceHash, encodedBytes, jumpEdges, counts, checkpoints };
  }
  function controllerBoundaryProof() {
    const definition2 = FOOT_DEFINITION;
    if (!definition2) throw new Error("Missing controller definition");
    const run2 = (actor, terrain, tick2, jumpPressed = false) => {
      const frame = { tick: tick2, geometryRevision: actor.geometryRevision };
      const index = new CollisionIndex(
        new CollisionGrid(terrain.filter((target) => target.delta.x === 0 && target.delta.y === 0)),
        terrain.filter((target) => target.delta.x !== 0 || target.delta.y !== 0),
        frame
      );
      const result = stepFootController(
        actor,
        { held: 0, jumpPressed },
        definition2,
        FOOT_SHAPES,
        index,
        frame
      );
      if (result.status !== "complete")
        throw new Error(`Boundary controller failure: ${JSON.stringify(result)}`);
      return result;
    };
    const roof = footTerrain(101, -20, -40, 40, 15);
    const crouched2 = footActor();
    crouched2.body.shapeId = 2;
    crouched2.locomotion = "crouched";
    const blockedStand = run2(crouched2, [FOOT_FLOOR, roof], 1);
    const clearanceJump = run2(
      blockedStand.actor,
      [FOOT_FLOOR, { ...roof, delta: { x: 0, y: pixels(-20) } }],
      2,
      true
    );
    const risen = { ...roof, rect: { ...roof.rect, y: roof.rect.y - pixels(20) } };
    const airborne = run2(clearanceJump.actor, [FOOT_FLOOR, risen], 3);
    const carrier = { ...FOOT_FLOOR, delta: { x: pixels(2), y: 0 } };
    const carried = run2(footActor(), [carrier], 1);
    const removal = run2({ ...carried.actor, geometryRevision: 2 }, [], 2);
    const cases3 = [
      { name: "blocked-stand", result: blockedStand },
      { name: "end-clearance-jump", result: clearanceJump },
      { name: "buffered-airborne", result: airborne },
      { name: "carried", result: carried },
      { name: "removed-support", result: removal }
    ];
    return { cases: cases3, traceHash: stateHash(cases3) };
  }

  // test/fixtures/death-body-proof.ts
  function deathContext(tick2, fixed = [FOOT_FLOOR], moving = []) {
    const shape = FOOT_SHAPES.get(1);
    if (!shape || !FOOT_DEFINITION) throw new Error("Missing death physics content");
    const frame = { tick: tick2, geometryRevision: 1 };
    return {
      shape,
      definition: FOOT_DEFINITION,
      shapes: FOOT_SHAPES,
      // Block entry deliberately so each collision case can finish independently of the death timer.
      anchors: [{ x: pixels(500), y: 0 }],
      index: new CollisionIndex(new CollisionGrid(fixed), moving, frame),
      frame,
      fallBoundary: pixels(100)
    };
  }
  function airbornePlayer(x = 0, y = -8, vx = 2, vy = -1) {
    const actor = footActor(x, y);
    actor.locomotion = "airborne";
    Object.assign(actor.body, { vx: pixels(vx), vy: pixels(vy), grounded: false, supportId: null });
    return actor;
  }
  function check10(ok, reason) {
    if (!ok) throw new Error(`Death body proof: ${reason}`);
  }
  function record(actor, tick2) {
    return {
      tick: tick2,
      life: actor.life,
      bodyPresence: actor.bodyPresence,
      lives: actor.lives,
      since: actor.lifeStartTick,
      body: actor.body
    };
  }
  function deathBodyProof() {
    const cases3 = [];
    for (const kind of ["solid", "one-way"]) {
      const initial = airbornePlayer();
      let actor = damagePlayer(initial, 0, 1, "classic").actor;
      check10(actor.body.vx === pixels(2) && actor.body.vy === -256, "hit erased airborne momentum");
      const trace = [record(actor, 0)];
      for (let tick2 = 1; tick2 <= 40; tick2++) {
        actor = stepPlayerLife(
          actor,
          tick2,
          "classic",
          deathContext(tick2, [{ ...FOOT_FLOOR, kind }])
        ).actor;
        trace.push(record(actor, tick2));
      }
      const landed = trace.find((sample2) => sample2.body.grounded);
      check10(landed && landed.tick > 1 && landed.tick < 30, "did not land before the entry deadline");
      check10(trace[1] && trace[1].body.y < initial.body.y, "upward velocity was lost");
      check10(actor.body.y === 0 && actor.body.vx === 0 && actor.body.vy === 0, "did not settle");
      check10(
        actor.life === "death" && actor.lives === 2 && actor.lifeStartTick === 0,
        "blocked entry spent a life or reset the clock"
      );
      cases3.push({ name: kind, landedTick: landed.tick, trace, hash: stateHash(trace) });
    }
    {
      let actor = damagePlayer(footActor(), 0, 1, "classic").actor;
      const trace = [record(actor, 0)];
      for (let tick2 = 1; tick2 <= 10; tick2++) {
        const platform = {
          ...footTerrain(100, tick2 - 1, -(tick2 - 1), 80, 8),
          delta: { x: pixels(1), y: pixels(-1) }
        };
        actor = stepPlayerLife(actor, tick2, "classic", deathContext(tick2, [], [platform])).actor;
        check10(
          actor.body.x === pixels(tick2) && actor.body.y === pixels(-tick2) && actor.body.grounded,
          "platform carry diverged"
        );
        trace.push(record(actor, tick2));
      }
      actor = stepPlayerLife(actor, 11, "classic", deathContext(11, [])).actor;
      check10(
        !actor.body.grounded && actor.body.y > pixels(-10),
        "removed support left corpse suspended"
      );
      trace.push(record(actor, 11));
      cases3.push({ name: "platform-and-support-loss", landedTick: 0, trace, hash: stateHash(trace) });
    }
    {
      const actor = damagePlayer(footActor(), 0, 1, "classic").actor;
      const ceiling = footTerrain(101, -100, -40, 200, 5);
      const lift = {
        ...footTerrain(100, -100, 0, 200, 8),
        delta: { x: 0, y: pixels(-4) }
      };
      const result = stepPlayerLife(actor, 1, "classic", deathContext(1, [ceiling], [lift]));
      check10(
        result.actor.bodyPresence === "removed" && result.actor.lives === 2 && result.notice === null,
        "crush stalled or spent another life"
      );
      check10(
        result.actor.body.x === actor.body.x && result.actor.body.y === actor.body.y,
        "crush committed unresolved position"
      );
      const trace = [record(actor, 0), record(result.actor, 1)];
      cases3.push({ name: "crush", landedTick: null, trace, hash: stateHash(trace) });
    }
    {
      let actor = damagePlayer(airbornePlayer(0, 99, 2, 8), 0, 1, "classic").actor;
      const trace = [record(actor, 0)];
      for (let tick2 = 1; tick2 <= 90; tick2++) {
        const result = stepPlayerLife(actor, tick2, "classic", deathContext(tick2, []));
        check10(result.notice === null, "blocked void entry emitted life event");
        actor = damagePlayer(result.actor, tick2, 1, "classic", "fall").actor;
        trace.push(record(actor, tick2));
      }
      check10(
        actor.bodyPresence === "removed" && actor.lives === 2 && actor.lifeStartTick === 0,
        "void changed life accounting"
      );
      check10(stateHash(actor.body) === stateHash(trace[1]?.body), "removed body kept integrating");
      const entry = deathContext(91);
      entry.anchors = [{ x: 0, y: 0 }];
      actor = stepPlayerLife(actor, 91, "classic", entry).actor;
      check10(
        actor.life === "respawning" && actor.bodyPresence === "present" && actor.lives === 2,
        "removed corpse blocked a safe entry"
      );
      trace.push(record(actor, 91));
      cases3.push({ name: "void-and-entry-retry", landedTick: null, trace, hash: stateHash(trace) });
    }
    return { cases: cases3, hash: stateHash(cases3) };
  }

  // src/game/labs/encounter.ts
  var labEncounter = new EncounterLifecycle({
    id: 1,
    participants: [1],
    members: [
      {
        id: 2,
        required: true,
        critical: false,
        retreatAllowed: false,
        watchdogTicks: 180,
        ambientCleanupTicks: null
      }
    ],
    objectives: []
  });

  // src/game/labs/route.ts
  function routeFixture() {
    const definition2 = FOOT_DEFINITION, shape = FOOT_SHAPES.get(1);
    if (!definition2 || !shape) throw new Error("Missing route fixture definitions");
    const targets2 = [
      footTerrain(100, 0, 300, 100, 40),
      footTerrain(101, 130, 300, 120, 40),
      footTerrain(102, 280, 300, 220, 40)
    ];
    const surface = new WalkSurface(targets2, shape, 1);
    const sources = [footActor(50, 300), footActor(200, 300)];
    const links = sources.map((actor2, i) => {
      actor2.body.supportId = 100 + i;
      const destinationX = actor2.body.x + pixels(153);
      const source3 = surface.locate(actor2.body.x, actor2.body.y, 1, 1);
      const destination2 = surface.locate(destinationX, actor2.body.y, 1, 1);
      if (!source3 || !destination2) throw new Error("Missing route endpoint");
      return new CompiledTraversal(
        {
          id: i + 1,
          kind: "jump",
          sourceSpanId: source3.id,
          sourceX: actor2.body.x,
          destinationSpanId: destination2.id,
          destinationMinX: destinationX,
          destinationMaxX: destinationX,
          direction: 1,
          maxTicks: 90
        },
        actor2,
        definition2,
        FOOT_SHAPES,
        targets2,
        surface
      );
    });
    const actor = sources[0];
    if (!actor) throw new Error("Missing route actor");
    const graph = new NavigationGraph(surface, definition2, links);
    const destination = { x: pixels(380), y: pixels(300), facing: 1 };
    const route = graph.route(
      { x: actor.body.x, y: actor.body.y, facing: actor.facing },
      destination,
      1
    );
    if (route.status !== "route") throw new Error("Missing engineering route");
    const follower = new RouteFollower(graph, route, FOOT_SHAPES);
    return { actor, definition: definition2, targets: targets2, surface, links, graph, destination, route, follower };
  }

  // src/game/actors/routed.ts
  var RETRY_TICKS = 30;
  function same2(a, b) {
    return a.x === b.x && a.y === b.y && a.facing === b.facing;
  }
  function createRoutedEnemy(actor, goal) {
    position(goal.x);
    position(goal.y);
    if (goal.facing !== -1 && goal.facing !== 1) throw new Error("Invalid enemy goal facing");
    return {
      actor,
      goal: { ...goal },
      plan: null,
      cursor: null,
      status: "idle",
      reason: null,
      removalReason: null,
      nextPlanTick: 0,
      plans: 0
    };
  }
  var RoutedEnemyDriver = class {
    constructor(graph, shapes2, bounds) {
      this.graph = graph;
      integer(shapes2.size, 1, 4096, "enemy shape count");
      for (const value of [bounds.x, bounds.y, bounds.x + bounds.w, bounds.y + bounds.h])
        position(value);
      if (bounds.w <= 0 || bounds.h <= 0) throw new Error("Invalid enemy kill bounds");
      this.#bounds = Object.freeze({ ...bounds });
      this.#shapes = new Map(
        [...shapes2].map(([id2, shape]) => [
          id2,
          Object.freeze({ ...shape, rect: Object.freeze({ ...shape.rect }) })
        ])
      );
      Object.freeze(this);
    }
    graph;
    #followers = /* @__PURE__ */ new Map();
    #shapes;
    #bounds;
    #follower(plan) {
      const key = canonical(plan);
      let follower = this.#followers.get(key);
      if (!follower) {
        follower = new RouteFollower(this.graph, plan, this.#shapes);
        if (this.#followers.size >= 32) {
          const first = this.#followers.keys().next().value;
          if (first !== void 0) this.#followers.delete(first);
        }
        this.#followers.set(key, follower);
      }
      return follower;
    }
    step(current, goal, index, frame) {
      index.assertFrame(frame);
      integer(frame.tick, 1, COUNTER_LIMIT - 3604, "enemy navigation tick");
      integer(current.plans, 0, COUNTER_LIMIT - 2, "enemy plan count");
      integer(current.nextPlanTick, 0, COUNTER_LIMIT - 1, "enemy retry tick");
      position(goal.x);
      position(goal.y);
      if (goal.facing !== -1 && goal.facing !== 1) throw new Error("Invalid enemy goal facing");
      if (current.status === "removed")
        return { status: "complete", enemy: current, events: [], result: null };
      if (current.plan === null !== (current.cursor === null))
        throw new Error("Enemy plan/cursor mismatch");
      let enemy = { ...current, goal: { ...goal } };
      const events = [];
      const id2 = current.actor.body.id;
      const neutral2 = () => stepFootController(
        { ...current.actor, geometryRevision: frame.geometryRevision, jumpBufferTicks: 0 },
        { held: 0, jumpPressed: false },
        this.graph.actorDefinition,
        this.#shapes,
        index,
        frame
      );
      let result;
      const changedGoal = !same2(current.goal, goal);
      const changedGeometry = this.graph.surface.geometryRevision !== frame.geometryRevision || current.actor.geometryRevision !== frame.geometryRevision || current.plan !== null && current.plan.geometryRevision !== frame.geometryRevision;
      if (changedGoal || changedGeometry) {
        const reason = changedGeometry ? "geometry" : "goal";
        if (current.plan) events.push({ kind: "route-cancelled", id: id2, tick: frame.tick, reason });
        enemy = {
          ...enemy,
          plan: null,
          cursor: null,
          status: "waiting",
          reason,
          nextPlanTick: frame.tick + 1
        };
        result = neutral2();
      } else if (current.plan && current.cursor) {
        const progress = this.#follower(current.plan).step(
          current.actor,
          current.cursor,
          index,
          frame
        );
        result = progress.result;
        if (progress.status === "active")
          enemy = {
            ...enemy,
            actor: progress.actor,
            cursor: progress.cursor,
            status: "routing",
            reason: null
          };
        else if (progress.status === "arrived")
          enemy = {
            ...enemy,
            actor: progress.actor,
            plan: null,
            cursor: null,
            status: "arrived",
            reason: null
          };
        else if (progress.status === "cancelled") {
          events.push({ kind: "route-cancelled", id: id2, tick: frame.tick, reason: progress.reason });
          enemy = {
            ...enemy,
            actor: progress.actor,
            plan: null,
            cursor: null,
            status: "waiting",
            reason: progress.reason,
            nextPlanTick: frame.tick + RETRY_TICKS
          };
        }
      } else {
        const actor = current.actor;
        const settled = actor.life === "alive" && actor.action.kind === "ready" && actor.vehicleId === null && actor.locomotion === "grounded" && actor.body.grounded && actor.body.vx === 0 && actor.body.vy === 0 && actor.body.shapeId === this.graph.surface.shapeId && actor.ignoredSupportTicks === 0 && actor.jumpBufferTicks === 0;
        if (!settled) {
          enemy = { ...enemy, status: "waiting", reason: actor.body.grounded ? "state" : "airborne" };
          result = neutral2();
        } else if (same2({ x: actor.body.x, y: actor.body.y, facing: actor.facing }, goal)) {
          enemy = { ...enemy, status: "arrived", reason: null };
          result = neutral2();
        } else if (frame.tick < current.nextPlanTick) result = neutral2();
        else {
          const route = this.graph.route(
            { x: actor.body.x, y: actor.body.y, facing: actor.facing },
            goal,
            frame.geometryRevision
          );
          enemy.plans++;
          if (route.status === "unreachable") {
            enemy = {
              ...enemy,
              status: "unreachable",
              reason: "no-route",
              nextPlanTick: frame.tick + RETRY_TICKS
            };
            result = neutral2();
          } else {
            const follower = this.#follower(route);
            const cursor = follower.begin(actor, frame.tick - 1);
            const progress = follower.step(actor, cursor, index, frame);
            result = progress.result;
            events.push({ kind: "route-started", id: id2, tick: frame.tick, links: [...route.linkIds] });
            if (progress.status === "active")
              enemy = {
                ...enemy,
                plan: route,
                cursor: progress.cursor,
                status: "routing",
                reason: null
              };
            else if (progress.status === "arrived")
              enemy = { ...enemy, status: "arrived", reason: null };
            else if (progress.status === "cancelled") {
              events.push({ kind: "route-cancelled", id: id2, tick: frame.tick, reason: progress.reason });
              enemy = {
                ...enemy,
                status: "waiting",
                reason: progress.reason,
                nextPlanTick: frame.tick + RETRY_TICKS
              };
            }
          }
        }
      }
      if (result.status === "failed") {
        if (result.physics.reason !== "crushed") return { status: "failed", result };
        enemy = {
          ...enemy,
          actor: { ...current.actor, geometryRevision: frame.geometryRevision, life: "death" },
          plan: null,
          cursor: null,
          status: "removed",
          removalReason: "crushed"
        };
        events.push({ kind: "removed", id: id2, tick: frame.tick, reason: "crushed" });
      } else {
        enemy.actor = result.actor;
        const body4 = result.actor.body, bounds = this.#bounds;
        if (body4.x < bounds.x || body4.x > bounds.x + bounds.w || body4.y < bounds.y || body4.y > bounds.y + bounds.h) {
          enemy = {
            ...enemy,
            actor: { ...result.actor, life: "death" },
            plan: null,
            cursor: null,
            status: "removed",
            removalReason: "out-of-bounds"
          };
          events.push({ kind: "removed", id: id2, tick: frame.tick, reason: "out-of-bounds" });
        } else if (enemy.status === "arrived" && !body4.grounded)
          enemy = { ...enemy, status: "waiting", reason: "airborne" };
      }
      return { status: "complete", enemy, events, result };
    }
  };

  // src/game/labs/routed.ts
  function routedEnemyFixture(removed = false) {
    const base = routeFixture();
    const shape = FOOT_SHAPES.get(1);
    if (!shape) throw new Error("Missing enemy shape");
    const revision = removed ? 2 : 1;
    const targets2 = base.targets.filter((target) => !(removed && target.id === 102));
    const surface = new WalkSurface(targets2, shape, revision);
    const links = [];
    for (const old of base.links) {
      const first = old.poses[0], last = old.poses.at(-1);
      if (!first || !last) throw new Error("Missing route poses");
      const source3 = surface.locate(first.x, first.y, first.facing, revision);
      const destination = surface.locate(last.x, last.y, last.facing, revision);
      if (!source3 || !destination) continue;
      const actor2 = footState();
      actor2.body.id = 2;
      actor2.body.x = first.x;
      actor2.body.y = first.y;
      actor2.facing = first.facing;
      actor2.geometryRevision = revision;
      actor2.body.supportId = source3.supportIds[0] ?? null;
      links.push(
        new CompiledTraversal(
          { ...old.definition, sourceSpanId: source3.id, destinationSpanId: destination.id },
          actor2,
          base.definition,
          FOOT_SHAPES,
          targets2,
          surface
        )
      );
    }
    const graph = new NavigationGraph(surface, base.definition, links);
    const bounds = { x: pixels(-30), y: pixels(-80), w: pixels(700), h: pixels(470) };
    const driver = new RoutedEnemyDriver(graph, FOOT_SHAPES, bounds);
    const actor = footState(50, 300);
    actor.body.id = 2;
    actor.geometryRevision = revision;
    return {
      graph,
      targets: targets2,
      driver,
      bounds,
      links,
      goal: base.destination,
      enemy: createRoutedEnemy(actor, base.destination),
      preview: removed ? null : base.follower
    };
  }

  // src/game/labs/traversal.ts
  function traversalFixture(kind) {
    if (!FOOT_DEFINITION) throw new Error("Missing lab actor definition");
    const shape = FOOT_SHAPES.get(1);
    if (!shape) throw new Error("Missing lab shape");
    const actor = kind === "jump" ? footActor(100, 300) : footActor(220, 220);
    const targets2 = kind === "jump" ? [footTerrain(100, 0, 300, 140, 40), footTerrain(101, 210, 300, 220, 40)] : [footTerrain(100, 160, 220, 140, 8, "one-way"), footTerrain(101, 0, 300, 640, 40)];
    const surface = new WalkSurface(targets2, shape, 1);
    const source3 = surface.locate(actor.body.x, actor.body.y, 1, 1);
    const destination = surface.locate(pixels(kind === "jump" ? 253 : 220), pixels(300), 1, 1);
    if (!source3 || !destination) throw new Error("Missing traversal endpoint span");
    const authored = {
      id: kind === "jump" ? 1 : 2,
      kind,
      sourceSpanId: source3.id,
      sourceX: actor.body.x,
      destinationSpanId: destination.id,
      destinationMinX: pixels(kind === "jump" ? 220 : 210),
      destinationMaxX: pixels(kind === "jump" ? 400 : 230),
      direction: kind === "jump" ? 1 : 0,
      maxTicks: 90
    };
    const link = new CompiledTraversal(
      authored,
      actor,
      FOOT_DEFINITION,
      FOOT_SHAPES,
      targets2,
      surface
    );
    return { actor, targets: targets2, surface, authored, link };
  }

  // src/game/labs/controller.ts
  var LAB_SCENARIOS = [
    "course",
    "moving-support",
    "crush",
    "enemy-ledge",
    "encounter-clear",
    "jump-link",
    "drop-link",
    "route-chain",
    "compiled-route",
    "enemy-route"
  ];
  var LAB_LIMIT = 3600;
  var traversalFixtures = /* @__PURE__ */ new Map();
  function getTraversalFixture(scenario) {
    if (scenario !== "jump-link" && scenario !== "drop-link") return null;
    let fixture = traversalFixtures.get(scenario);
    if (!fixture) {
      fixture = traversalFixture(scenario === "jump-link" ? "jump" : "drop");
      traversalFixtures.set(scenario, fixture);
    }
    return fixture;
  }
  function labTraversal(scenario) {
    return getTraversalFixture(scenario)?.link ?? null;
  }
  var compiledLab = null;
  var routeLab = null;
  function getRouteFixture(scenario) {
    if (scenario === "compiled-route") {
      compiledLab ??= compiledLevelFixture();
      return compiledLab;
    }
    if (scenario !== "route-chain") return null;
    routeLab ??= routeFixture();
    return routeLab;
  }
  function labRoute(scenario) {
    return getRouteFixture(scenario)?.follower ?? null;
  }
  var routedLabs = /* @__PURE__ */ new Map();
  function getRoutedLab(removed) {
    let fixture = routedLabs.get(removed);
    if (!fixture) {
      fixture = routedEnemyFixture(removed);
      routedLabs.set(removed, fixture);
    }
    return fixture;
  }
  function geometry(scenario, tick2, removed) {
    if (scenario === "enemy-route")
      return getRoutedLab(removed).targets.map((target) => ({
        ...target,
        rect: { ...target.rect },
        delta: { ...target.delta }
      }));
    const fixture = getTraversalFixture(scenario) ?? getRouteFixture(scenario);
    if (fixture)
      return fixture.targets.filter((target) => !(removed && target.id === fixture.targets.at(-1)?.id)).map((target) => ({ ...target, rect: { ...target.rect }, delta: { ...target.delta } }));
    if (scenario === "course")
      return [
        footTerrain(100, 0, 300, 230, 40),
        footTerrain(101, 280, 300, 360, 40),
        footTerrain(102, 130, 265, 70, 10),
        footTerrain(103, 340, 250, 90, 6, "one-way"),
        footTerrain(104, 465, 235, 12, 65),
        footTerrain(105, 560, 270, 80, 12)
      ];
    if (scenario === "crush")
      return [
        footTerrain(100, 0, 300, 640, 40),
        {
          ...footTerrain(110, 260, 210 + Math.min(tick2, 65), 120, 12),
          delta: { x: 0, y: tick2 < 65 ? pixels(1) : 0 }
        }
      ];
    if (scenario === "encounter-clear")
      return [
        footTerrain(100, 0, 300, 100, 40),
        ...removed ? [] : [footTerrain(110, 200, 230, 160, 8)]
      ];
    if (scenario === "enemy-ledge")
      return [
        footTerrain(100, 0, 300, 640, 40),
        ...removed ? [] : [footTerrain(110, 200, 230, 160, 8)]
      ];
    const phase = tick2 % 240;
    const x = 200 + (phase <= 120 ? phase : 240 - phase);
    const nextPhase = (tick2 + 1) % 240;
    const nextX = 200 + (nextPhase <= 120 ? nextPhase : 240 - nextPhase);
    return [
      footTerrain(100, 0, 300, 640, 40),
      ...removed ? [] : [
        { ...footTerrain(110, x, 230, 100, 8, "one-way"), delta: { x: pixels(nextX - x), y: 0 } }
      ]
    ];
  }
  function createControllerLab(scenario) {
    if (!LAB_SCENARIOS.includes(scenario)) throw new Error("Unknown lab scenario");
    const fixture = getTraversalFixture(scenario) ?? getRouteFixture(scenario);
    const actor = scenario === "enemy-route" || scenario === "encounter-clear" ? footActor(80, 300) : fixture ? JSON.parse(JSON.stringify(fixture.actor)) : footActor(
      scenario === "course" ? 60 : scenario === "crush" ? 320 : 240,
      scenario === "moving-support" ? 230 : 300
    );
    if (scenario === "moving-support") actor.body.supportId = 110;
    const enemyBody = footActor(240, 230).body;
    enemyBody.id = 2;
    enemyBody.supportId = 110;
    return {
      scenario,
      tick: 0,
      geometryRevision: 1,
      removed: false,
      actor,
      traversal: null,
      route: null,
      traversalStatus: "idle",
      enemy: scenario === "enemy-ledge" || scenario === "encounter-clear" ? {
        body: enemyBody,
        facing: 1,
        geometryRevision: 1,
        life: "alive",
        removalReason: null,
        turns: 0
      } : null,
      navigatingEnemy: scenario === "enemy-route" ? JSON.parse(JSON.stringify(getRoutedLab(false).enemy)) : null,
      enemyNavigationEvents: [],
      encounter: ["enemy-ledge", "enemy-route", "encounter-clear"].includes(scenario) ? labEncounter.begin() : null,
      encounterNotices: [],
      resolvedEnemies: [],
      terrain: geometry(scenario, 0, false),
      result: null,
      stopped: null
    };
  }
  function stepControllerLab(state, command2) {
    if (state.stopped) return state;
    integer(command2.held, 0, HELD_MASK, "lab held");
    if (typeof command2.jumpPressed !== "boolean" || typeof command2.removePlatform !== "boolean" || typeof command2.startTraversal !== "boolean")
      throw new Error("Invalid lab command");
    if (!FOOT_DEFINITION) throw new Error("Missing lab actor definition");
    const removed = state.removed || (state.scenario === "moving-support" || state.scenario === "enemy-ledge" || state.scenario === "encounter-clear" || state.scenario === "jump-link" || state.scenario === "drop-link" || state.scenario === "route-chain" || state.scenario === "compiled-route" || state.scenario === "enemy-route") && command2.removePlatform;
    const revision = state.geometryRevision + Number(removed !== state.removed);
    const terrain = geometry(state.scenario, state.tick, removed);
    const frame = { tick: state.tick + 1, geometryRevision: revision };
    const index = new CollisionIndex(
      new CollisionGrid(terrain.filter((t) => t.delta.x === 0 && t.delta.y === 0)),
      terrain.filter((t) => t.delta.x !== 0 || t.delta.y !== 0),
      frame
    );
    const link = labTraversal(state.scenario);
    const runner = labRoute(state.scenario);
    let route = state.route;
    let traversal = state.traversal;
    let traversalStatus = state.traversalStatus;
    if (command2.startTraversal && !traversal && !route) {
      try {
        if (runner) route = runner.begin(state.actor, state.tick);
        else {
          if (!link) throw new Error("No authored link in this scenario");
          traversal = link.begin(state.actor, state.tick);
        }
        traversalStatus = "active";
      } catch {
        traversalStatus = "unavailable";
      }
    }
    let result;
    if (route && runner) {
      const progress = runner.step(state.actor, route, index, frame);
      result = progress.result;
      route = progress.status === "failed" ? null : progress.cursor;
      traversalStatus = progress.status === "arrived" ? "landed" : progress.status;
    } else if (traversal && link) {
      const progress = link.step(state.actor, traversal, index, frame);
      result = progress.result;
      traversal = progress.status === "failed" ? null : progress.cursor;
      traversalStatus = progress.status;
    } else
      result = stepFootController(
        { ...state.actor, geometryRevision: revision },
        command2,
        FOOT_DEFINITION,
        FOOT_SHAPES,
        index,
        frame
      );
    const actor = result.status !== "failed" ? result.actor : state.actor;
    let enemy = state.enemy;
    let enemyFailure = null;
    let enemyFault = null;
    const resolvedEnemies = [...state.resolvedEnemies];
    if (enemy) {
      const shape = FOOT_SHAPES.get(enemy.body.shapeId);
      if (!shape) throw new Error("Missing enemy shape");
      const enemyStep = stepGroundedEnemy(
        { ...enemy, geometryRevision: revision },
        {
          speed: pixels(1),
          gravity: FOOT_DEFINITION.gravity,
          terminalVelocity: FOOT_DEFINITION.terminalVelocity,
          bounds: { x: pixels(-30), y: pixels(-80), w: pixels(700), h: pixels(470) }
        },
        shape,
        index,
        frame
      );
      if (enemyStep.status === "failed") {
        enemyFailure = `enemy-${enemyStep.physics.reason}`;
        if (enemyStep.physics.reason === "crushed") throw new Error("Unresolved proven crush");
        enemyFault = enemyStep.physics.reason;
      } else {
        enemy = enemyStep.enemy;
        if (enemy.removalReason && !resolvedEnemies.some((resolved) => resolved.id === enemy?.body.id))
          resolvedEnemies.push({ id: enemy.body.id, reason: enemy.removalReason });
      }
    }
    let navigatingEnemy = state.navigatingEnemy;
    let enemyNavigationEvents = [];
    if (navigatingEnemy) {
      const fixture = getRoutedLab(removed);
      const progress = fixture.driver.step(navigatingEnemy, fixture.goal, index, frame);
      if (progress.status === "failed") {
        enemyFailure = `enemy-${progress.result.physics.reason}`;
        if (progress.result.physics.reason === "crushed") throw new Error("Unresolved proven crush");
        enemyFault = progress.result.physics.reason;
      } else {
        navigatingEnemy = progress.enemy;
        enemyNavigationEvents = progress.events;
        for (const event of progress.events)
          if (event.kind === "removed" && !resolvedEnemies.some((entry) => entry.id === event.id))
            resolvedEnemies.push({ id: event.id, reason: event.reason });
      }
    }
    let encounter = state.encounter;
    let encounterNotices = [];
    if (encounter) {
      const member = encounter.members[0];
      if (!member) throw new Error("Missing lab encounter member");
      const events = [];
      const received = encounter.receipts.length;
      const sequence = () => received + events.length + 1;
      if (member.status === "pending")
        events.push({ kind: "activate", id: 2, tick: frame.tick, sequence: sequence() });
      if (enemyFault)
        events.push({
          kind: "fault",
          id: 2,
          tick: frame.tick,
          sequence: sequence(),
          reason: enemyFault
        });
      const removal = enemy?.removalReason ?? navigatingEnemy?.removalReason;
      if (removal && member.status !== "resolved")
        events.push({
          kind: "resolve",
          id: 2,
          tick: frame.tick,
          sequence: sequence(),
          reason: removal,
          killerId: null
        });
      const body4 = enemy?.body ?? navigatingEnemy?.actor.body;
      const progress = labEncounter.step(
        encounter,
        frame.tick,
        events,
        body4 && !removal ? [
          {
            id: 2,
            progressKey: canonical({ x: body4.x, y: body4.y, vx: body4.vx, vy: body4.vy }),
            unreachable: navigatingEnemy?.status === "unreachable"
          }
        ] : []
      );
      encounter = progress.state;
      encounterNotices = progress.notices;
    }
    const stopped = enemyFailure ?? (result.status === "failed" ? result.physics.reason : actor.body.y > pixels(390) ? "kill-bound" : frame.tick >= LAB_LIMIT ? "recording-limit" : null);
    return {
      ...state,
      tick: frame.tick,
      geometryRevision: revision,
      removed,
      actor,
      traversal,
      route,
      traversalStatus,
      enemy,
      navigatingEnemy,
      enemyNavigationEvents,
      resolvedEnemies,
      encounter,
      encounterNotices,
      terrain: geometry(state.scenario, frame.tick, removed),
      result,
      stopped
    };
  }
  function labFingerprint(state) {
    return canonical({
      scenario: state.scenario,
      tick: state.tick,
      geometryRevision: state.geometryRevision,
      removed: state.removed,
      actor: state.actor,
      traversal: state.traversal,
      route: state.route,
      traversalStatus: state.traversalStatus,
      enemy: state.enemy,
      navigatingEnemy: state.navigatingEnemy,
      enemyNavigationEvents: state.enemyNavigationEvents,
      resolvedEnemies: state.resolvedEnemies,
      encounter: state.encounter,
      encounterNotices: state.encounterNotices,
      stopped: state.stopped
    });
  }
  function replayControllerLab(recording) {
    if (recording.format !== 6 || !Array.isArray(recording.commands) || recording.commands.length > LAB_LIMIT)
      throw new Error("Invalid lab recording");
    let state = createControllerLab(recording.scenario);
    for (const command2 of recording.commands) {
      if (state.stopped) throw new Error("Recording continues after stop");
      state = stepControllerLab(state, command2);
    }
    if (labFingerprint(state) !== recording.finalState) throw new Error("Lab replay diverged");
    return state;
  }

  // test/fixtures/encounter-proof.ts
  function encounterProof() {
    let state = createControllerLab("encounter-clear");
    let traceHash = "00000000";
    const commands = [];
    const notices = [];
    const checkpoints = [];
    for (let tick2 = 1; tick2 <= 120; tick2++) {
      const command2 = {
        held: 0,
        jumpPressed: tick2 === 1,
        removePlatform: tick2 === 11,
        startTraversal: false
      };
      commands.push(command2);
      const restored = stepControllerLab(JSON.parse(JSON.stringify(state)), command2);
      state = stepControllerLab(state, command2);
      if (state.stopped || labFingerprint(restored) !== labFingerprint(state))
        throw new Error("Encounter world restore failed");
      traceHash = stateHash({ traceHash, state: labFingerprint(state) });
      notices.push(...state.encounterNotices);
      if ([1, 10, 11, 30, 60, 120].includes(tick2))
        checkpoints.push({ tick: tick2, enemy: state.enemy, encounter: state.encounter });
    }
    const finalState = labFingerprint(state);
    replayControllerLab({ format: 6, scenario: "encounter-clear", commands, finalState });
    if (state.encounter?.phase !== "complete" || state.encounter.kills.some((k) => k.count !== 0) || notices.filter((n) => n.kind === "complete").length !== 1)
      throw new Error("Environmental encounter completion failed");
    const boss = new EncounterLifecycle({
      id: 99,
      participants: [1],
      members: [
        {
          id: 42,
          required: true,
          critical: true,
          retreatAllowed: false,
          watchdogTicks: 60,
          ambientCleanupTicks: null
        }
      ],
      objectives: []
    });
    const failure = boss.step(
      boss.begin(),
      1,
      [
        { sequence: 1, tick: 1, kind: "activate", id: 42 },
        { sequence: 2, tick: 1, kind: "resolve", id: 42, reason: "out-of-bounds", killerId: null }
      ],
      []
    );
    if (failure.state.phase !== "failed") throw new Error("Critical pose loss failed open");
    return { ticks: state.tick, traceHash, notices, checkpoints, failure };
  }

  // test/fixtures/entry-proof.ts
  function check11(ok, reason) {
    if (!ok) throw new Error(`Entry physics proof: ${reason}`);
  }
  function context(tick2, fixed, moving = []) {
    return { ...deathContext(tick2, fixed, moving), anchors: [{ x: 0, y: 0 }] };
  }
  function sample(actor, tick2) {
    return {
      tick: tick2,
      life: actor.life,
      presence: actor.bodyPresence,
      since: actor.lifeStartTick,
      lives: actor.lives,
      protection: actor.invulnerableTicks,
      body: actor.body
    };
  }
  function enter2(ctx) {
    const actor = enterPlayer(footActor(), ctx.frame.tick, "classic", ctx);
    check11(actor, "expected a safe anchor");
    return actor;
  }
  function carryContext(tick2, kind) {
    const platform = {
      ...footTerrain(100, -100 + tick2, -tick2, 200, 8, kind),
      delta: { x: pixels(1), y: -pixels(1) }
    };
    return { ...context(tick2, [], [platform]), anchors: [{ x: pixels(tick2), y: -pixels(tick2) }] };
  }
  function entryPhysicsProof() {
    const carry = [];
    for (const kind of ["solid", "one-way"]) {
      let actor2 = enter2(carryContext(0, kind));
      const trace = [sample(actor2, 0)];
      check11(actor2.body.x === pixels(1) && actor2.body.y === -pixels(1), "entry frame lost carry");
      for (let tick2 = 1; tick2 < 12; tick2++) {
        const ctx2 = carryContext(tick2, kind);
        actor2 = stepPlayerLife(actor2, tick2, "classic", ctx2).actor;
        const controlled = stepFootController(
          actor2,
          { held: Held.Right, jumpPressed: true },
          ctx2.definition,
          ctx2.shapes,
          ctx2.index,
          ctx2.frame
        );
        check11(controlled.status === "inactive", "entry accepted movement");
        const fired = stepFirearm(
          controlled.actor,
          { held: Held.Fire, firePressed: true },
          tick2,
          1,
          COMBAT_CATALOG
        );
        check11(fired.outcome === "unavailable" && fired.markers.length === 0, "entry accepted fire");
        actor2 = fired.actor;
        check11(
          actor2.body.x === pixels(tick2 + 1) && actor2.body.y === -pixels(tick2 + 1) && actor2.body.grounded,
          "protected carry diverged"
        );
        check11(
          actor2.jumpBufferTicks === 0 && actor2.weapon.shotOrdinal === 0,
          "entry queued rejected input"
        );
        trace.push(sample(actor2, tick2));
      }
      const ctx = carryContext(12, kind), ready3 = stepPlayerLife(actor2, 12, "classic", ctx);
      check11(ready3.notice?.kind === "ready", "entry deadline moved");
      const idle = stepFootController(
        ready3.actor,
        { held: 0, jumpPressed: false },
        ctx.definition,
        ctx.shapes,
        ctx.index,
        ctx.frame
      );
      check11(
        idle.status === "complete" && idle.actor.body.x === pixels(13) && idle.actor.body.y === -pixels(13),
        "ready frame carried twice"
      );
      const jump = stepFootController(
        ready3.actor,
        { held: Held.Right, jumpPressed: true },
        ctx.definition,
        ctx.shapes,
        ctx.index,
        ctx.frame
      );
      const vy = ctx.definition.jumpVelocity + ctx.definition.gravity;
      check11(
        jump.status === "complete" && jump.jumpRequest === "consumed" && jump.actor.body.vy === vy && jump.actor.body.x === pixels(12) + ctx.definition.runSpeed && jump.actor.body.y === -pixels(12) + vy && jump.actor.body.supportId === null,
        "first eligible jump did not consume exactly one frame"
      );
      const fire = stepFirearm(
        jump.actor,
        { held: Held.Fire, firePressed: true },
        12,
        1,
        COMBAT_CATALOG
      );
      check11(
        fire.outcome === "applied" && fire.actor.weapon.shotOrdinal === 1 && fire.markers.filter((marker) => marker.marker.kind === "spawn-attack").length === 1,
        "first eligible fire duplicated/lost"
      );
      carry.push({
        kind,
        trace,
        idle: sample(idle.actor, 12),
        jump: sample(fire.actor, 12),
        shots: fire.actor.weapon.shotOrdinal
      });
    }
    const ceiling = footTerrain(101, -100, -40, 200, 5), floor = footTerrain(100, -100, 0, 200, 8);
    const lift = { ...floor, delta: { x: 0, y: -pixels(4) } };
    const unsafe = context(0, [ceiling], [lift]);
    const original = footActor(), before = canonical(original);
    check11(
      enterPlayer(original, 0, "classic", unsafe) === null && canonical(original) === before,
      "unsafe initial sweep admitted or mutated player"
    );
    const fallback = enter2({
      ...context(0, [ceiling, footTerrain(200, 140, 0, 100, 8)], [lift]),
      anchors: [
        { x: 0, y: 0 },
        { x: pixels(150), y: 0 }
      ]
    });
    check11(
      fallback.body.x === pixels(150) && fallback.body.supportId === 200 && fallback.lives === 3,
      "unsafe priority anchor prevented safe fallback"
    );
    check11(
      enterPlayer(original, 0, "classic", {
        ...context(0, [], [{ ...floor, delta: { x: 0, y: pixels(4) } }]),
        fallBoundary: pixels(2)
      }) === null,
      "entry ended below fall plane"
    );
    let actor = enter2(context(0, [ceiling, floor]));
    const crushed = stepPlayerLife(actor, 1, "classic", {
      ...unsafe,
      frame: { tick: 1, geometryRevision: 1 },
      index: context(1, [ceiling], [lift]).index
    });
    actor = crushed.actor;
    check11(
      crushed.notice === null && actor.life === "respawning" && actor.bodyPresence === "removed" && actor.lives === 3 && actor.invulnerableTicks === 0 && actor.lifeStartTick === 0,
      "protected crush spent a life or restarted entry"
    );
    const waiting = [sample(actor, 1)];
    for (let tick2 = 2; tick2 <= 30; tick2++) {
      const ctx = context(tick2, []);
      const restored = stepPlayerLife(JSON.parse(JSON.stringify(actor)), tick2, "classic", ctx);
      const next = stepPlayerLife(actor, tick2, "classic", ctx);
      check11(
        canonical(next) === canonical(restored) && next.notice === null && next.actor.bodyPresence === "removed" && next.actor.life === "respawning" && next.actor.lives === 3,
        "waiting entry changed across reconstruction or became ready"
      );
      actor = next.actor;
      waiting.push(sample(actor, tick2));
    }
    const retried = stepPlayerLife(actor, 31, "classic", context(31, [floor]));
    check11(
      retried.notice?.kind === "respawn" && retried.actor.bodyPresence === "present" && retried.actor.lifeStartTick === 31 && retried.actor.invulnerableTicks === 120,
      "safe retry did not restart protection/animation"
    );
    actor = retried.actor;
    for (let tick2 = 32; tick2 <= 43; tick2++)
      actor = stepPlayerLife(actor, tick2, "classic", context(tick2, [floor])).actor;
    check11(
      actor.life === "alive" && actor.lifeStartTick === 43 && actor.lives === 3,
      "retry deadline/accounting diverged"
    );
    let falling = enter2({ ...context(0, [floor]), fallBoundary: pixels(2) });
    const supportLoss = [sample(falling, 0)];
    for (let tick2 = 1; tick2 <= 6; tick2++) {
      falling = stepPlayerLife(falling, tick2, "classic", {
        ...context(tick2, []),
        fallBoundary: pixels(2)
      }).actor;
      supportLoss.push(sample(falling, tick2));
    }
    check11(
      supportLoss[1]?.body.vy === 55 && supportLoss[3]?.presence === "present" && supportLoss[4]?.presence === "removed" && falling.lives === 3 && falling.life === "respawning",
      "lost support floated or charged a life"
    );
    const result = {
      carry,
      fallback: sample(fallback, 0),
      waiting,
      retried: sample(retried.actor, 31),
      ready: sample(actor, 43),
      supportLoss
    };
    return { ...result, hash: stateHash(result) };
  }

  // test/fixtures/entry-recovery-proof.ts
  var ENTRY_BOUNDARIES = [0, 6, 11, 12, 68, 69, 98, 99, 110, 111];
  function recordMovingEntry() {
    const initial = createCombatRuntime("ordnance");
    const frame = { tick: 0, geometryRevision: 1 }, index = combatCollisionIndex("ordnance", frame);
    initial.combat.players = initial.combat.players.map((actor) => {
      const entered = enterPlayer(
        actor,
        0,
        "classic",
        combatEntryContext(actor, index, frame, "ordnance")
      );
      if (!entered) throw new Error("Missing initial lift entry");
      return entered;
    });
    initial.snapshot = combatSnapshot(initial.combat, initial.snapshot, initial.campaign);
    return recordCombatInputs(
      initial,
      145,
      (tick2) => ({
        held: tick2 <= 50 ? Held.Right : 0,
        edges: tick2 === 6 || tick2 === 12 ? [Edge.FireOnset] : []
      }),
      { duplicatePackets: true }
    );
  }
  async function entryRecoveryProof() {
    const fixture = recordMovingEntry(), identity3 = await combatArchiveIdentity(), checkpoints = [];
    for (const [slot] of fixture.state.combat.players.entries()) {
      const initial = fixture.states[0]?.combat.players[slot], protectedBody = fixture.states[11]?.combat.players[slot], ready3 = fixture.states[12]?.combat.players[slot], killed = fixture.states[69]?.combat.players[slot], entered = fixture.states[99]?.combat.players[slot], resumed = fixture.states[111]?.combat.players[slot];
      if (!initial || protectedBody?.life !== "respawning" || protectedBody.body.x !== initial.body.x + pixels(11) || protectedBody.weapon.shotOrdinal !== 0 || ready3?.life !== "alive" || ready3.body.x !== initial.body.x + pixels(15) || ready3.weapon.shotOrdinal !== 1 || killed?.life !== "death" || killed.bodyPresence !== "removed" || killed.lifeStartTick !== 69 || killed.lives !== 2 || entered?.life !== "respawning" || entered.bodyPresence !== "present" || entered.lifeStartTick !== 99 || resumed?.life !== "alive" || resumed.lifeStartTick !== 111 || resumed.lives !== 2)
        throw new Error(`Moving entry/crush lifecycle diverged for slot ${slot}`);
    }
    for (const tick2 of ENTRY_BOUNDARIES) {
      const original = fixture.states[tick2], accepted = fixture.states[tick2 + 15];
      if (!original || !accepted) throw new Error("Missing moving entry boundary");
      const raw = await encodeCombatCheckpoint(original, identity3), restored = await decodeCombatCheckpoint(raw, identity3);
      const resumed = await restoreCombatJournalSegment(
        restored,
        await encodeCombatJournalSegment(original, fixture.entries.slice(tick2, tick2 + 15), identity3),
        identity3
      );
      const context2 = combatPeerContext(original.snapshot, 0), wire = encodeSnapshot(original.snapshot, context2);
      if (canonical(restored) !== canonical(original) || canonical(resumed) !== canonical(accepted) || canonical(decodeSnapshot(wire, context2)) !== canonical(original.snapshot))
        throw new Error("Moving entry archive/wire continuation diverged");
      checkpoints.push({
        tick: tick2,
        through: resumed.combat.tick,
        player: restored.combat.players[0],
        snapshotBytes: wire.length,
        checkpointBytes: new TextEncoder().encode(raw).byteLength,
        hash: combatRuntimeHash(resumed)
      });
    }
    const events = fixture.states.flatMap(
      (state) => state.combat.events.filter((event) => event.kind === "shot").map((event) => ({ tick: state.combat.tick, ...event }))
    );
    const transitions = fixture.states.flatMap(
      (state, index) => state.combat.players.filter(
        (player2) => player2.life !== fixture.states[index - 1]?.combat.players[player2.slot]?.life
      ).map(({ slot, life, lives, bodyPresence }) => ({
        tick: state.combat.tick,
        slot,
        life,
        lives,
        bodyPresence
      }))
    );
    return {
      checkpoints,
      events,
      transitions,
      duplicates: fixture.duplicates,
      reconciliations: fixture.reconciliations,
      ticks: fixture.state.combat.tick,
      traceHash: stateHash(fixture.states.map(combatRuntimeHash))
    };
  }

  // test/fixtures/event-delivery-proof.ts
  function eventDeliveryProof() {
    const initial = createCombatWorkload();
    let world = initial.combat, history = createEventHistory(1);
    const contexts = world.players.map((actor) => combatEventContext(probeContext(actor.slot)));
    const primary = contexts[0];
    if (!primary) throw new Error("Missing event proof owner");
    const receivers = contexts.map(
      (context2) => new EventReceiver(context2, { ...initial.snapshot, connectionEpoch: context2.connectionEpoch })
    );
    const chains = ["0", "0", "0", "0"], kills = [0, 0, 0, 0];
    const traces = [];
    let dropped = 0, repairTick = 0;
    const actionKeys = /* @__PURE__ */ new Map();
    const keyOwners = /* @__PURE__ */ new Map();
    for (let tick2 = 1; tick2 <= 300; tick2++) {
      const next = stepCombatLab(
        world,
        world.players.map(() => ({
          held: Held.Fire,
          jumpPressed: false,
          interactPressed: false,
          grenadePressed: false,
          firePressed: tick2 === 1
        }))
      );
      const notices = combatGameplayEvents(world, next);
      for (const event of notices)
        if (event.confirmation) {
          const key = JSON.stringify(event.confirmation);
          if (actionKeys.has(event.actionInstanceId) && actionKeys.get(event.actionInstanceId) !== key || keyOwners.has(key) && keyOwners.get(key) !== event.actionInstanceId)
            throw new Error("Firearm confirmation key was reused or changed between markers");
          actionKeys.set(event.actionInstanceId, key);
          keyOwners.set(key, event.actionInstanceId);
        }
      history = stageEventTick(history, tick2, notices, primary);
      world = next;
      if (tick2 % 3 !== 0) continue;
      for (const [slot, receiver] of receivers.entries()) {
        const context2 = contexts[slot];
        if (!context2) throw new Error("Missing event proof session");
        const batches = eventBatches(history, receiver.cursor, context2.connectionEpoch);
        if (batches === null) {
          const snapshot = combatSnapshot(world, initial.snapshot);
          Object.assign(snapshot, {
            snapshotId: tick2 * 4 + slot + 10,
            connectionEpoch: context2.connectionEpoch,
            baselineEventCursor: history.cursor
          });
          snapshot.stateHash = roomWorkloadHash(snapshot);
          const baseline = decodeSnapshot(
            encodeSnapshot(snapshot, probeContext(slot)),
            probeContext(slot)
          );
          const promise = decodeEventBaseline(
            JSON.stringify({
              type: "resync-required",
              scope: "events",
              reason: "history-expired",
              runEpoch: 1,
              connectionEpoch: context2.connectionEpoch,
              snapshotId: baseline.snapshotId,
              tick: tick2,
              baselineEventCursor: history.cursor
            }),
            context2
          );
          receiver.installBaseline(baseline, promise);
          if (!acceptsEventBaseline(promise, baseline.snapshotId, receiver.cursor, 0))
            throw new Error("Missing explicit event baseline acceptance");
          repairTick = tick2;
        } else if (slot === 0 && tick2 > 60 && repairTick === 0) dropped += batches.length;
        else
          for (const batch of batches) {
            const decoded = decodeEventBatch(encodeEventBatch(batch, context2), context2);
            const fresh = receiver.consume(decoded);
            if (slot === 1 && receiver.consume(decoded).length !== 0)
              throw new Error("Duplicate event was replayed");
            for (const item of fresh) {
              chains[slot] = stateHash([chains[slot], { runEpoch: 1, ...item }]);
              if (item.event.kind === "killed") kills[slot] = (kills[slot] ?? 0) + 1;
            }
          }
      }
      traces.push(
        stateHash({ tick: tick2, history, receivers: receivers.map((item) => item.status), chains, kills })
      );
    }
    if (receivers.some((item) => item.cursor !== history.cursor || item.requiresBaseline))
      throw new Error("Event cursor convergence failed");
    if (chains[1] !== chains[2] || chains[2] !== chains[3] || receivers[0]?.status.baselines !== 1 || !repairTick || receivers[1]?.status.duplicates === 0 || kills.some((count) => count !== 2))
      throw new Error("Event delivery, repair or effect deduplication failed");
    if (actionKeys.size !== world.players.reduce((sum, actor) => sum + actor.weapon.shotOrdinal, 0))
      throw new Error("Missing automatic-fire confirmation key");
    return {
      ticks: world.tick,
      confirmedActions: actionKeys.size,
      cursor: history.cursor,
      repairTick,
      droppedFrames: dropped,
      retained: history.entries.length,
      capEvictions: history.capEvictions,
      ageEvictions: history.ageEvictions,
      receivers: receivers.map((item) => item.status),
      kills,
      unimpairedHash: chains[1],
      traceHash: stateHash(traces)
    };
  }

  // test/fixtures/foot-combat-proof.ts
  function recordFootCombat(mode) {
    return recordCombatInputs(
      createCombatRuntime("range"),
      120,
      (tick2) => mode === "melee" ? { held: tick2 <= 45 ? Held.Right : Held.Fire, edges: tick2 === 46 ? [Edge.FireOnset] : [] } : {
        held: mode === "crouched-grenade" ? Held.Down : 0,
        edges: tick2 === 1 || tick2 === 3 ? [Edge.Grenade] : []
      },
      { duplicatePackets: true }
    );
  }
  async function footCombatProof() {
    const identity3 = await combatArchiveIdentity();
    const scenarios = [];
    for (const mode of ["melee", "grenade", "crouched-grenade"]) {
      const fixture = recordFootCombat(mode);
      const checkpoints = [];
      for (const tick2 of mode === "melee" ? [46, 50, 51, 54] : [1, 4, 5, 50, 51, 76, 88, 94, 95]) {
        const original = fixture.states[tick2], accepted = fixture.states[tick2 + 15];
        if (!original || !accepted) throw new Error("Missing foot combat boundary");
        const raw = await encodeCombatCheckpoint(original, identity3);
        const restored = await decodeCombatCheckpoint(raw, identity3);
        if (canonical(restored) !== canonical(original)) throw new Error("Foot checkpoint diverged");
        const segment = await encodeCombatJournalSegment(
          original,
          fixture.entries.slice(tick2, tick2 + 15),
          identity3
        );
        const resumed = await restoreCombatJournalSegment(restored, segment, identity3);
        if (canonical(resumed) !== canonical(accepted))
          throw new Error("Foot action replay diverged");
        const context2 = combatPeerContext(original.snapshot, 0);
        const bytes = encodeSnapshot(original.snapshot, context2);
        if (canonical(decodeSnapshot(bytes, context2)) !== canonical(original.snapshot))
          throw new Error("Foot action snapshot diverged");
        const eventContext = combatEventContext(context2);
        const batches = eventBatches(
          resumed.history,
          original.history.cursor,
          context2.connectionEpoch
        );
        if (!batches) throw new Error("Foot action lost event prefix");
        for (const batch of batches)
          if (canonical(decodeEventBatch(encodeEventBatch(batch, eventContext), eventContext)) !== canonical(batch))
            throw new Error("Foot action event frame diverged");
        checkpoints.push({
          tick: tick2,
          checkpointBytes: new TextEncoder().encode(raw).byteLength,
          snapshotBytes: bytes.byteLength,
          hash: combatRuntimeHash(restored),
          resumedHash: combatRuntimeHash(resumed),
          resumedTick: resumed.combat.tick,
          stocks: original.combat.players.map((player2) => player2.grenadeStock),
          cursors: original.combat.players.map((player2) => player2.action.nextMarkerIndex),
          hitIds: original.combat.strikes.map((strike) => strike.hitIds),
          grenades: original.combat.grenades.map(({ id: id2, spawnTick, bounces, body: body4 }) => ({
            id: id2,
            spawnTick,
            bounces,
            x: body4.x,
            y: body4.y,
            vx: body4.vx,
            vy: body4.vy
          }))
        });
      }
      const notices = fixture.states.flatMap(
        (state) => state.combat.events.map((event) => ({ tick: state.combat.tick, ...event }))
      );
      const actions = notices.filter((event) => ["melee", "throw", "explosion", "killed"].includes(event.kind)).map(({ tick: tick2, kind, ownerId, actionInstanceId, targetId }) => ({
        tick: tick2,
        kind,
        ownerId,
        actionInstanceId,
        targetId
      }));
      const releases = actions.filter(
        (event) => event.kind === (mode === "melee" ? "melee" : "throw")
      );
      if (canonical(releases.map((event) => event.tick)) !== canonical(Array(4).fill(mode === "melee" ? 51 : 5)))
        throw new Error("Foot action release duplicated or mistimed");
      if (mode !== "melee") {
        if (fixture.state.combat.players.some((player2) => player2.grenadeStock !== 9))
          throw new Error("Duplicate or busy grenade input spent stock");
        const detonations = actions.filter((event) => event.kind === "explosion");
        if (canonical(detonations.map((event) => event.tick)) !== canonical([95, 95, 95, 95]))
          throw new Error("Grenade fuse duplicated or mistimed");
      }
      scenarios.push({
        mode,
        ticks: fixture.state.combat.tick,
        duplicates: fixture.duplicates,
        reconciliations: fixture.reconciliations,
        actions,
        checkpoints,
        stateHash: combatRuntimeHash(fixture.state),
        traceHash: stateHash(fixture.states.map(combatRuntimeHash))
      });
    }
    return {
      scenarios,
      scope: "Engineering range, actual admitted intent and exact private recovery; no authored mission or final art acceptance"
    };
  }

  // test/fixtures/grounded-proof.ts
  function seamProof() {
    const results = [];
    const rotateRect = (rect) => ({
      x: -rect.y - rect.h,
      y: rect.x,
      w: rect.h,
      h: rect.w
    });
    const rotatePoint = (point3) => ({ x: -point3.y, y: point3.x });
    let body4 = { x: 0, y: 0, w: 10, h: 10 };
    let a = { x: -20, y: 10, w: 30, h: 10 };
    let b = { x: 10, y: 10, w: 30, h: 10 };
    let motion2 = { x: 5, y: 2 };
    let expected = { x: 5, y: 0, w: 10, h: 10 };
    for (let rotation = 0; rotation < 4; rotation++) {
      const targets2 = [a, b].map((rect, i) => ({
        id: i + 1,
        rect,
        delta: { x: 0, y: 0 },
        kind: "solid"
      }));
      const forward3 = moveKinematic({ rect: body4, motion: motion2, supportId: null }, targets2);
      const reverse = moveKinematic({ rect: body4, motion: motion2, supportId: null }, [...targets2].reverse());
      results.push({ rotation, expected, forward: forward3, reverse });
      body4 = rotateRect(body4);
      a = rotateRect(a);
      b = rotateRect(b);
      motion2 = rotatePoint(motion2);
      expected = rotateRect(expected);
    }
    return { results, traceHash: stateHash(results) };
  }
  function groundedProof(restoreAt) {
    let state = createControllerLab("enemy-ledge");
    let traceHash = "00000000";
    const checkpoints = [];
    for (let tick2 = 1; tick2 <= 1200; tick2++) {
      state = stepControllerLab(state, {
        held: 0,
        jumpPressed: tick2 % 60 === 1,
        startTraversal: false,
        removePlatform: tick2 === 901
      });
      if (state.stopped) throw new Error(`Enemy lab stopped: ${state.stopped}`);
      traceHash = stateHash({
        traceHash,
        tick: tick2,
        actor: state.actor,
        enemy: state.enemy,
        resolvedEnemies: state.resolvedEnemies
      });
      if ([1, 300, 600, 900, 901, 960, 1200].includes(tick2))
        checkpoints.push({ tick: tick2, enemy: state.enemy, geometryRevision: state.geometryRevision });
      if (tick2 === restoreAt) state = JSON.parse(JSON.stringify(state));
    }
    return { ticks: 1200, traceHash, checkpoints };
  }

  // test/fixtures/hmg-proof.ts
  var HMG_BOUNDARIES = [1, 6, 7, 11, 26, 47, 48, 51, 66, 70, 96, 97, 101, 102];
  var hmgInput = (tick2) => ({
    held: (tick2 <= 100 ? Held.Fire : 0) | (tick2 >= 6 && tick2 <= 25 || tick2 >= 66 && tick2 <= 85 || tick2 >= 101 ? Held.Up : 0) | (tick2 >= 47 && tick2 <= 65 || tick2 >= 91 && tick2 <= 100 ? Held.Down : 0) | (tick2 >= 86 && tick2 <= 90 ? Held.Left : 0),
    edges: tick2 === 46 ? [Edge.Jump] : []
  });
  function recordHmg() {
    return recordCombatInputs(createCombatRuntime("hmg"), 120, hmgInput, { duplicatePackets: true });
  }
  async function hmgProof() {
    const fixture = recordHmg(), identity3 = await combatArchiveIdentity(), checkpoints = [];
    for (const tick2 of HMG_BOUNDARIES) {
      const original = fixture.states[tick2], accepted = fixture.states[tick2 + 15];
      if (!original || !accepted) throw new Error("Missing HMG boundary");
      const raw = await encodeCombatCheckpoint(original, identity3), restored = await decodeCombatCheckpoint(raw, identity3);
      const journal = await encodeCombatJournalSegment(
        original,
        fixture.entries.slice(tick2, tick2 + 15),
        identity3
      );
      const resumed = await restoreCombatJournalSegment(restored, journal, identity3);
      const context2 = combatPeerContext(original.snapshot, 0), wire = encodeSnapshot(original.snapshot, context2);
      if (canonical(restored) !== canonical(original) || canonical(resumed) !== canonical(accepted) || canonical(decodeSnapshot(wire, context2)) !== canonical(original.snapshot))
        throw new Error("HMG continuation diverged");
      checkpoints.push({
        tick: tick2,
        snapshotBytes: wire.length,
        checkpointBytes: new TextEncoder().encode(raw).byteLength,
        players: original.combat.players,
        projectiles: original.combat.projectiles,
        hash: combatRuntimeHash(original),
        resumedHash: combatRuntimeHash(resumed),
        resumedTick: resumed.combat.tick
      });
    }
    const releases = fixture.states.flatMap(
      (state) => state.combat.projectiles.filter((projectile) => projectile.spawnTick === state.combat.tick).map((projectile) => ({ tick: state.combat.tick, ...projectile }))
    );
    const events = fixture.states.flatMap(
      (state) => state.combat.events.map((event) => ({ tick: state.combat.tick, ...event }))
    );
    for (const player2 of fixture.state.combat.players) {
      const shots = releases.filter((shot) => shot.ownerId === player2.playerId);
      if (player2.weapon.shotOrdinal !== 20 || player2.weapon.ammo !== 130 || player2.lives !== 3 || player2.grenadeStock !== 10 || !shots.some((shot) => shot.velocity.x && shot.velocity.y < 0) || !shots.some((shot) => shot.velocity.x && shot.velocity.y > 0))
        throw new Error("HMG sweep, stock or life outcome diverged");
    }
    return {
      ticks: 120,
      duplicates: fixture.duplicates,
      reconciliations: fixture.reconciliations,
      checkpoints,
      releases,
      events,
      players: fixture.state.combat.players,
      finalHash: combatRuntimeHash(fixture.state),
      traceHash: stateHash(fixture.states.map(combatRuntimeHash))
    };
  }

  // src/shared/input/capture.ts
  var MAX_CAPTURE_EDGES = 64;
  var INPUT_FRAME_RATE = 30;
  var INPUT_FRAME_BURST = 10;
  function inputSequenceLimit(initialServerTick, snapshotTick) {
    integer(initialServerTick, 0, COUNTER_LIMIT - 1, "input baseline tick");
    integer(snapshotTick, initialServerTick, COUNTER_LIMIT - 1, "validated snapshot tick");
    return Math.min(COUNTER_LIMIT - 1, snapshotTick + MAX_CLIENT_LEAD_TICKS) - initialServerTick;
  }
  var InputCapture = class {
    constructor(epoch) {
      this.epoch = epoch;
      const controlEpoch = epoch;
      integer(controlEpoch, 1, COUNTER_LIMIT - 1, "input control epoch");
    }
    epoch;
    #sources = /* @__PURE__ */ new Map();
    #edges = [];
    #commands = [];
    #cursors = [0, 0, 0, 0, 0];
    #sequence = 0;
    #stopped = false;
    #tokens = INPUT_FRAME_BURST;
    #lastBudgetTime = null;
    #lastSendTime = null;
    get controlEpoch() {
      return this.epoch;
    }
    /** New samples use the new owner; already captured commands keep immutable old identities. */
    advanceControlEpoch(controlEpoch) {
      this.#guard();
      integer(controlEpoch, this.epoch + 1, COUNTER_LIMIT - 1, "input ownership advance");
      this.epoch = controlEpoch;
      this.#edges.length = 0;
    }
    get held() {
      return [...this.#sources.values()].reduce((mask, binding) => mask | (binding.held ?? 0), 0);
    }
    get pending() {
      return this.#commands.length;
    }
    get pendingEdges() {
      return this.#edges.length;
    }
    get sequence() {
      return this.#sequence;
    }
    get requiresResync() {
      return this.#stopped;
    }
    #reject(message) {
      this.#stopped = true;
      throw new ProtocolError("resync-required", message);
    }
    #guard() {
      if (this.#stopped) this.#reject("Input capture requires a fresh baseline");
    }
    press(source3, binding) {
      this.#guard();
      if (source3.length === 0 || source3.length > 80 || !binding.held && !binding.edge || !Number.isInteger(binding.held ?? 0) || (binding.held ?? 0) < 0 || (binding.held ?? 0) > HELD_MASK || binding.edge !== void 0 && !EDGE_KINDS.includes(binding.edge))
        this.#reject("Invalid input binding");
      const previous = this.#sources.get(source3);
      if (previous) {
        if (previous.held !== binding.held || previous.edge !== binding.edge)
          this.#reject("Input source binding changed while pressed");
        return;
      }
      if (this.#sources.size >= 64) this.#reject("Input source bound");
      const edgeHeld = [...this.#sources.values()].some((b) => b.edge === binding.edge);
      if (binding.edge !== void 0 && !edgeHeld) {
        if (this.#edges.length >= MAX_CAPTURE_EDGES) this.#reject("Input edge queue bound");
        const index = binding.edge - 1;
        let id2;
        try {
          id2 = nextCounter(this.#cursors[index] ?? 0);
        } catch {
          this.#reject("Input edge counter needs rotation");
        }
        this.#cursors[index] = id2;
        this.#edges.push({ kind: binding.edge, id: id2 });
      }
      this.#sources.set(source3, { ...binding });
    }
    release(source3) {
      this.#sources.delete(source3);
    }
    /** Release unsampled intent. Already captured commands retain their immutable identities. */
    neutralize() {
      this.#sources.clear();
      this.#edges.length = 0;
    }
    capture(aim) {
      this.#guard();
      if (!Number.isInteger(aim) || aim < 0 || aim > 2) this.#reject("Invalid input aim");
      if (this.#commands.length >= MAX_QUEUED_COMMANDS) this.#reject("Unsent input queue bound");
      let sequence;
      try {
        sequence = nextCounter(this.#sequence);
      } catch {
        this.#reject("Input sequence needs rotation");
      }
      const command2 = {
        sequence,
        clientTick: sequence - 1,
        controlEpoch: this.controlEpoch,
        held: this.held,
        aim,
        edges: this.#edges.splice(0, MAX_EDGES_PER_COMMAND)
      };
      this.#sequence = sequence;
      this.#commands.push(command2);
      return structuredClone(command2);
    }
    /** The caller supplies the last validated snapshot's sequence limit; force only bypasses batching delay. */
    takeBatch(nowMs, throughSequence, force = false) {
      this.#guard();
      if (!Number.isSafeInteger(throughSequence) || throughSequence < 0 || throughSequence >= COUNTER_LIMIT)
        this.#reject("Invalid input send window");
      if (!Number.isFinite(nowMs) || nowMs < 0 || nowMs < (this.#lastBudgetTime ?? 0))
        this.#reject("Input transport clock invalid/regressed");
      if (this.#lastBudgetTime !== null)
        this.#tokens = Math.min(
          INPUT_FRAME_BURST,
          this.#tokens + (nowMs - this.#lastBudgetTime) * INPUT_FRAME_RATE / 1e3
        );
      this.#lastBudgetTime = nowMs;
      if (!this.#commands.length) return null;
      const batch = this.#commands.slice(0, MAX_COMMANDS).filter((command2) => command2.sequence <= throughSequence);
      if (!batch.length) return null;
      const due = force || this.#commands.length >= MAX_COMMANDS || batch.some((command2) => command2.edges.length > 0) || this.#lastSendTime !== null && nowMs - this.#lastSendTime >= 50;
      if (!due || this.#tokens < 1) return null;
      this.#tokens--;
      this.#lastSendTime = nowMs;
      return this.#commands.splice(0, batch.length);
    }
  };

  // test/fixtures/input-capture-proof.ts
  function inputCaptureProof() {
    const input = new InputCapture(1), frames = [];
    for (let tick2 = 1; tick2 <= 60; tick2++) {
      if (tick2 === 2 || tick2 === 17) {
        input.press("fire", { held: Held.Fire, edge: Edge.FireOnset });
        input.release("fire");
      }
      if (tick2 === 8) {
        input.press("jump", { edge: Edge.Jump });
        input.release("jump");
        input.press("grenade", { edge: Edge.Grenade });
        input.release("grenade");
      }
      if (tick2 === 20) input.press("left", { held: Held.Left });
      if (tick2 === 25) input.neutralize();
      input.capture(0);
      const commands2 = input.takeBatch(tick2 * 1e3 / 60, input.sequence);
      if (commands2) {
        const packet = encodeInputBatch({
          runEpoch: 1,
          connectionEpoch: 1,
          packetSequence: frames.length + 1,
          snapshotAck: 0,
          eventAck: 0,
          commands: commands2
        });
        frames.push(decodeInputBatch(packet, { runEpoch: 1, connectionEpoch: 1 }).commands);
      }
    }
    const remainder = input.takeBatch(1001, input.sequence, true);
    if (remainder) frames.push(remainder);
    const commands = frames.flat();
    if (commands.length !== 60 || input.pending !== 0) throw new Error("Lost captured command");
    return {
      ticks: commands.length,
      frames: frames.length,
      traceHash: stateHash(commands),
      edges: commands.flatMap((c) => c.edges.map((edge) => ({ tick: c.clientTick, ...edge }))),
      heldTicks: commands.filter((c) => c.held !== 0).map((c) => c.clientTick)
    };
  }

  // test/fixtures/input-flow-proof.ts
  function inputFlowProof(initialServerTick = 0) {
    function run2(limited) {
      const input = new InputCapture(1);
      const identity3 = { runEpoch: 1, connectionEpoch: 1 };
      const stream = new InputStream({
        ...identity3,
        playerId: 1,
        controlEpoch: 1,
        baselineServerTick: initialServerTick
      });
      let serverTick = initialServerTick, snapshotTick = initialServerTick, packetSequence = 0, nowMs = 0;
      const captured = [], sent = [], edges = [];
      const capture = () => {
        const command2 = input.capture(0);
        captured.push(command2);
        return command2;
      };
      const packet = (commands2) => encodeInputBatch({
        ...identity3,
        packetSequence: ++packetSequence,
        snapshotAck: 0,
        eventAck: 0,
        commands: commands2
      });
      const send = () => {
        nowMs += 50;
        const commands2 = input.takeBatch(
          nowMs,
          inputSequenceLimit(initialServerTick, snapshotTick),
          true
        );
        if (!commands2) throw new Error("Expected eligible transport prefix");
        stream.receive(packet(commands2), nowMs, serverTick);
        sent.push(...commands2);
        return commands2;
      };
      const step = () => {
        nowMs += 17;
        const result = stream.processTick(++serverTick, nowMs, (applied) => {
          for (const edge of applied.command.edges)
            edges.push({ tick: serverTick, sequence: applied.command.sequence, ...edge });
          return applied.command.edges.map((edge) => ({ ...edge, outcome: "applied" }));
        });
        return result;
      };
      for (let group = 0; group < 40; group++) {
        for (let index = 0; index < 3; index++) capture();
        send();
        for (let index = 0; index < 3; index++) step();
        snapshotTick = serverTick;
      }
      for (let index = 0; index < 4; index++) capture();
      send();
      send();
      capture();
      capture();
      input.press("jump", { edge: Edge.Jump });
      input.release("jump");
      input.press("fire", { held: Held.Fire, edge: Edge.FireOnset });
      input.release("fire");
      const deferred = capture();
      const through = inputSequenceLimit(initialServerTick, snapshotTick);
      nowMs += 50;
      const commands = input.takeBatch(nowMs, limited ? through : input.sequence, true);
      if (!commands) throw new Error("Missing late batch");
      const priorQueue = stream.queuedCommands;
      try {
        stream.receive(packet(commands), nowMs, serverTick);
      } catch (error) {
        if (limited) throw error;
        return {
          status: "rejected",
          error: String(error),
          tick: serverTick,
          rejected: commands.map((command2) => command2.sequence),
          priorQueue,
          retainedQueue: stream.queuedCommands,
          acknowledgment: stream.acknowledgment,
          requiresResync: stream.requiresResync
        };
      }
      sent.push(...commands);
      const closedWindow = input.takeBatch(nowMs, through, true), blockedCommands = input.pending;
      if (closedWindow !== null || blockedCommands !== 1)
        throw new Error("Closed window lost or sent its tail");
      input.neutralize();
      capture();
      capture();
      for (let index = 0; index < 3; index++) step();
      snapshotTick = serverTick;
      const released = send();
      const duplicate = stream.receive(
        encodeInputBatch({
          ...identity3,
          packetSequence,
          snapshotAck: 0,
          eventAck: 0,
          commands: released
        }),
        ++nowMs,
        serverTick
      );
      for (let index = 0; index < 7; index++) step();
      if (canonical(captured) !== canonical(sent) || input.pending !== 0 || stream.queuedCommands !== 0)
        throw new Error("Input flow changed or lost a captured command");
      return {
        status: "pass",
        firstLimit: through,
        firstBatch: commands.map((command2) => command2.sequence),
        blockedCommands,
        deferred,
        releasedLimit: inputSequenceLimit(initialServerTick, snapshotTick),
        released,
        duplicate: duplicate.duplicate,
        finalTick: serverTick,
        acknowledgment: stream.acknowledgment,
        appliedEdges: edges,
        commands: captured.length,
        traceHash: stateHash({ captured, sent, edges, acknowledgment: stream.acknowledgment }),
        requiresResync: stream.requiresResync
      };
    }
    const unsafe = run2(false), safe = run2(true);
    if (unsafe.status !== "rejected" || safe.status !== "pass")
      throw new Error("Input flow control mismatch");
    return { initialServerTick, unsafe, safe };
  }

  // test/fixtures/laser-combat-proof.ts
  var LASER_COMBAT_BOUNDARIES = [
    0,
    1,
    2,
    6,
    7,
    8,
    12,
    13,
    18,
    19,
    24,
    25,
    31,
    32,
    37,
    42,
    43,
    49,
    50
  ];
  function recordLaserCombat() {
    return recordCombatInputs(
      createCombatRuntime("laser"),
      72,
      (tick2) => ({
        held: tick2 >= 7 && tick2 <= 24 ? Held.Fire | Held.Up : tick2 >= 31 && tick2 <= 42 ? Held.Fire | Held.Right : 0,
        edges: [1, 7, 13, 31, 49].includes(tick2) ? [Edge.FireOnset] : []
      }),
      { duplicatePackets: true }
    );
  }
  async function laserCombatProof() {
    const fixture = recordLaserCombat(), identity3 = await combatArchiveIdentity(), checkpoints = [];
    for (const tick2 of LASER_COMBAT_BOUNDARIES) {
      const original = fixture.states[tick2], accepted = fixture.states[tick2 + 15];
      if (!original || !accepted) throw new Error("Missing laser continuation boundary");
      const raw = await encodeCombatCheckpoint(original, identity3);
      const restored = await decodeCombatCheckpoint(raw, identity3);
      const segment = await encodeCombatJournalSegment(
        original,
        fixture.entries.slice(tick2, tick2 + 15),
        identity3
      );
      const resumed = await restoreCombatJournalSegment(restored, segment, identity3);
      if (canonical(restored) !== canonical(original) || canonical(resumed) !== canonical(accepted))
        throw new Error("Laser archive continuation diverged");
      const context2 = combatPeerContext(original.snapshot, 0), bytes = encodeSnapshot(original.snapshot, context2);
      if (canonical(decodeSnapshot(bytes, context2)) !== canonical(original.snapshot))
        throw new Error("Beam geometry snapshot diverged");
      checkpoints.push({
        tick: tick2,
        checkpointBytes: new TextEncoder().encode(raw).byteLength,
        snapshotBytes: bytes.byteLength,
        beams: original.combat.beams,
        volumes: original.snapshot.combat?.volumes,
        hash: combatRuntimeHash(original),
        resumedTick: resumed.combat.tick,
        resumedHash: combatRuntimeHash(resumed)
      });
    }
    const events = fixture.states.flatMap(
      (state) => state.combat.events.filter((event) => ["shot", "explosion", "impact", "killed"].includes(event.kind)).map((event) => ({ tick: state.combat.tick, ...event }))
    );
    if (fixture.state.combat.players.some(
      (player2) => player2.lives !== 3 || player2.weapon.ammo !== 113 || player2.weapon.shotOrdinal !== 7
    ))
      throw new Error("Laser charge/life accounting diverged");
    if (events.filter((event) => event.kind === "shot").length !== 28 || fixture.state.combat.beams.length)
      throw new Error("Laser release/terminal count diverged");
    if (!fixture.states.some(
      (state) => state.combat.beams.some((beam) => beam.tick > beam.spawnTick && beam.heading === 1)
    ))
      throw new Error("Laser fixture did not exercise a held upward charge");
    return {
      ticks: 72,
      duplicates: fixture.duplicates,
      checkpoints,
      events,
      finalHash: combatRuntimeHash(fixture.state),
      traceHash: stateHash(fixture.states.map(combatRuntimeHash)),
      encounter: fixture.state.combat.encounter.phase,
      players: fixture.state.combat.players.map(({ weapon: weapon2, lives }) => ({ weapon: weapon2, lives })),
      scope: "Accepted four-player laser energy/pulse accounting, public clipped geometry and private charge lifetime through checkpoint and journal replay. Engineering content; SQLite and browser room execution are separate harnesses."
    };
  }

  // src/shared/diagnostics/controller-workload.ts
  var CONTROLLER_IDENTITY = {
    ...PROBE_IDENTITY,
    contentHash: navigation_default.contentHash,
    presentationBuild: navigation_default.graphicsHash
  };
  var CONTROLLER_TERRAIN = navigation_default.gameplay.terrain;
  var shapes = new Map(
    navigation_default.gameplay.definitions.shapes.map((s) => [s.id, s])
  );
  var definition = navigation_default.gameplay.definitions.actors.find(
    (a) => a.id === navigation_default.gameplay.entry.actorId
  );
  if (!definition) throw new Error("Missing compiled controller definition");
  var grid = new CollisionGrid(CONTROLLER_TERRAIN);
  function createControllerWorkload() {
    const world = createRoomWorkload(1);
    world.players = Array.from(
      { length: 4 },
      (_, slot) => ({
        ...footActor(),
        ...structuredClone(navigation_default.gameplay.entry.actor),
        playerId: slot + 1,
        slot,
        controlEpoch: 1,
        body: {
          ...structuredClone(navigation_default.gameplay.entry.actor.body),
          id: slot + 1,
          x: navigation_default.gameplay.entry.actor.body.x + slot * 3 * 256
        }
      })
    );
    world.enemies = [];
    world.projectiles = [];
    world.platforms = [];
    world.vehicles = [];
    world.threats = [];
    world.campaign.remainingEnemies = 0;
    return world;
  }
  function stepNetworkController(actor, command2, tick2) {
    if (!definition || command2.controlEpoch !== actor.controlEpoch)
      throw new Error("Controller epoch/policy mismatch");
    const frame = { tick: tick2, geometryRevision: 1 };
    const result = stepFootController(
      actor,
      { held: command2.held, jumpPressed: command2.edges.some((e) => e.kind === Edge.Jump) },
      definition,
      shapes,
      new CollisionIndex(grid, [], frame),
      frame
    );
    if (result.status === "failed") throw new Error(`Controller physics: ${result.physics.reason}`);
    let next = result.actor;
    next.processedEdgeIds = [...actor.processedEdgeIds];
    for (const edge of command2.edges) next.processedEdgeIds[edge.kind - 1] = edge.id;
    if (next.life === "alive" && next.body.y > 390 * 256)
      next = damagePlayer(next, tick2, 1, "classic", "fall").actor;
    let jumpHandled = false;
    const edges = command2.edges.map((edge) => {
      const applied = edge.kind === Edge.Jump && !jumpHandled && result.status === "complete" && (result.jumpRequest === "consumed" || result.jumpRequest === "buffered");
      if (edge.kind === Edge.Jump) jumpHandled = true;
      return { ...edge, outcome: applied ? "applied" : "unavailable" };
    });
    return { actor: next, edges };
  }

  // test/fixtures/mapped-prediction-proof.ts
  function mappedPredictionProof() {
    const world = createControllerWorkload(), context2 = probeContext(0);
    world.roomMode = "playing";
    const actor = world.players[0], acknowledgment = world.acknowledgments[0];
    if (!actor || !acknowledgment) throw new Error("Missing actor");
    const initial = {
      runEpoch: 1,
      connectionEpoch: 1,
      snapshotId: world.snapshotId,
      tick: 0,
      actor,
      acknowledgment
    };
    const step = (a, c, tick2) => stepNetworkController(a, c, tick2).actor;
    const prediction = new ControllerPrediction(initial, step, mappingForSnapshot(world, 1));
    const commands = [
      { sequence: 1, clientTick: 0, controlEpoch: 1, held: Held.Right, aim: 0, edges: [] },
      {
        sequence: 2,
        clientTick: 1,
        controlEpoch: 1,
        held: 0,
        aim: 0,
        edges: [{ kind: Edge.Jump, id: 1 }]
      },
      { sequence: 3, clientTick: 2, controlEpoch: 1, held: Held.Down, aim: 0, edges: [] }
    ];
    for (const command2 of commands) prediction.submit(command2);
    const stream = new InputStream({ ...context2, controlEpoch: 1, baselineServerTick: 0 });
    const receive = (commands2, packetSequence, now, tick2) => stream.receive(
      encodeInputBatch({ ...context2, packetSequence, snapshotAck: 0, eventAck: 0, commands: commands2 }),
      now,
      tick2
    );
    receive(commands.slice(0, 1), 1, 0, 0);
    const applied = [];
    for (let tick2 = 1; tick2 <= 3; tick2++) {
      if (tick2 === 3) receive(commands.slice(1), 2, 34, 2);
      const result2 = stream.processTick(tick2, tick2 * 17, (input) => {
        const current = world.players[0];
        if (!current) throw new Error("Missing actor");
        const result3 = stepNetworkController(current, input.command, tick2);
        world.players[0] = result3.actor;
        return result3.edges;
      });
      world.acknowledgments[0] = result2.acknowledgment;
      world.tick = tick2;
      applied.push({
        tick: tick2,
        sequence: result2.input.submittedCommand?.sequence ?? 0,
        repeated: result2.input.repeatedHeld
      });
    }
    world.snapshotId++;
    world.stateHash = roomWorkloadHash(world);
    const snapshot = decodeSnapshot(encodeSnapshot(world, context2), context2);
    const restored = snapshot.players[0], ack = snapshot.acknowledgments[0], pending = commands[2];
    if (!restored || !ack || !pending) throw new Error("Missing snapshot data");
    const mapping = decodeInputMapping(JSON.stringify(mappingForSnapshot(snapshot, 1)));
    const result = prediction.reconcile(
      {
        ...initial,
        tick: snapshot.tick,
        snapshotId: snapshot.snapshotId,
        actor: restored,
        acknowledgment: ack
      },
      mapping
    );
    const expected = step(restored, pending, 4);
    if (stateHash(prediction.actor) !== stateHash(expected))
      throw new Error("Remapped replay diverged");
    return {
      applied,
      mapping,
      replayed: result.replayed,
      predictedTick: prediction.tick,
      edgeCursor: prediction.actor.processedEdgeIds[0],
      traceHash: stateHash({ applied, actor: prediction.actor, mapping })
    };
  }

  // test/fixtures/movement-proof.ts
  function movingCase(seed) {
    let rng = seed;
    const next = (range) => {
      rng = randomStep(rng);
      return rng % range;
    };
    const input = {
      rect: { x: 0, y: 0, w: 10, h: 10 },
      motion: { x: next(81) - 40, y: next(81) - 40 },
      supportId: null
    };
    const targets2 = Array.from({ length: 4 }, (_, index) => ({
      id: index + 1,
      rect: { x: next(101) - 50, y: next(101) - 50, w: next(20) + 1, h: next(20) + 1 },
      kind: "solid",
      delta: { x: next(81) - 40, y: next(81) - 40 }
    }));
    return { input, targets: targets2 };
  }
  function movingCasesProof() {
    const outcomes = Array.from({ length: 512 }, (_, index) => {
      const seed = index + 1;
      const { input, targets: targets2 } = movingCase(seed);
      const result = moveKinematic(input, targets2);
      if (result.status !== "complete" && result.status !== "crushed")
        throw new Error(`Moving case ${seed}: ${result.status}`);
      return { seed, result };
    });
    return {
      outcomes,
      complete: outcomes.filter(({ result }) => result.status === "complete").length,
      crushed: outcomes.filter(({ result }) => result.status === "crushed").length,
      traceHash: stateHash(outcomes)
    };
  }
  function movementProof(restoreAfterTick, cellPixels) {
    let body4 = {
      rect: { x: pixels(40), y: pixels(66), w: pixels(14), h: pixels(34) },
      motion: { x: 0, y: 0 },
      supportId: 1
    };
    const platform = {
      id: 1,
      rect: { x: 0, y: pixels(100), w: pixels(160), h: pixels(8) },
      delta: { x: 0, y: 0 },
      kind: "one-way"
    };
    const floor = {
      id: 2,
      rect: { x: pixels(-200), y: pixels(220), w: pixels(600), h: pixels(20) },
      delta: { x: 0, y: 0 },
      kind: "solid"
    };
    const fixed = cellPixels ? new CollisionGrid([floor], cellPixels) : void 0;
    const trace = [];
    const checkpoints = [];
    let contacts = 0;
    for (let tick2 = 1; tick2 <= 1200; tick2++) {
      const direction = Math.floor((tick2 - 1) / 60) % 2 === 0 ? 1 : -1;
      platform.delta = { x: pixels(direction), y: pixels(-direction) };
      body4.motion = {
        x: 0,
        y: tick2 === 240 ? pixels(-12) : Math.min(pixels(8), body4.motion.y + pixels(1))
      };
      const geometryRevision = tick2 < 900 ? 1 : 2;
      const terrain = geometryRevision === 1 ? [platform, floor] : [floor];
      const frame = { geometryRevision, tick: tick2 };
      const result = moveKinematic(
        body4,
        fixed ? new CollisionIndex(fixed, geometryRevision === 1 ? [platform] : [], frame) : terrain,
        { frame, ...tick2 >= 600 && tick2 <= 620 ? { ignoredOneWayId: 1 } : {} }
      );
      if (result.status !== "complete")
        throw new Error(`Movement proof tick ${tick2}: ${result.status}`);
      body4 = result;
      contacts += result.contacts.length;
      platform.rect = {
        ...platform.rect,
        x: platform.rect.x + platform.delta.x,
        y: platform.rect.y + platform.delta.y
      };
      trace.push({
        tick: tick2,
        bodyHash: stateHash(body4),
        geometryHash: stateHash({ geometryRevision, terrain })
      });
      if (tick2 % 60 === 0 || [239, 241, 599, 601, 899, 901].includes(tick2))
        checkpoints.push({
          tick: tick2,
          x: body4.rect.x,
          y: body4.rect.y,
          supportId: body4.supportId,
          geometryRevision
        });
      if (tick2 === restoreAfterTick) {
        body4 = JSON.parse(
          JSON.stringify({ rect: body4.rect, motion: body4.motion, supportId: body4.supportId })
        );
        platform.rect = JSON.parse(JSON.stringify(platform.rect));
      }
    }
    return { ticks: 1200, traceHash: stateHash(trace), contacts, checkpoints };
  }

  // test/fixtures/navigation-proof.ts
  function navigationProof() {
    const targets2 = [
      { id: 1, kind: "solid", rect: { x: -100, y: 0, w: 100, h: 10 }, delta: { x: 0, y: 0 } },
      { id: 2, kind: "solid", rect: { x: 0, y: 0, w: 100, h: 10 }, delta: { x: 0, y: 0 } },
      { id: 3, kind: "solid", rect: { x: 20, y: -40, w: 10, h: 40 }, delta: { x: 0, y: 0 } },
      { id: 4, kind: "one-way", rect: { x: -80, y: -20, w: 40, h: 4 }, delta: { x: 0, y: 0 } }
    ];
    const shape = { id: 1, rect: { x: -3, y: -18, w: 10, h: 18 } };
    const spans = new WalkSurface(targets2, shape, 1).spans;
    const reversed = new WalkSurface([...targets2].reverse(), shape, 1).spans;
    const removed = new WalkSurface(
      targets2.filter((target) => target.id !== 4),
      shape,
      2
    ).spans;
    return { spans, reversed, removed, traceHash: stateHash({ spans, reversed, removed }) };
  }

  // test/fixtures/ordnance-proof.ts
  var ORDNANCE_BOUNDARIES = [1, 4, 5, 49, 50, 55, 82, 83, 95];
  var DELAYED_ORDNANCE_BOUNDARIES = [6, 9, 10, 50, 76, 81, 82, 83, 100];
  function recordOrdnance(startTick = 1) {
    return recordCombatInputs(
      createCombatRuntime("ordnance"),
      120,
      (tick2) => ({
        held: 0,
        edges: tick2 === startTick || tick2 === startTick + 2 ? [Edge.Grenade] : []
      }),
      { duplicatePackets: true }
    );
  }
  async function ordnanceScenario(startTick) {
    const fixture = recordOrdnance(startTick), identity3 = await combatArchiveIdentity(), checkpoints = [];
    for (const tick2 of startTick === 1 ? ORDNANCE_BOUNDARIES : DELAYED_ORDNANCE_BOUNDARIES) {
      const original = fixture.states[tick2], accepted = fixture.states[tick2 + 15];
      if (!original || !accepted) throw new Error("Missing ordnance boundary");
      const raw = await encodeCombatCheckpoint(original, identity3), restored = await decodeCombatCheckpoint(raw, identity3);
      const segment = await encodeCombatJournalSegment(
        original,
        fixture.entries.slice(tick2, tick2 + 15),
        identity3
      );
      const resumed = await restoreCombatJournalSegment(restored, segment, identity3);
      const context2 = combatPeerContext(original.snapshot, 0), wire = encodeSnapshot(original.snapshot, context2);
      if (canonical(restored) !== canonical(original) || canonical(resumed) !== canonical(accepted) || canonical(decodeSnapshot(wire, context2)) !== canonical(original.snapshot))
        throw new Error("Ordnance continuation diverged");
      checkpoints.push({
        tick: tick2,
        snapshotBytes: wire.length,
        checkpointBytes: new TextEncoder().encode(raw).byteLength,
        platforms: original.snapshot.platforms,
        grenades: original.combat.grenades,
        hash: combatRuntimeHash(original),
        resumedHash: combatRuntimeHash(resumed),
        resumedTick: resumed.combat.tick
      });
    }
    const events = fixture.states.flatMap(
      (state) => state.combat.events.map((event) => ({ tick: state.combat.tick, ...event }))
    );
    if (events.filter((event) => event.kind === "throw").length !== 4 || events.filter((event) => event.kind === "explosion").length !== 0 || events.filter((event) => event.kind === "impact" && event.impact?.definitionId === 5).length !== 4 || fixture.state.combat.players.some((player2) => player2.grenadeStock !== 9 || player2.lives !== 3))
      throw new Error("Ordnance crush/debit outcome diverged");
    return {
      startTick,
      ticks: fixture.state.combat.tick,
      duplicates: fixture.duplicates,
      reconciliations: fixture.reconciliations,
      checkpoints,
      events,
      finalHash: combatRuntimeHash(fixture.state),
      traceHash: stateHash(fixture.states.map(combatRuntimeHash))
    };
  }
  async function ordnanceProof() {
    return { ...await ordnanceScenario(1), delayed: await ordnanceScenario(6) };
  }

  // test/fixtures/player-life-proof.ts
  function playerLifeProof() {
    let state = createCombatLab("range"), restored = structuredClone(state);
    const hashes = [], notices = [], checkpoints = [];
    for (let tick2 = 1; tick2 <= 900; tick2++) {
      const commands = [
        {
          held: Held.Right,
          jumpPressed: false,
          interactPressed: false,
          grenadePressed: false,
          firePressed: false
        }
      ];
      const result = advanceCombatLab(state, commands);
      const replay = advanceCombatLab(restored, commands);
      state = result.state;
      restored = replay.state;
      if (stateHash(state) !== stateHash(restored) || stateHash(result.lifeNotices) !== stateHash(replay.lifeNotices))
        throw new Error(`Player life replay mismatch at ${tick2}`);
      const player3 = state.players[0];
      if (!player3) throw new Error("Missing life proof player");
      if (result.lifeNotices.length || player3.life !== "alive" && tick2 - player3.lifeStartTick === 6) {
        restored = JSON.parse(JSON.stringify(restored));
        checkpoints.push({
          tick: tick2,
          life: player3.life,
          since: player3.lifeStartTick,
          lives: player3.lives
        });
      }
      notices.push(...result.lifeNotices);
      hashes.push(stateHash(state));
      if (player3.life === "spectating") break;
    }
    const player2 = state.players[0];
    if (player2?.life !== "spectating" || player2.lives !== 0 || notices.filter((notice2) => notice2.kind === "death").length !== 3)
      throw new Error("Three real falls did not consume exactly three lives");
    return {
      tick: state.tick,
      notices,
      checkpoints,
      player: player2,
      traceHash: stateHash(hashes),
      finalHash: stateHash(state)
    };
  }

  // src/shared/diagnostics/combat-recovery.ts
  function settleSeats(state, playerIds, advanceControl = true) {
    state.combat.beams = state.combat.beams.filter((beam) => !playerIds.includes(beam.ownerId));
    const before = structuredClone(state.combat), changes = /* @__PURE__ */ new Map();
    const frame = { tick: state.combat.tick, geometryRevision: state.snapshot.geometryRevision }, index = new CollisionIndex(
      new CollisionGrid(
        combatEndTerrain(state.combat.scenario, state.combat.tick, state.combat.props)
      ),
      [],
      frame
    );
    for (const player2 of state.combat.players) {
      if (!playerIds.includes(player2.playerId) || player2.vehicleId === null) continue;
      const tank = state.combat.tanks.find(
        (tank2) => tankOwner(tank2) === player2.playerId && tank2.body.id === player2.vehicleId
      );
      if (!tank) throw new Error("Combat vehicle handoff owner mismatch");
      releaseCombatTank(state.combat, tank, "disconnect", changes, [], index, frame);
    }
    if (advanceControl) commitCombatSeats(before, state.combat, changes);
    for (const ack of state.snapshot.acknowledgments) {
      const actor = state.combat.players.find((player2) => player2.playerId === ack.playerId);
      if (!actor) throw new Error("Missing settled seat acknowledgment");
      ack.controlEpoch = actor.controlEpoch;
    }
    state.snapshot = combatSnapshot(state.combat, state.snapshot, state.campaign);
  }
  function transitionCombatRuntime(current, kind) {
    const state = structuredClone(current);
    if (current.snapshot.roomMode === "expired" || current.snapshot.roomMode === "completed" && kind !== "expire")
      throw new Error("Terminal combat room cannot resume");
    if (kind === "continue") {
      if (current.snapshot.roomMode !== "intermission" || current.pausedFrom !== null)
        throw new Error("Continue requires a confirmed wipe boundary");
      settleSeats(
        state,
        state.combat.players.map((player2) => player2.playerId),
        false
      );
      const reset = continueCombatCheckpoint(state.combat, state.campaign, current.snapshot.runEpoch);
      state.combat = reset.combat;
      state.campaign = reset.campaign;
      state.snapshot = combatSnapshot(state.combat, state.snapshot, state.campaign);
      state.snapshot = renewControllerGenerations(state.snapshot);
      state.snapshot.roomMode = "loading";
      state.combat.players = structuredClone(state.snapshot.players);
      state.history = { ...createEventHistory(state.snapshot.runEpoch), tick: state.combat.tick };
      state.connectedPlayerIds = [];
      state.snapshot.baselineEventCursor = 0;
      state.snapshot.snapshotId = 1;
      state.snapshot.connectionEpoch = state.snapshot.acknowledgments[0]?.connectionEpoch ?? 0;
      state.snapshot = combatSnapshot(state.combat, state.snapshot, state.campaign);
    } else if (kind === "pause" || kind === "expire") {
      if (kind === "pause" ? !isPausableRoom(current.snapshot.roomMode) : ![
        "lobby",
        "loading",
        "playing",
        "intermission",
        "paused-empty",
        "recovering",
        "completed"
      ].includes(current.snapshot.roomMode))
        throw new Error("Invalid empty combat boundary");
      settleSeats(
        state,
        state.combat.players.map((player2) => player2.playerId)
      );
      state.snapshot.roomMode = kind === "pause" ? "paused-empty" : "expired";
      state.pausedFrom = kind === "pause" && isPausableRoom(current.snapshot.roomMode) ? current.snapshot.roomMode : null;
      state.connectedPlayerIds = [];
    } else if (kind === "load") {
      if (!["lobby", "intermission"].includes(current.snapshot.roomMode))
        throw new Error("Load requires lobby or intermission");
      if (["wipe", "defeat"].includes(current.campaign.state.phase))
        throw new Error("A wiped campaign cannot load without a continue");
      state.snapshot.roomMode = "loading";
    } else if (kind === "start") {
      if (current.snapshot.roomMode !== "loading")
        throw new Error("Combat start requires loading barrier");
      state.snapshot.roomMode = "playing";
    } else {
      const origin = current.pausedFrom ?? current.snapshot.roomMode;
      settleSeats(
        state,
        state.combat.players.map((player2) => player2.playerId),
        false
      );
      state.snapshot = renewControllerGenerations(state.snapshot);
      if (origin === "lobby" || origin === "intermission") state.snapshot.roomMode = origin;
      state.pausedFrom = null;
      state.combat.players = structuredClone(state.snapshot.players);
      state.combat.events = [];
      state.connectedPlayerIds = [];
      state.history = { ...createEventHistory(state.snapshot.runEpoch), tick: state.combat.tick };
      state.snapshot.baselineEventCursor = 0;
      state.snapshot.snapshotId = 1;
      state.snapshot.connectionEpoch = state.snapshot.acknowledgments[0]?.connectionEpoch ?? 0;
      state.snapshot = combatSnapshot(state.combat, state.snapshot, state.campaign);
    }
    state.snapshot.stateHash = roomWorkloadHash(state.snapshot);
    return state;
  }

  // test/fixtures/player-life-recovery-proof.ts
  function recordPlayerLifeRecovery() {
    const { state, states, entries } = recordCombatInputs(createCombatRuntime(), 900);
    if (!state.combat.players.every((player2) => player2.life === "spectating" && player2.lives === 0))
      throw new Error("Missing exhausted party");
    const death = states.find((s) => s.combat.players[0]?.life === "death")?.combat.tick;
    const entry = states.find((s) => s.combat.players[0]?.life === "respawning")?.combat.tick;
    if (death === void 0 || entry === void 0)
      throw new Error("Missing death or entry boundary");
    return { states, entries, death, entry, finalTick: state.combat.tick };
  }
  async function playerLifeRecoveryProof() {
    const identity3 = await combatArchiveIdentity(), fixture = recordPlayerLifeRecovery();
    const checkpoints = [];
    for (const tick2 of [fixture.death + 6, fixture.entry + 6, fixture.finalTick]) {
      const captured = fixture.states[tick2], through = Math.min(tick2 + 15, fixture.finalTick);
      if (!captured) throw new Error("Missing life checkpoint");
      const raw = await encodeCombatCheckpoint(captured, identity3);
      let restored2 = await decodeCombatCheckpoint(raw, identity3);
      if (canonical(restored2) !== canonical(captured)) throw new Error("Life checkpoint mismatch");
      if (through > tick2) {
        const segment = await encodeCombatJournalSegment(
          captured,
          fixture.entries.slice(tick2, through),
          identity3
        );
        restored2 = await restoreCombatJournalSegment(restored2, segment, identity3);
      }
      if (canonical(restored2) !== canonical(fixture.states[through]))
        throw new Error("Life journal continuation mismatch");
      const baseline2 = decodeSnapshot(
        encodeSnapshot(restored2.snapshot, probeContext(0)),
        probeContext(0)
      );
      if (canonical(baseline2.players) !== canonical(restored2.combat.players))
        throw new Error("Life baseline lost state");
      checkpoints.push({
        tick: tick2,
        through,
        players: baseline2.players.map((p) => ({
          playerId: p.playerId,
          life: p.life,
          lifeStartTick: p.lifeStartTick,
          bodyPresence: p.bodyPresence,
          lives: p.lives,
          invulnerableTicks: p.invulnerableTicks,
          weapon: p.weapon
        })),
        bytes: new TextEncoder().encode(raw).byteLength,
        stateHash: combatRuntimeHash(restored2)
      });
    }
    const wipe = fixture.states.at(-1);
    if (wipe?.campaign.state.phase !== "wipe") throw new Error("Missing actual campaign wipe");
    const continued = transitionCombatRuntime(wipe, "continue");
    const reset = await decodeCombatCheckpoint(
      await encodeCombatCheckpoint(continued, identity3),
      identity3
    );
    if (canonical(reset) !== canonical(continued)) throw new Error("Continue checkpoint mismatch");
    const running = transitionCombatRuntime(reset, "start");
    const replay = recordCombatInputs(running, 15);
    const restored = await restoreCombatJournalSegment(
      running,
      await encodeCombatJournalSegment(running, replay.entries, identity3),
      identity3
    );
    if (canonical(restored) !== canonical(replay.state))
      throw new Error("Continued input journal mismatch");
    const context2 = controllerPeerContext(restored.snapshot, 0);
    const baseline = decodeSnapshot(encodeSnapshot(restored.snapshot, context2), context2);
    if (canonical(baseline.players) !== canonical(restored.combat.players))
      throw new Error("Continued baseline mismatch");
    return {
      deathTick: fixture.death,
      entryTick: fixture.entry,
      finalTick: fixture.finalTick,
      checkpoints,
      continue: {
        wipeTick: wipe.combat.tick,
        runEpoch: continued.snapshot.runEpoch,
        campaign: restored.campaign,
        checkpointHash: combatRuntimeHash(continued),
        restoredHash: combatRuntimeHash(restored),
        through: restored.combat.tick,
        reconciliations: replay.reconciliations,
        players: baseline.players.map(
          ({ playerId, life, lifeStartTick, lives, invulnerableTicks, weapon: weapon2 }) => ({
            playerId,
            life,
            lifeStartTick,
            lives,
            invulnerableTicks,
            weapon: weapon2
          })
        )
      },
      scope: "Four admitted input streams, life/continue baselines, journal replay and reconciled life transitions; diagnostic checkpoint reset, no authored campaign or enemy damage"
    };
  }

  // test/fixtures/prediction-proof.ts
  function predictionProof() {
    const world = createControllerWorkload();
    world.roomMode = "playing";
    const peers = world.players.map((actor, slot) => {
      const acknowledgment = world.acknowledgments[slot];
      if (!acknowledgment) throw new Error("Missing ack");
      return {
        slot,
        sequence: 0,
        packet: 0,
        snapshotAck: 0,
        stream: new InputStream({ ...probeContext(slot), controlEpoch: 1, baselineServerTick: 0 }),
        prediction: new ControllerPrediction(
          { runEpoch: 1, connectionEpoch: slot + 1, tick: 0, actor, acknowledgment },
          (a, c, t) => stepNetworkController(a, c, t).actor
        ),
        minY: actor.body.y,
        crouched: false
      };
    });
    const send = (peer, tick2) => {
      const commands = [];
      for (let i = 0; i < 3; i++) {
        const clientTick = peer.sequence, command2 = {
          sequence: ++peer.sequence,
          clientTick,
          controlEpoch: 1,
          held: clientTick < 10 ? Held.Right : clientTick >= 30 && clientTick < 40 ? Held.Left : clientTick >= 70 && clientTick < 80 ? Held.Down : 0,
          aim: 0,
          edges: clientTick === 6 + peer.slot * 3 ? [{ kind: Edge.Jump, id: 1 }] : []
        };
        peer.prediction.submit(command2);
        commands.push(command2);
      }
      peer.stream.receive(
        encodeInputBatch({
          runEpoch: 1,
          connectionEpoch: peer.slot + 1,
          packetSequence: ++peer.packet,
          snapshotAck: peer.snapshotAck,
          eventAck: 0,
          commands
        }),
        tick2 * 1e3 / 60,
        tick2
      );
    };
    for (const peer of peers) {
      send(peer, 0);
      send(peer, 0);
    }
    let traceHash = "00000000", bytes = 0, reconciliations = 0;
    for (let tick2 = 1; tick2 <= 180; tick2++) {
      for (const peer of peers) {
        const processed = peer.stream.processTick(tick2, tick2 * 1e3 / 60, (input) => {
          const actor2 = world.players[peer.slot];
          if (!actor2) throw new Error("Missing actor");
          const result = stepNetworkController(actor2, input.command, tick2);
          world.players[peer.slot] = result.actor;
          return result.edges;
        });
        world.acknowledgments[peer.slot] = processed.acknowledgment;
        const actor = world.players[peer.slot];
        if (!actor) throw new Error("Missing actor");
        actor.processedEdgeIds = [...processed.acknowledgment.processedEdgeIds];
        peer.minY = Math.min(peer.minY, actor.body.y);
        peer.crouched ||= actor.body.shapeId === 2;
      }
      world.tick = tick2;
      if (tick2 % 3 === 0) {
        world.stateHash = roomWorkloadHash(world);
        for (const peer of peers) {
          world.connectionEpoch = peer.slot + 1;
          world.snapshotId++;
          const encoded = encodeSnapshot(world, probeContext(peer.slot));
          bytes = encoded.byteLength;
          peer.stream.recordSent(world.snapshotId, 0);
          peer.snapshotAck = world.snapshotId;
          const decoded = decodeSnapshot(encoded, probeContext(peer.slot)), actor = decoded.players[peer.slot], acknowledgment = decoded.acknowledgments[peer.slot];
          if (!actor || !acknowledgment) throw new Error("Missing decoded player");
          const before = canonical(peer.prediction.actor);
          const result = peer.prediction.reconcile({
            runEpoch: 1,
            connectionEpoch: peer.slot + 1,
            tick: tick2,
            actor,
            acknowledgment
          });
          if (result.correction?.changed || canonical(peer.prediction.actor) !== before)
            throw new Error("Full controller replay divergence");
          reconciliations++;
          send(peer, tick2);
        }
      }
      traceHash = stateHash({ traceHash, tick: tick2, players: world.players, acks: world.acknowledgments });
    }
    if (peers.some((p) => p.minY >= 280 * 256 || !p.crouched))
      throw new Error("Missing jump/crouch behavior");
    return {
      ticks: world.tick,
      traceHash,
      bytes,
      reconciliations,
      players: world.players,
      coverage: peers.map((p) => ({
        slot: p.slot,
        minY: p.minY,
        crouched: p.crouched,
        pending: p.prediction.pending
      }))
    };
  }

  // test/fixtures/protocol-v3/snapshot-golden.json
  var snapshot_golden_default = [
    {
      name: "one-player",
      byteLength: 448,
      snapshot: {
        runEpoch: 1,
        connectionEpoch: 2,
        snapshotId: 3,
        tick: 120,
        baselineEventCursor: 4,
        geometryRevision: 7,
        stateHash: 305419896,
        roomMode: "playing",
        camera: {
          x: -512,
          y: 0
        },
        campaign: {
          ruleset: "classic",
          mission: 1,
          checkpointId: 1,
          continuesRemaining: 3,
          continuesUsed: 0,
          phase: "playing",
          encounterId: 2,
          remainingEnemies: 1
        },
        acknowledgments: [
          {
            playerId: 1,
            connectionEpoch: 2,
            controlEpoch: 2,
            lastProcessedSequence: 9,
            appliedAtServerTick: 118,
            processedEdgeIds: [1, 2, 3, 4, 5]
          }
        ],
        players: [
          {
            body: {
              id: 10,
              x: -256,
              y: 51200,
              vx: 768,
              vy: 0,
              remainderX: -1,
              remainderY: 2,
              shapeId: 1,
              supportId: 100,
              grounded: true,
              contacts: [
                {
                  otherId: 100,
                  normalX: 0,
                  normalY: -1,
                  toiNumerator: 0,
                  toiDenominator: 1,
                  kind: "solid"
                }
              ]
            },
            playerId: 1,
            slot: 0,
            controlEpoch: 2,
            life: "alive",
            locomotion: "grounded",
            action: {
              kind: "ready",
              actionInstanceId: 0,
              stateStartTick: 0,
              definitionId: 0,
              nextMarkerIndex: 0
            },
            facing: -1,
            aim: 1,
            jumpBufferTicks: 3,
            coyoteTicks: 4,
            ignoredSupportId: 101,
            ignoredSupportTicks: 2,
            invulnerableTicks: 100,
            reboardCooldownTicks: 22,
            vehicleSpecialTicks: 0,
            vehicleId: null,
            weapon: {
              id: "heavy-machine-gun",
              ammo: 149,
              cooldownTicks: 4,
              shotOrdinal: 9,
              lastActionInstanceId: 8
            },
            grenadeStock: 10,
            grenadeCooldownTicks: 3,
            meleeCooldownTicks: 2,
            geometryRevision: 7,
            health: 1,
            lives: 3,
            lastRallyMission: 0,
            processedEdgeIds: [1, 2, 3, 4, 5],
            lifeStartTick: 0,
            firearmAim: {
              pitch: 2,
              nextStepTick: 121
            },
            bodyPresence: "present"
          }
        ],
        vehicles: [],
        enemies: [],
        projectiles: [],
        platforms: [],
        threats: [],
        removedIds: [],
        combat: null
      },
      hex: "4546030c0200c001010000000200000003000000780000000400000007000000785634120100000000000000000000000200000000000000000000000000000000feffff000000000000000001000000010000000300000000000000000000000200000001000000010000000200000002000000090000007600000001000000020000000300000004000000050000000a00000000ffffff00c800000003000000000000ffffffff02000000010000006400000001000000010000006400000000000000ffffffff000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffff010000000200000079000000030000000400000065000000020000006400000016000000000000000000000001000000950000000400000009000000080000000a0000000300000002000000070000000100000003000000000000000100000002000000030000000400000005000000"
    },
    {
      name: "all-sections",
      byteLength: 988,
      snapshot: {
        runEpoch: 1,
        connectionEpoch: 2,
        snapshotId: 3,
        tick: 120,
        baselineEventCursor: 4,
        geometryRevision: 7,
        stateHash: 305419896,
        roomMode: "playing",
        camera: {
          x: -512,
          y: 0
        },
        campaign: {
          ruleset: "classic",
          mission: 1,
          checkpointId: 1,
          continuesRemaining: 3,
          continuesUsed: 0,
          phase: "playing",
          encounterId: 2,
          remainingEnemies: 1
        },
        acknowledgments: [
          {
            playerId: 1,
            connectionEpoch: 2,
            controlEpoch: 2,
            lastProcessedSequence: 9,
            appliedAtServerTick: 118,
            processedEdgeIds: [1, 2, 3, 4, 5]
          }
        ],
        players: [
          {
            body: {
              id: 10,
              x: -256,
              y: 51200,
              vx: 768,
              vy: 0,
              remainderX: -1,
              remainderY: 2,
              shapeId: 1,
              supportId: 100,
              grounded: true,
              contacts: [
                {
                  otherId: 100,
                  normalX: 0,
                  normalY: -1,
                  toiNumerator: 0,
                  toiDenominator: 1,
                  kind: "solid"
                }
              ]
            },
            playerId: 1,
            slot: 0,
            controlEpoch: 2,
            life: "alive",
            locomotion: "grounded",
            action: {
              kind: "ready",
              actionInstanceId: 0,
              stateStartTick: 0,
              definitionId: 0,
              nextMarkerIndex: 0
            },
            facing: -1,
            aim: 1,
            jumpBufferTicks: 3,
            coyoteTicks: 4,
            ignoredSupportId: 101,
            ignoredSupportTicks: 2,
            invulnerableTicks: 100,
            reboardCooldownTicks: 22,
            vehicleSpecialTicks: 0,
            vehicleId: null,
            weapon: {
              id: "heavy-machine-gun",
              ammo: 149,
              cooldownTicks: 4,
              shotOrdinal: 9,
              lastActionInstanceId: 8
            },
            grenadeStock: 10,
            grenadeCooldownTicks: 3,
            meleeCooldownTicks: 2,
            geometryRevision: 7,
            health: 1,
            lives: 3,
            lastRallyMission: 0,
            processedEdgeIds: [1, 2, 3, 4, 5],
            lifeStartTick: 0,
            firearmAim: {
              pitch: 2,
              nextStepTick: 121
            },
            bodyPresence: "present"
          }
        ],
        vehicles: [
          {
            body: {
              id: 20,
              x: 64e3,
              y: 51200,
              vx: 768,
              vy: 0,
              remainderX: 0,
              remainderY: 0,
              shapeId: 2,
              supportId: 100,
              grounded: true,
              contacts: [
                {
                  otherId: 100,
                  normalX: 0,
                  normalY: -1,
                  toiNumerator: 0,
                  toiDenominator: 1,
                  kind: "solid"
                }
              ]
            },
            definitionId: 1,
            kind: "tank",
            lifecycle: "available",
            occupantId: null,
            reservedBy: null,
            controlEpoch: 1,
            armor: 3,
            action: {
              kind: "ready",
              actionInstanceId: 0,
              stateStartTick: 0,
              definitionId: 0,
              nextMarkerIndex: 0
            },
            weapon: {
              id: "sidearm",
              ammo: 0,
              cooldownTicks: 0,
              shotOrdinal: 0,
              lastActionInstanceId: 0
            },
            components: [
              {
                id: 1,
                health: 3,
                broken: false
              },
              {
                id: 2,
                health: 0,
                broken: true
              }
            ],
            ownerControlEpoch: null,
            facing: 1,
            heading: 0,
            invulnerableTicks: 0
          }
        ],
        enemies: [
          {
            id: 30,
            definitionId: 1,
            x: 40960,
            y: 46080,
            vx: 0,
            vy: 0,
            shapeId: 3,
            facing: 1,
            health: 4,
            mode: 2,
            stateStartTick: 110,
            actionInstanceId: 99,
            actionDefinitionId: 1,
            modeTicks: 10,
            supportId: 100,
            geometryRevision: 7
          }
        ],
        projectiles: [
          {
            id: 40,
            ownerId: 10,
            actionInstanceId: 100,
            definitionId: 1,
            x: 65536,
            y: 25600,
            vx: 4096,
            vy: 0,
            spawnTick: 119,
            lifetimeTicks: 30,
            heading: 0,
            shapeId: 4
          }
        ],
        platforms: [
          {
            id: 50,
            x: 12800,
            y: 38400,
            vx: 64,
            vy: 0,
            shapeId: 2,
            trajectoryId: 1,
            trajectoryTick: 120
          }
        ],
        threats: [
          {
            actionInstanceId: 101,
            sourceId: 30,
            definitionId: 1,
            telegraphTick: 120,
            activeTick: 153,
            endTick: 213,
            x: 40960,
            y: 46080,
            vx: 0,
            vy: 0,
            heading: 64,
            targetId: 10,
            motion: "locked",
            cancelled: false,
            stateVersion: 1,
            shapeId: 4
          }
        ],
        removedIds: [60, 61],
        combat: null
      },
      hex: "4546030c0200dc03010000000200000003000000780000000400000007000000785634120101010001000100010002000200000000000000000000000000000000feffff000000000000000001000000010000000300000000000000000000000200000001000000010000000200000002000000090000007600000001000000020000000300000004000000050000000a00000000ffffff00c800000003000000000000ffffffff02000000010000006400000001000000010000006400000000000000ffffffff000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000002000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffff010000000200000079000000030000000400000065000000020000006400000016000000000000000000000001000000950000000400000009000000080000000a00000003000000020000000700000001000000030000000000000001000000020000000300000004000000050000001400000000fa000000c8000000030000000000000000000000000000020000006400000001000000010000006400000000000000ffffffff000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000001000000030000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000000010000000300000000000000020000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000001e0000000100000000a0000000b400000000000000000000030000000100000004000000020000006e00000063000000010000000a0000006400000007000000280000000a000000640000000100000000000100006400000010000000000000770000001e00000000000000040000003200000000320000009600004000000000000000020000000100000078000000650000001e000000010000007800000099000000d500000000a0000000b400000000000000000000400000000a000000010000000000000001000000040000003c0000003d000000"
    }
  ];

  // test/fixtures/rifle-proof.ts
  var recordRifleRecovery = () => recordCombatInputs(createCombatRuntime("rifle"), 180, 0);
  async function rifleRecoveryProof() {
    const { states, entries, state, reconciliations } = recordRifleRecovery();
    const identity3 = await combatArchiveIdentity();
    const firstDeath = states.find(
      (state2) => state2.combat.players.some((player2) => player2.life === "death")
    );
    if (!firstDeath) throw new Error("Rifle fixture did not reach hostile damage");
    const checkpoints = [];
    for (const tick2 of [
      12,
      28,
      37,
      firstDeath.combat.tick,
      firstDeath.combat.tick + 30,
      firstDeath.combat.tick + 42
    ]) {
      const original = states[tick2], accepted = states[tick2 + 15];
      if (!original || !accepted) throw new Error("Missing rifle checkpoint boundary");
      const raw = await encodeCombatCheckpoint(original, identity3);
      const restored = await decodeCombatCheckpoint(raw, identity3);
      if (canonical(original) !== canonical(restored)) throw new Error("Rifle checkpoint diverged");
      const segment = await encodeCombatJournalSegment(
        original,
        entries.slice(tick2, tick2 + 15),
        identity3
      );
      const resumed = await restoreCombatJournalSegment(restored, segment, identity3);
      if (canonical(resumed) !== canonical(accepted)) throw new Error("Rifle replay diverged");
      const context2 = combatPeerContext(resumed.snapshot, 0);
      if (canonical(decodeSnapshot(encodeSnapshot(resumed.snapshot, context2), context2)) !== canonical(resumed.snapshot))
        throw new Error("Rifle snapshot diverged");
      const eventContext = combatEventContext(context2);
      const batches = eventBatches(
        resumed.history,
        original.history.cursor,
        eventContext.connectionEpoch
      );
      if (!batches) throw new Error("Rifle checkpoint lost the event prefix");
      for (const batch of batches) {
        if (canonical(decodeEventBatch(encodeEventBatch(batch, eventContext), eventContext)) !== canonical(batch))
          throw new Error("Enemy event wire identity diverged");
      }
      checkpoints.push({
        tick: tick2,
        checkpointBytes: new TextEncoder().encode(raw).byteLength,
        markerCursors: restored.combat.targets.map((target) => target.rifle?.action.nextMarkerIndex),
        targets: restored.combat.targets.map((target) => target.rifle?.targetId),
        threats: restored.snapshot.threats.length,
        resumedTick: resumed.combat.tick,
        hash: combatRuntimeHash(resumed),
        players: restored.combat.players.map(({ life, lives, invulnerableTicks }) => ({
          life,
          lives,
          invulnerableTicks
        }))
      });
    }
    const firstBurst = states.slice(0, 73).filter(
      (state2) => state2.combat.events.some((event) => event.ownerId === 20 && event.kind === "shot")
    ).map((state2) => state2.combat.tick);
    if (canonical(firstBurst) !== canonical([25, 31, 37]))
      throw new Error("Authored rifle release changed");
    return {
      ticks: state.combat.tick,
      reconciliations,
      firstBurst,
      remainingFirstBurst: firstBurst.filter((tick2) => tick2 > 28),
      firstDeathTick: firstDeath.combat.tick,
      checkpoints,
      stateHash: combatRuntimeHash(state),
      traceHash: stateHash(states.map(combatRuntimeHash)),
      scope: "Engineering rifle scenario; server hit outcomes correct movement prediction, no client prediction of hostile collisions or authored mission acceptance"
    };
  }

  // test/fixtures/rocket-combat-proof.ts
  var ROCKET_COMBAT_BOUNDARIES = [
    0,
    7,
    8,
    10,
    13,
    31,
    32,
    33,
    40,
    41,
    55,
    56,
    120,
    121,
    144,
    145
  ];
  function recordRocketCombat() {
    return recordCombatInputs(
      createCombatRuntime("rocket"),
      160,
      (tick2) => ({
        held: tick2 >= 31 && tick2 <= 55 ? Held.Fire : 0,
        edges: tick2 === 1 ? [Edge.Jump] : tick2 === 7 || tick2 === 31 ? [Edge.FireOnset] : []
      }),
      { duplicatePackets: true }
    );
  }
  async function rocketCombatProof() {
    const fixture = recordRocketCombat(), identity3 = await combatArchiveIdentity(), checkpoints = [];
    for (const tick2 of ROCKET_COMBAT_BOUNDARIES) {
      const original = fixture.states[tick2], accepted = fixture.states[tick2 + 15];
      if (!original || !accepted) throw new Error("Missing launcher continuation boundary");
      const raw = await encodeCombatCheckpoint(original, identity3);
      const restored = await decodeCombatCheckpoint(raw, identity3);
      const segment = await encodeCombatJournalSegment(
        original,
        fixture.entries.slice(tick2, tick2 + 15),
        identity3
      );
      const resumed = await restoreCombatJournalSegment(restored, segment, identity3);
      if (canonical(restored) !== canonical(original) || canonical(resumed) !== canonical(accepted))
        throw new Error("Launcher archive continuation diverged");
      const context2 = combatPeerContext(original.snapshot, 0), bytes = encodeSnapshot(original.snapshot, context2);
      if (canonical(decodeSnapshot(bytes, context2)) !== canonical(original.snapshot))
        throw new Error("Rocket flight snapshot diverged");
      checkpoints.push({
        tick: tick2,
        checkpointBytes: new TextEncoder().encode(raw).byteLength,
        snapshotBytes: bytes.byteLength,
        rockets: original.combat.rockets,
        hash: combatRuntimeHash(original),
        resumedTick: resumed.combat.tick,
        resumedHash: combatRuntimeHash(resumed)
      });
    }
    const events = fixture.states.flatMap(
      (state) => state.combat.events.filter((event) => ["shot", "explosion", "impact", "killed"].includes(event.kind)).map((event) => ({ tick: state.combat.tick, ...event }))
    );
    if (fixture.state.combat.players.some(
      (player2) => player2.lives !== 3 || player2.weapon.ammo !== 17 || player2.weapon.shotOrdinal !== 3
    ))
      throw new Error("Launcher charge/life accounting diverged");
    if (events.filter((event) => event.kind === "shot").length !== 12 || fixture.state.combat.rockets.length)
      throw new Error("Launcher release/terminal count diverged");
    if (!fixture.states.some(
      (state) => state.combat.rockets.some(
        (rocket2) => rocket2.heading !== rocket2.launchHeading && rocket2.targetId !== null
      )
    ))
      throw new Error("Launcher fixture did not exercise guided flight");
    return {
      ticks: 160,
      duplicates: fixture.duplicates,
      checkpoints,
      events,
      finalHash: combatRuntimeHash(fixture.state),
      traceHash: stateHash(fixture.states.map(combatRuntimeHash)),
      encounter: fixture.state.combat.encounter.phase,
      players: fixture.state.combat.players.map(({ weapon: weapon2, lives }) => ({ weapon: weapon2, lives })),
      scope: "Accepted four-player launcher input/ammo, visible flight and private lock/clocks through checkpoint and journal replay. Engineering content; SQLite and browser room execution are separate harnesses."
    };
  }

  // test/fixtures/rocket-proof.ts
  var source2 = {
    id: 1e3,
    ownerId: 1,
    team: 1,
    actionInstanceId: 7,
    definitionId: ROCKET_ATTACK.id
  };
  var body3 = (entityId, x, y = 0) => ({
    id: entityId * 10,
    entityId,
    team: 2,
    kind: "body",
    rect: { x: pixels(x - 4), y: pixels(y - 6), w: pixels(8), h: pixels(12) },
    delta: { x: 0, y: 0 }
  });
  var wall2 = (x) => ({
    id: 900,
    kind: "solid",
    rect: { x: pixels(x), y: -pixels(100), w: pixels(1), h: pixels(200) },
    delta: { x: 0, y: 0 }
  });
  var fast = {
    ...ROCKET_PROFILE,
    launchSpeed: pixels(32),
    maximumSpeed: pixels(32),
    blastRadius: pixels(16)
  };
  var cases2 = [
    {
      name: "crowded-impact",
      heading: 0,
      profile: fast,
      frame: () => ({
        terrain: [],
        hurtboxes: [body3(500, 14), ...Array.from({ length: 16 }, (_, i) => body3(20 + i, 8, 12))]
      })
    },
    { name: "lifetime", heading: 0, frame: () => ({ terrain: [], hurtboxes: [] }) },
    ...[0, 8, 16, 24].map((heading) => ({
      name: `guided-${heading}`,
      heading,
      frame: () => ({
        terrain: [],
        hurtboxes: [
          body3(
            20,
            heading === 0 ? 200 : heading === 8 ? -40 : heading === 16 ? -200 : 40,
            heading === 0 ? 40 : heading === 8 ? 200 : heading === 16 ? -40 : -200
          )
        ]
      })
    })),
    {
      name: "thin-wall",
      heading: 0,
      profile: fast,
      frame: () => ({ terrain: [wall2(10)], hurtboxes: [body3(20, 20)] })
    },
    {
      name: "moving-wall",
      heading: 0,
      profile: fast,
      frame: () => ({
        terrain: [{ ...wall2(19), delta: { x: -pixels(32), y: 0 } }],
        hurtboxes: [body3(20, 14), body3(21, 25)]
      })
    },
    {
      name: "moving-victims",
      heading: 0,
      profile: fast,
      frame: () => ({
        terrain: [],
        hurtboxes: [
          body3(20, 14),
          { ...body3(21, 10, 40), delta: { x: 0, y: -pixels(40) } },
          { ...body3(22, 10, 10), delta: { x: 0, y: pixels(40) } }
        ]
      })
    },
    {
      name: "crossing",
      heading: 0,
      profile: fast,
      frame: () => ({
        terrain: [],
        hurtboxes: [{ ...body3(20, 16, -20), delta: { x: 0, y: pixels(40) } }]
      })
    },
    {
      name: "shield",
      heading: 0,
      profile: fast,
      frame: () => ({
        terrain: [],
        hurtboxes: [body3(20, 20), { ...body3(20, 16), id: 201, kind: "shield" }]
      })
    },
    {
      name: "overlapping-hurtboxes",
      heading: 0,
      profile: fast,
      frame: () => ({
        terrain: [],
        hurtboxes: [body3(20, 14), { ...body3(20, 14), id: 201 }, body3(21, 20)]
      })
    },
    {
      name: "covered-lock",
      heading: 0,
      frame: (tick2) => ({
        terrain: tick2 < 3 ? [] : [wall2(100)],
        hurtboxes: tick2 < 3 ? [body3(20, 200)] : [body3(20, 200), body3(21, 60)]
      })
    },
    {
      name: "dead-lock",
      heading: 0,
      frame: (tick2) => ({ terrain: [], hurtboxes: tick2 < 3 ? [body3(20, 200)] : [body3(21, 60)] })
    }
  ];
  function run(study, restored, reverse = false) {
    const profile = study.profile ?? ROCKET_PROFILE, definition2 = {
      ...ROCKET_ATTACK,
      speed: profile.launchSpeed,
      lifetimeTicks: profile.lifetimeTicks
    };
    let rocket2 = restored ?? createRocket(source2, { x: 0, y: 0 }, study.heading, 1, profile);
    const steps = [], states = [rocket2];
    while (rocket2.tick - rocket2.spawnTick < profile.lifetimeTicks) {
      const { terrain, hurtboxes } = study.frame(rocket2.tick + 1);
      if (reverse) {
        terrain.reverse();
        hurtboxes.reverse();
      }
      const step = stepRocket(
        rocket2,
        rocket2.tick + 1,
        definition2,
        ROCKET_SHAPE,
        profile,
        terrain,
        hurtboxes
      );
      steps.push(step);
      if (step.status !== "active") return { steps, states, terminal: step };
      rocket2 = step.rocket;
      states.push(rocket2);
    }
    throw new Error("Rocket exceeded its lifetime");
  }
  function rocketProof() {
    return {
      scope: "Released rocket acceleration, guidance, collision and blast timing in a deterministic fixture; no launcher UI, room wiring, media or production claim.",
      cases: cases2.map((study) => {
        const result = run(study), traceHash = stateHash(result.steps);
        if (stateHash(run(study, void 0, true).steps) !== traceHash)
          throw new Error(`Rocket order dependence: ${study.name}`);
        const restoredTicks = [];
        for (const tick2 of [1, 2, 3, 4, 7, 8, 20, 50, 89]) {
          const state = result.states.find((state2) => state2.tick === tick2);
          if (!state) continue;
          const restored = JSON.parse(JSON.stringify(state));
          const replay = run(study, restored);
          if (stateHash(replay.steps) !== stateHash(result.steps.slice(tick2 - 1)))
            throw new Error(`Rocket continuation changed at ${study.name}:${tick2}`);
          restoredTicks.push(tick2);
        }
        const locks = result.states.filter((state, i, states) => i === 0 || state.targetId !== states[i - 1]?.targetId).map(({ tick: tick2, targetId }) => ({ tick: tick2, targetId }));
        return {
          name: study.name,
          ticks: result.steps.length,
          traceHash,
          restoredTicks,
          headings: [...new Set(result.states.map((state) => state.heading))],
          maximumSpeed: Math.max(...result.states.map((state) => state.speed)),
          locks,
          terminal: result.terminal
        };
      })
    };
  }

  // test/fixtures/route-proof.ts
  function routeProof() {
    const {
      actor: initial,
      definition: definition2,
      targets: targets2,
      surface,
      links,
      destination,
      route,
      follower
    } = routeFixture();
    const from = { x: initial.body.x, y: initial.body.y, facing: initial.facing };
    const reversed = new NavigationGraph(surface, definition2, [...links].reverse()).route(
      from,
      destination,
      1
    );
    let actor = initial;
    let cursor = follower.begin(actor, 0);
    let traceHash = "00000000";
    const checkpoints = [];
    let cancellation = null;
    for (let tick2 = 1; tick2 <= route.costTicks; tick2++) {
      if (!cursor) throw new Error("Early route arrival");
      const frame = { tick: tick2, geometryRevision: 1 };
      const index = new CollisionIndex(new CollisionGrid(targets2), [], frame);
      const result = follower.step(actor, cursor, index, frame);
      const restored = follower.step(
        JSON.parse(JSON.stringify(actor)),
        JSON.parse(JSON.stringify(cursor)),
        index,
        frame
      );
      if (stateHash(restored) !== stateHash(result)) throw new Error("Restored route diverged");
      if (result.status !== "active" && result.status !== "arrived")
        throw new Error("Route fixture failed");
      actor = result.actor;
      cursor = result.cursor;
      traceHash = stateHash({ traceHash, tick: tick2, actor, cursor, status: result.status });
      if ([1, 10, 52, 56, 107, 117].includes(tick2)) checkpoints.push({ tick: tick2, actor, cursor });
      if (tick2 === 10 && cursor) {
        const changed = { tick: 11, geometryRevision: 2 };
        cancellation = follower.step(
          actor,
          cursor,
          new CollisionIndex(
            new CollisionGrid(targets2.filter((target) => target.id !== 102)),
            [],
            changed
          ),
          changed
        );
      }
    }
    return { route, reversed, ticks: route.costTicks, traceHash, checkpoints, cancellation };
  }

  // test/fixtures/routed-enemy-proof.ts
  function routedEnemyProof() {
    return [false, true].map((remove) => {
      let state = createControllerLab("enemy-route");
      let traceHash = "00000000";
      const commands = [];
      const checkpoints = [];
      for (let tick2 = 0; tick2 < 150; tick2++) {
        const command2 = {
          held: 0,
          jumpPressed: tick2 === 0,
          startTraversal: false,
          removePlatform: remove && tick2 === 60
        };
        commands.push(command2);
        state = stepControllerLab(state, command2);
        if (state.stopped) throw new Error(`Routed enemy fixture stopped: ${state.stopped}`);
        traceHash = stateHash({ traceHash, state: labFingerprint(state) });
        if ([0, 59, 60, 116, 149].includes(tick2))
          checkpoints.push({
            tick: state.tick,
            enemy: state.navigatingEnemy,
            events: state.enemyNavigationEvents
          });
      }
      const finalState = labFingerprint(state);
      replayControllerLab({ format: 6, scenario: "enemy-route", commands, finalState });
      if (state.navigatingEnemy?.status !== (remove ? "unreachable" : "arrived") || state.navigatingEnemy.actor.body.supportId !== (remove ? 101 : 102))
        throw new Error("Wrong routed enemy outcome");
      return { remove, ticks: state.tick, traceHash, checkpoints, finalState };
    });
  }

  // test/fixtures/shield-proof.ts
  var SHIELD_BOUNDARIES = {
    bash: [18, 29, 30, 33, 48, 56, 57, 65],
    break: [34, 35, 53, 61, 62, 94, 95, 130, 131]
  };
  function recordShieldCombat(mode) {
    return recordCombatInputs(
      createCombatRuntime("guard"),
      180,
      (tick2) => mode === "bash" ? { held: tick2 <= 32 ? Held.Right : Held.Down } : {
        held: tick2 <= 5 ? Held.Down : tick2 <= 56 ? Held.Right : tick2 <= 131 ? Held.Down : tick2 <= 133 ? Held.Left | Held.Fire : tick2 < 146 ? Held.Down | Held.Fire : tick2 === 146 ? Held.Right | Held.Fire : Held.Down | Held.Fire,
        edges: tick2 === 1 ? [Edge.Grenade] : tick2 === 24 ? [Edge.Jump] : tick2 === 132 ? [Edge.FireOnset] : []
      },
      { duplicatePackets: true }
    );
  }
  async function shieldCombatProof() {
    const identity3 = await combatArchiveIdentity();
    const scenarios = [];
    for (const mode of ["bash", "break"]) {
      const fixture = recordShieldCombat(mode);
      const checkpoints = [];
      for (const tick2 of SHIELD_BOUNDARIES[mode]) {
        const original = fixture.states[tick2], accepted = fixture.states[tick2 + 15];
        if (!original || !accepted) throw new Error("Missing shield boundary");
        const raw = await encodeCombatCheckpoint(original, identity3);
        const restored = await decodeCombatCheckpoint(raw, identity3);
        if (canonical(restored) !== canonical(original))
          throw new Error("Shield checkpoint diverged");
        const segment = await encodeCombatJournalSegment(
          original,
          fixture.entries.slice(tick2, tick2 + 15),
          identity3
        );
        const resumed = await restoreCombatJournalSegment(restored, segment, identity3);
        if (canonical(resumed) !== canonical(accepted)) throw new Error("Shield replay diverged");
        const context2 = combatPeerContext(original.snapshot, 0);
        const bytes = encodeSnapshot(original.snapshot, context2);
        if (canonical(decodeSnapshot(bytes, context2)) !== canonical(original.snapshot))
          throw new Error("Shield snapshot diverged");
        const events2 = eventBatches(
          resumed.history,
          original.history.cursor,
          context2.connectionEpoch
        );
        if (!events2) throw new Error("Shield events lost prefix");
        const eventContext = combatEventContext(context2);
        for (const batch of events2)
          if (canonical(decodeEventBatch(encodeEventBatch(batch, eventContext), eventContext)) !== canonical(batch))
            throw new Error("Shield event wire diverged");
        checkpoints.push({
          tick: tick2,
          checkpointBytes: new TextEncoder().encode(raw).byteLength,
          snapshotBytes: bytes.byteLength,
          guard: original.combat.targets[0]?.guard,
          threats: original.snapshot.threats,
          hash: combatRuntimeHash(original),
          resumedTick: resumed.combat.tick,
          resumedHash: combatRuntimeHash(resumed)
        });
      }
      const events = fixture.states.flatMap(
        (state) => state.combat.events.filter((event) => ["melee", "killed", "shield-break", "explosion"].includes(event.kind)).map((event) => ({
          tick: state.combat.tick,
          kind: event.kind,
          ownerId: event.ownerId,
          targetId: event.targetId,
          actionInstanceId: event.actionInstanceId
        }))
      );
      if (mode === "bash" && (fixture.states[30]?.combat.targets[0]?.guard?.hitIds.length !== 3 || fixture.states[56]?.combat.targets[0]?.guard?.facing !== -1 || fixture.states[57]?.combat.targets[0]?.guard?.facing !== 1))
        throw new Error("Bash or committed turn evidence missing");
      if (mode === "break" && (events.filter((event) => event.kind === "shield-break").length !== 1 || fixture.states[95]?.combat.targets[0]?.health !== 1 || fixture.states[95]?.combat.targets[0]?.guard?.integrity !== 0 || fixture.states[95]?.combat.players.some((player2) => player2.lives !== 3)))
        throw new Error("Blast counterplay or evasion evidence missing");
      scenarios.push({
        mode,
        ticks: fixture.state.combat.tick,
        duplicates: fixture.duplicates,
        checkpoints,
        events,
        finalHash: combatRuntimeHash(fixture.state),
        traceHash: stateHash(fixture.states.map(combatRuntimeHash)),
        encounter: fixture.state.combat.encounter.phase
      });
    }
    return {
      scenarios,
      scope: "Admitted four-player engineering shield/rifle encounter; committed turn, bash hit ledger, jump evasion, grenade guard break and fragile body; no authored mission or production timing acceptance"
    };
  }

  // test/fixtures/spatial-proof.ts
  var SPATIAL_FRAME = { geometryRevision: 1, tick: 1 };
  function spatialScene() {
    const fixed = Array.from({ length: 512 }, (_, index) => ({
      id: index + 1,
      rect: {
        x: pixels(index % 32 * 96),
        y: pixels(Math.floor(index / 32) * 96 + 64),
        w: pixels(64),
        h: pixels(16)
      },
      kind: index % 3 === 0 ? "one-way" : "solid",
      delta: { x: 0, y: 0 }
    }));
    const moving = Array.from({ length: 32 }, (_, index) => {
      const base = fixed[index * 13];
      if (!base) throw new Error("Missing spatial moving fixture");
      return {
        id: 1e3 + index,
        rect: {
          x: base.rect.x + pixels(80),
          y: base.rect.y - pixels(64),
          w: pixels(8),
          h: pixels(80)
        },
        kind: "solid",
        delta: { x: pixels(index % 2 === 0 ? -64 : 16), y: 0 }
      };
    });
    const bodies = Array.from({ length: 64 }, (_, index) => {
      const base = fixed[index * 7];
      if (!base) throw new Error("Missing spatial actor fixture");
      return {
        rect: {
          x: base.rect.x + pixels(8),
          y: base.rect.y - pixels(34),
          w: pixels(14),
          h: pixels(34)
        },
        motion: { x: pixels(index % 2 === 0 ? 3 : -3), y: 55 },
        supportId: base.id
      };
    });
    return { fixed, moving, bodies };
  }
  function spatialProof() {
    const scene = spatialScene();
    const reference = scene.bodies.map(
      (body4) => moveKinematic(body4, [...scene.fixed, ...scene.moving])
    );
    if (reference.some((result) => result.status !== "complete"))
      throw new Error("Spatial fixture did not complete");
    const cells = [32, 64].map((cellPixels) => {
      const fixed = new CollisionGrid([...scene.fixed].reverse(), cellPixels);
      const index = new CollisionIndex(fixed, [...scene.moving].reverse(), SPATIAL_FRAME);
      const outcomes = scene.bodies.map(
        (body4) => moveKinematic(body4, index, { frame: SPATIAL_FRAME })
      );
      if (JSON.stringify(outcomes) !== JSON.stringify(reference))
        throw new Error(`Spatial result mismatch: ${cellPixels}`);
      return {
        cellPixels,
        staticGrid: fixed.statistics,
        dynamicGrid: index.dynamic.statistics,
        initialCandidates: scene.bodies.map(
          (body4) => index.query(sweepBounds(body4.rect, body4.motion)).length
        ),
        outcomes,
        traceHash: stateHash(outcomes)
      };
    });
    return {
      fixed: scene.fixed.length,
      moving: scene.moving.length,
      bodies: scene.bodies.length,
      referenceHash: stateHash(reference),
      cells
    };
  }

  // test/fixtures/support-proof.ts
  var SUPPORT_BOUNDARIES = [1, 11, 25, 34, 35, 36, 50, 58, 59, 60];
  var supportInput = (tick2) => ({
    held: 0,
    edges: tick2 === 1 || tick2 === 25 ? [Edge.FireOnset] : []
  });
  function recordSupport() {
    return recordCombatInputs(createCombatRuntime("support"), 120, supportInput, {
      duplicatePackets: true
    });
  }
  async function supportProof() {
    const fixture = recordSupport(), identity3 = await combatArchiveIdentity(), checkpoints = [];
    for (const tick2 of SUPPORT_BOUNDARIES) {
      const original = fixture.states[tick2], accepted = fixture.states[tick2 + 15];
      if (!original || !accepted) throw new Error("Missing support boundary");
      const raw = await encodeCombatCheckpoint(original, identity3);
      const restored = await decodeCombatCheckpoint(raw, identity3);
      const journal = await encodeCombatJournalSegment(
        original,
        fixture.entries.slice(tick2, tick2 + 15),
        identity3
      );
      const resumed = await restoreCombatJournalSegment(restored, journal, identity3);
      const context2 = combatPeerContext(original.snapshot, 0), wire = encodeSnapshot(original.snapshot, context2);
      if (canonical(restored) !== canonical(original) || canonical(resumed) !== canonical(accepted) || canonical(decodeSnapshot(wire, context2)) !== canonical(original.snapshot))
        throw new Error("Destructible support continuation diverged");
      checkpoints.push({
        tick: tick2,
        snapshotBytes: wire.length,
        checkpointBytes: new TextEncoder().encode(raw).byteLength,
        geometryRevision: original.snapshot.geometryRevision,
        props: original.combat.props,
        targets: original.combat.targets,
        encounter: original.combat.encounter,
        hash: combatRuntimeHash(original),
        resumedTick: resumed.combat.tick,
        resumedHash: combatRuntimeHash(resumed)
      });
    }
    const world = fixture.state.combat;
    if (world.props[0]?.destroyedTick !== 35 || world.encounter.phase !== "complete" || world.encounter.members.some(
      (member) => member.reason !== "out-of-bounds" || member.resolvedTick !== 59 || member.killerId !== null
    ) || world.encounter.kills.some((kill) => kill.count !== 0) || world.players.some((player2) => player2.weapon.shotOrdinal !== 2 || player2.lives !== 3))
      throw new Error("Support destruction or physical encounter outcome diverged");
    return {
      ticks: world.tick,
      duplicates: fixture.duplicates,
      reconciliations: fixture.reconciliations,
      checkpoints,
      props: world.props,
      encounter: world.encounter,
      players: world.players,
      events: fixture.states.flatMap(
        (state) => state.combat.events.map((event) => ({ tick: state.combat.tick, ...event }))
      ),
      finalHash: combatRuntimeHash(fixture.state),
      traceHash: stateHash(fixture.states.map(combatRuntimeHash))
    };
  }

  // test/fixtures/tank-proof.ts
  var TANK_BOUNDARIES = [1, 11, 12, 15, 21, 60, 90, 96, 97];
  var tankInput = (tick2) => ({
    held: (tick2 >= 13 && tick2 <= 26 ? Held.Right : 0) | (tick2 >= 15 && tick2 <= 21 ? Held.Up : 0) | (tick2 >= 60 && tick2 <= 74 ? Held.Fire : 0),
    edges: tick2 === 1 || tick2 === 90 ? [Edge.Interact] : tick2 === 15 ? [Edge.Jump] : tick2 === 60 ? [Edge.FireOnset] : []
  });
  function recordTankCombat(through = 120, input = tankInput) {
    let state = createCombatRuntime("tank");
    const states = [structuredClone(state)], entries = [];
    const streams = state.combat.players.map(
      (actor) => new InputStream({
        ...combatPeerContext(state.snapshot, actor.slot),
        controlEpoch: actor.controlEpoch,
        baselineServerTick: 0
      })
    );
    const cursors = streams.map(() => [0, 0, 0, 0, 0]);
    let duplicates = 0;
    for (let tick2 = 1; tick2 <= through; tick2++) {
      for (const [slot, stream] of streams.entries()) {
        const intent = input(tick2, slot, state), player2 = state.combat.players[slot], ids2 = cursors[slot];
        if (!player2 || !ids2) throw new Error("Missing tank command owner");
        const command2 = {
          sequence: tick2,
          clientTick: tick2 - 1,
          controlEpoch: intent.controlEpoch ?? player2.controlEpoch,
          held: intent.held,
          aim: 0,
          edges: (intent.edges ?? []).map((kind) => {
            const id2 = (ids2[kind - 1] ?? 0) + 1;
            ids2[kind - 1] = id2;
            return { kind, id: id2 };
          })
        };
        const packet = encodeInputBatch({
          ...combatPeerContext(state.snapshot, slot),
          packetSequence: tick2,
          snapshotAck: 0,
          eventAck: 0,
          commands: [command2]
        });
        stream.receive(packet, tick2 * 16, tick2 - 1);
        const duplicate = stream.receive(packet, tick2 * 16, tick2 - 1);
        if (!duplicate.duplicate || duplicate.admitted || duplicate.renewed)
          throw new Error("Tank duplicate changed admission");
        duplicates++;
      }
      let journal;
      const committed = InputStream.processWorldTick(streams, tick2, tick2 * 16, (prepared) => {
        const candidate = stageCombatRuntime(state, prepared);
        validateCombatCheckpoint(candidate.state);
        journal = candidate.journal;
        return candidate;
      });
      if (!journal) throw new Error("Missing tank input transaction");
      state = committed.state;
      entries.push(journal);
      states.push(structuredClone(state));
      if (state.snapshot.roomMode !== "playing") break;
    }
    return { states, entries, state, duplicates, streams };
  }
  async function tankCombatProof() {
    const fixture = recordTankCombat(), identity3 = await combatArchiveIdentity(), checkpoints = [];
    for (const tick2 of TANK_BOUNDARIES) {
      const original = fixture.states[tick2], accepted = fixture.states[tick2 + 15];
      if (!original || !accepted) throw new Error("Missing tank checkpoint boundary");
      const raw = await encodeCombatCheckpoint(original, identity3), restored = await decodeCombatCheckpoint(raw, identity3), segment = await encodeCombatJournalSegment(
        original,
        fixture.entries.slice(tick2, tick2 + 15),
        identity3
      ), resumed = await restoreCombatJournalSegment(restored, segment, identity3), context2 = combatPeerContext(original.snapshot, 0), bytes = encodeSnapshot(original.snapshot, context2);
      if (canonical(restored) !== canonical(original) || canonical(resumed) !== canonical(accepted) || canonical(decodeSnapshot(bytes, context2)) !== canonical(original.snapshot))
        throw new Error("Tank continuation diverged");
      checkpoints.push({
        tick: tick2,
        checkpointBytes: new TextEncoder().encode(raw).byteLength,
        snapshotBytes: bytes.byteLength,
        tanks: original.combat.tanks,
        hash: combatRuntimeHash(original),
        resumedTick: resumed.combat.tick,
        resumedHash: combatRuntimeHash(resumed)
      });
    }
    return {
      ticks: fixture.state.combat.tick,
      duplicates: fixture.duplicates,
      checkpoints,
      transfers: fixture.entries.flatMap(
        (entry) => entry.boundaryEvents.filter(({ event }) => event.kind === "seat").map(({ event }) => ({ tick: entry.tick, ...event }))
      ),
      encounter: fixture.state.combat.encounter.phase,
      finalHash: combatRuntimeHash(fixture.state),
      traceHash: stateHash(fixture.states.map(combatRuntimeHash))
    };
  }

  // test/fixtures/traversal-proof.ts
  function traversalProof() {
    const routes = ["jump", "drop"].map((kind) => {
      const { actor: source4, targets: targets3, link: link2 } = traversalFixture(kind);
      let actor2 = source4;
      let cursor2 = link2.begin(actor2, 100);
      const trace = [];
      for (let elapsed = 0; elapsed < link2.commands.length; elapsed++) {
        if (!cursor2) throw new Error("Premature traversal completion");
        const frame2 = { tick: 101 + elapsed, geometryRevision: 1 };
        const index = new CollisionIndex(new CollisionGrid(targets3), [], frame2);
        const result = link2.step(actor2, cursor2, index, frame2);
        const restored = link2.step(
          JSON.parse(JSON.stringify(actor2)),
          JSON.parse(JSON.stringify(cursor2)),
          index,
          frame2
        );
        if (stateHash(result) !== stateHash(restored)) throw new Error("Restored traversal diverged");
        if (result.status !== "active" && result.status !== "landed")
          throw new Error("Traversal failed");
        actor2 = result.actor;
        cursor2 = result.cursor;
        trace.push({ status: result.status, actor: actor2, cursor: cursor2, events: result.result.events });
      }
      return {
        kind,
        ticks: trace.length,
        poses: link2.poses,
        traceHash: stateHash(trace),
        finalActor: actor2
      };
    });
    const { actor: source3, targets: targets2, link } = traversalFixture("jump");
    let actor = source3;
    let cursor = link.begin(actor, 0);
    for (let tick2 = 1; tick2 <= 10; tick2++) {
      const frame2 = { tick: tick2, geometryRevision: 1 };
      const result = link.step(
        actor,
        cursor,
        new CollisionIndex(new CollisionGrid(targets2), [], frame2),
        frame2
      );
      if (result.status !== "active" || !result.cursor) throw new Error("Unexpected traversal state");
      actor = result.actor;
      cursor = result.cursor;
    }
    const frame = { tick: 11, geometryRevision: 2 };
    const cancellation = link.step(
      actor,
      cursor,
      new CollisionIndex(new CollisionGrid(targets2.filter((target) => target.id !== 101)), [], frame),
      frame
    );
    return { routes, cancellation, traceHash: stateHash({ routes, cancellation }) };
  }

  // test/fixtures/world-combat-proof.ts
  function worldCombatProof() {
    let state = createCombatWorkload();
    state.snapshot.roomMode = "playing";
    const streams = state.combat.players.map(
      (actor) => new InputStream({
        ...probeContext(actor.slot),
        controlEpoch: actor.controlEpoch,
        baselineServerTick: 0
      })
    );
    const hashes = [];
    for (let tick2 = 1; tick2 <= 120; tick2++) {
      for (const [slot, stream] of streams.entries()) {
        stream.receive(
          encodeInputBatch({
            ...probeContext(slot),
            packetSequence: tick2,
            snapshotAck: 0,
            eventAck: 0,
            commands: [
              {
                sequence: tick2,
                clientTick: tick2 - 1,
                controlEpoch: 1,
                held: Held.Fire,
                aim: 0,
                edges: tick2 === 1 ? [{ kind: Edge.FireOnset, id: 1 }] : []
              }
            ]
          }),
          tick2 * 16,
          tick2 - 1
        );
      }
      const transaction = InputStream.processWorldTick(streams, tick2, tick2 * 16, (prepared) => {
        const result = evaluateCombatTick(state.combat, state.snapshot, prepared);
        for (const actor of result.state.combat.players) {
          const context2 = probeContext(actor.slot);
          const snapshot = { ...result.state.snapshot, connectionEpoch: context2.connectionEpoch };
          if (stateHash(decodeSnapshot(encodeSnapshot(snapshot, context2), context2)) !== stateHash(snapshot))
            throw new Error("Combat snapshot mismatch");
        }
        return result;
      });
      state = transaction.state;
      if (transaction.processed.some(
        (result) => result.acknowledgment.appliedAtServerTick !== state.combat.tick
      ))
        throw new Error("Combat acknowledgment boundary mismatch");
      hashes.push(stateHash({ state, processed: transaction.processed }));
    }
    const before = stateHash(state), acks = streams.map((stream) => stream.acknowledgment);
    let failed = false;
    try {
      InputStream.processWorldTick(streams, 121, 1936, (prepared) => {
        evaluateCombatTick(state.combat, state.snapshot, prepared);
        throw new Error("Injected world publication rejection");
      });
    } catch {
      failed = true;
    }
    if (!failed || before !== stateHash(state) || stateHash(acks) !== stateHash(streams.map((stream) => stream.acknowledgment)) || streams.some((stream) => !stream.requiresResync))
      throw new Error("World abort was not isolated");
    return {
      ticks: state.combat.tick,
      phase: state.combat.encounter.phase,
      shots: state.combat.players.map((actor) => actor.weapon.shotOrdinal),
      kills: state.combat.encounter.kills,
      nextActionId: state.combat.nextActionId,
      abortAtTick: 121,
      traceHash: stateHash(hashes),
      finalHash: before
    };
  }

  // test/fixtures/contract-proof.ts
  async function contractProof() {
    const context2 = {
      runEpoch: 1,
      connectionEpoch: 2,
      playerId: 1,
      geometryRevision: 7,
      shapeIds: /* @__PURE__ */ new Set([1, 2, 3, 4])
    };
    const snapshots = snapshot_golden_default.map((golden) => {
      const bytes = encodeSnapshot(golden.snapshot, context2);
      const decoded = decodeSnapshot(bytes, context2);
      return {
        name: golden.name,
        hex: Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join(""),
        stateHash: stateHash(decoded)
      };
    });
    const stream = new InputStream({
      runEpoch: 1,
      connectionEpoch: 2,
      playerId: 1,
      controlEpoch: 2,
      baselineServerTick: 100
    });
    const command2 = {
      sequence: 1,
      clientTick: 0,
      controlEpoch: 2,
      held: Held.Right | Held.Fire,
      aim: 0,
      edges: [
        { kind: Edge.Jump, id: 1 },
        { kind: Edge.FireOnset, id: 1 }
      ]
    };
    const packet = encodeInputBatch({
      runEpoch: 1,
      connectionEpoch: 2,
      packetSequence: 1,
      snapshotAck: 0,
      eventAck: 0,
      commands: [command2]
    });
    const admitted = stream.receive(packet, 0, 100);
    const process = (input) => input.command.edges.map((edge) => ({
      ...edge,
      outcome: edge.kind === Edge.FireOnset ? "cooldown" : "applied"
    }));
    const trace = [stream.processTick(101, 16, process)];
    const duplicate = stream.receive(packet, 100, 101);
    trace.push(stream.processTick(102, 200, process), stream.processTick(103, 250, process));
    return {
      snapshots,
      admitted,
      duplicate,
      trace,
      collision: collisionProof(),
      combat: combatProof(),
      playerLife: playerLifeProof(),
      bodyPresence: deathBodyProof(),
      entryPhysics: entryPhysicsProof(),
      entryRecovery: await entryRecoveryProof(),
      airborneDeathRecovery: await airborneDeathRecoveryProof(),
      playerLifeRecovery: await playerLifeRecoveryProof(),
      campaign: campaignProof(),
      worldCombat: worldCombatProof(),
      combatRecovery: await combatRecoveryProof(),
      rifleRecovery: await rifleRecoveryProof(),
      footCombat: await footCombatProof(),
      shieldCombat: await shieldCombatProof(),
      areaCombat: await areaCombatProof(),
      tankCombat: await tankCombatProof(),
      ordnance: await ordnanceProof(),
      hmg: await hmgProof(),
      support: await supportProof(),
      rocket: rocketProof(),
      rocketCombat: await rocketCombatProof(),
      beam: beamProof(),
      laserCombat: await laserCombatProof(),
      combatReconnect: combatReconnectProof(),
      eventDelivery: eventDeliveryProof(),
      movement: movementProof(),
      controller: controllerProof(),
      grounded: groundedProof(),
      restoredGrounded: groundedProof(600),
      seams: seamProof(),
      navigation: navigationProof(),
      traversal: traversalProof(),
      route: routeProof(),
      compiledLevel: compiledLevelProof(),
      encounter: encounterProof(),
      prediction: predictionProof(),
      mappedPrediction: mappedPredictionProof(),
      inputCapture: inputCaptureProof(),
      inputFlow: [inputFlowProof(), inputFlowProof(720)],
      routedEnemy: routedEnemyProof(),
      controllerBoundaries: controllerBoundaryProof(),
      restoredController: controllerProof(599),
      spatial: spatialProof(),
      indexedMovement: [32, 64].map((cellPixels) => ({
        cellPixels,
        ...movementProof(void 0, cellPixels)
      })),
      movingCases: movingCasesProof(),
      restoredMovement: [239, 601, 899].map((tick2) => ({
        restoredAfterTick: tick2,
        ...movementProof(tick2)
      }))
    };
  }
  return __toCommonJS(contract_proof_exports);
})();
